#!/bin/bash

# NESA-Africa Backend Database Backup Script

set -e

# Configuration
BACKUP_DIR="./backups"
DATE=$(date +%Y%m%d_%H%M%S)
POSTGRES_USER="nesa_user"
POSTGRES_DB="nesa_africa"
RETENTION_DAYS=30

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "💾 NESA-Africa Database Backup"
echo "=============================="

# Create backup directory if it doesn't exist
mkdir -p $BACKUP_DIR

# Backup PostgreSQL
echo "📦 Backing up PostgreSQL database..."
docker-compose exec -T postgres pg_dump -U $POSTGRES_USER $POSTGRES_DB | gzip > $BACKUP_DIR/backup_$DATE.sql.gz

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Backup created: $BACKUP_DIR/backup_$DATE.sql.gz${NC}"
    
    # Get backup size
    SIZE=$(du -h $BACKUP_DIR/backup_$DATE.sql.gz | cut -f1)
    echo "📊 Backup size: $SIZE"
else
    echo -e "${RED}❌ Backup failed!${NC}"
    exit 1
fi

# Clean up old backups
echo ""
echo "🧹 Cleaning up old backups (older than $RETENTION_DAYS days)..."
find $BACKUP_DIR -name "backup_*.sql.gz" -mtime +$RETENTION_DAYS -delete
echo -e "${GREEN}✅ Cleanup complete${NC}"

# List recent backups
echo ""
echo "📋 Recent backups:"
ls -lh $BACKUP_DIR/backup_*.sql.gz | tail -5

echo ""
echo -e "${GREEN}✅ Backup process complete!${NC}"
