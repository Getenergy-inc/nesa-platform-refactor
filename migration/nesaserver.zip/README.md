# NESA-Africa Backend

A comprehensive backend system for the NESA-Africa platform built with a modular monolith architecture.

## 🏗️ Architecture

This backend follows a **modular monolith** approach, providing:

- **Single deployable unit** with well-separated business modules
- **Dual database setup**: PostgreSQL (Prisma) + MongoDB (Mongoose)
- **RESTful APIs** with comprehensive validation
- **JWT authentication** with role-based access control (RBAC)
- **File upload & storage** with cloud integration
- **Email service** for notifications and verification
- **Comprehensive logging** and error handling

## 📁 Project Structure

```
server/
├── src/
│   ├── modules/           # Business modules (self-contained)
│   │   ├── auth/         # Authentication & User Management
│   │   ├── nrc/          # NRC Volunteer System
│   │   ├── nominations/  # Nomination System
│   │   ├── judges/       # Judge Management
│   │   ├── voting/       # Voting System
│   │   ├── wallet/       # Wallet & AGC Integration
│   │   ├── chapters/     # Chapter Management
│   │   ├── files/        # File Upload & Storage
│   │   ├── notifications/ # Email & Notification Service
│   │   └── admin/        # Admin Dashboard
│   ├── shared/           # Shared utilities
│   │   ├── database/     # DB connections & models
│   │   ├── middleware/   # Common middleware
│   │   ├── utils/        # Helper functions
│   │   ├── types/        # TypeScript definitions
│   │   └── constants/    # Application constants
│   └── config/           # Configuration
├── prisma/               # Prisma schema & migrations
├── logs/                 # Application logs
└── dist/                 # Compiled JavaScript (production)
```

## 🚀 Getting Started

### Prerequisites

- Node.js 18+ 
- PostgreSQL 14+
- MongoDB 6+
- npm or yarn

### Installation

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Set up environment variables:**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

3. **Set up databases:**
   ```bash
   # Generate Prisma client
   npm run prisma:generate
   
   # Run database migrations
   npm run prisma:migrate
   ```

4. **Start development server:**
   ```bash
   npm run dev
   ```

## 🛠️ Available Scripts

- `npm run dev` - Start development server with hot reload
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm test` - Run tests
- `npm run test:watch` - Run tests in watch mode
- `npm run prisma:generate` - Generate Prisma client
- `npm run prisma:migrate` - Run database migrations
- `npm run prisma:studio` - Open Prisma Studio

## 🔧 Configuration

Key environment variables:

```env
# Server
NODE_ENV=development
PORT=5000

# Databases
DATABASE_URL="postgresql://..."
MONGODB_URI="mongodb://..."

# JWT
JWT_SECRET=your-secret-key

# Email (SendGrid)
SENDGRID_API_KEY=your-api-key

# File Upload (Cloudinary)
CLOUDINARY_CLOUD_NAME=your-cloud-name
CLOUDINARY_API_KEY=your-api-key
CLOUDINARY_API_SECRET=your-api-secret
```

## 📊 Database Schema

The system uses a dual database approach:

- **PostgreSQL**: Relational data (users, applications, nominations, etc.)
- **MongoDB**: Document storage (file metadata, logs, analytics)

## 🔐 Authentication & Authorization

- JWT-based authentication
- Role-based access control (RBAC)
- Email verification required
- Password hashing with bcrypt
- Rate limiting on auth endpoints

## 📝 API Documentation

Once running, visit:
- Health Check: `http://localhost:5000/health`
- API Base: `http://localhost:5000/api/v1`

## 🧪 Testing

```bash
# Run all tests
npm test

# Run tests in watch mode
npm run test:watch

# Run tests with coverage
npm test -- --coverage
```

## 🚀 Deployment

1. **Build the application:**
   ```bash
   npm run build
   ```

2. **Set production environment variables**

3. **Run database migrations:**
   ```bash
   npm run prisma:migrate
   ```

4. **Start the server:**
   ```bash
   npm start
   ```

## 📈 Monitoring & Logging

- Winston for structured logging
- Health check endpoint
- Error tracking and reporting
- Performance monitoring

## 🤝 Contributing

1. Follow the modular architecture
2. Write tests for new features
3. Use TypeScript strictly
4. Follow the existing code style
5. Update documentation

## 📄 License

MIT License - see LICENSE file for details.
