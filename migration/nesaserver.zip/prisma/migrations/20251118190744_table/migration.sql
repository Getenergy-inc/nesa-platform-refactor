/*
  Warnings:

  - You are about to drop the column `currencyEquivalentBalance` on the `wallets` table. All the data in the column will be lost.

*/
-- CreateEnum
CREATE TYPE "SettlementStatus" AS ENUM ('PENDING', 'APPROVED', 'PAID', 'REJECTED');

-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "WalletTransactionType" ADD VALUE 'PURCHASE_USER';
ALTER TYPE "WalletTransactionType" ADD VALUE 'PURCHASE_COMPANY';
ALTER TYPE "WalletTransactionType" ADD VALUE 'EARN';
ALTER TYPE "WalletTransactionType" ADD VALUE 'SPEND';
ALTER TYPE "WalletTransactionType" ADD VALUE 'TRANSFER';
ALTER TYPE "WalletTransactionType" ADD VALUE 'DONATION';
ALTER TYPE "WalletTransactionType" ADD VALUE 'ADMIN_ACTION';
ALTER TYPE "WalletTransactionType" ADD VALUE 'SETTLEMENT';
ALTER TYPE "WalletTransactionType" ADD VALUE 'REVERSAL';

-- DropIndex
DROP INDEX "votes_voterId_nominationId_key";

-- AlterTable
ALTER TABLE "wallets" DROP COLUMN "currencyEquivalentBalance",
ADD COLUMN     "balance" DOUBLE PRECISION NOT NULL DEFAULT 0,
ADD COLUMN     "reserved" DOUBLE PRECISION NOT NULL DEFAULT 0;

-- CreateTable
CREATE TABLE "provider_health" (
    "id" TEXT NOT NULL,
    "providerName" TEXT NOT NULL,
    "isEnabled" BOOLEAN NOT NULL DEFAULT true,
    "status" TEXT NOT NULL DEFAULT 'ACTIVE',
    "lastCheckedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "responseTime" DOUBLE PRECISION,
    "errorRate" DOUBLE PRECISION,
    "lastError" TEXT,
    "notes" TEXT,

    CONSTRAINT "provider_health_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "settlements" (
    "id" TEXT NOT NULL,
    "settlementDate" TIMESTAMP(3) NOT NULL,
    "chapterId" TEXT,
    "ambassadorId" TEXT,
    "amount" DOUBLE PRECISION NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'AGC',
    "paymentMethod" TEXT NOT NULL,
    "referenceId" TEXT,
    "status" "SettlementStatus" NOT NULL DEFAULT 'PENDING',
    "notes" TEXT,
    "approvedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "settlements_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "freeze_controls" (
    "id" TEXT NOT NULL,
    "freezeTransfers" BOOLEAN NOT NULL DEFAULT false,
    "freezeVoting" BOOLEAN NOT NULL DEFAULT false,
    "freezePurchases" BOOLEAN NOT NULL DEFAULT false,
    "reason" TEXT,
    "frozenBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "freeze_controls_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "provider_health_providerName_key" ON "provider_health"("providerName");

-- AddForeignKey
ALTER TABLE "settlements" ADD CONSTRAINT "settlements_chapterId_fkey" FOREIGN KEY ("chapterId") REFERENCES "chapters"("id") ON DELETE SET NULL ON UPDATE CASCADE;
