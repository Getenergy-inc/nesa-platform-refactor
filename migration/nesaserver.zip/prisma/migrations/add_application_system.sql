-- Migration: Add Application System
-- This migration adds the generic Application model to support the enhanced signup flow

-- Add new enum values to ApplicationStatus
ALTER TYPE "ApplicationStatus" ADD VALUE IF NOT EXISTS 'DRAFT';
ALTER TYPE "ApplicationStatus" ADD VALUE IF NOT EXISTS 'SUBMITTED';
ALTER TYPE "ApplicationStatus" ADD VALUE IF NOT EXISTS 'WITHDRAWN';

-- Create ApplicationType enum
DO $$ BEGIN
    CREATE TYPE "ApplicationType" AS ENUM ('JUDGE', 'NRC_VOLUNTEER', 'AMBASSADOR', 'CHAPTER_LEADER', 'VOLUNTEER');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Create applications table
CREATE TABLE IF NOT EXISTS "applications" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "applicationType" "ApplicationType" NOT NULL,
    "status" "ApplicationStatus" NOT NULL DEFAULT 'DRAFT',
    "personalInfo" JSONB NOT NULL,
    "professionalInfo" JSONB NOT NULL,
    "motivation" JSONB NOT NULL,
    "references" JSONB NOT NULL DEFAULT '[]',
    "documents" JSONB NOT NULL DEFAULT '[]',
    "submittedAt" TIMESTAMP(3),
    "reviewedAt" TIMESTAMP(3),
    "reviewedBy" TEXT,
    "reviewComments" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "applications_pkey" PRIMARY KEY ("id")
);

-- Create unique constraint for one application per type per user
CREATE UNIQUE INDEX IF NOT EXISTS "applications_userId_applicationType_key" ON "applications"("userId", "applicationType");

-- Add foreign key constraint
ALTER TABLE "applications" ADD CONSTRAINT "applications_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS "applications_userId_idx" ON "applications"("userId");
CREATE INDEX IF NOT EXISTS "applications_status_idx" ON "applications"("status");
CREATE INDEX IF NOT EXISTS "applications_applicationType_idx" ON "applications"("applicationType");
CREATE INDEX IF NOT EXISTS "applications_submittedAt_idx" ON "applications"("submittedAt");
CREATE INDEX IF NOT EXISTS "applications_reviewedBy_idx" ON "applications"("reviewedBy");

-- Add comments for documentation
COMMENT ON TABLE "applications" IS 'Generic application system for role-based applications (Judge, NRC Volunteer, Ambassador, etc.)';
COMMENT ON COLUMN "applications"."personalInfo" IS 'JSON object containing personal information: { fullName, email, phone, country, state, city }';
COMMENT ON COLUMN "applications"."professionalInfo" IS 'JSON object containing professional information: { currentPosition, organization, yearsOfExperience, educationLevel, fieldOfExpertise, linkedinProfile, resume }';
COMMENT ON COLUMN "applications"."motivation" IS 'JSON object containing motivation information: { whyApply, relevantExperience, timeCommitment, additionalInfo }';
COMMENT ON COLUMN "applications"."references" IS 'JSON array of references: [{ name, position, organization, email, phone }]';
COMMENT ON COLUMN "applications"."documents" IS 'JSON array of uploaded documents: [{ type, name, url }]';

-- Insert sample data for testing (optional)
-- INSERT INTO "applications" ("id", "userId", "applicationType", "status", "personalInfo", "professionalInfo", "motivation") 
-- VALUES (
--     'sample-app-1',
--     'sample-user-id',
--     'JUDGE',
--     'DRAFT',
--     '{"fullName": "John Doe", "email": "john@example.com", "phone": "+1234567890", "country": "Nigeria", "state": "Lagos"}',
--     '{"currentPosition": "Education Director", "organization": "Sample School", "yearsOfExperience": 10, "educationLevel": "Masters", "fieldOfExpertise": ["Education Leadership"]}',
--     '{"whyApply": "Passionate about education", "relevantExperience": "10 years in education", "timeCommitment": "10 hours per month"}'
-- );

-- Migration completed successfully
-- Run this migration with: psql -d your_database -f add_application_system.sql
