-- CreateEnum
CREATE TYPE "ApplicationType" AS ENUM ('JUDGE', 'NRC_VOLUNTEER', 'AMBASSADOR', 'CHAPTER_LEADER', 'VOLUNTEER');

-- CreateEnum
CREATE TYPE "NRCApplicationType" AS ENUM ('REGIONAL_VOLUNTEER', 'INTERNAL_STAFF', 'INTERNATIONAL_OBSERVER');

-- CreateEnum
CREATE TYPE "NRCVolunteerType" AS ENUM ('REGIONAL_VOLUNTEER', 'INTERNAL_STAFF', 'INTERNATIONAL_OBSERVER');

-- CreateEnum
CREATE TYPE "AchievementLevel" AS ENUM ('BRONZE', 'SILVER', 'GOLD', 'PLATINUM', 'DIAMOND');

-- CreateEnum
CREATE TYPE "VerificationStatus" AS ENUM ('PENDING', 'VERIFIED', 'REJECTED', 'IN_REVIEW');

-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "ApplicationStatus" ADD VALUE 'SUBMITTED';
ALTER TYPE "ApplicationStatus" ADD VALUE 'WITHDRAWN';

-- AlterTable
ALTER TABLE "nominee_profiles" ADD COLUMN     "approvedAt" TIMESTAMP(3),
ADD COLUMN     "qualityScore" DOUBLE PRECISION NOT NULL DEFAULT 0,
ADD COLUMN     "reviewNotes" TEXT,
ADD COLUMN     "reviewedBy" TEXT,
ADD COLUMN     "submittedAt" TIMESTAMP(3),
ADD COLUMN     "verificationStatus" "VerificationStatus" NOT NULL DEFAULT 'PENDING';

-- AlterTable
ALTER TABLE "nrc_applications" ADD COLUMN     "advisoryInterests" TEXT[],
ADD COLUMN     "africanEducationExperience" TEXT,
ADD COLUMN     "applicationType" "NRCApplicationType" NOT NULL DEFAULT 'REGIONAL_VOLUNTEER',
ADD COLUMN     "assignmentPreferences" TEXT[],
ADD COLUMN     "availabilityHours" INTEGER,
ADD COLUMN     "contentManagementExperience" BOOLEAN DEFAULT false,
ADD COLUMN     "contributionAreas" TEXT[],
ADD COLUMN     "dataVerificationSkills" TEXT,
ADD COLUMN     "department" TEXT,
ADD COLUMN     "devOpsExperience" BOOLEAN DEFAULT false,
ADD COLUMN     "digitalToolsProficiency" TEXT,
ADD COLUMN     "endorsementCapability" TEXT,
ADD COLUMN     "expertise" TEXT[],
ADD COLUMN     "expertiseProfile" TEXT,
ADD COLUMN     "institutionalAffiliations" TEXT[],
ADD COLUMN     "interviewExperience" TEXT,
ADD COLUMN     "languageSkills" TEXT[],
ADD COLUMN     "networkConnections" TEXT,
ADD COLUMN     "platformTestingExperience" TEXT,
ADD COLUMN     "projectExperience" TEXT,
ADD COLUMN     "publicationHistory" TEXT,
ADD COLUMN     "region" TEXT,
ADD COLUMN     "regionalKnowledge" TEXT[],
ADD COLUMN     "researchBackground" TEXT,
ADD COLUMN     "researchCapabilities" TEXT,
ADD COLUMN     "socialImpactKnowledge" TEXT,
ADD COLUMN     "subcategoryCommitment" INTEGER DEFAULT 3,
ADD COLUMN     "targetRegions" TEXT[],
ADD COLUMN     "validationCapabilities" TEXT;

-- AlterTable
ALTER TABLE "nrc_volunteers" ADD COLUMN     "achievementLevel" "AchievementLevel" NOT NULL DEFAULT 'BRONZE',
ADD COLUMN     "agcTokensEarned" DOUBLE PRECISION NOT NULL DEFAULT 0,
ADD COLUMN     "assignedCategories" TEXT[],
ADD COLUMN     "assignedRegions" TEXT[],
ADD COLUMN     "assignedSubcategories" TEXT[],
ADD COLUMN     "qualityScore" DOUBLE PRECISION NOT NULL DEFAULT 0,
ADD COLUMN     "region" TEXT,
ADD COLUMN     "volunteerType" "NRCVolunteerType" NOT NULL DEFAULT 'REGIONAL_VOLUNTEER',
ADD COLUMN     "weeklyTarget" INTEGER NOT NULL DEFAULT 50,
ALTER COLUMN "targetNominees" SET DEFAULT 200;

-- CreateTable
CREATE TABLE "applications" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "applicationType" "ApplicationType" NOT NULL,
    "status" "ApplicationStatus" NOT NULL DEFAULT 'DRAFT',
    "personalInfo" JSONB NOT NULL,
    "professionalInfo" JSONB NOT NULL,
    "motivation" JSONB NOT NULL,
    "references" JSONB NOT NULL DEFAULT '[]',
    "documents" JSONB NOT NULL DEFAULT '[]',
    "submittedAt" TIMESTAMP(3),
    "reviewedAt" TIMESTAMP(3),
    "reviewedBy" TEXT,
    "reviewComments" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "applications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "nrc_performance_metrics" (
    "id" TEXT NOT NULL,
    "volunteerId" TEXT NOT NULL,
    "weeklyUploads" INTEGER NOT NULL DEFAULT 0,
    "monthlyUploads" INTEGER NOT NULL DEFAULT 0,
    "totalUploads" INTEGER NOT NULL DEFAULT 0,
    "averageQuality" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "lastResetDate" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "nrc_performance_metrics_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "applications_userId_applicationType_key" ON "applications"("userId", "applicationType");

-- CreateIndex
CREATE UNIQUE INDEX "nrc_performance_metrics_volunteerId_key" ON "nrc_performance_metrics"("volunteerId");

-- AddForeignKey
ALTER TABLE "applications" ADD CONSTRAINT "applications_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "nrc_performance_metrics" ADD CONSTRAINT "nrc_performance_metrics_volunteerId_fkey" FOREIGN KEY ("volunteerId") REFERENCES "nrc_volunteers"("id") ON DELETE CASCADE ON UPDATE CASCADE;
