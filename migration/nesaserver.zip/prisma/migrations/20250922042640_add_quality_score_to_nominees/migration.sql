/*
  Warnings:

  - You are about to drop the column `advisoryInterests` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `africanEducationExperience` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `applicationType` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `assignmentPreferences` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `availabilityHours` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `contentManagementExperience` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `contributionAreas` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `dataVerificationSkills` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `department` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `devOpsExperience` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `digitalToolsProficiency` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `endorsementCapability` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `expertise` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `expertiseProfile` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `institutionalAffiliations` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `interviewExperience` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `languageSkills` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `networkConnections` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `platformTestingExperience` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `projectExperience` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `publicationHistory` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `region` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `regionalKnowledge` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `researchBackground` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `researchCapabilities` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `socialImpactKnowledge` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `subcategoryCommitment` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `targetRegions` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `validationCapabilities` on the `nrc_applications` table. All the data in the column will be lost.
  - You are about to drop the column `achievementLevel` on the `nrc_volunteers` table. All the data in the column will be lost.
  - You are about to drop the column `agcTokensEarned` on the `nrc_volunteers` table. All the data in the column will be lost.
  - You are about to drop the column `assignedCategories` on the `nrc_volunteers` table. All the data in the column will be lost.
  - You are about to drop the column `assignedRegions` on the `nrc_volunteers` table. All the data in the column will be lost.
  - You are about to drop the column `assignedSubcategories` on the `nrc_volunteers` table. All the data in the column will be lost.
  - You are about to drop the column `qualityScore` on the `nrc_volunteers` table. All the data in the column will be lost.
  - You are about to drop the column `region` on the `nrc_volunteers` table. All the data in the column will be lost.
  - You are about to drop the column `volunteerType` on the `nrc_volunteers` table. All the data in the column will be lost.
  - You are about to drop the column `weeklyTarget` on the `nrc_volunteers` table. All the data in the column will be lost.
  - You are about to drop the `nrc_performance_metrics` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "nrc_performance_metrics" DROP CONSTRAINT "nrc_performance_metrics_volunteerId_fkey";

-- AlterTable
ALTER TABLE "nominations" ADD COLUMN     "profileImageId" TEXT;

-- AlterTable
ALTER TABLE "nrc_applications" DROP COLUMN "advisoryInterests",
DROP COLUMN "africanEducationExperience",
DROP COLUMN "applicationType",
DROP COLUMN "assignmentPreferences",
DROP COLUMN "availabilityHours",
DROP COLUMN "contentManagementExperience",
DROP COLUMN "contributionAreas",
DROP COLUMN "dataVerificationSkills",
DROP COLUMN "department",
DROP COLUMN "devOpsExperience",
DROP COLUMN "digitalToolsProficiency",
DROP COLUMN "endorsementCapability",
DROP COLUMN "expertise",
DROP COLUMN "expertiseProfile",
DROP COLUMN "institutionalAffiliations",
DROP COLUMN "interviewExperience",
DROP COLUMN "languageSkills",
DROP COLUMN "networkConnections",
DROP COLUMN "platformTestingExperience",
DROP COLUMN "projectExperience",
DROP COLUMN "publicationHistory",
DROP COLUMN "region",
DROP COLUMN "regionalKnowledge",
DROP COLUMN "researchBackground",
DROP COLUMN "researchCapabilities",
DROP COLUMN "socialImpactKnowledge",
DROP COLUMN "subcategoryCommitment",
DROP COLUMN "targetRegions",
DROP COLUMN "validationCapabilities";

-- AlterTable
ALTER TABLE "nrc_volunteers" DROP COLUMN "achievementLevel",
DROP COLUMN "agcTokensEarned",
DROP COLUMN "assignedCategories",
DROP COLUMN "assignedRegions",
DROP COLUMN "assignedSubcategories",
DROP COLUMN "qualityScore",
DROP COLUMN "region",
DROP COLUMN "volunteerType",
DROP COLUMN "weeklyTarget",
ALTER COLUMN "targetNominees" SET DEFAULT 10;

-- DropTable
DROP TABLE "nrc_performance_metrics";

-- DropEnum
DROP TYPE "AchievementLevel";

-- DropEnum
DROP TYPE "NRCApplicationType";

-- DropEnum
DROP TYPE "NRCVolunteerType";
