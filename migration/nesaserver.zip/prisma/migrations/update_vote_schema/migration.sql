-- Remove unique constraint on votes table to allow multiple votes per nomination
-- This allows users to vote multiple times for the same nomination

-- Drop the existing unique constraint
ALTER TABLE "votes" DROP CONSTRAINT IF EXISTS "votes_voterId_nominationId_key";

-- Add indexes for better query performance
CREATE INDEX IF NOT EXISTS "votes_voterId_idx" ON "votes"("voterId");
CREATE INDEX IF NOT EXISTS "votes_nominationId_idx" ON "votes"("nominationId");
CREATE INDEX IF NOT EXISTS "votes_createdAt_idx" ON "votes"("createdAt");
