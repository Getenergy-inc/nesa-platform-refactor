import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  const email = process.env.SUPERADMIN_EMAIL;
  const password = process.env.SUPERADMIN_PASSWORD;
  const firstName = process.env.SUPER_ADMIN_FIRST_NAME || 'Super';
  const lastName = process.env.SUPER_ADMIN_LAST_NAME || 'Admin';

  if (!email || !password) {
    // eslint-disable-next-line no-console
    console.error('Missing SUPERADMIN_EMAIL or SUPERADMIN_PASSWORD');
    process.exit(1);
  }

  const existing = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
  if (existing) {
    // eslint-disable-next-line no-console
    console.log('Superadmin already exists');
    return;
  }

  const hashed = await bcrypt.hash(password, 12);

  await prisma.user.create({
    data: {
      email: email.toLowerCase(),
      password: hashed,
      role: 'SUPER_ADMIN',
      isVerified: true,
      firstName,
      lastName,
      fullName: `${firstName} ${lastName}`,
    }
  });

  // eslint-disable-next-line no-console
  console.log('Superadmin created:', email);
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    // eslint-disable-next-line no-console
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });