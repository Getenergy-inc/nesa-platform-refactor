#!/usr/bin/env node

/**
 * Backend Implementation Testing Script
 * Tests the newly implemented application system and enhanced signup flow
 */

const axios = require('axios');
const fs = require('fs');
const path = require('path');

const BASE_URL = 'http://localhost:3001';
const API_BASE = `${BASE_URL}/api/v1`;

// Test configuration
const TEST_CONFIG = {
  testUser: {
    email: 'test.backend@example.com',
    password: 'TestPassword123!',
    fullName: 'Backend Test User',
    country: 'Nigeria',
    state: 'Lagos',
    accountType: 'Individual',
    intents: ['Apply as Judge']
  }
};

let authToken = '';
let testUserId = '';
let testApplicationId = '';

// Utility functions
const log = (message, type = 'info') => {
  const timestamp = new Date().toISOString();
  const colors = {
    info: '\x1b[36m',    // Cyan
    success: '\x1b[32m', // Green
    error: '\x1b[31m',   // Red
    warning: '\x1b[33m', // Yellow
    reset: '\x1b[0m'     // Reset
  };
  
  console.log(`${colors[type]}[${timestamp}] ${message}${colors.reset}`);
};

const makeRequest = async (method, endpoint, data = null, headers = {}) => {
  try {
    const config = {
      method,
      url: `${API_BASE}${endpoint}`,
      headers: {
        'Content-Type': 'application/json',
        ...headers
      }
    };

    if (authToken) {
      config.headers.Authorization = `Bearer ${authToken}`;
    }

    if (data) {
      config.data = data;
    }

    const response = await axios(config);
    return { success: true, data: response.data, status: response.status };
  } catch (error) {
    return {
      success: false,
      error: error.response?.data || error.message,
      status: error.response?.status || 500
    };
  }
};

// Test functions
const testHealthCheck = async () => {
  log('Testing health check...', 'info');
  
  const result = await makeRequest('GET', '/health');
  if (result.success) {
    log('✅ Health check passed', 'success');
    return true;
  } else {
    log(`❌ Health check failed: ${result.error}`, 'error');
    return false;
  }
};

const testSignupFlow = async () => {
  log('Testing enhanced signup flow...', 'info');
  
  const result = await makeRequest('POST', '/auth/signup-flow', TEST_CONFIG.testUser);
  
  if (result.success && result.data.success) {
    log('✅ Signup flow successful', 'success');
    
    // Extract user data and tokens
    const { user, tokens, postSignupActions, dashboardRoute, nextSteps } = result.data.data;
    testUserId = user.id;
    authToken = tokens.accessToken;
    
    log(`   User ID: ${testUserId}`, 'info');
    log(`   Dashboard Route: ${dashboardRoute}`, 'info');
    log(`   Post-signup Actions: ${postSignupActions?.length || 0}`, 'info');
    log(`   Next Steps: ${nextSteps?.length || 0}`, 'info');
    
    return true;
  } else {
    log(`❌ Signup flow failed: ${result.error?.message || 'Unknown error'}`, 'error');
    return false;
  }
};

const testApplicationEndpoints = async () => {
  log('Testing application endpoints...', 'info');
  
  // Test 1: Get application requirements
  log('  Testing get requirements...', 'info');
  const reqResult = await makeRequest('GET', '/applications/requirements/JUDGE');
  if (reqResult.success) {
    log('  ✅ Get requirements successful', 'success');
  } else {
    log(`  ❌ Get requirements failed: ${reqResult.error}`, 'error');
    return false;
  }
  
  // Test 2: Check eligibility
  log('  Testing check eligibility...', 'info');
  const eligResult = await makeRequest('GET', `/applications/eligibility/JUDGE?userId=${testUserId}`);
  if (eligResult.success) {
    log('  ✅ Check eligibility successful', 'success');
  } else {
    log(`  ❌ Check eligibility failed: ${eligResult.error}`, 'error');
  }
  
  // Test 3: Submit application
  log('  Testing submit application...', 'info');
  const applicationData = {
    applicationType: 'JUDGE',
    personalInfo: {
      fullName: 'Backend Test User',
      email: 'test.backend@example.com',
      phone: '+2348012345678',
      country: 'Nigeria',
      state: 'Lagos'
    },
    professionalInfo: {
      currentPosition: 'Education Director',
      organization: 'Test School',
      yearsOfExperience: 10,
      educationLevel: 'Masters',
      fieldOfExpertise: ['Education Leadership', 'Policy Development']
    },
    motivation: {
      whyApply: 'Passionate about improving education standards',
      relevantExperience: '10 years in educational leadership',
      timeCommitment: '15 hours per month'
    }
  };
  
  const submitResult = await makeRequest('POST', '/applications/submit', applicationData);
  if (submitResult.success && submitResult.data.success) {
    log('  ✅ Submit application successful', 'success');
    testApplicationId = submitResult.data.data.application.id;
    log(`     Application ID: ${testApplicationId}`, 'info');
  } else {
    log(`  ❌ Submit application failed: ${submitResult.error?.message || 'Unknown error'}`, 'error');
    return false;
  }
  
  // Test 4: Get user applications
  log('  Testing get user applications...', 'info');
  const getUserAppsResult = await makeRequest('GET', `/applications/user/${testUserId}`);
  if (getUserAppsResult.success && getUserAppsResult.data.success) {
    log('  ✅ Get user applications successful', 'success');
    const apps = getUserAppsResult.data.data.applications;
    log(`     Found ${apps.length} application(s)`, 'info');
  } else {
    log(`  ❌ Get user applications failed: ${getUserAppsResult.error}`, 'error');
  }
  
  // Test 5: Get specific application
  if (testApplicationId) {
    log('  Testing get specific application...', 'info');
    const getAppResult = await makeRequest('GET', `/applications/${testApplicationId}`);
    if (getAppResult.success && getAppResult.data.success) {
      log('  ✅ Get specific application successful', 'success');
    } else {
      log(`  ❌ Get specific application failed: ${getAppResult.error}`, 'error');
    }
  }
  
  return true;
};

const testFileUpload = async () => {
  log('Testing file upload endpoints...', 'info');
  
  // Test 1: Get upload configuration
  log('  Testing get upload config...', 'info');
  const configResult = await makeRequest('GET', '/files/config/upload');
  if (configResult.success) {
    log('  ✅ Get upload config successful', 'success');
    const config = configResult.data.data;
    log(`     Max file size: ${config.maxFileSize} bytes`, 'info');
    log(`     Allowed types: ${config.allowedFileTypes.length}`, 'info');
  } else {
    log(`  ❌ Get upload config failed: ${configResult.error}`, 'error');
    return false;
  }
  
  // Test 2: File service health check
  log('  Testing file service health...', 'info');
  const healthResult = await makeRequest('GET', '/files/health');
  if (healthResult.success) {
    log('  ✅ File service health check successful', 'success');
  } else {
    log(`  ❌ File service health check failed: ${healthResult.error}`, 'error');
  }
  
  return true;
};

const testOTPFlow = async () => {
  log('Testing OTP verification flow...', 'info');
  
  // Test 1: Send verification OTP
  log('  Testing send verification OTP...', 'info');
  const sendResult = await makeRequest('POST', '/auth/otp/send-verify-email', {
    email: TEST_CONFIG.testUser.email
  });
  
  if (sendResult.success && sendResult.data.success) {
    log('  ✅ Send verification OTP successful', 'success');
  } else {
    log(`  ❌ Send verification OTP failed: ${sendResult.error?.message || 'Unknown error'}`, 'error');
  }
  
  return true;
};

// Main test runner
const runTests = async () => {
  log('🚀 Starting Backend Implementation Tests', 'info');
  log('==========================================', 'info');
  
  const tests = [
    { name: 'Health Check', fn: testHealthCheck },
    { name: 'Enhanced Signup Flow', fn: testSignupFlow },
    { name: 'Application Endpoints', fn: testApplicationEndpoints },
    { name: 'File Upload System', fn: testFileUpload },
    { name: 'OTP Verification', fn: testOTPFlow }
  ];
  
  const results = [];
  
  for (const test of tests) {
    log(`\n📋 Running: ${test.name}`, 'info');
    try {
      const result = await test.fn();
      results.push({ name: test.name, success: result });
      
      if (result) {
        log(`✅ ${test.name} completed successfully`, 'success');
      } else {
        log(`❌ ${test.name} failed`, 'error');
      }
    } catch (error) {
      log(`❌ ${test.name} threw error: ${error.message}`, 'error');
      results.push({ name: test.name, success: false, error: error.message });
    }
  }
  
  // Summary
  log('\n📊 Test Results Summary', 'info');
  log('========================', 'info');
  
  const passed = results.filter(r => r.success).length;
  const total = results.length;
  
  results.forEach(result => {
    const status = result.success ? '✅ PASS' : '❌ FAIL';
    log(`${status} ${result.name}`, result.success ? 'success' : 'error');
    if (result.error) {
      log(`    Error: ${result.error}`, 'error');
    }
  });
  
  log(`\n🎯 Overall: ${passed}/${total} tests passed (${Math.round(passed/total*100)}%)`, 
      passed === total ? 'success' : 'warning');
  
  if (passed === total) {
    log('🎉 All tests passed! Backend implementation is working correctly.', 'success');
  } else {
    log('⚠️  Some tests failed. Check the implementation and try again.', 'warning');
  }
  
  return passed === total;
};

// Run the tests
if (require.main === module) {
  runTests()
    .then(success => {
      process.exit(success ? 0 : 1);
    })
    .catch(error => {
      log(`💥 Test runner crashed: ${error.message}`, 'error');
      process.exit(1);
    });
}

module.exports = { runTests };
