/**
 * Queue System Test Script
 * 
 * Run this script to test the queue system:
 * npx ts-node test-queue-system.ts
 */

import { queueService } from './src/shared/queues';
import { config } from './src/config';

async function testQueueSystem() {
  console.log('🧪 Testing Queue System...\n');

  try {
    // Test 1: Send OTP
    console.log('1️⃣ Testing OTP Queue...');
    await queueService.sendOTP({
      email: 'test@example.com',
      otp: '123456',
      firstName: 'Test User',
      purpose: 'signup',
    });
    console.log('✅ OTP queued successfully\n');

    // Test 2: Send Email
    console.log('2️⃣ Testing Email Queue...');
    await queueService.sendEmail({
      to: 'test@example.com',
      subject: 'Test Email',
      html: '<h1>Test Email</h1>',
      text: 'Test Email',
    });
    console.log('✅ Email queued successfully\n');

    // Test 3: Payment Notification
    console.log('3️⃣ Testing Payment Queue...');
    await queueService.processPayment({
      type: 'payment-success',
      userId: 'test-user-123',
      email: 'test@example.com',
      amount: 50000,
      currency: 'NGN',
      reference: 'TEST-PAY-123',
    });
    console.log('✅ Payment notification queued successfully\n');

    // Test 4: Voting Notification
    console.log('4️⃣ Testing Voting Queue...');
    await queueService.processVoting({
      type: 'vote-cast',
      userId: 'test-user-123',
      email: 'test@example.com',
      nomineeId: 'test-nominee-456',
      nomineeName: 'Test Nominee',
      categoryId: 'test-cat-789',
      categoryName: 'Test Category',
    });
    console.log('✅ Voting notification queued successfully\n');

    // Test 5: Wallet Notification
    console.log('5️⃣ Testing Wallet Queue...');
    await queueService.processWallet({
      type: 'wallet-credited',
      userId: 'test-user-123',
      email: 'test@example.com',
      amount: 10000,
      currency: 'AGC',
      balance: 50000,
      reference: 'TEST-WALLET-123',
    });
    console.log('✅ Wallet notification queued successfully\n');

    // Test 6: Nomination Notification
    console.log('6️⃣ Testing Nomination Queue...');
    await queueService.processNomination({
      type: 'nomination-submitted',
      userId: 'test-user-123',
      email: 'test@example.com',
      nomineeName: 'Test Nominee',
      categoryName: 'Test Category',
    });
    console.log('✅ Nomination notification queued successfully\n');

    // Test 7: In-app Notification
    console.log('7️⃣ Testing Notification Queue...');
    await queueService.sendNotification({
      userId: 'test-user-123',
      type: 'general',
      title: 'Test Notification',
      message: 'This is a test notification',
    });
    console.log('✅ Notification queued successfully\n');

    // Wait a bit for jobs to process
    console.log('⏳ Waiting for jobs to process...\n');
    await new Promise(resolve => setTimeout(resolve, 5000));

    // Get queue statistics
    console.log('📊 Queue Statistics:');
    const stats = await queueService.getQueueStats();
    console.table(stats);

    console.log('\n✅ All tests completed!');
    console.log(`\n📊 View Bull Board Dashboard: http://localhost:${config.port}/admin/queues`);
    
  } catch (error) {
    console.error('❌ Test failed:', error);
    process.exit(1);
  }
}

// Run tests
testQueueSystem()
  .then(() => {
    console.log('\n✅ Queue system is working correctly!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ Queue system test failed:', error);
    process.exit(1);
  });
