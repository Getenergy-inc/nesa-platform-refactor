# NESA-Africa Backend - Docker Deployment Guide for Contabo

This guide will help you deploy the entire NESA-Africa backend application on Contabo using Docker containers.

## 📋 Prerequisites

- Contabo VPS with at least 4GB RAM and 2 CPU cores
- Ubuntu 20.04 or later (recommended)
- Root or sudo access
- Domain name pointed to your server IP (optional but recommended)

## 🚀 Quick Start

### 1. Install Docker and Docker Compose on Contabo

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Add your user to docker group (optional)
sudo usermod -aG docker $USER
newgrp docker

# Verify installation
docker --version
docker-compose --version
```

### 2. Clone Your Repository

```bash
# Clone your repository
git clone <your-repo-url> nesa-africa-backend
cd nesa-africa-backend
```

### 3. Configure Environment Variables

```bash
# Copy production environment template
cp .env.production .env

# Edit the .env file with your production values
nano .env
```

**IMPORTANT**: Update these critical values in `.env`:
- `POSTGRES_PASSWORD` - Strong database password
- `REDIS_PASSWORD` - Strong Redis password
- `JWT_SECRET` - Random 64-character string
- `JWT_REFRESH_SECRET` - Different random 64-character string
- `SESSION_SECRET` - Random string
- `SENDGRID_API_KEY` - Your SendGrid API key
- `CLOUDINARY_*` - Your Cloudinary credentials
- `PAYSTACK_*` - Your Paystack credentials
- `FRONTEND_URL` - Your frontend domain
- `CORS_ORIGINS` - Allowed origins
- `SUPERADMIN_PASSWORD` - Strong admin password

### 4. Build and Start Containers

```bash
# Build the application image
docker-compose build

# Start all services
docker-compose up -d

# Check if all containers are running
docker-compose ps

# View logs
docker-compose logs -f
```

### 5. Run Database Migrations

```bash
# Migrations run automatically on container start
# But you can run them manually if needed:


# Seed the database (optional)
docker-compose exec app npm run seed
```

## 🔧 Container Architecture

The deployment includes:

1. **PostgreSQL** (port 5432) - Primary database
2. **Redis** (port 6379) - Caching, sessions, and job queues
3. **App** (port 5000) - Node.js backend application
4. **Nginx** (ports 80/443) - Reverse proxy (optional, for production)

## 📊 Container Management

### Start/Stop Services

```bash
# Start all services
docker-compose up -d

# Stop all services
docker-compose down

# Restart a specific service
docker-compose restart app

# Stop and remove all containers, networks, and volumes
docker-compose down -v
```

### View Logs

```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f app
docker-compose logs -f postgres
docker-compose logs -f redis

# Last 100 lines
docker-compose logs --tail=100 app
```

### Execute Commands in Containers

```bash
# Access app container shell
docker-compose exec app sh

# Run Prisma commands
docker-compose exec app npx prisma studio
docker-compose exec app npx prisma migrate deploy

# Access PostgreSQL
docker-compose exec postgres psql -U nesa_user -d nesa_africa

# Access Redis CLI
docker-compose exec redis redis-cli -a your_redis_password
```

## 🔒 Production Setup with Nginx and SSL

### Enable Nginx Reverse Proxy

```bash
# Start with nginx profile
docker-compose --profile production up -d
```

### Setup SSL with Let's Encrypt

```bash
# Install certbot
sudo apt install certbot

# Get SSL certificate
sudo certbot certonly --standalone -d your-domain.com -d www.your-domain.com

# Copy certificates to nginx folder
sudo cp /etc/letsencrypt/live/your-domain.com/fullchain.pem nginx/ssl/
sudo cp /etc/letsencrypt/live/your-domain.com/privkey.pem nginx/ssl/

# Update nginx.conf to enable HTTPS (uncomment HTTPS server block)
nano nginx/nginx.conf

# Restart nginx
docker-compose restart nginx
```

### Auto-renew SSL Certificates

```bash
# Add to crontab
sudo crontab -e

# Add this line to renew certificates every 3 months
0 0 1 */3 * certbot renew --quiet && cp /etc/letsencrypt/live/your-domain.com/*.pem /path/to/nginx/ssl/ && docker-compose restart nginx
```

## 💾 Backup and Restore

### Backup Database

```bash
# Create backup directory
mkdir -p backups

# Backup PostgreSQL
docker-compose exec postgres pg_dump -U nesa_user nesa_africa > backups/backup_$(date +%Y%m%d_%H%M%S).sql

# Backup with docker-compose
docker-compose exec postgres pg_dump -U nesa_user nesa_africa | gzip > backups/backup_$(date +%Y%m%d_%H%M%S).sql.gz
```

### Restore Database

```bash
# Restore from backup
docker-compose exec -T postgres psql -U nesa_user -d nesa_africa < backups/backup_20240101_120000.sql

# Restore from gzipped backup
gunzip < backups/backup_20240101_120000.sql.gz | docker-compose exec -T postgres psql -U nesa_user -d nesa_africa
```

### Automated Backups

Create a backup script:

```bash
# Create backup script
nano backup.sh
```

Add this content:

```bash
#!/bin/bash
BACKUP_DIR="/root/nesa-africa-backend/backups"
DATE=$(date +%Y%m%d_%H%M%S)
cd /root/nesa-africa-backend
docker-compose exec -T postgres pg_dump -U nesa_user nesa_africa | gzip > $BACKUP_DIR/backup_$DATE.sql.gz
# Keep only last 30 days of backups
find $BACKUP_DIR -name "backup_*.sql.gz" -mtime +30 -delete
```

Make it executable and add to crontab:

```bash
chmod +x backup.sh
crontab -e
# Add: 0 2 * * * /root/nesa-africa-backend/backup.sh
```

## 🔍 Monitoring and Health Checks

### Check Container Health

```bash
# View container status
docker-compose ps

# Check health status
docker inspect --format='{{.State.Health.Status}}' nesa-app
docker inspect --format='{{.State.Health.Status}}' nesa-postgres
docker inspect --format='{{.State.Health.Status}}' nesa-redis
```

### Monitor Resource Usage

```bash
# Real-time stats
docker stats

# Specific container
docker stats nesa-app
```

### Application Health Endpoint

```bash
# Check if app is healthy
curl http://localhost:5000/health
```

## 🔄 Updates and Deployment

### Deploy New Version

```bash
# Pull latest code
git pull origin main

# Rebuild and restart
docker-compose build app
docker-compose up -d app

# Run migrations if needed
docker-compose exec app npx prisma migrate deploy
```

### Zero-Downtime Deployment (Advanced)

```bash
# Scale up new version
docker-compose up -d --scale app=2 --no-recreate

# Wait for health check
sleep 30

# Remove old container
docker-compose up -d --scale app=1
```

## 🛡️ Security Best Practices

1. **Change all default passwords** in `.env`
2. **Use strong, random secrets** for JWT and session
3. **Enable firewall** on Contabo:
   ```bash
   sudo ufw allow 22/tcp
   sudo ufw allow 80/tcp
   sudo ufw allow 443/tcp
   sudo ufw enable
   ```
4. **Regular updates**:
   ```bash
   sudo apt update && sudo apt upgrade -y
   docker-compose pull
   docker-compose up -d
   ```
5. **Limit SSH access** - Use SSH keys instead of passwords
6. **Enable SSL/TLS** for production
7. **Regular backups** - Automate database backups

## 🐛 Troubleshooting

### Container won't start

```bash
# Check logs
docker-compose logs app

# Check if ports are available
sudo netstat -tulpn | grep :5000

# Restart all services
docker-compose down && docker-compose up -d
```

### Database connection issues

```bash
# Check if postgres is healthy
docker-compose ps postgres

# Test connection
docker-compose exec app npx prisma db pull

# Check DATABASE_URL in .env
docker-compose exec app env | grep DATABASE_URL
```

### Out of disk space

```bash
# Check disk usage
df -h

# Clean up Docker
docker system prune -a --volumes

# Remove old images
docker image prune -a
```

### Performance issues

```bash
# Check resource usage
docker stats

# Increase container resources in docker-compose.yml:
# deploy:
#   resources:
#     limits:
#       cpus: '2'
#       memory: 2G
```

## 📞 Support

For issues or questions:
- Check logs: `docker-compose logs -f`
- Review documentation in `/docs` folder
- Contact: support@nesa-africa.com

## 🎯 Quick Commands Reference

```bash
# Start everything
docker-compose up -d

# Stop everything
docker-compose down

# View logs
docker-compose logs -f app

# Restart app
docker-compose restart app

# Run migrations
docker-compose exec app npx prisma migrate deploy

# Backup database
docker-compose exec postgres pg_dump -U nesa_user nesa_africa > backup.sql

# Access app shell
docker-compose exec app sh

# Check health
curl http://localhost:5000/health
```
