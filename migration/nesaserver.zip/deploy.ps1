# NESA-Africa Backend Deployment Script for Windows
# PowerShell script to deploy the application

Write-Host "🚀 NESA-Africa Backend Deployment Script" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

# Check if .env file exists
if (-not (Test-Path .env)) {
    Write-Host "❌ Error: .env file not found!" -ForegroundColor Red
    Write-Host "Please copy .env.production to .env and configure it:" -ForegroundColor Yellow
    Write-Host "  copy .env.production .env" -ForegroundColor Yellow
    Write-Host "  notepad .env" -ForegroundColor Yellow
    exit 1
}

# Check if Docker is running
try {
    docker ps | Out-Null
} catch {
    Write-Host "❌ Docker is not running!" -ForegroundColor Red
    Write-Host "Please start Docker Desktop first" -ForegroundColor Yellow
    exit 1
}

# Check if Docker Compose is available
try {
    docker-compose --version | Out-Null
} catch {
    Write-Host "❌ Docker Compose is not installed!" -ForegroundColor Red
    exit 1
}

Write-Host "📦 Building Docker images..." -ForegroundColor Yellow
docker-compose build

Write-Host ""
Write-Host "🔄 Starting containers..." -ForegroundColor Yellow
docker-compose up -d

Write-Host ""
Write-Host "⏳ Waiting for services to be healthy..." -ForegroundColor Yellow
Start-Sleep -Seconds 10

# Check container health
Write-Host ""
Write-Host "🔍 Checking container status..." -ForegroundColor Yellow
docker-compose ps

Write-Host ""
Write-Host "📊 Running database migrations..." -ForegroundColor Yellow
docker-compose exec -T app npx prisma migrate deploy

Write-Host ""
Write-Host "✅ Deployment complete!" -ForegroundColor Green
Write-Host ""
Write-Host "📝 Useful commands:" -ForegroundColor Cyan
Write-Host "  View logs:           docker-compose logs -f"
Write-Host "  Stop services:       docker-compose down"
Write-Host "  Restart app:         docker-compose restart app"
Write-Host "  Check health:        curl http://localhost:5000/health"
Write-Host ""
Write-Host "🌐 Application should be running at:" -ForegroundColor Cyan
Write-Host "  http://localhost:5000"
Write-Host ""
