import Redis from 'ioredis';
import { config } from './index';

// Create Redis client for general use
export const redisClient = new Redis(config.redis.url, {
  maxRetriesPerRequest: null,
  enableReadyCheck: false,
  retryStrategy: (times: number) => {
    const delay = Math.min(times * 50, 2000);
    return delay;
  },
});

// Create separate Redis client for Bull queues
export const bullRedisClient = new Redis(config.redis.url, {
  maxRetriesPerRequest: null,
  enableReadyCheck: false,
});

redisClient.on('connect', () => {
  console.log('✅ Redis client connected');
});

redisClient.on('error', (err) => {
  console.error('❌ Redis client error:', err);
});

bullRedisClient.on('connect', () => {
  console.log('✅ Bull Redis client connected');
});

bullRedisClient.on('error', (err) => {
  console.error('❌ Bull Redis client error:', err);
});

export default redisClient;
