import swaggerJsdoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';
import YAML from 'yamljs';
import path from 'path';
import { Application } from 'express';
import { config } from './index';

// Load the OpenAPI specification from YAML file
let swaggerDocument: any;
try {
  const yamlPath = path.join(__dirname, '../../swagger-auth-documentation.yaml');
  swaggerDocument = YAML.load(yamlPath);
} catch (error) {
  console.warn('⚠️ swagger-auth-documentation.yaml not found, using JSDoc only');
  swaggerDocument = null;
}

// Swagger JSDoc options (fallback if YAML file is not found)
const swaggerOptions: swaggerJsdoc.Options = {
  definition: {
    openapi: '3.0.3',
    info: {
      title: 'NESA-Africa Authentication API',
      version: '1.0.0',
      description: 'Comprehensive authentication system for NESA-Africa platform',
      contact: {
        name: 'NESA-Africa Development Team',
        email: 'dev@nesa-africa.com',
      },
      license: {
        name: 'MIT',
        url: 'https://opensource.org/licenses/MIT',
      },
    },
    servers: [
      {
        url: `http://localhost:${config.port}/api/${config.apiVersion}`,
        description: 'Development server',
      },
      {
        url: `https://api.nesa-africa.com/api/${config.apiVersion}`,
        description: 'Production server',
      },
    ],
    components: {
      securitySchemes: {
        BearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
        },
      },
    },
  },
  apis: [
    path.join(__dirname, '../modules/auth/routes/*.ts'),
    path.join(__dirname, '../shared/routes/*.ts'),
    path.join(__dirname, '../modules/*/routes/*.ts'),
    path.join(__dirname, '../modules/wallet/routes/*.ts'),
    path.join(__dirname, '../modules/wallet/controllers/*.ts'),
  ],
};

// Generate swagger specification
const swaggerSpec = swaggerJsdoc(swaggerOptions);

// Swagger UI options
const swaggerUiOptions: swaggerUi.SwaggerUiOptions = {
  customCss: `
    .swagger-ui .topbar { display: none; }
    .swagger-ui .info .title { color: #2c5aa0; }
    .swagger-ui .scheme-container { background: #fafafa; padding: 15px; }
  `,
  customSiteTitle: 'NESA-Africa API Documentation',
  customfavIcon: '/favicon.ico',
  swaggerOptions: {
    persistAuthorization: true,
    displayRequestDuration: true,
    filter: true,
    tryItOutEnabled: true,
    requestInterceptor: (req: any) => {
      // Add any request interceptors here
      return req;
    },
  },
};

/**
 * Setup Swagger documentation for the Express app
 * @param app Express application instance
 */
export const setupSwagger = (app: Application): void => {
  try {
    // Merge YAML document with JSDoc generated spec
    let finalSwaggerDoc: any;
    
    if (swaggerDocument && swaggerSpec) {
      // Merge both documents - JSDoc takes precedence for paths
      finalSwaggerDoc = {
        ...swaggerDocument,
        paths: {
          ...(swaggerDocument as any).paths,
          ...(swaggerSpec as any).paths,
        },
        components: {
          schemas: {
            ...(swaggerDocument as any).components?.schemas,
            ...(swaggerSpec as any).components?.schemas,
          },
          securitySchemes: {
            ...(swaggerDocument as any).components?.securitySchemes,
            ...(swaggerSpec as any).components?.securitySchemes,
          },
        },
        tags: [
          ...((swaggerDocument as any).tags || []),
          ...((swaggerSpec as any).tags || []),
        ],
      };
    } else {
      finalSwaggerDoc = swaggerDocument || swaggerSpec;
    }
    
    // Update server URLs dynamically
    if (finalSwaggerDoc.servers) {
      finalSwaggerDoc.servers = [
        {
          url: `http://localhost:${config.port}/api/${config.apiVersion}`,
          description: 'Development server',
        },
        {
          url: `https://api.nesa-africa.com/api/${config.apiVersion}`,
          description: 'Production server',
        },
      ];
    }

    // Serve swagger documentation at /api/docs
    app.use('/api/docs', swaggerUi.serve);
    app.get('/api/docs', swaggerUi.setup(finalSwaggerDoc, swaggerUiOptions));

    // Serve raw swagger JSON at /api/docs/json
    app.get('/api/docs/json', (_req, res) => {
      res.setHeader('Content-Type', 'application/json');
      res.send(finalSwaggerDoc);
    });

    // Serve raw swagger YAML at /api/docs/yaml
    app.get('/api/docs/yaml', (_req, res) => {
      res.setHeader('Content-Type', 'text/yaml');
      res.send(YAML.stringify(finalSwaggerDoc, 4));
    });

    console.log(`📚 Swagger documentation available at: http://localhost:${config.port}/api/docs`);
    console.log(`📄 Swagger JSON available at: http://localhost:${config.port}/api/docs/json`);
    console.log(`📄 Swagger YAML available at: http://localhost:${config.port}/api/docs/yaml`);
    
  } catch (error) {
    console.error('❌ Failed to setup Swagger documentation:', error);
    
    // Fallback: serve a simple documentation page
    app.get('/api/docs', (_req, res) => {
      res.send(`
        <html>
          <head>
            <title>NESA-Africa API Documentation</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 40px; }
              .error { color: #d32f2f; background: #ffebee; padding: 20px; border-radius: 4px; }
              .info { color: #1976d2; background: #e3f2fd; padding: 20px; border-radius: 4px; margin-top: 20px; }
            </style>
          </head>
          <body>
            <h1>NESA-Africa API Documentation</h1>
            <div class="error">
              <h3>Documentation Loading Error</h3>
              <p>There was an issue loading the Swagger documentation. Please check the server logs.</p>
              <p>Error: ${error instanceof Error ? error.message : 'Unknown error'}</p>
            </div>
            <div class="info">
              <h3>Alternative Access</h3>
              <p>You can access the API documentation files directly:</p>
              <ul>
                <li><a href="/api/docs/json">JSON Format</a></li>
                <li><a href="/api/docs/yaml">YAML Format</a></li>
              </ul>
              <p>Or import the Postman collection for testing:</p>
              <ul>
                <li>File: <code>NESA-Africa-Auth-Postman-Collection.json</code></li>
                <li>Location: <code>server/</code> directory</li>
              </ul>
            </div>
          </body>
        </html>
      `);
    });
  }
};

export { swaggerSpec, swaggerDocument };