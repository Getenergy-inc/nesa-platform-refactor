/**
 * Normalizes a phone number to a consistent format, primarily for Nigerian numbers.
 * This function converts various formats (e.g., `080...`, `+234...`) into a
 * standard E.164-like format without the leading `+` (e.g., `2348012345678`).
 *
 * @param phoneNumber The phone number string to normalize.
 * @returns The normalized phone number string.
 */
export function normalizePhoneNumber(phoneNumber: string): string {
  if (!phoneNumber) {
    return '';
  }

  // Remove all non-digit characters
  const digits = phoneNumber.replace(/\D/g, '');

  // Case 1: Nigerian number starting with '0' (e.g., 08012345678) -> 2348012345678
  if (digits.startsWith('0') && digits.length === 11) {
    return '234' + digits.substring(1);
  }

  // Case 2: Number already includes country code (e.g., 2348012345678)
  if (digits.startsWith('234') && digits.length === 13) {
    return digits;
  }

  // Fallback: return the digits as is for international or unknown formats
  return digits;
}