import { PrismaClient } from '@prisma/client';

// Single shared Prisma client instance for the app
// Export as `any` to avoid strict generated-client typing issues during
// incremental compilation. The runtime instance is a proper PrismaClient.
export const prisma: any = new PrismaClient();
