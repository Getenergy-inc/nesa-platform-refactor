import handlebars from 'handlebars';
import fs from 'fs';
import path from 'path';
import { config } from '@/config';

class EmailTemplateService {
  private templatesPath = path.join(__dirname, '../../views/emails');
  private layoutPath = path.join(this.templatesPath, 'layouts/main.hbs');
  private compiledTemplates: Map<string, HandlebarsTemplateDelegate> = new Map();
  private layout: HandlebarsTemplateDelegate | null = null;

  constructor() {
    this.loadLayout();
    this.registerHelpers();
  }

  private loadLayout(): void {
    try {
      const layoutSource = fs.readFileSync(this.layoutPath, 'utf-8');
      this.layout = handlebars.compile(layoutSource);
    } catch (error) {
      console.error('Failed to load email layout:', error);
    }
  }

  private registerHelpers(): void {
    // Register custom Handlebars helpers
    handlebars.registerHelper('year', () => new Date().getFullYear());
    
    handlebars.registerHelper('formatCurrency', (amount: number) => {
      return new Intl.NumberFormat('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(amount);
    });

    handlebars.registerHelper('eq', (a: any, b: any) => a === b);
    handlebars.registerHelper('ne', (a: any, b: any) => a !== b);
    handlebars.registerHelper('gt', (a: number, b: number) => a > b);
    handlebars.registerHelper('lt', (a: number, b: number) => a < b);
  }

  private getTemplate(templateName: string): HandlebarsTemplateDelegate {
    if (this.compiledTemplates.has(templateName)) {
      return this.compiledTemplates.get(templateName)!;
    }

    const templatePath = path.join(this.templatesPath, `${templateName}.hbs`);
    const templateSource = fs.readFileSync(templatePath, 'utf-8');
    const compiled = handlebars.compile(templateSource);
    
    this.compiledTemplates.set(templateName, compiled);
    return compiled;
  }

  public render(templateName: string, data: any): { html: string; text: string } {
    try {
      const template = this.getTemplate(templateName);
      
      // Logo URL - prefer server-served asset so emails can load image from backend
      // You can override with env var EMAIL_ASSET_BASE_URL if needed (eg. https://assets.example.com)
      const assetBase = process.env.EMAIL_ASSET_BASE_URL || process.env.BACKEND_URL || `http://localhost:${config.port}`;
      const logoUrl = `${assetBase.replace(/\/$/, '')}/assets/nesa-logo.webp`;
      
      const body = template({
        ...data,
        frontendUrl: config.frontendUrl,
        logoUrl,
      });

      const html = this.layout
        ? this.layout({
            ...data,
            body,
            frontendUrl: config.frontendUrl,
            logoUrl,
            year: new Date().getFullYear(),
          })
        : body;

      // Generate plain text version (strip HTML tags)
      const text = this.htmlToText(html);

      return { html, text };
    } catch (error) {
      console.error(`Failed to render template ${templateName}:`, error);
      throw error;
    }
  }

  private htmlToText(html: string): string {
    return html
      .replace(/<style[^>]*>.*?<\/style>/gi, '')
      .replace(/<script[^>]*>.*?<\/script>/gi, '')
      .replace(/<[^>]+>/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // Template-specific render methods for type safety
  public renderOtp(data: {
    otpCode: string;
    otp?: string;
    userName?: string;
    message: string;
    headerTitle?: string;
    headerSubtitle?: string;
  }) {
    return this.render('otp', data);
  }

  public renderWelcomeBonus(data: {
    firstName: string;
    agcBonus: number;
    bonusTypeText: string;
    bonusDescription: string;
  }) {
    return this.render('welcome-bonus', {
      ...data,
      headerTitle: '🎉 Welcome to NESA-Africa!',
    });
  }

  public renderVoteConfirmation(data: {
    voterName: string;
    nomineeName: string;
    nomineeCategory: string;
    agcSpent: number;
    voteWeight: number;
    remainingBalance: number;
    totalVotesForNominee: number;
  }) {
    return this.render('vote-confirmation', {
      ...data,
      headerTitle: '✅ Vote Confirmed!',
      headerSubtitle: 'Thank You for Supporting Excellence',
    });
  }

  public renderPasswordReset(data: { resetUrl: string; userName?: string }) {
    // the password-reset template expects `resetLink` and `userName`
    const payload: any = {
      resetLink: data.resetUrl,
    };
    if (data.userName) payload.userName = data.userName;
    return this.render('password-reset', payload);
  }

  public renderEmailVerification(data: { verificationUrl: string }) {
    return this.render('email-verification', data);
  }

  public renderFirstLoginWelcome(data: { userName: string; bonusAmount?: number; joinDate?: string }) {
    const payload: any = {
      userName: data.userName,
      bonusAmount: typeof data.bonusAmount !== 'undefined' ? data.bonusAmount : undefined,
      joinDate: data.joinDate || undefined,
      headerTitle: 'Welcome to NESA-Africa! 🎉',
      headerSubtitle: 'Your Journey to Excellence Begins Here',
    };

    return this.render('first-login-welcome', payload);
  }

  // ============================================
  // NOMINATION SYSTEM EMAIL TEMPLATES
  // ============================================

  public renderNomineeInvitation(data: {
    nomineeName: string;
    awardCategory: string;
    acceptanceLink: string;
    expiresAt: Date;
  }) {
    return this.render('nominee-invitation', {
      ...data,
      expiresAt: data.expiresAt.toLocaleDateString(),
      headerTitle: '🌟 You\'ve Been Nominated!',
      headerSubtitle: 'Celebrate Your Excellence and Impact',
    });
  }

  public renderNominationConfirmation(data: {
    nominatorName: string;
    nomineeName: string;
    awardCategory: string;
  }) {
    return this.render('nomination-confirmation', {
      ...data,
      headerTitle: '✅ Nomination Submitted',
      headerSubtitle: 'Thank You for Recognizing Excellence',
    });
  }

  public renderNominationApproved(data: {
    nomineeName: string;
    awardCategory: string;
    approvalCount: number;
    certificateThreshold?: number;
  }) {
    return this.render('nomination-approved', {
      ...data,
      certificateThreshold: data.certificateThreshold || 10,
      headerTitle: '🎉 Nomination Approved!',
      headerSubtitle: 'You\'re One Step Closer to Recognition',
    });
  }

  public renderNominationRejected(data: {
    nomineeName: string;
    nominatorName: string;
    awardCategory: string;
    rejectionReason: string;
  }) {
    return this.render('nomination-rejected', {
      ...data,
      headerTitle: 'Nomination Status Update',
      headerSubtitle: 'We\'ve Reviewed Your Submission',
    });
  }

  public renderCertificateIssued(data: {
    nomineeName: string;
    awardCategory: string;
    awardType: string;
    certificateNumber: string;
    downloadLink: string;
    approvalCount: number;
  }) {
    return this.render('certificate-issued', {
      ...data,
      headerTitle: '🏆 Certificate Issued!',
      headerSubtitle: 'Celebrate Your Recognition',
    });
  }

  public renderNomineeAcceptance(data: {
    nomineeName: string;
    awardCategory: string;
  }) {
    return this.render('nominee-acceptance', {
      ...data,
      headerTitle: '✅ Nomination Accepted',
      headerSubtitle: 'Welcome to Our Recognition Program',
    });
  }

  public renderNomineeDecline(data: {
    nomineeName: string;
    awardCategory: string;
  }) {
    return this.render('nominee-decline', {
      ...data,
      headerTitle: 'Nomination Status Updated',
      headerSubtitle: 'Thank You for Your Consideration',
    });
  }
}

export const emailTemplateService = new EmailTemplateService();
