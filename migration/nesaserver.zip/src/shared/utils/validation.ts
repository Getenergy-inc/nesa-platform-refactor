import { z } from 'zod';
import { Request, Response, NextFunction } from 'express';
import { ValidationError } from './errors';

// Common validation schemas
export const emailSchema = z.string().email('Invalid email format');
export const passwordSchema = z.string().min(8, 'Password must be at least 8 characters');
export const phoneSchema = z.string().regex(/^\+?[\d\s\-()]+$/, 'Invalid phone number format');
export const urlSchema = z.string().url('Invalid URL format');

// Pagination schema
export const paginationSchema = z.object({
  page: z.coerce.number().min(1).default(1),
  limit: z.coerce.number().min(1).max(100).default(10),
  sortBy: z.string().optional(),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
});

// User role validation
export const userRoleSchema = z.enum([
  'FREE_MEMBER',
  'STANDARD_MEMBER',
  'AMBASSADOR',
  'JUDGE',
  'VOLUNTEER',
  'NRC_VOLUNTEER',
  'INTERN',
  'NOMINEE',
  'SPONSOR',
  'CHAPTER_LEADER',
  'ADMIN'
]);

// Account type validation
export const accountTypeSchema = z.enum([
  'INDIVIDUAL',
  'NGO',
  'CORPORATION',
  'GOVERNMENT',
  'SCHOOL',
  'DIASPORA_GROUP'
]);

// User intent validation
export const userIntentSchema = z.enum([
  'VOTE_OR_NOMINATE',
  'APPLY_FOR_EDUAID_SCHOLARSHIP',
  'BECOME_AMBASSADOR',
  'JOIN_WEBINAR_EXPO',
  'SPONSOR_OR_CSR_PARTNER',
  'APPLY_AS_JUDGE',
  'JOIN_LOCAL_CHAPTER',
  'JOIN_NESA_TEAM',
  'GET_GALA_TICKET',
  'DONATE',
  'APPLY_AS_NRC_VOLUNTEER'
]);

// Language validation
export const languageSchema = z.enum(['EN', 'FR', 'AR', 'PT']);

// Gender validation
export const genderSchema = z.enum(['MALE', 'FEMALE', 'OTHER', 'PREFER_NOT_TO_SAY']);

// Application status validation
export const applicationStatusSchema = z.enum(['PENDING', 'APPROVED', 'REJECTED', 'UNDER_REVIEW']);

// Nominee status validation
export const nomineeStatusSchema = z.enum(['DRAFT', 'SUBMITTED', 'APPROVED', 'REJECTED', 'SHORTLISTED']);

// File validation
export const fileValidationSchema = z.object({
  mimetype: z.string(),
  size: z.number().max(5 * 1024 * 1024, 'File size must be less than 5MB'),
  originalname: z.string(),
});

// Common field validations
export const nameSchema = z.string().min(2, 'Name must be at least 2 characters').max(100, 'Name must be less than 100 characters');
export const countrySchema = z.string().min(2, 'Country is required');
export const stateSchema = z.string().min(2, 'State/Region is required');

// Validation middleware
export const validateRequest = (schema: z.ZodSchema) => {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      const validatedData = schema.parse({
        body: req.body,
        query: req.query,
        params: req.params,
      });
      
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (req as any).validatedData = validatedData;
      next();
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationErrors = error.errors.map(err => ({
          field: err.path.join('.'),
          message: err.message,
          code: err.code,
        }));
        
        res.status(400).json({
          success: false,
          message: 'Validation failed',
          errors: validationErrors,
        });
        return;
      }

      next(new ValidationError('Invalid request data'));
    }
  };
};

// Validate file uploads
export const validateFileUpload = (file: Express.Multer.File, allowedTypes: string[] = []) => {
  if (!file) {
    throw new ValidationError('File is required');
  }

  if (allowedTypes.length > 0 && !allowedTypes.includes(file.mimetype)) {
    throw new ValidationError(`File type not allowed. Allowed types: ${allowedTypes.join(', ')}`);
  }

  if (file.size > 5 * 1024 * 1024) { // 5MB
    throw new ValidationError('File size must be less than 5MB');
  }

  return true;
};

// Sanitize input
export const sanitizeInput = (input: string): string => {
  return input.trim().replace(/[<>]/g, '');
};

// Validate and sanitize object
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const sanitizeObject = (obj: Record<string, any>): Record<string, any> => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const sanitized: Record<string, any> = {};
  
  for (const [key, value] of Object.entries(obj)) {
    if (typeof value === 'string') {
      sanitized[key] = sanitizeInput(value);
    } else if (Array.isArray(value)) {
      sanitized[key] = value.map(item => 
        typeof item === 'string' ? sanitizeInput(item) : item
      );
    } else {
      sanitized[key] = value;
    }
  }
  
  return sanitized;
};
