import { Router, Request, Response } from 'express';
import { queueService } from '../queues';
import { verifyToken, requireAdmin } from '../middleware/auth';

const router = Router();

/**
 * @route GET /api/v1/queues/stats
 * @desc Get queue statistics
 * @access Private (Admin only)
 */
router.get('/stats', verifyToken, requireAdmin, async (req: Request, res: Response) => {
  try {
    const stats = await queueService.getQueueStats();
    
    res.json({
      success: true,
      message: 'Queue statistics retrieved successfully',
      data: stats,
    });
  } catch (error: any) {
    console.error('Error fetching queue stats:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch queue statistics',
      error: error.message,
    });
  }
});

/**
 * @route POST /api/v1/queues/clean
 * @desc Clean old completed jobs from queues
 * @access Private (Admin only)
 */
router.post('/clean', verifyToken, requireAdmin, async (req: Request, res: Response) => {
  try {
    const { grace = 24 * 60 * 60 * 1000 } = req.body; // Default 24 hours
    
    const results = await queueService.cleanOldJobs(grace);
    
    res.json({
      success: true,
      message: 'Old jobs cleaned successfully',
      data: results,
    });
  } catch (error: any) {
    console.error('Error cleaning queues:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to clean queues',
      error: error.message,
    });
  }
});

/**
 * @route GET /api/v1/queues/health
 * @desc Check queue system health
 * @access Public
 */
router.get('/health', async (req: Request, res: Response) => {
  try {
    const stats = await queueService.getQueueStats();
    
    // Check if any queue has too many failed jobs
    const hasIssues = stats.some(queue => queue.failed > 50);
    
    res.json({
      success: true,
      healthy: !hasIssues,
      message: hasIssues ? 'Some queues have issues' : 'All queues are healthy',
      data: {
        queues: stats.length,
        totalJobs: stats.reduce((sum, q) => sum + q.total, 0),
        totalFailed: stats.reduce((sum, q) => sum + q.failed, 0),
      },
    });
  } catch (error: any) {
    console.error('Error checking queue health:', error);
    res.status(500).json({
      success: false,
      healthy: false,
      message: 'Failed to check queue health',
      error: error.message,
    });
  }
});

export default router;
