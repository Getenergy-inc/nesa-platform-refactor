import { Router, Request, Response } from 'express';
import prisma from '@/shared/database/postgresql';
import mongoose from 'mongoose';
import Redis from 'ioredis';

const router = Router();

// Redis client (optional - only if Redis is configured)
let redisClient: Redis | null = null;
try {
  if (process.env.REDIS_URL) {
    redisClient = new Redis(process.env.REDIS_URL);
  }
} catch (error) {
  console.warn('Redis not configured or unavailable');
}

interface HealthStatus {
  status: 'healthy' | 'unhealthy';
  timestamp: string;
  uptime: number;
  environment: string;
  version: string;
  services: {
    database: {
      postgresql: 'connected' | 'disconnected' | 'error';
      mongodb: 'connected' | 'disconnected' | 'error';
      redis: 'connected' | 'disconnected' | 'error' | 'not_configured';
    };
    memory: {
      used: string;
      total: string;
      percentage: string;
    };
    cpu: {
      usage: string;
    };
  };
}

/**
 * Health check endpoint
 * GET /health
 */
router.get('/health', async (req: Request, res: Response) => {
  const startTime = Date.now();
  
  try {
    // Check PostgreSQL connection
    let postgresqlStatus: 'connected' | 'disconnected' | 'error' = 'disconnected';
    try {
      await prisma.$queryRaw`SELECT 1`;
      postgresqlStatus = 'connected';
    } catch (error) {
      postgresqlStatus = 'error';
    }

    // Check MongoDB connection
    let mongodbStatus: 'connected' | 'disconnected' | 'error' = 'disconnected';
    try {
      if (mongoose.connection.readyState === 1) {
        mongodbStatus = 'connected';
      } else {
        mongodbStatus = 'disconnected';
      }
    } catch (error) {
      mongodbStatus = 'error';
    }

    // Check Redis connection
    let redisStatus: 'connected' | 'disconnected' | 'error' | 'not_configured' = 'not_configured';
    if (redisClient) {
      try {
        await redisClient.ping();
        redisStatus = 'connected';
      } catch (error) {
        redisStatus = 'error';
      }
    }

    // Get memory usage
    const memoryUsage = process.memoryUsage();
    const totalMemory = memoryUsage.heapTotal;
    const usedMemory = memoryUsage.heapUsed;
    const memoryPercentage = ((usedMemory / totalMemory) * 100).toFixed(2);

    // Get CPU usage (simplified)
    const cpuUsage = process.cpuUsage();
    const cpuPercentage = ((cpuUsage.user + cpuUsage.system) / 1000000).toFixed(2);

    const healthStatus: HealthStatus = {
      status: postgresqlStatus === 'connected' ? 'healthy' : 'unhealthy',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      environment: process.env.NODE_ENV || 'development',
      version: process.env.npm_package_version || '1.0.0',
      services: {
        database: {
          postgresql: postgresqlStatus,
          mongodb: mongodbStatus,
          redis: redisStatus
        },
        memory: {
          used: `${(usedMemory / 1024 / 1024).toFixed(2)} MB`,
          total: `${(totalMemory / 1024 / 1024).toFixed(2)} MB`,
          percentage: `${memoryPercentage}%`
        },
        cpu: {
          usage: `${cpuPercentage} ms`
        }
      }
    };

    const responseTime = Date.now() - startTime;
    
    res.status(healthStatus.status === 'healthy' ? 200 : 503).json({
      ...healthStatus,
      responseTime: `${responseTime}ms`
    });

  } catch (error) {
    const responseTime = Date.now() - startTime;
    
    res.status(503).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error',
      responseTime: `${responseTime}ms`
    });
  }
});

/**
 * Readiness check endpoint
 * GET /ready
 */
router.get('/ready', async (req: Request, res: Response) => {
  try {
    // Check if the application is ready to serve requests
    await prisma.$queryRaw`SELECT 1`;
    
    res.status(200).json({
      status: 'ready',
      timestamp: new Date().toISOString(),
      message: 'Application is ready to serve requests'
    });
  } catch (error) {
    res.status(503).json({
      status: 'not_ready',
      timestamp: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error',
      message: 'Application is not ready to serve requests'
    });
  }
});

/**
 * Liveness check endpoint
 * GET /live
 */
router.get('/live', (req: Request, res: Response) => {
  // Simple liveness check - if this endpoint responds, the app is alive
  res.status(200).json({
    status: 'alive',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    message: 'Application is alive'
  });
});

/**
 * Database-specific health checks
 */
router.get('/health/database', async (req: Request, res: Response) => {
  try {
    const startTime = Date.now();
    
    // Test PostgreSQL
    const postgresStart = Date.now();
    await prisma.$queryRaw`SELECT NOW() as current_time`;
    const postgresTime = Date.now() - postgresStart;

    // Test MongoDB
    const mongoStart = Date.now();
    let mongoTime = 0;
    let mongoStatus = 'disconnected';
    
    if (mongoose.connection.readyState === 1 && mongoose.connection.db) {
      await mongoose.connection.db.admin().ping();
      mongoTime = Date.now() - mongoStart;
      mongoStatus = 'connected';
    }

    // Test Redis
    const redisStart = Date.now();
    let redisTime = 0;
    let redisStatus = 'not_configured';
    
    if (redisClient) {
      await redisClient.ping();
      redisTime = Date.now() - redisStart;
      redisStatus = 'connected';
    }

    const totalTime = Date.now() - startTime;

    res.status(200).json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      databases: {
        postgresql: {
          status: 'connected',
          responseTime: `${postgresTime}ms`
        },
        mongodb: {
          status: mongoStatus,
          responseTime: mongoStatus === 'connected' ? `${mongoTime}ms` : 'N/A'
        },
        redis: {
          status: redisStatus,
          responseTime: redisStatus === 'connected' ? `${redisTime}ms` : 'N/A'
        }
      },
      totalResponseTime: `${totalTime}ms`
    });

  } catch (error) {
    res.status(503).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

export default router;