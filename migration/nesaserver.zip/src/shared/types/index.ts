// eslint-disable-next-line @typescript-eslint/no-explicit-any
export interface ApiResponse<T = any> {
  success: boolean;
  message: string;
  data?: T;
  errors?: ValidationError[];
  meta?: {
    page?: number;
    limit?: number;
    total?: number;
    totalPages?: number;
  };
}

export interface ValidationError {
  field: string;
  message: string;
  code?: string;
}

export interface PaginationQuery {
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface FilterQuery {
  search?: string;
  status?: string;
  category?: string;
  country?: string;
  dateFrom?: string;
  dateTo?: string;
}

// User Types (matching Prisma enum format)
export type UserRole =
  | 'FREE_MEMBER'
  | 'STANDARD_MEMBER'
  | 'AMBASSADOR'
  | 'JUDGE'
  | 'VOLUNTEER'
  | 'NRC_VOLUNTEER'
  | 'INTERN'
  | 'NOMINEE'
  | 'SPONSOR'
  | 'CHAPTER_LEADER'
  | 'ADMIN'
  | 'SUPER_ADMIN';

export type AccountType =
  | 'INDIVIDUAL'
  | 'NGO'
  | 'CORPORATION'
  | 'GOVERNMENT'
  | 'SCHOOL'
  | 'DIASPORA_GROUP';

export type UserIntent =
  | 'VOTE_OR_NOMINATE'
  | 'APPLY_FOR_EDUAID_SCHOLARSHIP'
  | 'BECOME_AMBASSADOR'
  | 'JOIN_WEBINAR_EXPO'
  | 'SPONSOR_OR_CSR_PARTNER'
  | 'APPLY_AS_JUDGE'
  | 'JOIN_LOCAL_CHAPTER'
  | 'JOIN_NESA_TEAM'
  | 'GET_GALA_TICKET'
  | 'DONATE'
  | 'APPLY_AS_NRC_VOLUNTEER';

export interface BaseUser {
  id: string;
  email: string;
  phone: string | null;
  role: UserRole;
  isVerified: boolean;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Authentication Types
export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  email: string;
  password: string;
  firstName?: string;
  lastName?: string;
  accountType?: AccountType;
  intents?: UserIntent[];
  country?: string;
  organizationName?: string;
}

export interface PasswordResetRequest {
  email: string;
}

export interface PasswordResetConfirm {
  token: string;
  newPassword: string;
}

export interface EmailVerification {
  token: string;
}

// Admin Management Types
export type PlatformSection =
  | 'USER_MANAGEMENT'
  | 'NRC_VOLUNTEERS'
  | 'NOMINATIONS'
  | 'JUDGES'
  | 'VOTING_SYSTEM'
  | 'WALLET_MANAGEMENT'
  | 'CHAPTER_MANAGEMENT'
  | 'FILE_MANAGEMENT'
  | 'NOTIFICATIONS'
  | 'ANALYTICS'
  | 'SYSTEM_SETTINGS'
  | 'ALL_SECTIONS';

export type AdminPermission =
  | 'READ'
  | 'WRITE'
  | 'DELETE'
  | 'MANAGE_USERS'
  | 'MANAGE_PERMISSIONS'
  | 'VIEW_ANALYTICS'
  | 'SYSTEM_CONFIG'
  | 'FULL_ACCESS';

export type InvitationStatus =
  | 'PENDING'
  | 'ACCEPTED'
  | 'EXPIRED'
  | 'REVOKED';

export interface AdminInvitation {
  id: string;
  email: string;
  sections: PlatformSection[];
  permissions: AdminPermission[];
  status: InvitationStatus;
  invitedBy: string;
  invitedAt: Date;
  expiresAt: Date;
  acceptedAt?: Date;
}

export interface AdminInviteRequest {
  email: string;
  sections: PlatformSection[];
  permissions: AdminPermission[];
  message?: string;
}

export interface AdminAcceptInvitation {
  token: string;
  password: string;
  firstName: string;
  lastName: string;
}

// File Upload Types
export interface FileUpload {
  id: string;
  originalName: string;
  filename: string;
  mimetype: string;
  size: number;
  url: string;
  uploadedBy: string;
  uploadedAt: Date;
}

// Notification Types
export type NotificationType = 
  | 'application_submitted'
  | 'application_approved'
  | 'application_rejected'
  | 'nominee_submitted'
  | 'system_update'
  | 'voting_opened'
  | 'voting_closed'
  | 'wallet_transaction';

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  read: boolean;
  actionUrl?: string;
  createdAt: Date;
}

// AGC Wallet Types
export interface WalletTransaction {
  id: string;
  walletId: string;
  type: 'credit' | 'debit';
  amount: number;
  reason: string;
  description?: string;
  referenceId?: string;
  status: 'pending' | 'completed' | 'failed';
  createdAt: Date;
}

export interface Wallet {
  id: string;
  userId: string;
  agcWithdrawableBalance: number;
  agcLockedBalance: number;
  currencyEquivalentBalance: number;
  lastUpdated: Date;
}

// Chapter Types
export interface Chapter {
  id: string;
  name: string;
  country: string;
  region: string;
  type: 'online' | 'hybrid' | 'physical';
  leaderId?: string;
  memberCount: number;
  isActive: boolean;
  createdAt: Date;
}

// Common Status Types
export type ApplicationStatus = 'pending' | 'approved' | 'rejected' | 'under_review';
export type NomineeStatus = 'draft' | 'submitted' | 'approved' | 'rejected' | 'shortlisted';
export type VotingStatus = 'not_started' | 'active' | 'closed' | 'results_published';

// Error Types
export interface AppError extends Error {
  statusCode: number;
  isOperational: boolean;
}

export interface DatabaseError extends Error {
  code?: string;
  constraint?: string;
}

// Request Types
import { Request } from 'express';

export interface AuthenticatedRequest extends Request {
  user?: BaseUser;
  file?: Express.Multer.File | undefined;
  files?: Express.Multer.File[] | { [fieldname: string]: Express.Multer.File[] } | undefined;
}

// JWT Payload
export interface JWTPayload {
  userId: string;
  email: string;
  role: UserRole;
  iat?: number;
  exp?: number;
}

// Email Template Types
export interface EmailTemplate {
  subject: string;
  html: string;
  text?: string;
}

export interface EmailData {
  to: string;
  from?: string;
  subject: string;
  html: string;
  text?: string;
  templateId?: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  dynamicTemplateData?: Record<string, any>;
}

// Audit Log Types
export interface AuditLog {
  id: string;
  userId?: string;
  action: string;
  resource: string;
  resourceId?: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  details?: Record<string, any>;
  ipAddress?: string;
  userAgent?: string;
  createdAt: Date;
}

// Configuration Types
export interface DatabaseConfig {
  postgresql: {
    url: string;
    host: string;
    port: number;
    database: string;
    username: string;
    password: string;
  };
  mongodb: {
    uri: string;
    host: string;
    port: number;
    database: string;
  };
  companyReserveWalletId: string;
}

export interface AppConfig {
  port: number;
  nodeEnv: string;
  apiVersion: string;
  frontendUrl: string;
  corsOrigins: string[];
  database: DatabaseConfig;
  jwt: {
    secret: string;
    expiresIn: string;
    refreshSecret: string;
    refreshExpiresIn: string;
  };
  email: {
    apiKey: string;
    fromEmail: string;
    fromName: string;
  };
  smtp: {
    host: string;
    port: number;
    user: string;
    pass: string;
  };
  redis: {
    url: string;
  };
  fileUpload: {
    cloudName: string;
    apiKey: string;
    apiSecret: string;
  };
  security: {
    bcryptSaltRounds: number;
    sessionSecret: string;
  };
  rateLimit: {
    windowMs: number;
    maxRequests: number;
  };
  paystack: {
    secretKey: string;
    publicKey: string;
    webhookSecret: string;
  };
  flutterwave: {
    secretKey: string;
    publicKey: string;
    encryptionKey: string;
    webhookSecret: string;
  };
}
