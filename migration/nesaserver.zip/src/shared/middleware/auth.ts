import { Request, Response, NextFunction } from 'express';
import jwt, { SignOptions } from 'jsonwebtoken';
import { config } from '@/config';
import { prisma } from '@/shared/database/postgresql';
import { AuthenticationError, AuthorizationError } from '@/shared/utils/errors';
import { JWTPayload, UserRole } from '@/shared/types';

// Extend Request interface
declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: {
        id: string;
        email: string;
        phone: string | null;
        role: UserRole;
        isVerified: boolean;
        isActive: boolean;
        createdAt: Date;
        updatedAt: Date;
      };
    }
  }
}

// Verify JWT token
export const verifyToken = async (req: Request, _res: Response, next: NextFunction) => {
  try {
    // Development bypass for testing (only in development environment)
    if (config.nodeEnv === 'development' && req.headers['x-bypass-auth'] === 'development-testing') {
      // Create a test user for development
      req.user = {
        id: 'test-user-id',
        email: 'test@example.com',
        phone: '+2348000000000',
        role: 'FREE_MEMBER' as UserRole,
        isVerified: true,
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      return next();
    }

    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new AuthenticationError('Access token is required');
    }

    const token = authHeader.substring(7); // Remove 'Bearer ' prefix
    
    if (!token) {
      throw new AuthenticationError('Access token is required');
    }

    // Check for development test token
    if (config.nodeEnv === 'development' && 
        token.includes('testSignatureForDevelopment')) {
      // Create a test user for development
      req.user = {
        id: 'test-user-id',
        email: 'test@example.com',
        phone: '+2348000000000',
        role: 'FREE_MEMBER' as UserRole,
        isVerified: true,
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      return next();
    }

    // Verify the token
    const decoded = jwt.verify(token, config.jwt.secret) as JWTPayload;
    
    // Get user from database
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: {
        id: true,
        email: true,
        phone: true,
        role: true,
        isVerified: true,
        isActive: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    if (!user) {
      throw new AuthenticationError('User not found');
    }

    if (!user.isActive) {
      throw new AuthenticationError('Account is deactivated');
    }

    // Attach user to request
    req.user = user;
    next();
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      return next(new AuthenticationError('Invalid token'));
    }
    if (error instanceof jwt.TokenExpiredError) {
      return next(new AuthenticationError('Token expired'));
    }
    next(error);
  }
};

// Optional authentication (doesn't throw error if no token)
export const optionalAuth = async (req: Request, _res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return next();
    }

    const token = authHeader.substring(7);
    
    if (!token) {
      return next();
    }

    const decoded = jwt.verify(token, config.jwt.secret) as JWTPayload;
    
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: {
        id: true,
        email: true,
        phone: true,
        role: true,
        isVerified: true,
        isActive: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    if (user && user.isActive) {
      req.user = user;
    }
    
    next();
  } catch (error) {
    // Ignore token errors for optional auth
    next();
  }
};

// Require email verification
export const requireVerification = (req: Request, _res: Response, next: NextFunction) => {
  if (!req.user) {
    return next(new AuthenticationError('Authentication required'));
  }

  if (!req.user.isVerified) {
    return next(new AuthenticationError('Email verification required'));
  }

  next();
};

// Role-based authorization
export const requireRole = (...roles: UserRole[]) => {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) {
      return next(new AuthenticationError('Authentication required'));
    }

    if (!roles.includes(req.user.role)) {
      return next(new AuthorizationError('Insufficient permissions'));
    }

    next();
  };
};

// Admin only
export const requireAdmin = requireRole('ADMIN' as UserRole);

// Judge or Admin
export const requireJudgeOrAdmin = requireRole('JUDGE' as UserRole, 'ADMIN' as UserRole);

// NRC Volunteer or Admin
export const requireNRCOrAdmin = requireRole('NRC_VOLUNTEER' as UserRole, 'ADMIN' as UserRole);

// Chapter Leader or Admin
export const requireChapterLeaderOrAdmin = requireRole('CHAPTER_LEADER' as UserRole, 'ADMIN' as UserRole);

// Super Admin only
export const requireSuperAdmin = requireRole('SUPER_ADMIN' as UserRole);

// Section-based access control
export const requireSection = (section: string, permission?: string) => {
  return async (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) {
      return next(new AuthenticationError('Authentication required'));
    }

    // Super admins have access to all sections
    if (req.user.role === 'SUPER_ADMIN' as UserRole) {
      return next();
    }

    // Check if admin has access to the required section
    if (req.user.role === 'ADMIN' as UserRole) {
      try {
        const adminSections = await prisma.adminSection.findMany({
          where: {
            userId: req.user.id,
            OR: [
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              { section: section as any },
              { section: 'ALL_SECTIONS' }
            ]
          }
        });

        if (adminSections.length === 0) {
          return next(new AuthorizationError('Access denied to this section'));
        }

        // Check specific permission if required
        if (permission) {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          const hasPermission = adminSections.some((adminSection: any) =>
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            adminSection.permissions.includes(permission as any) ||
            adminSection.permissions.includes('FULL_ACCESS')
          );

          if (!hasPermission) {
            return next(new AuthorizationError('Insufficient permissions for this action'));
          }
        }

        return next();
      } catch (error) {
        return next(new AuthorizationError('Failed to verify section access'));
      }
    }

    return next(new AuthorizationError('Admin access required'));
  };
};

// Generate JWT token
export const generateToken = (payload: Omit<JWTPayload, 'iat' | 'exp'>): string => {
  return jwt.sign(payload as object, config.jwt.secret, {
    expiresIn: config.jwt.expiresIn,
  } as SignOptions);
};

// Generate refresh token
export const generateRefreshToken = (payload: Omit<JWTPayload, 'iat' | 'exp'>): string => {
  return jwt.sign(payload as object, config.jwt.refreshSecret, {
    expiresIn: config.jwt.refreshExpiresIn,
  } as SignOptions);
};

// Verify refresh token
export const verifyRefreshToken = (token: string): JWTPayload => {
  return jwt.verify(token, config.jwt.refreshSecret) as JWTPayload;
};

// Export AuthenticatedRequest type from shared/types
export { AuthenticatedRequest } from '@/shared/types';
// Backwards-compatible aliases expected by some modules
export const authenticate = verifyToken;
export const authorize = (roles: string[]) => requireRole(...(roles as any));
