import { Request, Response, NextFunction } from 'express';
import { handleError } from '@/shared/utils/errors';
import logger from '@/shared/utils/logger';
import { config } from '@/config';

// Global error handler middleware
export const errorHandler = (
  error: Error,
  req: Request,
  res: Response,
  _next: NextFunction
) => {
  // Handle the error and convert to AppError
  const appError = handleError(error);
  
  // Log the error
  logger.error(`${appError.statusCode} - ${appError.message} - ${req.originalUrl} - ${req.method} - ${req.ip}`, {
    error: appError,
    stack: appError.stack,
    url: req.originalUrl,
    method: req.method,
    ip: req.ip,
    userAgent: req.get('User-Agent'),
    userId: req.user?.id,
  });

  // Don't leak error details in production
  const isDevelopment = config.nodeEnv === 'development';
  
  const errorResponse = {
    success: false,
    message: appError.message,
    ...(isDevelopment && {
      stack: appError.stack,
      error: appError,
    }),
  };

  res.status(appError.statusCode).json(errorResponse);
};

// 404 handler
export const notFoundHandler = (req: Request, res: Response, _next: NextFunction) => {
  res.status(404).json({
    success: false,
    message: `Route ${req.originalUrl} not found`
  });
};

// Async error wrapper
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const asyncHandler = (fn: (...args: any[]) => Promise<any>) => {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};
