import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { AuthenticationError } from '@/shared/utils/errors';

// Create (or reuse) a CSRF token cookie that's readable by JS (not HttpOnly)
export const ensureCsrfCookie = (req: Request, res: Response) => {
  let csrfToken = req.cookies?.csrfToken as string | undefined;
  if (!csrfToken) {
    csrfToken = crypto.randomBytes(24).toString('hex');
    res.cookie('csrfToken', csrfToken, {
      httpOnly: false, // must be readable by client JS
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 30 * 24 * 60 * 60 * 1000
    });
  }
  return csrfToken;
};

// Issue CSRF token on demand
export const issueCsrfToken = (req: Request, res: Response) => {
  const token = ensureCsrfCookie(req, res);
  res.json({ success: true, message: 'CSRF token issued', data: { csrfToken: token } });
};

// Verify CSRF for refresh-token endpoint using Double Submit Cookie pattern
export const verifyRefreshCsrf = (req: Request, _res: Response, next: NextFunction) => {
  const cookieToken = req.cookies?.csrfToken;
  const headerToken = (req.headers['x-csrf-token'] as string) || (req.headers['x-xsrf-token'] as string);

  if (!cookieToken || !headerToken || cookieToken !== headerToken) {
    return next(new AuthenticationError('Invalid CSRF token'));
  }
  next();
};