import rateLimit from 'express-rate-limit';
import { config } from '@/config';

// General rate limiter
export const generalLimiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.maxRequests,
  message: {
    success: false,
    message: 'Too many requests from this IP, please try again later.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Strict rate limiter for authentication endpoints
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20, // Limit each IP to 20 requests per windowMs 
  message: {
    success: false,
    message: 'Too many authentication attempts, please try again in 15 minutes.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// OTP send limiter (avoid spamming)
export const otpSendLimiter = rateLimit({
  windowMs: 10 * 60 * 1000, // 10 minutes
  max: 10, // 10 OTP sends per 10 minutes per IP (increased for development)
  message: {
    success: false,
    message: 'Too many OTP requests, please try again in 10 minutes.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// OTP verify limiter (brute-force protection)
export const otpVerifyLimiter = rateLimit({
  windowMs: 10 * 60 * 1000, // 10 minutes
  max: 10, // 10 verifications per 10 minutes per IP
  message: {
    success: false,
    message: 'Too many OTP verification attempts, please try again later.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Rate limiter for file uploads
export const uploadLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 10, // Limit each IP to 10 uploads per minute
  message: {
    success: false,
    message: 'Too many file uploads, please try again later.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Rate limiter for voting
export const votingLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 5, // Limit each IP to 5 votes per minute
  message: {
    success: false,
    message: 'Too many votes, please slow down.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Rate limiter for nominations
export const nominationLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10, // Limit each IP to 10 nominations per hour
  message: {
    success: false,
    message: 'Too many nominations, please try again later.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Rate limiter for email sending
export const emailLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 20, // Limit each IP to 20 emails per hour
  message: {
    success: false,
    message: 'Too many email requests, please try again later.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Rate limiter for NRC registration (more lenient than auth)
export const nrcRegistrationLimiter = rateLimit({
  windowMs: 30 * 60 * 1000, // 30 minutes
  max: 20, // 20 registration attempts per 30 minutes (for testing purposes)
  message: {
    success: false,
    message: 'Too many registration attempts. Please try again later.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});
