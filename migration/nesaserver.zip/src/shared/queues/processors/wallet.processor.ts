import { Job } from 'bull';
import { emailQueue } from '../queues';

export interface WalletJobData {
  type: 'wallet-credited' | 'wallet-debited' | 'wallet-transfer' | 'wallet-withdrawal';
  userId: string;
  email: string;
  amount: number;
  currency: string;
  balance: number;
  reference: string;
  metadata?: any;
}

export const processWalletJob = async (job: Job<WalletJobData>) => {
  const { type, email, amount, currency, balance, reference } = job.data;

  try {
    console.log(`💰 Processing wallet job ${job.id} - ${type}`);

    const emailContent = generateWalletEmail(type, amount, currency, balance, reference);

    await emailQueue.add(
      {
        to: email,
        subject: emailContent.subject,
        html: emailContent.html,
        text: emailContent.text,
      },
      {
        priority: 2,
      }
    );

    console.log(`✅ Wallet notification queued for ${email}`);
    return { success: true, type, reference };
  } catch (error: any) {
    console.error(`❌ Failed to process wallet notification:`, error);
    throw new Error(`Wallet processing failed: ${error.message}`);
  }
};

function generateWalletEmail(
  type: string,
  amount: number,
  currency: string,
  balance: number,
  reference: string
) {
  const formatAmount = (amt: number, curr: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: curr,
    }).format(amt / 100);
  };

  let subject = '';
  let html = '';
  let text = '';

  switch (type) {
    case 'wallet-credited':
      subject = `Wallet Credited - ${formatAmount(amount, currency)}`;
      html = `
        <h2>💰 Wallet Credited</h2>
        <p>Your wallet has been credited successfully.</p>
        <p><strong>Amount:</strong> ${formatAmount(amount, currency)}</p>
        <p><strong>New Balance:</strong> ${formatAmount(balance, currency)}</p>
        <p><strong>Reference:</strong> ${reference}</p>
      `;
      text = `Wallet credited: ${formatAmount(amount, currency)}\nNew Balance: ${formatAmount(balance, currency)}`;
      break;

    case 'wallet-debited':
      subject = `Wallet Debited - ${formatAmount(amount, currency)}`;
      html = `
        <h2>💳 Wallet Debited</h2>
        <p>Your wallet has been debited.</p>
        <p><strong>Amount:</strong> ${formatAmount(amount, currency)}</p>
        <p><strong>New Balance:</strong> ${formatAmount(balance, currency)}</p>
        <p><strong>Reference:</strong> ${reference}</p>
      `;
      text = `Wallet debited: ${formatAmount(amount, currency)}\nNew Balance: ${formatAmount(balance, currency)}`;
      break;

    default:
      subject = `Wallet Update - ${reference}`;
      html = `<p>Wallet transaction update</p>`;
      text = `Wallet transaction update`;
  }

  return { subject, html, text };
}
