import { Job } from 'bull';
import { emailQueue, notificationQueue } from '../queues';

export interface VotingJobData {
  type: 'vote-cast' | 'vote-confirmed' | 'voting-reminder' | 'voting-results';
  userId: string;
  email: string;
  nomineeId?: string;
  nomineeName?: string;
  categoryId?: string;
  categoryName?: string;
  metadata?: any;
}

export const processVotingJob = async (job: Job<VotingJobData>) => {
  const { type, email, nomineeName, categoryName, metadata } = job.data;

  try {
    console.log(`🗳️ Processing voting job ${job.id} - ${type}`);

    // Generate email content based on voting type
    const emailContent = generateVotingEmail(type, nomineeName, categoryName, metadata);

    // Add to email queue
    await emailQueue.add(
      {
        to: email,
        subject: emailContent.subject,
        html: emailContent.html,
        text: emailContent.text,
      },
      {
        priority: 3, // Medium priority
      }
    );

    // Also add to notification queue for in-app notifications
    await notificationQueue.add({
      userId: job.data.userId,
      type: 'voting',
      title: emailContent.subject,
      message: emailContent.text,
      metadata: job.data,
    });

    console.log(`✅ Voting notification queued for ${email}`);
    return { success: true, type };
  } catch (error: any) {
    console.error(`❌ Failed to process voting notification:`, error);
    throw new Error(`Voting processing failed: ${error.message}`);
  }
};

function generateVotingEmail(
  type: string,
  nomineeName: string | undefined,
  categoryName: string | undefined,
  metadata: any
) {
  let subject = '';
  let html = '';
  let text = '';

  switch (type) {
    case 'vote-cast':
      subject = `Vote Recorded - ${categoryName}`;
      html = `
        <h2>🗳️ Your Vote Has Been Recorded</h2>
        <p>Thank you for voting!</p>
        <p><strong>Nominee:</strong> ${nomineeName}</p>
        <p><strong>Category:</strong> ${categoryName}</p>
        <p>Your vote helps recognize excellence in education across Africa.</p>
      `;
      text = `Your vote has been recorded for ${nomineeName} in ${categoryName}`;
      break;

    case 'vote-confirmed':
      subject = `Vote Confirmed - ${categoryName}`;
      html = `
        <h2>✅ Vote Confirmed</h2>
        <p>Your vote has been confirmed and counted.</p>
        <p><strong>Nominee:</strong> ${nomineeName}</p>
        <p><strong>Category:</strong> ${categoryName}</p>
      `;
      text = `Vote confirmed for ${nomineeName} in ${categoryName}`;
      break;

    case 'voting-reminder':
      subject = `Reminder: Cast Your Vote`;
      html = `
        <h2>⏰ Don't Forget to Vote!</h2>
        <p>Voting is still open. Make your voice heard!</p>
        <p>Visit the NESA-Africa platform to cast your vote.</p>
      `;
      text = `Reminder: Voting is still open. Cast your vote now!`;
      break;

    default:
      subject = `Voting Update`;
      html = `<p>Voting update notification</p>`;
      text = `Voting update notification`;
  }

  return { subject, html, text };
}
