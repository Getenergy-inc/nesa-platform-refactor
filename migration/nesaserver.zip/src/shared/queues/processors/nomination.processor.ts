import { Job } from 'bull';
import { emailQueue } from '../queues';

export interface NominationJobData {
  type: 'nomination-submitted' | 'nomination-approved' | 'nomination-rejected';
  userId: string;
  email: string;
  nomineeName: string;
  categoryName: string;
  metadata?: any;
}

export const processNominationJob = async (job: Job<NominationJobData>) => {
  const { type, email, nomineeName, categoryName } = job.data;

  try {
    console.log(`🏆 Processing nomination job ${job.id} - ${type}`);

    const emailContent = generateNominationEmail(type, nomineeName, categoryName);

    await emailQueue.add(
      {
        to: email,
        subject: emailContent.subject,
        html: emailContent.html,
        text: emailContent.text,
      },
      {
        priority: 3,
      }
    );

    console.log(`✅ Nomination notification queued for ${email}`);
    return { success: true, type };
  } catch (error: any) {
    console.error(`❌ Failed to process nomination:`, error);
    throw new Error(`Nomination processing failed: ${error.message}`);
  }
};

function generateNominationEmail(type: string, nomineeName: string, categoryName: string) {
  let subject = '';
  let html = '';
  let text = '';

  switch (type) {
    case 'nomination-submitted':
      subject = `Nomination Submitted - ${nomineeName}`;
      html = `
        <h2>🏆 Nomination Submitted</h2>
        <p>Your nomination has been successfully submitted!</p>
        <p><strong>Nominee:</strong> ${nomineeName}</p>
        <p><strong>Category:</strong> ${categoryName}</p>
        <p>We'll review your nomination and get back to you soon.</p>
      `;
      text = `Nomination submitted for ${nomineeName} in ${categoryName}`;
      break;

    case 'nomination-approved':
      subject = `Nomination Approved - ${nomineeName}`;
      html = `
        <h2>✅ Nomination Approved</h2>
        <p>Great news! Your nomination has been approved.</p>
        <p><strong>Nominee:</strong> ${nomineeName}</p>
        <p><strong>Category:</strong> ${categoryName}</p>
      `;
      text = `Nomination approved for ${nomineeName} in ${categoryName}`;
      break;

    case 'nomination-rejected':
      subject = `Nomination Update - ${nomineeName}`;
      html = `
        <h2>📋 Nomination Update</h2>
        <p>Thank you for your nomination submission.</p>
        <p><strong>Nominee:</strong> ${nomineeName}</p>
        <p><strong>Category:</strong> ${categoryName}</p>
        <p>Unfortunately, this nomination doesn't meet our current criteria.</p>
      `;
      text = `Nomination update for ${nomineeName} in ${categoryName}`;
      break;

    default:
      subject = `Nomination Update`;
      html = `<p>Nomination update notification</p>`;
      text = `Nomination update notification`;
  }

  return { subject, html, text };
}
