import { Job } from 'bull';
import { emailQueue } from '../queues';

export interface OTPJobData {
  email: string;
  otp: string;
  firstName?: string;
  purpose: 'signup' | 'login' | 'password-reset' | 'email-verification';
}

export const processOTPJob = async (job: Job<OTPJobData>) => {
  const { email, otp, firstName, purpose } = job.data;

  try {
    console.log(`🔐 Processing OTP job ${job.id} for ${email}`);

    // Generate email content based on purpose
    const emailContent = generateOTPEmail(otp, firstName, purpose);

    // Add to email queue
    await emailQueue.add(
      {
        to: email,
        subject: emailContent.subject,
        html: emailContent.html,
        text: emailContent.text,
      },
      {
        priority: 1, // High priority for OTP emails
        attempts: 5,
      }
    );

    console.log(`✅ OTP email queued for ${email}`);
    return { success: true, email };
  } catch (error: any) {
    console.error(`❌ Failed to process OTP:`, error);
    throw new Error(`OTP processing failed: ${error.message}`);
  }
};

function generateOTPEmail(otp: string, firstName: string | undefined, purpose: string) {
  const purposeText = {
    signup: 'complete your registration',
    login: 'verify your login',
    'password-reset': 'reset your password',
    'email-verification': 'verify your email',
  }[purpose] || 'verify your account';

  const subject = `Your NESA-Africa OTP Code - ${otp}`;
  
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
        .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
        .otp-box { background: white; border: 2px dashed #667eea; padding: 20px; text-align: center; margin: 20px 0; border-radius: 8px; }
        .otp-code { font-size: 32px; font-weight: bold; color: #667eea; letter-spacing: 8px; }
        .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🔐 NESA-Africa</h1>
          <p>One-Time Password</p>
        </div>
        <div class="content">
          <p>Hello ${firstName || 'there'},</p>
          <p>Use the following OTP code to ${purposeText}:</p>
          <div class="otp-box">
            <div class="otp-code">${otp}</div>
          </div>
          <p><strong>This code will expire in 10 minutes.</strong></p>
          <p>If you didn't request this code, please ignore this email.</p>
          <div class="footer">
            <p>© ${new Date().getFullYear()} NESA-Africa. All rights reserved.</p>
          </div>
        </div>
      </div>
    </body>
    </html>
  `;

  const text = `
    Hello ${firstName || 'there'},
    
    Your OTP code to ${purposeText} is: ${otp}
    
    This code will expire in 10 minutes.
    
    If you didn't request this code, please ignore this email.
    
    © ${new Date().getFullYear()} NESA-Africa. All rights reserved.
  `;

  return { subject, html, text };
}
