import { Job } from 'bull';
import { emailQueue } from '../queues';

export interface PaymentJobData {
  type: 'payment-initiated' | 'payment-success' | 'payment-failed' | 'refund-processed';
  userId: string;
  email: string;
  amount: number;
  currency: string;
  reference: string;
  metadata?: any;
}

export const processPaymentJob = async (job: Job<PaymentJobData>) => {
  const { type, email, amount, currency, reference, metadata } = job.data;

  try {
    console.log(`💳 Processing payment job ${job.id} - ${type}`);

    // Generate email content based on payment type
    const emailContent = generatePaymentEmail(type, amount, currency, reference, metadata);

    // Add to email queue
    await emailQueue.add(
      {
        to: email,
        subject: emailContent.subject,
        html: emailContent.html,
        text: emailContent.text,
      },
      {
        priority: 2, // Medium-high priority
      }
    );

    console.log(`✅ Payment notification queued for ${email}`);
    return { success: true, type, reference };
  } catch (error: any) {
    console.error(`❌ Failed to process payment notification:`, error);
    throw new Error(`Payment processing failed: ${error.message}`);
  }
};

function generatePaymentEmail(
  type: string,
  amount: number,
  currency: string,
  reference: string,
  metadata: any
) {
  const formatAmount = (amt: number, curr: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: curr,
    }).format(amt / 100); // Assuming amount is in cents
  };

  let subject = '';
  let html = '';
  let text = '';

  switch (type) {
    case 'payment-success':
      subject = `Payment Successful - ${formatAmount(amount, currency)}`;
      html = `
        <h2>✅ Payment Successful</h2>
        <p>Your payment has been processed successfully.</p>
        <p><strong>Amount:</strong> ${formatAmount(amount, currency)}</p>
        <p><strong>Reference:</strong> ${reference}</p>
        <p>Thank you for your payment!</p>
      `;
      text = `Payment Successful\n\nAmount: ${formatAmount(amount, currency)}\nReference: ${reference}`;
      break;

    case 'payment-failed':
      subject = `Payment Failed - ${formatAmount(amount, currency)}`;
      html = `
        <h2>❌ Payment Failed</h2>
        <p>Unfortunately, your payment could not be processed.</p>
        <p><strong>Amount:</strong> ${formatAmount(amount, currency)}</p>
        <p><strong>Reference:</strong> ${reference}</p>
        <p>Please try again or contact support.</p>
      `;
      text = `Payment Failed\n\nAmount: ${formatAmount(amount, currency)}\nReference: ${reference}`;
      break;

    default:
      subject = `Payment Update - ${reference}`;
      html = `<p>Payment update for reference: ${reference}</p>`;
      text = `Payment update for reference: ${reference}`;
  }

  return { subject, html, text };
}
