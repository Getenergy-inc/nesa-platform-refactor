import { Job } from 'bull';
import nodemailer from 'nodemailer';
import { config } from '../../../config';

export interface EmailJobData {
  to: string;
  subject: string;
  html: string;
  text?: string;
  from?: string;
}

// Create transporter
const transporter = nodemailer.createTransport({
  host: config.smtp.host,
  port: config.smtp.port,
  secure: false,
  auth: {
    user: config.smtp.user,
    pass: config.smtp.pass,
  },
});

export const processEmailJob = async (job: Job<EmailJobData>) => {
  const { to, subject, html, text, from } = job.data;

  try {
    console.log(`📧 Processing email job ${job.id} to ${to}`);

    const info = await transporter.sendMail({
      from: from || `"${config.email.fromName}" <${config.email.fromEmail}>`,
      to,
      subject,
      text,
      html,
    });

    console.log(`✅ Email sent successfully: ${info.messageId}`);
    return { success: true, messageId: info.messageId };
  } catch (error: any) {
    console.error(`❌ Failed to send email:`, error);
    throw new Error(`Email sending failed: ${error.message}`);
  }
};
