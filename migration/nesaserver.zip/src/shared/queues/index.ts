// Export queues
export * from './queues';

// Export processors
export { processEmailJob } from './processors/email.processor';
export { processOTPJob } from './processors/otp.processor';
export { processPaymentJob } from './processors/payment.processor';
export { processVotingJob } from './processors/voting.processor';
export { processNotificationJob } from './processors/notification.processor';
export { processNominationJob } from './processors/nomination.processor';
export { processWalletJob } from './processors/wallet.processor';

// Export processor types
export type { EmailJobData } from './processors/email.processor';
export type { OTPJobData } from './processors/otp.processor';
export type { PaymentJobData } from './processors/payment.processor';
export type { VotingJobData } from './processors/voting.processor';
export type { NotificationJobData } from './processors/notification.processor';
export type { NominationJobData } from './processors/nomination.processor';
export type { WalletJobData } from './processors/wallet.processor';

// Export workers
export { initializeWorkers } from './workers';

// Export board
export { serverAdapter, bullBoard } from './board';

// Export config
export * from './config/queue.config';

// Export services
export { queueService } from './services/queueService';
export { default as QueueService } from './services/queueService';
