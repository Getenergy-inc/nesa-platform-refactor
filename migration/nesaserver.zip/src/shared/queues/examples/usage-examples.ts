/**
 * Queue Usage Examples
 * 
 * This file demonstrates how to use the queue system in your services
 */

import { queueService } from '../services/queueService';

// ============================================
// Example 1: Send OTP Email
// ============================================
export async function sendOTPExample() {
  await queueService.sendOTP({
    email: 'user@example.com',
    otp: '123456',
    firstName: 'John',
    purpose: 'signup',
  });
  
  console.log('✅ OTP email queued successfully');
}

// ============================================
// Example 2: Send Payment Notification
// ============================================
export async function sendPaymentNotificationExample() {
  await queueService.processPayment({
    type: 'payment-success',
    userId: 'user-123',
    email: 'user@example.com',
    amount: 50000, // Amount in cents (500.00)
    currency: 'NGN',
    reference: 'PAY-123456',
    metadata: {
      description: 'Membership payment',
    },
  });
  
  console.log('✅ Payment notification queued successfully');
}

// ============================================
// Example 3: Send Voting Notification
// ============================================
export async function sendVotingNotificationExample() {
  await queueService.processVoting({
    type: 'vote-cast',
    userId: 'user-123',
    email: 'user@example.com',
    nomineeId: 'nominee-456',
    nomineeName: 'Dr. Jane Smith',
    categoryId: 'cat-789',
    categoryName: 'Best Teacher of the Year',
  });
  
  console.log('✅ Voting notification queued successfully');
}

// ============================================
// Example 4: Send Wallet Transaction Notification
// ============================================
export async function sendWalletNotificationExample() {
  await queueService.processWallet({
    type: 'wallet-credited',
    userId: 'user-123',
    email: 'user@example.com',
    amount: 10000, // 100.00 AGC
    currency: 'AGC',
    balance: 50000, // New balance: 500.00 AGC
    reference: 'WALLET-123456',
  });
  
  console.log('✅ Wallet notification queued successfully');
}

// ============================================
// Example 5: Send Direct Email
// ============================================
export async function sendDirectEmailExample() {
  await queueService.sendEmail({
    to: 'user@example.com',
    subject: 'Welcome to NESA-Africa',
    html: '<h1>Welcome!</h1><p>Thank you for joining us.</p>',
    text: 'Welcome! Thank you for joining us.',
  });
  
  console.log('✅ Email queued successfully');
}

// ============================================
// Example 6: Get Queue Statistics
// ============================================
export async function getQueueStatsExample() {
  const stats = await queueService.getQueueStats();
  console.log('📊 Queue Statistics:', stats);
  return stats;
}

// ============================================
// Integration Example: In Your Auth Service
// ============================================
export async function authServiceIntegrationExample() {
  // In your signup service, replace direct email sending with:
  
  // OLD WAY (blocking):
  // await emailService.sendOTP(email, otp);
  
  // NEW WAY (non-blocking with queue):
  await queueService.sendOTP({
    email: 'newuser@example.com',
    otp: '123456',
    firstName: 'John',
    purpose: 'signup',
  });
  
  // The email will be sent asynchronously by the queue worker
  // Your API response will be faster!
}

// ============================================
// Integration Example: In Your Payment Service
// ============================================
export async function paymentServiceIntegrationExample() {
  // After successful payment processing:
  
  await queueService.processPayment({
    type: 'payment-success',
    userId: 'user-123',
    email: 'user@example.com',
    amount: 50000,
    currency: 'NGN',
    reference: 'PAY-123456',
  });
  
  // Payment notification will be sent asynchronously
}

// ============================================
// Integration Example: In Your Voting Service
// ============================================
export async function votingServiceIntegrationExample() {
  // After vote is recorded:
  
  await queueService.processVoting({
    type: 'vote-cast',
    userId: 'user-123',
    email: 'user@example.com',
    nomineeId: 'nominee-456',
    nomineeName: 'Dr. Jane Smith',
    categoryId: 'cat-789',
    categoryName: 'Best Teacher of the Year',
  });
  
  // Voting confirmation will be sent asynchronously
}
