import {
  emailQueue,
  otpQueue,
  paymentQueue,
  votingQueue,
  notificationQueue,
  nominationQueue,
  walletQueue,
} from "./queues";

import { processEmailJob } from "./processors/email.processor";
import { processOTPJob } from "./processors/otp.processor";
import { processPaymentJob } from "./processors/payment.processor";
import { processVotingJob } from "./processors/voting.processor";
import { processNotificationJob } from "./processors/notification.processor";
import { processNominationJob } from "./processors/nomination.processor";
import { processWalletJob } from "./processors/wallet.processor";

// Register processors
export const initializeWorkers = () => {
  console.log("🚀 Initializing queue workers...");

  // Email queue processor
  emailQueue.process(5, processEmailJob); // Process 5 jobs concurrently

  // OTP queue processor
  otpQueue.process(10, processOTPJob); // Process 10 jobs concurrently

  // Payment queue processor
  paymentQueue.process(3, processPaymentJob);

  // Voting queue processor
  votingQueue.process(5, processVotingJob);

  // Notification queue processor
  notificationQueue.process(10, processNotificationJob);

  // Nomination queue processor
  nominationQueue.process(5, processNominationJob);

  // Wallet queue processor
  walletQueue.process(5, processWalletJob);

  console.log("✅ All queue workers initialized");
};

export default initializeWorkers;
