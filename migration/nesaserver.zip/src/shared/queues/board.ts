import { createBullBoard } from '@bull-board/api';
import { BullAdapter } from '@bull-board/api/bullAdapter';
import { ExpressAdapter } from '@bull-board/express';
import {
  emailQueue,
  otpQueue,
  paymentQueue,
  votingQueue,
  notificationQueue,
  nominationQueue,
  walletQueue,
} from './queues';

// Create Express adapter for Bull Board
export const serverAdapter = new ExpressAdapter();
serverAdapter.setBasePath('/admin/queues');

// Create Bull Board
export const bullBoard = createBullBoard({
  queues: [
    new BullAdapter(emailQueue),
    new BullAdapter(otpQueue),
    new BullAdapter(paymentQueue),
    new BullAdapter(votingQueue),
    new BullAdapter(notificationQueue),
    new BullAdapter(nominationQueue),
    new BullAdapter(walletQueue),
  ],
  serverAdapter,
});

export default serverAdapter;
