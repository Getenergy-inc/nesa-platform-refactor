import {
  emailQueue,
  otpQueue,
  paymentQueue,
  votingQueue,
  notificationQueue,
  nominationQueue,
  walletQueue,
} from '../queues';
import type { EmailJobData } from '../processors/email.processor';
import type { OTPJobData } from '../processors/otp.processor';
import type { PaymentJobData } from '../processors/payment.processor';
import type { VotingJobData } from '../processors/voting.processor';
import type { NotificationJobData } from '../processors/notification.processor';
import type { NominationJobData } from '../processors/nomination.processor';
import type { WalletJobData } from '../processors/wallet.processor';

/**
 * Queue Service - Centralized service for adding jobs to queues
 */
class QueueService {
  /**
   * Send OTP email
   */
  async sendOTP(data: OTPJobData) {
    return await otpQueue.add(data, {
      priority: 1, // High priority
      attempts: 5,
      backoff: {
        type: 'exponential',
        delay: 2000,
      },
    });
  }

  /**
   * Send email directly
   */
  async sendEmail(data: EmailJobData) {
    return await emailQueue.add(data, {
      priority: 2,
      attempts: 3,
    });
  }

  /**
   * Process payment notification
   */
  async processPayment(data: PaymentJobData) {
    return await paymentQueue.add(data, {
      priority: 2,
      attempts: 3,
    });
  }

  /**
   * Process voting notification
   */
  async processVoting(data: VotingJobData) {
    return await votingQueue.add(data, {
      priority: 3,
      attempts: 2,
    });
  }

  /**
   * Send notification
   */
  async sendNotification(data: NotificationJobData) {
    return await notificationQueue.add(data, {
      priority: 3,
      attempts: 2,
    });
  }

  /**
   * Process nomination
   */
  async processNomination(data: NominationJobData) {
    return await nominationQueue.add(data, {
      priority: 3,
      attempts: 2,
    });
  }

  /**
   * Process wallet transaction
   */
  async processWallet(data: WalletJobData) {
    return await walletQueue.add(data, {
      priority: 2,
      attempts: 3,
    });
  }

  /**
   * Get queue statistics
   */
  async getQueueStats() {
    const queues = [
      { name: 'email', queue: emailQueue },
      { name: 'otp', queue: otpQueue },
      { name: 'payment', queue: paymentQueue },
      { name: 'voting', queue: votingQueue },
      { name: 'notification', queue: notificationQueue },
      { name: 'nomination', queue: nominationQueue },
      { name: 'wallet', queue: walletQueue },
    ];

    const stats = await Promise.all(
      queues.map(async ({ name, queue }) => {
        const [waiting, active, completed, failed, delayed] = await Promise.all([
          queue.getWaitingCount(),
          queue.getActiveCount(),
          queue.getCompletedCount(),
          queue.getFailedCount(),
          queue.getDelayedCount(),
        ]);

        return {
          name,
          waiting,
          active,
          completed,
          failed,
          delayed,
          total: waiting + active + completed + failed + delayed,
        };
      })
    );

    return stats;
  }

  /**
   * Clean old jobs from all queues
   */
  async cleanOldJobs(grace: number = 24 * 60 * 60 * 1000) {
    const queues = [
      emailQueue,
      otpQueue,
      paymentQueue,
      votingQueue,
      notificationQueue,
      nominationQueue,
      walletQueue,
    ];

    const results = await Promise.all(
      queues.map(async (queue) => {
        const cleaned = await queue.clean(grace, 'completed');
        return { queue: queue.name, cleaned };
      })
    );

    return results;
  }
}

export const queueService = new QueueService();
export default queueService;
