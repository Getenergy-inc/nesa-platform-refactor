import { QueueOptions } from "bull";
import { config } from "../../../config";

export const defaultQueueOptions: QueueOptions = {
  redis: config.redis.url,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: "exponential",
      delay: 2000,
    },
    removeOnComplete: 100, // Keep last 100 completed jobs
    removeOnFail: 200, // Keep last 200 failed jobs
  },
  settings: {
    lockDuration: 30000, // 30 seconds
    stalledInterval: 30000,
    maxStalledCount: 1,
  },
};

export const queueNames = {
  EMAIL: "email-queue",
  OTP: "otp-queue",
  PAYMENT: "payment-queue",
  VOTING: "voting-queue",
  NOTIFICATION: "notification-queue",
  NOMINATION: "nomination-queue",
  WALLET: "wallet-queue",
} as const;

export type QueueName = typeof queueNames[keyof typeof queueNames];
