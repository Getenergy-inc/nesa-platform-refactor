import Queue from "bull";
import { defaultQueueOptions, queueNames } from "./config/queue.config";

// Create all queues
export const emailQueue = new Queue(queueNames.EMAIL, defaultQueueOptions);
export const otpQueue = new Queue(queueNames.OTP, defaultQueueOptions);
export const paymentQueue = new Queue(queueNames.PAYMENT, defaultQueueOptions);
export const votingQueue = new Queue(queueNames.VOTING, defaultQueueOptions);
export const notificationQueue = new Queue(
  queueNames.NOTIFICATION,
  defaultQueueOptions
);
export const nominationQueue = new Queue(
  queueNames.NOMINATION,
  defaultQueueOptions
);
export const walletQueue = new Queue(queueNames.WALLET, defaultQueueOptions);

// Export all queues as an array for easy iteration
export const allQueues = [
  emailQueue,
  otpQueue,
  paymentQueue,
  votingQueue,
  notificationQueue,
  nominationQueue,
  walletQueue,
];

// Graceful shutdown
export const closeQueues = async () => {
  console.log("🔄 Closing all queues...");
  await Promise.all(allQueues.map((queue) => queue.close()));
  console.log("✅ All queues closed");
};

// Queue event listeners for monitoring
allQueues.forEach((queue) => {
  queue.on("error", (error) => {
    console.error(`❌ Queue ${queue.name} error:`, error);
  });

  queue.on("waiting", (jobId) => {
    console.log(`⏳ Job ${jobId} is waiting in ${queue.name}`);
  });

  queue.on("active", (job) => {
    console.log(`🔄 Job ${job.id} is now active in ${queue.name}`);
  });

  queue.on("completed", (job) => {
    console.log(`✅ Job ${job.id} completed in ${queue.name}`);
  });

  queue.on("failed", (job, err) => {
    console.error(`❌ Job ${job?.id} failed in ${queue.name}:`, err.message);
  });

  queue.on("stalled", (job) => {
    console.warn(`⚠️ Job ${job.id} stalled in ${queue.name}`);
  });
});

export default {
  emailQueue,
  otpQueue,
  paymentQueue,
  votingQueue,
  notificationQueue,
  nominationQueue,
  walletQueue,
};
