import bcrypt from 'bcryptjs';
import { prisma } from '../postgresql';
import { config } from '@/config';
import logger from '@/shared/utils/logger';

export async function createSuperAdmin() {
  try {
    // Check if super admin already exists
    const existingSuperAdmin = await prisma.user.findFirst({
      where: { role: 'SUPER_ADMIN' }
    });

    if (existingSuperAdmin) {
      logger.info('Super admin already exists');
      return existingSuperAdmin;
    }

    // Super admin credentials from environment variables
    const superAdminEmail = process.env.SUPER_ADMIN_EMAIL || 'admin@nesa-africa.com';
    const superAdminPassword = process.env.SUPER_ADMIN_PASSWORD || 'SuperAdmin123!';
    const superAdminFirstName = process.env.SUPER_ADMIN_FIRST_NAME || 'Super';
    const superAdminLastName = process.env.SUPER_ADMIN_LAST_NAME || 'Admin';

    // Hash password
    const hashedPassword = await bcrypt.hash(superAdminPassword, config.security.bcryptSaltRounds);

    // Create super admin user
    const superAdmin = await prisma.user.create({
      data: {
        email: superAdminEmail.toLowerCase(),
        password: hashedPassword,
        firstName: superAdminFirstName,
        lastName: superAdminLastName,
        fullName: `${superAdminFirstName} ${superAdminLastName}`,
        role: 'SUPER_ADMIN',
        accountType: 'INDIVIDUAL',
        isVerified: true,
        emailVerifiedAt: new Date(),
        isActive: true,
        country: 'Nigeria', // Default country
        preferredLanguage: 'EN'
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        createdAt: true
      }
    });

    // Create admin sections for super admin (all sections with full access)
    const allSections = [
      'USER_MANAGEMENT',
      'NRC_VOLUNTEERS',
      'NOMINATIONS',
      'JUDGES',
      'VOTING_SYSTEM',
      'WALLET_MANAGEMENT',
      'CHAPTER_MANAGEMENT',
      'FILE_MANAGEMENT',
      'NOTIFICATIONS',
      'ANALYTICS',
      'SYSTEM_SETTINGS',
      'ALL_SECTIONS'
    ] as const;

    const allPermissions = [
      'READ',
      'WRITE',
      'DELETE',
      'MANAGE_USERS',
      'MANAGE_PERMISSIONS',
      'VIEW_ANALYTICS',
      'SYSTEM_CONFIG',
      'FULL_ACCESS'
    ] as const;

    for (const section of allSections) {
      await prisma.adminSection.create({
        data: {
          userId: superAdmin.id,
          section,
          permissions: [...allPermissions],
          assignedBy: superAdmin.id // Self-assigned
        }
      });
    }

    logger.info('Super admin created successfully:', {
      id: superAdmin.id,
      email: superAdmin.email,
      name: `${superAdmin.firstName} ${superAdmin.lastName}`
    });

    // Log the credentials for initial setup (only in development)
    if (config.nodeEnv === 'development') {
      logger.info('Super Admin Credentials:', {
        email: superAdminEmail,
        password: superAdminPassword,
        note: 'Please change the password after first login'
      });
    }

    return superAdmin;
  } catch (error) {
    logger.error('Failed to create super admin:', error);
    throw error;
  }
}

// Function to update super admin password
export async function updateSuperAdminPassword(newPassword: string) {
  try {
    const superAdmin = await prisma.user.findFirst({
      where: { role: 'SUPER_ADMIN' }
    });

    if (!superAdmin) {
      throw new Error('Super admin not found');
    }

    const hashedPassword = await bcrypt.hash(newPassword, config.security.bcryptSaltRounds);

    await prisma.user.update({
      where: { id: superAdmin.id },
      data: {
        password: hashedPassword,
        // Clear refresh tokens to force re-login
        refreshToken: null,
        refreshTokenExpires: null
      }
    });

    logger.info('Super admin password updated successfully');
  } catch (error) {
    logger.error('Failed to update super admin password:', error);
    throw error;
  }
}

// Function to create additional super admin
export async function createAdditionalSuperAdmin(
  email: string,
  password: string,
  firstName: string,
  lastName: string,
  createdBy: string
) {
  try {
    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email: email.toLowerCase() }
    });

    if (existingUser) {
      throw new Error('User with this email already exists');
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, config.security.bcryptSaltRounds);

    // Create super admin user
    const superAdmin = await prisma.user.create({
      data: {
        email: email.toLowerCase(),
        password: hashedPassword,
        firstName,
        lastName,
        fullName: `${firstName} ${lastName}`,
        role: 'SUPER_ADMIN',
        accountType: 'INDIVIDUAL',
        isVerified: true,
        emailVerifiedAt: new Date(),
        isActive: true,
        invitedBy: createdBy,
        invitedAt: new Date()
      }
    });

    // Create admin sections for super admin
    const allSections = [
      'USER_MANAGEMENT',
      'NRC_VOLUNTEERS',
      'NOMINATIONS',
      'JUDGES',
      'VOTING_SYSTEM',
      'WALLET_MANAGEMENT',
      'CHAPTER_MANAGEMENT',
      'FILE_MANAGEMENT',
      'NOTIFICATIONS',
      'ANALYTICS',
      'SYSTEM_SETTINGS',
      'ALL_SECTIONS'
    ] as const;

    const allPermissions = [
      'READ',
      'WRITE',
      'DELETE',
      'MANAGE_USERS',
      'MANAGE_PERMISSIONS',
      'VIEW_ANALYTICS',
      'SYSTEM_CONFIG',
      'FULL_ACCESS'
    ] as const;

    for (const section of allSections) {
      await prisma.adminSection.create({
        data: {
          userId: superAdmin.id,
          section,
          permissions: [...allPermissions],
          assignedBy: createdBy
        }
      });
    }

    logger.info('Additional super admin created successfully:', {
      id: superAdmin.id,
      email: superAdmin.email,
      name: `${superAdmin.firstName} ${superAdmin.lastName}`,
      createdBy
    });

    return superAdmin;
  } catch (error) {
    logger.error('Failed to create additional super admin:', error);
    throw error;
  }
}
