import { prisma } from '../postgresql';
import { mongodb } from '../mongodb';
import { createSuperAdmin } from './createSuperAdmin';
import logger from '@/shared/utils/logger';

async function main() {
  try {
    logger.info('Starting database seeding...');

    // Connect to databases
    await prisma.connect();
    await mongodb.connect();

    // Create super admin
    await createSuperAdmin();

    // Add more seeding functions here as needed
    // await seedCategories();
    // await seedCountries();
    // await seedDefaultSettings();

    logger.info('Database seeding completed successfully');
  } catch (error) {
    logger.error('Database seeding failed:', error);
    process.exit(1);
  } finally {
    await prisma.disconnect();
    await mongodb.disconnect();
  }
}

// Run seeding if this file is executed directly
if (require.main === module) {
  main();
}

export default main;
