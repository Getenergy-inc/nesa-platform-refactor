import { PrismaClient } from '@prisma/client';
import { config } from '@/config';
import logger from '@/shared/utils/logger';

// Extend PrismaClient with custom methods if needed
class ExtendedPrismaClient extends PrismaClient {
  private isConnected = false;
  private isDisconnected = false;
  private keepAliveTimer: NodeJS.Timeout | undefined;

  constructor() {
    super({
      datasources: {
        db: {
          url: config.database.postgresql.url
        }
      },
      log: config.nodeEnv === 'development' ? ['query', 'info', 'warn', 'error'] : ['error']
    });

    // Global middleware to retry on transient Neon/connection errors
    this.$use(async (params, next) => {
      let attempt = 0;
      // At most 1 retry per operation
      for (;;) {
        try {
          return await next(params);
        } catch (error) {
          if (attempt < 1 && this.isTransientError(error)) {
            attempt++;
            logger.warn('🔄 Transient DB error detected. Reconnecting and retrying once...');
            this.isConnected = false;
            try {
              await this.connect(3, 2000);
            } catch (e) {
              // If reconnect also fails, surface original error
              throw error;
            }
            continue;
          }
          throw error;
        }
      }
    });

    // Keep connection warm to avoid Neon idle disconnects
    if (config.nodeEnv !== 'test') {
      this.keepAliveTimer = setInterval(async () => {
        try {
          await this.$queryRaw`SELECT 1`;
        } catch (e) {
          // Do not crash on keepalive failures; normal operations will attempt reconnect
          logger.warn('PostgreSQL keepalive ping failed; connection will be retried on next query.');
        }
      }, 60_000);
      // Allow process to exit naturally
      // @ts-ignore - unref may not exist in some environments
      this.keepAliveTimer?.unref?.();
    }
  }

  private isTransientError(error: any): boolean {
    const code = error?.code as string | undefined;
    const message = String(error?.message || '');
    // Common transient cases for Neon/pgbouncer/network interruptions
    return (
      code === 'P1001' || // The database server was reached but timed out
      code === 'P1002' || // The database server timed out
      code === 'P1008' || // Operations timed out
      message.includes('Connection terminated') ||
      message.includes('ECONNRESET') ||
      message.includes('read ECONNRESET') ||
      message.includes('server closed the connection unexpectedly') ||
      message.includes('timeout') ||
      message.includes('SSL connection has been closed')
    );
  }

  async connect(retries = 5, delay = 5000) {
    if (this.isConnected) {
      return;
    }

    let attempts = 0;

    while (attempts < retries) {
      try {
        await this.$connect();
        this.isConnected = true;
        logger.info('✅ PostgreSQL connected successfully');
        return;
      } catch (error) {
        attempts++;
        logger.error(`❌ PostgreSQL connection failed (attempt ${attempts}/${retries}):`, error);

        if (attempts >= retries) {
          logger.error('❌ All PostgreSQL connection attempts failed');
          throw error;
        }

        logger.info(`Retrying in ${delay / 1000} seconds...`);
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }
  }

  async disconnect() {
    if (this.isDisconnected || !this.isConnected) {
      return;
    }

    try {
      if (this.keepAliveTimer) {
        clearInterval(this.keepAliveTimer);
        this.keepAliveTimer = undefined;
      }
      await this.$disconnect();
      this.isDisconnected = true;
      this.isConnected = false;
      logger.info('✅ PostgreSQL disconnected successfully');
    } catch (error) {
      logger.error('❌ PostgreSQL disconnection failed:', error);
      throw error;
    }
  }

  async healthCheck(): Promise<boolean> {
    try {
      await this.$queryRaw`SELECT 1`;
      return true;
    } catch (error) {
      logger.error('PostgreSQL health check failed:', error);
      return false;
    }
  }
}

// Create singleton instance with type assertion for application model
const prismaBase = new ExtendedPrismaClient();
const prisma = prismaBase as typeof prismaBase & {
  application: any; // Type assertion to include application model
};

// Handle graceful shutdown - only set up once
let shutdownHandlersSet = false;

if (!shutdownHandlersSet) {
  shutdownHandlersSet = true;
  
  process.on('beforeExit', async () => {
    await prisma.disconnect();
  });

  process.on('SIGINT', async () => {
    await prisma.disconnect();
    process.exit(0);
  });

  process.on('SIGTERM', async () => {
    await prisma.disconnect();
    process.exit(0);
  });
}

export { prisma };
export default prisma;
