import { prisma } from '@/shared/utils/prisma';
import logger from '@/shared/utils/logger';
import { ValidationError, NotFoundError, ConflictError } from '@/shared/utils/errors';
import crypto from 'crypto';

export interface CreateNomineeInput {
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  organization?: string;
  country: string;
  region?: string;
  website?: string;
  linkedinProfile?: string;
  awardCategory: string; // 'blue-garnet', 'gold-certificate', 'platinum-certificate'
  subcategory: string;
  profileImageUrl?: string;
  profileImagePublicId?: string;
}

export interface UpdateNomineeInput {
  firstName?: string;
  lastName?: string;
  phone?: string;
  organization?: string;
  region?: string;
  website?: string;
  linkedinProfile?: string;
  profileImageUrl?: string;
  profileImagePublicId?: string;
}

export interface CreateNominationRecordInput {
  nomineeId: string;
  nominatorId?: string;
  nominatorEmail: string;
  nominatorName: string;
  nominatorPhone?: string;
  nominatorMessage?: string;
  awardCategory: string;
  subcategory: string;
  nominationReason: string;
}

/**
 * NomineeService - Manages nominee records and nomination tracking
 */
class NomineeService {
  /**
   * Create a new nominee
   */
  async createNominee(input: CreateNomineeInput) {
    try {
      // Check if nominee with email already exists
      const existingNominee = await prisma.nominee.findUnique({
        where: { email: input.email }
      });

      if (existingNominee) {
        throw new ConflictError(`Nominee with email ${input.email} already exists`);
      }

      // Create nominee
      const nominee = await prisma.nominee.create({
        data: {
          firstName: input.firstName,
          lastName: input.lastName,
          fullName: `${input.firstName} ${input.lastName}`,
          email: input.email,
          phone: input.phone,
          organization: input.organization,
          country: input.country,
          region: input.region,
          website: input.website,
          linkedinProfile: input.linkedinProfile,
          awardCategory: input.awardCategory,
          subcategory: input.subcategory,
          profileImageUrl: input.profileImageUrl,
          profileImagePublicId: input.profileImagePublicId,
          acceptanceStatus: 'PENDING' as any
        }
      });

      logger.info(`Nominee created: ${nominee.id} (${nominee.email})`);
      return nominee;
    } catch (error) {
      logger.error('Failed to create nominee:', error);
      throw error;
    }
  }

  /**
   * Get nominee by ID
   */
  async getNomineeById(id: string) {
    try {
      const nominee = await prisma.nominee.findUnique({
        where: { id },
        include: {
          nominations: {
            where: { status: 'APPROVED' },
            select: { id: true, nominatorName: true, submittedAt: true }
          },
          supportingDocuments: true,
          certificates: true
        }
      });

      if (!nominee) {
        throw new NotFoundError(`Nominee with ID ${id} not found`);
      }

      return nominee;
    } catch (error) {
      logger.error('Failed to get nominee:', error);
      throw error;
    }
  }

  /**
   * Get nominee by email
   */
  async getNomineeByEmail(email: string) {
    try {
      const nominee = await prisma.nominee.findUnique({
        where: { email },
        include: {
          nominations: {
            where: { status: 'APPROVED' }
          },
          supportingDocuments: true,
          certificates: true
        }
      });

      if (!nominee) {
        throw new NotFoundError(`Nominee with email ${email} not found`);
      }

      return nominee;
    } catch (error) {
      logger.error('Failed to get nominee by email:', error);
      throw error;
    }
  }

  /**
   * Get all nominees for a category/subcategory
   */
  async getNomineesByCategory(
    awardCategory: string,
    subcategory?: string,
    skip = 0,
    take = 20
  ) {
    try {
      const where: any = {
        awardCategory,
        acceptanceStatus: 'ACCEPTED' // Only show accepted nominees publicly
      };

      if (subcategory) {
        where.subcategory = subcategory;
      }

      const [nominees, total] = await Promise.all([
        prisma.nominee.findMany({
          where,
          skip,
          take,
          orderBy: { approvedNominationCount: 'desc' },
          include: {
            nominations: {
              where: { status: 'APPROVED' },
              select: { id: true }
            },
            certificates: {
              select: { certificateNumber: true, issuedAt: true }
            }
          }
        }),
        prisma.nominee.count({ where })
      ]);

      return {
        data: nominees,
        pagination: {
          total,
          skip,
          take,
          pages: Math.ceil(total / take)
        }
      };
    } catch (error) {
      logger.error('Failed to get nominees by category:', error);
      throw error;
    }
  }

  /**
   * Update nominee information
   */
  async updateNominee(id: string, input: UpdateNomineeInput) {
    try {
      const nominee = await prisma.nominee.update({
        where: { id },
        data: {
          ...input,
          fullName: input.firstName && input.lastName
            ? `${input.firstName} ${input.lastName}`
            : undefined
        }
      });

      logger.info(`Nominee updated: ${id}`);
      return nominee;
    } catch (error) {
      if (error instanceof Error && error.message.includes('not found')) {
        throw new NotFoundError(`Nominee with ID ${id} not found`);
      }
      logger.error('Failed to update nominee:', error);
      throw error;
    }
  }

  /**
   * Create an acceptance token for nominee
   */
  async generateAcceptanceToken(nomineeId: string) {
    try {
      const nominee = await prisma.nominee.findUnique({
        where: { id: nomineeId }
      });

      if (!nominee) {
        throw new NotFoundError(`Nominee with ID ${nomineeId} not found`);
      }

      const token = crypto.randomBytes(32).toString('hex');
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 7); // Token valid for 7 days

      const updated = await prisma.nominee.update({
        where: { id: nomineeId },
        data: {
          acceptanceToken: token,
          acceptanceTokenExpires: expiresAt
        }
      });

      logger.info(`Acceptance token generated for nominee: ${nomineeId}`);
      return {
        token,
        expiresAt,
        acceptanceUrl: `${process.env.FRONTEND_URL}/nominees/accept?token=${token}`
      };
    } catch (error) {
      logger.error('Failed to generate acceptance token:', error);
      throw error;
    }
  }

  /**
   * Accept nomination by nominee
   */
  async acceptNomination(token: string) {
    try {
      const nominee = await prisma.nominee.findUnique({
        where: { acceptanceToken: token }
      });

      if (!nominee) {
        throw new NotFoundError('Invalid or expired acceptance token');
      }

      if (!nominee.acceptanceTokenExpires || nominee.acceptanceTokenExpires < new Date()) {
        throw new ValidationError('Acceptance token has expired');
      }

      const updated = await prisma.nominee.update({
        where: { id: nominee.id },
        data: {
          acceptanceStatus: 'ACCEPTED' as any,
          acceptedAt: new Date(),
          acceptanceToken: null,
          acceptanceTokenExpires: null
        }
      });

      logger.info(`Nominee accepted nomination: ${nominee.id}`);
      return updated;
    } catch (error) {
      logger.error('Failed to accept nomination:', error);
      throw error;
    }
  }

  /**
   * Decline nomination by nominee
   */
  async declineNomination(token: string, reason?: string) {
    try {
      const nominee = await prisma.nominee.findUnique({
        where: { acceptanceToken: token }
      });

      if (!nominee) {
        throw new NotFoundError('Invalid or expired acceptance token');
      }

      if (!nominee.acceptanceTokenExpires || nominee.acceptanceTokenExpires < new Date()) {
        throw new ValidationError('Acceptance token has expired');
      }

      const updated = await prisma.nominee.update({
        where: { id: nominee.id },
        data: {
          acceptanceStatus: 'DECLINED' as any,
          declinedAt: new Date(),
          declineReason: reason,
          acceptanceToken: null,
          acceptanceTokenExpires: null
        }
      });

      logger.info(`Nominee declined nomination: ${nominee.id}`);
      return updated;
    } catch (error) {
      logger.error('Failed to decline nomination:', error);
      throw error;
    }
  }

  /**
   * Create a nomination record
   */
  async createNominationRecord(input: CreateNominationRecordInput) {
    try {
      // Verify nominee exists
      const nominee = await prisma.nominee.findUnique({
        where: { id: input.nomineeId }
      });

      if (!nominee) {
        throw new NotFoundError(`Nominee with ID ${input.nomineeId} not found`);
      }

      // Check for duplicate nominations from same nominator
      if (input.nominatorEmail) {
        const existing = await prisma.nominationRecord.findFirst({
          where: {
            nomineeId: input.nomineeId,
            nominatorEmail: input.nominatorEmail,
            status: 'APPROVED'
          }
        });

        if (existing) {
          throw new ConflictError('You have already nominated this person');
        }
      }

      const nominationRecord = await prisma.nominationRecord.create({
        data: {
          nomineeId: input.nomineeId,
          nominatorId: input.nominatorId,
          nominatorEmail: input.nominatorEmail,
          nominatorName: input.nominatorName,
          nominatorPhone: input.nominatorPhone,
          nominatorMessage: input.nominatorMessage,
          awardCategory: input.awardCategory,
          subcategory: input.subcategory,
          nominationReason: input.nominationReason,
          status: 'PENDING' as any
        }
      });

      // Update nominee's nominator list (for deduplication)
      if (!nominee.nominatorEmails.includes(input.nominatorEmail)) {
        await prisma.nominee.update({
          where: { id: input.nomineeId },
          data: {
            nominatorEmails: [...nominee.nominatorEmails, input.nominatorEmail]
          }
        });
      }

      logger.info(`Nomination record created: ${nominationRecord.id}`);
      return nominationRecord;
    } catch (error) {
      logger.error('Failed to create nomination record:', error);
      throw error;
    }
  }

  /**
   * Approve a nomination and increment nomination count
   */
  async approveNomination(nominationRecordId: string, approvedBy: string) {
    try {
      const nominationRecord = await prisma.nominationRecord.findUnique({
        where: { id: nominationRecordId }
      });

      if (!nominationRecord) {
        throw new NotFoundError(`Nomination record with ID ${nominationRecordId} not found`);
      }

      // Update nomination status
      const updated = await prisma.nominationRecord.update({
        where: { id: nominationRecordId },
        data: {
          status: 'APPROVED' as any,
          approvedAt: new Date(),
          approvedBy,
          emailSent: true,
          emailSentAt: new Date()
        }
      });

      // Increment nominee's approval count
      const nominee = await prisma.nominee.findUnique({
        where: { id: nominationRecord.nomineeId }
      });

      if (nominee) {
        const newApprovedCount = nominee.approvedNominationCount + 1;

        await prisma.nominee.update({
          where: { id: nominationRecord.nomineeId },
          data: {
            nominationCount: { increment: 1 },
            approvedNominationCount: { increment: 1 }
          }
        });

        // Check if threshold for certificate reached
        if (newApprovedCount === 10) {
          logger.info(`Certificate threshold reached for nominee: ${nominationRecord.nomineeId}`);
          // Trigger certificate generation asynchronously
          this.triggerCertificateGeneration(nominationRecord.nomineeId, nominee, newApprovedCount)
            .catch(error => {
              logger.error('Failed to trigger certificate generation:', error);
            });
        }
      }

      logger.info(`Nomination approved: ${nominationRecordId}`);
      return updated;
    } catch (error) {
      logger.error('Failed to approve nomination:', error);
      throw error;
    }
  }

  /**
   * Reject a nomination
   */
  async rejectNomination(nominationRecordId: string, reason: string, rejectedBy: string) {
    try {
      const nominationRecord = await prisma.nominationRecord.findUnique({
        where: { id: nominationRecordId }
      });

      if (!nominationRecord) {
        throw new NotFoundError(`Nomination record with ID ${nominationRecordId} not found`);
      }

      const updated = await prisma.nominationRecord.update({
        where: { id: nominationRecordId },
        data: {
          status: 'REJECTED' as any,
          rejectionReason: reason,
          approvedBy: rejectedBy
        }
      });

      logger.info(`Nomination rejected: ${nominationRecordId}`);
      return updated;
    } catch (error) {
      logger.error('Failed to reject nomination:', error);
      throw error;
    }
  }

  /**
   * Get pending nominations for admin review
   */
  async getPendingNominations(skip = 0, take = 20) {
    try {
      const [nominations, total] = await Promise.all([
        prisma.nominationRecord.findMany({
          where: { status: 'PENDING' },
          skip,
          take,
          orderBy: { submittedAt: 'desc' },
          include: {
            nominee: {
              select: {
                id: true,
                fullName: true,
                email: true,
                awardCategory: true,
                subcategory: true,
                approvedNominationCount: true
              }
            }
          }
        }),
        prisma.nominationRecord.count({ where: { status: 'PENDING' } })
      ]);

      return {
        data: nominations,
        pagination: {
          total,
          skip,
          take,
          pages: Math.ceil(total / take)
        }
      };
    } catch (error) {
      logger.error('Failed to get pending nominations:', error);
      throw error;
    }
  }

  /**
   * Get statistics for a nominee
   */
  async getNomineeStats(nomineeId: string) {
    try {
      const nominee = await prisma.nominee.findUnique({
        where: { id: nomineeId },
        include: {
          nominations: {
            select: {
              id: true,
              status: true,
              submittedAt: true
            }
          },
          certificates: {
            select: {
              id: true,
              issuedAt: true,
              certificateNumber: true
            }
          }
        }
      });

      if (!nominee) {
        throw new NotFoundError(`Nominee with ID ${nomineeId} not found`);
      }

      const approvedCount = nominee.nominations.filter((n: any) => n.status === 'APPROVED').length;
      const pendingCount = nominee.nominations.filter((n: any) => n.status === 'PENDING').length;

      return {
        nomineeId,
        totalNominations: nominee.nominationCount,
        approvedNominations: nominee.approvedNominationCount,
        pendingNominations: pendingCount,
        acceptanceStatus: nominee.acceptanceStatus,
        certificateIssued: nominee.certificates.length > 0,
        certificates: nominee.certificates,
        nominationThresholdMet: nominee.approvedNominationCount >= 10
      };
    } catch (error) {
      logger.error('Failed to get nominee stats:', error);
      throw error;
    }
  }

  /**
   * Trigger certificate generation when threshold is reached
   * This runs asynchronously to avoid blocking the approval API call
   */
  private async triggerCertificateGeneration(
    nomineeId: string,
    nominee: any,
    approvalCount: number
  ): Promise<void> {
    try {
      // Dynamically import certificateService to avoid circular dependencies
      const { default: certificateService } = await import(
        '@/modules/certificates/services/CertificateService'
      );

      const awardTypeMap: Record<string, string> = {
        'blue-garnet': 'RECOGNITION',
        'gold-certificate': 'ACHIEVEMENT',
        'platinum-certificate': 'EXCELLENCE'
      };

      const awardType = awardTypeMap[nominee.awardCategory] || 'RECOGNITION';

      await certificateService.generateCertificate({
        nomineeId,
        awardCategory: nominee.awardCategory,
        awardType,
        approvalCount
      });

      logger.info(`Certificate generated successfully for nominee: ${nomineeId}`);
    } catch (error) {
      logger.error('Certificate generation failed:', error);
      // Don't throw - allow the nomination approval to complete
      // Admin can trigger manual certificate generation if needed
    }
  }
}

export const nomineeService = new NomineeService();
export default nomineeService;
