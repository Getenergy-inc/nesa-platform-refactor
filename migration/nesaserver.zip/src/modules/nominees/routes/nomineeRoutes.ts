import { Router, Request, Response, NextFunction } from 'express';
import multer from 'multer';
import nomineeService from '@/modules/nominees/services/NomineeService';
import cloudinaryService from '@/modules/files/services/CloudinaryService';
import { emailService } from '@/modules/notifications/services/emailService';
import { prisma } from '@/shared/utils/prisma';
import { authenticate, authorize } from '@/shared/middleware/auth';
import logger from '@/shared/utils/logger';
import { ValidationError, NotFoundError, ConflictError } from '@/shared/utils/errors';

const router = Router();

// Configure multer for file uploads (using memory storage for Cloudinary)
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB
  },
  fileFilter: (req, file, cb) => {
    const allowedMimes = [
      'image/jpeg',
      'image/png',
      'image/gif',
      'image/webp',
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];

    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new ValidationError('Invalid file type'));
    }
  }
});

/**
 * GET /api/v1/nominees?category=blue-garnet&subcategory=philanthropy&skip=0&take=20
 * Get nominees by award category
 */
router.get('/', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { category, subcategory, skip = 0, take = 20 } = req.query;

    if (!category) {
      throw new ValidationError('Award category is required');
    }

    const nominees = await nomineeService.getNomineesByCategory(
      category as string,
      subcategory as string | undefined,
      parseInt(skip as string),
      parseInt(take as string)
    );

    res.json({
      success: true,
      data: nominees
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/v1/nominees/:id
 * Get nominee by ID
 */
router.get('/:id', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const id = req.params.id as string | undefined;
    if (!id) {
      throw new ValidationError('Nominee ID is required');
    }
    const nominee = await nomineeService.getNomineeById(id);

    res.json({
      success: true,
      data: nominee
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/v1/nominees/:id/stats
 * Get nominee statistics
 */
router.get('/:id/stats', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const id = req.params.id as string | undefined;
    if (!id) {
      throw new ValidationError('Nominee ID is required');
    }
    const stats = await nomineeService.getNomineeStats(id);

    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/v1/nominees
 * Create a new nominee (admin only)
 */
router.post(
  '/',
  authenticate,
  authorize(['ADMIN', 'SUPERADMIN']),
  upload.single('profileImage'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { firstName, lastName, email, phone, organization, country, region, website, linkedinProfile, awardCategory, subcategory } = req.body;

      // Validation
      if (!firstName || !lastName || !email || !country || !awardCategory || !subcategory) {
        throw new ValidationError('Missing required fields');
      }

      let profileImageUrl: string | undefined;
      let profileImagePublicId: string | undefined;

      // Upload profile image if provided
      if (req.file) {
        const uploadResult = await cloudinaryService.uploadNomineeProfileImage(req.file, email);
        profileImageUrl = uploadResult.secureUrl;
        profileImagePublicId = uploadResult.publicId;
      }

      // Create nominee - only include optional fields when defined to satisfy
      // exactOptionalPropertyTypes behavior.
      const nomineePayload: any = {
        firstName,
        lastName,
        email,
        phone,
        organization,
        country,
        region,
        website,
        linkedinProfile,
        awardCategory,
        subcategory
      };

      if (typeof profileImageUrl !== 'undefined' && profileImageUrl !== null) {
        nomineePayload.profileImageUrl = profileImageUrl;
      }
      if (typeof profileImagePublicId !== 'undefined' && profileImagePublicId !== null) {
        nomineePayload.profileImagePublicId = profileImagePublicId;
      }

      const nominee = await nomineeService.createNominee(nomineePayload);

      // Generate acceptance token
      const tokenData = await nomineeService.generateAcceptanceToken(nominee.id);

      // Send invitation email to nominee
      await emailService.sendNomineeInvitationEmail({
        nomineeEmail: nominee.email,
        nomineeName: nominee.fullName,
        awardCategory,
        acceptanceLink: tokenData.acceptanceUrl,
        expiresAt: tokenData.expiresAt
      });

      res.status(201).json({
        success: true,
        message: 'Nominee created successfully',
        data: {
          ...nominee,
          acceptanceTokenExpires: tokenData.expiresAt
        }
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * POST /api/v1/nominations
 * Submit a public nomination
 */
router.post('/submit', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { nomineeEmail, nomineeId, nominatorName, nominatorEmail, nominatorPhone, nominatorMessage, awardCategory, subcategory, nominationReason } = req.body;

    // Validation
    if (!nomineeId && !nomineeEmail) {
      throw new ValidationError('Nominee ID or email is required');
    }
    if (!nominatorName || !nominatorEmail || !awardCategory || !subcategory || !nominationReason) {
      throw new ValidationError('Missing required nomination fields');
    }

    // Find nominee
    let nominee;
    if (nomineeId) {
      nominee = await nomineeService.getNomineeById(nomineeId);
    } else {
      nominee = await nomineeService.getNomineeByEmail(nomineeEmail);
    }

    // Create nomination record
    const nominationRecord = await nomineeService.createNominationRecord({
      nomineeId: nominee.id,
      nominatorEmail,
      nominatorName,
      nominatorPhone,
      nominatorMessage,
      awardCategory,
      subcategory,
      nominationReason
    });

    // Send confirmation email to nominator
    await emailService.sendNominationConfirmationEmail({
      nominatorEmail,
      nominatorName,
      nomineeName: nominee.fullName,
      awardCategory
    });

    res.status(201).json({
      success: true,
      message: 'Nomination submitted successfully. A confirmation email has been sent.',
      data: {
        nominationId: nominationRecord.id,
        status: nominationRecord.status
      }
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/v1/nominees/:id/accept
 * Accept nomination by nominee using token
 */
router.post('/accept-nomination', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { token, action = 'accept', declineReason } = req.body;

    if (!token) {
      throw new ValidationError('Acceptance token is required');
    }

    let nominee;
    if (action === 'accept') {
      nominee = await nomineeService.acceptNomination(token);
    } else if (action === 'decline') {
      nominee = await nomineeService.declineNomination(token, declineReason);
    } else {
      throw new ValidationError('Invalid action. Use "accept" or "decline"');
    }

    // Send confirmation email
    const emailAction = action === 'accept'
      ? 'sendNomineeAcceptanceEmail'
      : 'sendNomineeDeclineEmail';

    await emailService[emailAction]?.({
      nomineeEmail: nominee.email,
      nomineeName: nominee.fullName,
      awardCategory: nominee.awardCategory
    });

    res.json({
      success: true,
      message: `Nomination ${action}ed successfully`,
      data: {
        acceptanceStatus: nominee.acceptanceStatus,
        acceptedAt: nominee.acceptedAt,
        declinedAt: nominee.declinedAt
      }
    });
  } catch (error) {
    next(error);
  }
});

/**
 * PUT /api/v1/nominees/:id
 * Update nominee information (admin only)
 */
router.put(
  '/:id',
  authenticate,
  authorize(['ADMIN', 'SUPERADMIN']),
  upload.single('profileImage'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const id = req.params.id as string | undefined;
      if (!id) {
        throw new ValidationError('Nominee ID is required');
      }
      const { firstName, lastName, phone, organization, region, website, linkedinProfile } = req.body;

      let profileImageUrl: string | undefined;
      let profileImagePublicId: string | undefined;

      // Upload new profile image if provided
      if (req.file) {
        // Delete old image if exists
        const existingNominee = await nomineeService.getNomineeById(id);
        if (existingNominee.profileImagePublicId) {
          await cloudinaryService.deleteFile(existingNominee.profileImagePublicId);
        }

        // Upload new image
        const uploadResult = await cloudinaryService.uploadNomineeProfileImage(req.file, id);
        profileImageUrl = uploadResult.secureUrl;
        profileImagePublicId = uploadResult.publicId;
      }

      const updatePayload: any = {
        firstName,
        lastName,
        phone,
        organization,
        region,
        website,
        linkedinProfile
      };

      if (typeof profileImageUrl !== 'undefined' && profileImageUrl !== null) {
        updatePayload.profileImageUrl = profileImageUrl;
      }
      if (typeof profileImagePublicId !== 'undefined' && profileImagePublicId !== null) {
        updatePayload.profileImagePublicId = profileImagePublicId;
      }

      const nominee = await nomineeService.updateNominee(id, updatePayload);

      res.json({
        success: true,
        message: 'Nominee updated successfully',
        data: nominee
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * POST /api/v1/nominees/:id/documents
 * Upload supporting documents
 */
router.post(
  '/:id/documents',
  authenticate,
  authorize(['ADMIN', 'SUPERADMIN']),
  upload.array('documents', 5),
  async (req: Request, res: Response, next: NextFunction) => {
      try {
      const id = req.params.id as string | undefined;
      if (!id) {
        throw new ValidationError('Nominee ID is required');
      }

      if (!req.files || (req.files as Express.Multer.File[]).length === 0) {
        throw new ValidationError('No files provided');
      }

      const files = req.files as Express.Multer.File[];

      // Upload each document
      const uploadResults = await Promise.all(
        files.map(file => cloudinaryService.uploadSupportingDocument(file, id, 'supporting'))
      );

      // Create supporting document records
      const documents = await Promise.all(
        uploadResults.map((result, index) =>
          prisma.supportingDocument.create({
            data: {
              nomineeId: id,
              url: result.secureUrl,
              publicId: result.publicId,
              fileName: files[index]!.originalname,
              fileType: 'document',
              fileSize: files[index]!.size
            }
          })
        )
      );

      res.status(201).json({
        success: true,
        message: `${documents.length} document(s) uploaded successfully`,
        data: documents
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * GET /api/v1/nominations/pending
 * Get pending nominations for admin review
 */
router.get(
  '/pending-review',
  authenticate,
  authorize(['ADMIN', 'SUPERADMIN']),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { skip = 0, take = 20 } = req.query;

      const nominations = await nomineeService.getPendingNominations(
        parseInt(skip as string),
        parseInt(take as string)
      );

      res.json({
        success: true,
        data: nominations
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * POST /api/v1/nominations/:id/approve
 * Approve a nomination (admin only)
 */
router.post(
  '/approve/:id',
  authenticate,
  authorize(['ADMIN', 'SUPERADMIN']),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const id = req.params.id as string | undefined;
      if (!id) {
        throw new ValidationError('Nomination ID is required');
      }
      const userId = (req as any).user?.id;

      const nominationRecord = await nomineeService.approveNomination(id, userId);

      // TODO: Trigger email notifications
      // - Email nominee about new approval
      // - Check if 10 approval threshold reached

      res.json({
        success: true,
        message: 'Nomination approved successfully',
        data: nominationRecord
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * POST /api/v1/nominations/:id/reject
 * Reject a nomination (admin only)
 */
router.post(
  '/reject/:id',
  authenticate,
  authorize(['ADMIN', 'SUPERADMIN']),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const id = req.params.id as string | undefined;
      if (!id) {
        throw new ValidationError('Nomination ID is required');
      }
      const { reason } = req.body;
      const userId = (req as any).user?.id;

      if (!reason) {
        throw new ValidationError('Rejection reason is required');
      }

      const nominationRecord = await nomineeService.rejectNomination(id, reason, userId);

      // TODO: Send rejection email to nominator

      res.json({
        success: true,
        message: 'Nomination rejected successfully',
        data: nominationRecord
      });
    } catch (error) {
      next(error);
    }
  }
);

export default router;
