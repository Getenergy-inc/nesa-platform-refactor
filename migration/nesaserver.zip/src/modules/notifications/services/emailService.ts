import { config } from '@/config';
import { PlatformSection } from '@/shared/types';
import { ExternalServiceError } from '@/shared/utils/errors';
import logger from '@/shared/utils/logger';
import { emailQueue } from '@/shared/queues/queues';
import { EmailJobData } from '@/shared/queues/processors/email.processor';
import { emailTemplateService } from '@/shared/utils/emailTemplates';

export class EmailService {
  public readonly fromEmail = config.email.fromEmail;
  public readonly fromName = config.email.fromName;
  public readonly frontendUrl = config.frontendUrl;

  async sendOtpEmail(email: string, code: string, purpose: 'LOGIN' | 'VERIFY_EMAIL' | 'PASSWORD_RESET', userName?: string): Promise<void> {
    const subjectMap = {
      LOGIN: 'Your NESA-Africa Login OTP',
      VERIFY_EMAIL: 'Your NESA-Africa Email Verification OTP',
      PASSWORD_RESET: 'Your NESA-Africa Password Reset OTP'
    } as const;

    const messageMap = {
      LOGIN: 'Use this code to complete your login to NESA-Africa.',
      VERIFY_EMAIL: 'Use this code to verify your email address and activate your NESA-Africa account.',
      PASSWORD_RESET: 'Use this code to reset your NESA-Africa password.'
    } as const;

    try {
      const renderData: any = {
        otpCode: code,
        // For backward-compatible template variables, also provide `otp`
        otp: code,
        message: messageMap[purpose],
        headerTitle: 'Verification Code',
        headerSubtitle: subjectMap[purpose],
      };

      // Only include userName if defined to satisfy exactOptionalPropertyTypes
      if (typeof userName !== 'undefined' && userName !== null) {
        renderData.userName = userName;
      }

      const { html, text } = emailTemplateService.renderOtp(renderData);

      const emailData: EmailJobData = {
        to: email,
        from: `"${this.fromName}" <${this.fromEmail}>`,
        subject: subjectMap[purpose],
        html,
        text,
      };

      await emailQueue.add(emailData, {
        attempts: 3,
        backoff: {
          type: 'exponential',
          delay: 2000,
        },
        priority: 1, // High priority for OTP emails
      });

      logger.info(`OTP email queued for ${email}`);
    } catch (error) {
      logger.error('Failed to queue OTP email:', error);
      throw new ExternalServiceError('Failed to send OTP email');
    }
  }

  async sendVerificationEmail(email: string, token: string): Promise<void> {
    const verificationUrl = `${this.frontendUrl}api/v1/auth/verify-email?token=${token}`;
    
    try {
      const { html, text } = emailTemplateService.renderEmailVerification({ verificationUrl });

      const emailData: EmailJobData = {
        to: email,
        from: `"${this.fromName}" <${this.fromEmail}>`,
        subject: 'Verify Your NESA-Africa Account',
        html,
        text,
      };

      await emailQueue.add(emailData, {
        attempts: 3,
        priority: 1, // High priority
      });

      logger.info(`Email verification queued for ${email}`);
    } catch (error) {
      logger.error('Failed to queue email verification:', error);
      throw new ExternalServiceError('Failed to send verification email');
    }
  }

  async sendPasswordReset(email: string, token: string, userName?: string): Promise<void> {
    const resetUrl = `${this.frontendUrl}/reset-password?token=${token}`;

    try {
      const payload: { resetUrl: string; userName?: string } = { resetUrl };
      if (typeof userName !== 'undefined' && userName !== null) {
        payload.userName = userName;
      }

      const { html, text } = emailTemplateService.renderPasswordReset(payload);

      const emailData: EmailJobData = {
        to: email,
        from: `"${this.fromName}" <${this.fromEmail}>`,
        subject: 'Reset Your NESA-Africa Password',
        html,
        text,
      };

      await emailQueue.add(emailData, {
        attempts: 3,
        priority: 1, // High priority
      });

      logger.info(`Password reset email queued for ${email}`);
    } catch (error) {
      logger.error('Failed to queue password reset email:', error);
      throw new ExternalServiceError('Failed to send password reset email');
    }
  }

  async sendAdminInvitation(
    email: string, 
    token: string, 
    inviterName: string,
    sections: PlatformSection[],
    message?: string
  ): Promise<void> {
    const invitationUrl = `${this.frontendUrl}/admin/accept-invitation?token=${token}`;
    
    try {
      const emailData: EmailJobData = {
        to: email,
        from: `"${this.fromName}" <${this.fromEmail}>`,
        subject: 'Admin Invitation - NESA-Africa Platform',
        html: this.getAdminInvitationTemplate(invitationUrl, inviterName, sections, message),
        text: `You've been invited to be an admin on NESA-Africa platform. Accept invitation: ${invitationUrl}`
      };

      await emailQueue.add(emailData, {
        attempts: 3,
        priority: 1, // High priority
      });

      logger.info(`Admin invitation queued for ${email}`);
    } catch (error) {
      logger.error('Failed to queue admin invitation:', error);
      throw new ExternalServiceError('Failed to send admin invitation');
    }
  }

  async sendWelcomeEmail(email: string, firstName: string): Promise<void> {
    try {
      const emailData: EmailJobData = {
        to: email,
        from: `"${this.fromName}" <${this.fromEmail}>`,
        subject: 'Welcome to NESA-Africa!',
        html: this.getWelcomeTemplate(firstName),
        text: `Welcome to NESA-Africa, ${firstName}! Your account has been verified successfully.`
      };

      await emailQueue.add(emailData, {
        attempts: 2,
        priority: 3, // Lower priority for welcome emails
      });

      logger.info(`Welcome email queued for ${email}`);
    } catch (error) {
      logger.error('Failed to queue welcome email:', error);
      // Don't throw error for welcome email failure
    }
  }

  async sendFirstLoginWelcome(
    email: string,
    userName: string,
    bonusAmount?: number,
    joinDate?: string
  ): Promise<void> {
    try {
      const payload: { userName: string; bonusAmount?: number; joinDate?: string } = { userName };
      if (typeof bonusAmount !== 'undefined' && bonusAmount !== null) {
        payload.bonusAmount = bonusAmount;
      }
      if (typeof joinDate !== 'undefined' && joinDate !== null) {
        payload.joinDate = joinDate;
      }

      const { html, text } = emailTemplateService.renderFirstLoginWelcome(payload);

      const emailData: EmailJobData = {
        to: email,
        from: `"${this.fromName}" <${this.fromEmail}>`,
        subject: '🎉 Welcome to NESA-Africa - Let\'s Get Started!',
        html,
        text,
      };

      await emailQueue.add(emailData, {
        attempts: 2,
        priority: 2, // Medium priority
      });

      logger.info(`First login welcome email queued for ${email}`);
    } catch (error) {
      logger.error('Failed to queue first login welcome email:', error);
      // Don't throw error for welcome email failure
    }
  }

  async sendWelcomeWithBonusEmail(
    email: string, 
    firstName: string, 
    agcBonus: number,
    bonusType: 'withdrawable' | 'non-withdrawable'
  ): Promise<void> {
    try {
      const bonusTypeText = bonusType === 'withdrawable' ? 'Withdrawable' : 'Voting';
      const bonusDescription = bonusType === 'withdrawable' 
        ? 'You can use this bonus to vote or withdraw it later!' 
        : 'Use this bonus to vote for your preferred nominees!';

      const { html, text } = emailTemplateService.renderWelcomeBonus({
        firstName,
        agcBonus,
        bonusTypeText,
        bonusDescription,
      });

      const emailData: EmailJobData = {
        to: email,
        from: `"${this.fromName}" <${this.fromEmail}>`,
        subject: '🎉 Welcome to NESA-Africa - Your AGC Bonus Awaits!',
        html,
        text,
      };

      await emailQueue.add(emailData, {
        attempts: 2,
        priority: 3, // Lower priority for welcome emails
      });

      logger.info(`Welcome email with bonus queued for ${email}`);
    } catch (error) {
      logger.error('Failed to queue welcome email with bonus:', error);
      // Don't throw error for welcome email failure
    }
  }

  async sendVoteConfirmationEmail(
    email: string,
    voterName: string,
    nomineeName: string,
    nomineeCategory: string,
    agcSpent: number,
    voteWeight: number,
    remainingBalance: number,
    totalVotesForNominee: number
  ): Promise<void> {
    try {
      const { html, text } = emailTemplateService.renderVoteConfirmation({
        voterName,
        nomineeName,
        nomineeCategory,
        agcSpent,
        voteWeight,
        remainingBalance,
        totalVotesForNominee,
      });

      const emailData: EmailJobData = {
        to: email,
        from: `"${this.fromName}" <${this.fromEmail}>`,
        subject: '✅ Vote Confirmed - Thank You for Supporting Excellence!',
        html,
        text,
      };

      await emailQueue.add(emailData, {
        attempts: 2,
        priority: 2, // Medium priority
      });

      logger.info(`Vote confirmation email queued for ${email}`);
    } catch (error) {
      logger.error('Failed to queue vote confirmation email:', error);
      // Don't throw error for email failure
    }
  }

  // ============================================
  // NOMINATION SYSTEM EMAIL METHODS
  // Implementations for nomination-related emails are attached to the
  // exported `emailService` instance at the bottom of this file. The
  // instance-level methods are defined there to keep template rendering
  // centralized while still allowing access to the class helpers above.

  // Method stubs are provided here to satisfy TypeScript typing. The
  // actual implementations are assigned to the exported `emailService`
  // instance below (so they can access templates and queues in a
  // consistent place). These stubs act as fallbacks and should not be
  // relied upon at runtime.
  public async sendNomineeInvitationEmail(data: {
    nomineeEmail: string;
    nomineeName: string;
    awardCategory: string;
    acceptanceLink: string;
    expiresAt: Date;
  }): Promise<void> {
    logger.warn('sendNomineeInvitationEmail stub called; no-op');
    return Promise.resolve();
  }

  public async sendNominationConfirmationEmail(data: {
    nominatorEmail: string;
    nominatorName: string;
    nomineeName: string;
    awardCategory: string;
  }): Promise<void> {
    logger.warn('sendNominationConfirmationEmail stub called; no-op');
    return Promise.resolve();
  }

  public async sendNominationApprovedEmail(data: {
    nomineeEmail: string;
    nomineeName: string;
    awardCategory: string;
    approvalCount: number;
    certificateThreshold?: number;
  }): Promise<void> {
    logger.warn('sendNominationApprovedEmail stub called; no-op');
    return Promise.resolve();
  }

  public async sendNominationRejectedEmail(data: {
    nominatorEmail: string;
    nomineeName: string;
    awardCategory: string;
    rejectionReason: string;
  }): Promise<void> {
    logger.warn('sendNominationRejectedEmail stub called; no-op');
    return Promise.resolve();
  }

  public async sendCertificateIssuedEmail(data: {
    nomineeEmail: string;
    nomineeName: string;
    awardCategory: string;
    awardType: string;
    certificateNumber: string;
    downloadLink: string;
    approvalCount: number;
  }): Promise<void> {
    logger.warn('sendCertificateIssuedEmail stub called; no-op');
    return Promise.resolve();
  }

  public async sendNomineeAcceptanceEmail(data: {
    nomineeEmail: string;
    nomineeName: string;
    awardCategory: string;
  }): Promise<void> {
    logger.warn('sendNomineeAcceptanceEmail stub called; no-op');
    return Promise.resolve();
  }

  public async sendNomineeDeclineEmail(data: {
    nomineeEmail: string;
    nomineeName: string;
    awardCategory: string;
  }): Promise<void> {
    logger.warn('sendNomineeDeclineEmail stub called; no-op');
    return Promise.resolve();
  }

  private getEmailVerificationTemplate(verificationUrl: string): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Verify Your Email - NESA-Africa</title>
      </head>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">NESA-Africa</h1>
          <p style="color: white; margin: 10px 0 0 0; opacity: 0.9;">Network of Entrepreneurs and Small Business Advocates</p>
        </div>
        
        <div style="background: white; padding: 40px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
          <h2 style="color: #333; margin-bottom: 20px;">Verify Your Email Address</h2>
          
          <p>Thank you for joining NESA-Africa! To complete your registration and start participating in our community, please verify your email address.</p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${verificationUrl}" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">Verify Email Address</a>
          </div>
          
          <p style="color: #666; font-size: 14px;">If the button doesn't work, copy and paste this link into your browser:</p>
          <p style="color: #667eea; word-break: break-all; font-size: 14px;">${verificationUrl}</p>
          
          <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
          
          <p style="color: #666; font-size: 12px; text-align: center;">
            This verification link will expire in 24 hours. If you didn't create an account with NESA-Africa, please ignore this email.
          </p>
        </div>
      </body>
      </html>
    `;
  }

  private getPasswordResetTemplate(resetUrl: string): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Reset Your Password - NESA-Africa</title>
      </head>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">NESA-Africa</h1>
          <p style="color: white; margin: 10px 0 0 0; opacity: 0.9;">Network of Entrepreneurs and Small Business Advocates</p>
        </div>
        
        <div style="background: white; padding: 40px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
          <h2 style="color: #333; margin-bottom: 20px;">Reset Your Password</h2>
          
          <p>We received a request to reset your password for your NESA-Africa account. Click the button below to create a new password.</p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${resetUrl}" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">Reset Password</a>
          </div>
          
          <p style="color: #666; font-size: 14px;">If the button doesn't work, copy and paste this link into your browser:</p>
          <p style="color: #667eea; word-break: break-all; font-size: 14px;">${resetUrl}</p>
          
          <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
          
          <p style="color: #666; font-size: 12px; text-align: center;">
            This reset link will expire in 1 hour. If you didn't request a password reset, please ignore this email.
          </p>
        </div>
      </body>
      </html>
    `;
  }

  private getAdminInvitationTemplate(
    invitationUrl: string, 
    inviterName: string, 
    sections: PlatformSection[],
    message?: string
  ): string {
    const sectionNames = sections.map(section => 
      section.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase())
    ).join(', ');

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin Invitation - NESA-Africa</title>
      </head>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">NESA-Africa</h1>
          <p style="color: white; margin: 10px 0 0 0; opacity: 0.9;">Admin Invitation</p>
        </div>
        
        <div style="background: white; padding: 40px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
          <h2 style="color: #333; margin-bottom: 20px;">You're Invited to be an Admin!</h2>
          
          <p><strong>${inviterName}</strong> has invited you to be an administrator on the NESA-Africa platform.</p>
          
          <div style="background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #333;">Your Admin Access:</h3>
            <p><strong>Sections:</strong> ${sectionNames}</p>
          </div>
          
          ${message ? `
          <div style="background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <p style="margin: 0;"><strong>Message from ${inviterName}:</strong></p>
            <p style="margin: 10px 0 0 0; font-style: italic;">"${message}"</p>
          </div>
          ` : ''}
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${invitationUrl}" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">Accept Invitation</a>
          </div>
          
          <p style="color: #666; font-size: 14px;">If the button doesn't work, copy and paste this link into your browser:</p>
          <p style="color: #667eea; word-break: break-all; font-size: 14px;">${invitationUrl}</p>
          
          <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
          
          <p style="color: #666; font-size: 12px; text-align: center;">
            This invitation will expire in 7 days. If you don't want to be an admin, please ignore this email.
          </p>
        </div>
      </body>
      </html>
    `;
  }

  private getWelcomeTemplate(firstName: string): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome to NESA-Africa!</title>
      </head>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">Welcome to NESA-Africa!</h1>
          <p style="color: white; margin: 10px 0 0 0; opacity: 0.9;">Network of Entrepreneurs and Small Business Advocates</p>
        </div>
        
        <div style="background: white; padding: 40px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
          <h2 style="color: #333; margin-bottom: 20px;">Welcome, ${firstName}!</h2>
          
          <p>Your email has been verified successfully and your NESA-Africa account is now active. You can now:</p>
          
          <ul style="color: #666; padding-left: 20px;">
            <li>Nominate outstanding individuals and organizations</li>
            <li>Vote for your favorite nominees</li>
            <li>Apply for various opportunities</li>
            <li>Join local chapters</li>
            <li>Access exclusive resources and events</li>
          </ul>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${this.frontendUrl}/dashboard" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">Go to Dashboard</a>
          </div>
          
          <p style="color: #666; font-size: 14px; text-align: center;">
            Thank you for joining our community of entrepreneurs and advocates across Africa!
          </p>
        </div>
      </body>
      </html>
    `;
  }

  private getVoteConfirmationTemplate(
    voterName: string,
    nomineeName: string,
    nomineeCategory: string,
    agcSpent: number,
    voteWeight: number,
    remainingBalance: number,
    totalVotesForNominee: number
  ): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Vote Confirmed - NESA-Africa</title>
      </head>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">✅ Vote Confirmed!</h1>
          <p style="color: white; margin: 10px 0 0 0; opacity: 0.9;">Thank You for Supporting Excellence</p>
        </div>
        
        <div style="background: white; padding: 40px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
          <h2 style="color: #333; margin-bottom: 20px;">Thank You, ${voterName}!</h2>
          
          <p>Your vote has been successfully recorded. Thank you for supporting excellence in African entrepreneurship!</p>
          
          <!-- Vote Details -->
          <div style="background: #f8f9fa; padding: 25px; border-radius: 10px; margin: 25px 0;">
            <h3 style="margin-top: 0; color: #333; font-size: 18px;">📊 Vote Details</h3>
            
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 10px 0; border-bottom: 1px solid #e0e0e0;"><strong>Nominee:</strong></td>
                <td style="padding: 10px 0; border-bottom: 1px solid #e0e0e0; text-align: right;">${nomineeName}</td>
              </tr>
              <tr>
                <td style="padding: 10px 0; border-bottom: 1px solid #e0e0e0;"><strong>Category:</strong></td>
                <td style="padding: 10px 0; border-bottom: 1px solid #e0e0e0; text-align: right;">${nomineeCategory}</td>
              </tr>
              <tr>
                <td style="padding: 10px 0; border-bottom: 1px solid #e0e0e0;"><strong>AGC Spent:</strong></td>
                <td style="padding: 10px 0; border-bottom: 1px solid #e0e0e0; text-align: right; color: #667eea; font-weight: bold;">${agcSpent} AGC</td>
              </tr>
              <tr>
                <td style="padding: 10px 0; border-bottom: 1px solid #e0e0e0;"><strong>Vote Weight:</strong></td>
                <td style="padding: 10px 0; border-bottom: 1px solid #e0e0e0; text-align: right;">${voteWeight}</td>
              </tr>
              <tr>
                <td style="padding: 10px 0;"><strong>Total Votes for Nominee:</strong></td>
                <td style="padding: 10px 0; text-align: right; color: #28a745; font-weight: bold;">${totalVotesForNominee}</td>
              </tr>
            </table>
          </div>
          
          <!-- Remaining Balance -->
          <div style="background: linear-gradient(135deg, #ffd700 0%, #ffed4e 100%); padding: 20px; border-radius: 8px; text-align: center; margin: 25px 0;">
            <p style="margin: 0 0 5px 0; color: #333; font-size: 14px;">Your Remaining Balance</p>
            <div style="font-size: 36px; font-weight: bold; color: #333; margin: 5px 0;">
              ${remainingBalance} AGC
            </div>
            <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">You can vote again!</p>
          </div>
          
          <!-- Impact Message -->
          <div style="background: #e3f2fd; padding: 20px; border-radius: 8px; margin: 25px 0;">
            <h3 style="margin-top: 0; color: #333; font-size: 16px;">🌟 Your Impact</h3>
            <p style="color: #666; margin: 10px 0;">
              Your vote helps recognize and celebrate outstanding achievements in African entrepreneurship. Together, we're building a stronger ecosystem for innovation and growth across the continent.
            </p>
          </div>
          
          <!-- What's Next -->
          <h3 style="color: #333; margin: 25px 0 15px 0;">What You Can Do Next:</h3>
          <ul style="color: #666; padding-left: 20px;">
            <li><strong>Vote Again:</strong> Support more nominees with your remaining AGC</li>
            <li><strong>Purchase More AGC:</strong> Get more voting power to support your favorites</li>
            <li><strong>Share:</strong> Encourage others to vote for deserving nominees</li>
            <li><strong>Nominate:</strong> Know someone outstanding? Submit a nomination!</li>
          </ul>
          
          <!-- CTA Buttons -->
          <div style="text-align: center; margin: 35px 0 25px 0;">
            <a href="${this.frontendUrl}/voting" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block; margin: 5px;">Vote Again</a>
            <a href="${this.frontendUrl}/wallet/purchase" style="background: #28a745; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block; margin: 5px;">Buy More AGC</a>
          </div>
          
          <!-- Footer -->
          <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
          
          <p style="color: #666; font-size: 14px; text-align: center; margin: 20px 0;">
            <strong>Track Your Votes</strong><br>
            View your complete voting history in your <a href="${this.frontendUrl}/dashboard" style="color: #667eea;">dashboard</a>
          </p>
          
          <p style="color: #999; font-size: 12px; text-align: center; margin: 20px 0;">
            Thank you for being part of the NESA-Africa community!<br>
            Together, we celebrate and empower African excellence.
          </p>
        </div>
      </body>
      </html>
    `;
  }

  private getWelcomeWithBonusTemplate(firstName: string, agcBonus: number, bonusType: 'withdrawable' | 'non-withdrawable'): string {
    const bonusTypeText = bonusType === 'withdrawable' ? 'Withdrawable' : 'Voting';
    const bonusDescription = bonusType === 'withdrawable' 
      ? 'You can use this bonus to vote or withdraw it later!' 
      : 'Use this bonus to vote for your preferred nominees!';

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome to NESA-Africa!</title>
      </head>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">🎉 Welcome to NESA-Africa!</h1>
          <p style="color: white; margin: 10px 0 0 0; opacity: 0.9;">Network of Entrepreneurs and Small Business Advocates</p>
        </div>
        
        <div style="background: white; padding: 40px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
          <h2 style="color: #333; margin-bottom: 20px;">Welcome, ${firstName}!</h2>
          
          <p>Thank you for joining NESA-Africa! We're excited to have you as part of our community of entrepreneurs and advocates across Africa.</p>
          
          <!-- AGC Bonus Section -->
          <div style="background: linear-gradient(135deg, #ffd700 0%, #ffed4e 100%); padding: 25px; border-radius: 10px; text-align: center; margin: 30px 0; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
            <h3 style="margin: 0 0 10px 0; color: #333; font-size: 18px;">🎁 Your Signup Bonus</h3>
            <div style="font-size: 48px; font-weight: bold; color: #333; margin: 15px 0;">
              ${agcBonus} AGC
            </div>
            <p style="margin: 10px 0 0 0; color: #666; font-size: 14px;">${bonusTypeText} Bonus</p>
            <p style="margin: 10px 0 0 0; color: #666; font-size: 14px;">${bonusDescription}</p>
          </div>
          
          <!-- About NESA-Africa -->
          <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 25px 0;">
            <h3 style="margin-top: 0; color: #333; font-size: 18px;">About NESA-Africa</h3>
            <p style="color: #666; margin: 10px 0;">
              NESA-Africa is the premier network celebrating and empowering entrepreneurs, small businesses, and advocates across Africa. We recognize excellence, foster collaboration, and drive sustainable development through:
            </p>
            <ul style="color: #666; padding-left: 20px; margin: 10px 0;">
              <li><strong>Annual Awards:</strong> Honoring outstanding achievements in entrepreneurship and advocacy</li>
              <li><strong>Community Building:</strong> Connecting like-minded individuals and organizations</li>
              <li><strong>Capacity Development:</strong> Providing resources, training, and opportunities</li>
              <li><strong>Advocacy:</strong> Amplifying voices for policy change and economic empowerment</li>
            </ul>
          </div>
          
          <!-- What You Can Do -->
          <h3 style="color: #333; margin: 25px 0 15px 0;">What You Can Do Now:</h3>
          <ul style="color: #666; padding-left: 20px;">
            <li><strong>Vote for Nominees:</strong> Use your AGC bonus to support outstanding individuals and organizations</li>
            <li><strong>Submit Nominations:</strong> Recognize excellence in your community</li>
            <li><strong>Join Your Local Chapter:</strong> Connect with entrepreneurs in your region</li>
            <li><strong>Apply for Opportunities:</strong> Access scholarships, grants, and programs</li>
            <li><strong>Attend Events:</strong> Participate in webinars, expos, and the annual gala</li>
          </ul>
          
          <!-- CTA Buttons -->
          <div style="text-align: center; margin: 35px 0 25px 0;">
            <a href="${this.frontendUrl}/voting" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block; margin: 5px;">Start Voting</a>
            <a href="${this.frontendUrl}/dashboard" style="background: #28a745; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block; margin: 5px;">Go to Dashboard</a>
          </div>
          
          <!-- Footer -->
          <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
          
          <p style="color: #666; font-size: 14px; text-align: center; margin: 20px 0;">
            <strong>Need Help?</strong><br>
            Visit our <a href="${this.frontendUrl}/help" style="color: #667eea;">Help Center</a> or contact us at <a href="mailto:support@nesa-africa.com" style="color: #667eea;">support@nesa-africa.com</a>
          </p>
          
          <p style="color: #999; font-size: 12px; text-align: center; margin: 20px 0;">
            Follow us on social media to stay updated with the latest news and opportunities!
          </p>
        </div>
      </body>
      </html>
    `;
  }
}

export const emailService = new EmailService();

/**
 * EXTENSION METHODS FOR NOMINATION SYSTEM
 * These methods are added to the exported instance to handle nomination workflows
 */

// Nominee invitation email
emailService.sendNomineeInvitationEmail = async function(data: {
  nomineeEmail: string;
  nomineeName: string;
  awardCategory: string;
  acceptanceLink: string;
  expiresAt: Date;
}) {
  try {
    const { html, text } = emailTemplateService.renderNomineeInvitation({
      nomineeName: data.nomineeName,
      awardCategory: data.awardCategory,
      acceptanceLink: data.acceptanceLink,
      expiresAt: data.expiresAt,
    });

    const emailData: EmailJobData = {
      to: data.nomineeEmail,
      from: `"${this.fromName}" <${this.fromEmail}>`,
      subject: `🌟 You've Been Nominated for the ${data.awardCategory} Award!`,
      html,
      text,
    };

    await emailQueue.add(emailData, {
      attempts: 3,
      backoff: { type: 'exponential', delay: 2000 },
      priority: 1,
    });

    logger.info(`Nominee invitation email queued for ${data.nomineeEmail}`);
  } catch (error) {
    logger.error('Failed to queue nominee invitation email:', error);
    throw new ExternalServiceError('Failed to send nominee invitation email');
  }
};

// Nomination confirmation email (to nominator)
emailService.sendNominationConfirmationEmail = async function(data: {
  nominatorEmail: string;
  nominatorName: string;
  nomineeName: string;
  awardCategory: string;
}) {
  try {
    const { html, text } = emailTemplateService.renderNominationConfirmation({
      nominatorName: data.nominatorName,
      nomineeName: data.nomineeName,
      awardCategory: data.awardCategory,
    });

    const emailData: EmailJobData = {
      to: data.nominatorEmail,
      from: `"${this.fromName}" <${this.fromEmail}>`,
      subject: `✅ Your Nomination of ${data.nomineeName} Has Been Submitted`,
      html,
      text,
    };

    await emailQueue.add(emailData, {
      attempts: 2,
      priority: 2,
    });

    logger.info(`Nomination confirmation email queued for ${data.nominatorEmail}`);
  } catch (error) {
    logger.error('Failed to queue nomination confirmation email:', error);
    throw new ExternalServiceError('Failed to send nomination confirmation email');
  }
};

// Nomination approved email (to nominee)
emailService.sendNominationApprovedEmail = async function(data: {
  nomineeEmail: string;
  nomineeName: string;
  awardCategory: string;
  approvalCount: number;
  certificateThreshold?: number;
}) {
  try {
    const { html, text } = emailTemplateService.renderNominationApproved({
      nomineeName: data.nomineeName,
      awardCategory: data.awardCategory,
      approvalCount: data.approvalCount,
      certificateThreshold: data.certificateThreshold || 10,
    });

    const emailData: EmailJobData = {
      to: data.nomineeEmail,
      from: `"${this.fromName}" <${this.fromEmail}>`,
      subject: `🎉 Another Vote of Confidence! Your Nomination Has Been Approved`,
      html,
      text,
    };

    await emailQueue.add(emailData, {
      attempts: 2,
      priority: 2,
    });

    logger.info(`Nomination approved email queued for ${data.nomineeEmail}`);
  } catch (error) {
    logger.error('Failed to queue nomination approved email:', error);
    throw new ExternalServiceError('Failed to send nomination approved email');
  }
};

// Nomination rejected email (to nominator)
emailService.sendNominationRejectedEmail = async function(data: {
  nominatorEmail: string;
  nomineeName: string;
  awardCategory: string;
  rejectionReason: string;
}) {
  try {
    const { html, text } = emailTemplateService.renderNominationRejected({
      nomineeName: data.nomineeName,
      nominatorName: 'Valued Nominator',
      awardCategory: data.awardCategory,
      rejectionReason: data.rejectionReason,
    });

    const emailData: EmailJobData = {
      to: data.nominatorEmail,
      from: `"${this.fromName}" <${this.fromEmail}>`,
      subject: `Nomination Status Update: ${data.nomineeName}`,
      html,
      text,
    };

    await emailQueue.add(emailData, {
      attempts: 2,
      priority: 3,
    });

    logger.info(`Nomination rejected email queued for ${data.nominatorEmail}`);
  } catch (error) {
    logger.error('Failed to queue nomination rejected email:', error);
    throw new ExternalServiceError('Failed to send nomination rejected email');
  }
};

// Certificate issued email (to nominee)
emailService.sendCertificateIssuedEmail = async function(data: {
  nomineeEmail: string;
  nomineeName: string;
  awardCategory: string;
  awardType: string;
  certificateNumber: string;
  downloadLink: string;
  approvalCount: number;
}) {
  try {
    const { html, text } = emailTemplateService.renderCertificateIssued({
      nomineeName: data.nomineeName,
      awardCategory: data.awardCategory,
      awardType: data.awardType,
      certificateNumber: data.certificateNumber,
      downloadLink: data.downloadLink,
      approvalCount: data.approvalCount,
    });

    const emailData: EmailJobData = {
      to: data.nomineeEmail,
      from: `"${this.fromName}" <${this.fromEmail}>`,
      subject: `🏆 Your ${data.awardType} Certificate Is Ready to Download!`,
      html,
      text,
    };

    await emailQueue.add(emailData, {
      attempts: 3,
      backoff: { type: 'exponential', delay: 2000 },
      priority: 1,
    });

    logger.info(`Certificate issued email queued for ${data.nomineeEmail}`);
  } catch (error) {
    logger.error('Failed to queue certificate issued email:', error);
    throw new ExternalServiceError('Failed to send certificate issued email');
  }
};

// Nominee acceptance confirmation email
emailService.sendNomineeAcceptanceEmail = async function(data: {
  nomineeEmail: string;
  nomineeName: string;
  awardCategory: string;
}) {
  try {
    const { html, text } = emailTemplateService.renderNomineeAcceptance({
      nomineeName: data.nomineeName,
      awardCategory: data.awardCategory,
    });

    const emailData: EmailJobData = {
      to: data.nomineeEmail,
      from: `"${this.fromName}" <${this.fromEmail}>`,
      subject: `✅ Thank You for Accepting Your Nomination!`,
      html,
      text,
    };

    await emailQueue.add(emailData, {
      attempts: 2,
      priority: 2,
    });

    logger.info(`Nominee acceptance email queued for ${data.nomineeEmail}`);
  } catch (error) {
    logger.error('Failed to queue nominee acceptance email:', error);
    throw new ExternalServiceError('Failed to send nominee acceptance email');
  }
};

// Nominee decline notification email
emailService.sendNomineeDeclineEmail = async function(data: {
  nomineeEmail: string;
  nomineeName: string;
  awardCategory: string;
}) {
  try {
    const { html, text } = emailTemplateService.renderNomineeDecline({
      nomineeName: data.nomineeName,
      awardCategory: data.awardCategory,
    });

    const emailData: EmailJobData = {
      to: data.nomineeEmail,
      from: `"${this.fromName}" <${this.fromEmail}>`,
      subject: `Nomination Status Updated`,
      html,
      text,
    };

    await emailQueue.add(emailData, {
      attempts: 2,
      priority: 3,
    });

    logger.info(`Nominee decline email queued for ${data.nomineeEmail}`);
  } catch (error) {
    logger.error('Failed to queue nominee decline email:', error);
    throw new ExternalServiceError('Failed to send nominee decline email');
  }
};
