import { Router, Request, Response, NextFunction } from 'express';
import certificateService from '@/modules/certificates/services/CertificateService';
import { prisma } from '@/shared/utils/prisma';
import { authenticate } from '@/shared/middleware/auth';
import logger from '@/shared/utils/logger';
import { ValidationError, NotFoundError } from '@/shared/utils/errors';

const router = Router();

/**
 * POST /api/v1/certificates/generate
 * Generate a certificate for a nominee who has reached 10 approvals
 */
router.post(
  '/generate',
  authenticate,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { nomineeId, awardCategory, awardType = 'RECOGNITION', approvalCount } = req.body;

      if (!nomineeId || !awardCategory) {
        throw new ValidationError('Nominee ID and award category are required');
      }

      // Verify nominee exists and has reached threshold
      const nominee = await prisma.nominee.findUnique({
        where: { id: nomineeId }
      });

      if (!nominee) {
        throw new NotFoundError('Nominee not found');
      }

      if (approvalCount < 10) {
        throw new ValidationError('Nominee has not reached the certificate threshold (10 approvals)');
      }

      // Generate certificate
      const certificate = await certificateService.generateCertificate({
        nomineeId,
        awardCategory,
        awardType,
        approvalCount
      });

      logger.info(`Certificate generated for nominee ${nomineeId}`);

      res.status(201).json({
        success: true,
        message: 'Certificate generated successfully',
        data: certificate
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * GET /api/v1/certificates/:nomineeId
 * Get certificate for a nominee
 */
router.get(
  '/:nomineeId',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { nomineeId } = req.params;

      const nominee = await prisma.nominee.findUnique({
        where: { id: nomineeId }
      });

      if (!nominee) {
        throw new NotFoundError('Nominee not found');
      }

      if (!nominee.certificateUrl) {
        throw new NotFoundError('No certificate found for this nominee');
      }

      res.json({
        success: true,
        data: {
          nomineeId,
          fullName: nominee.fullName,
          awardCategory: nominee.awardCategory,
          certificateUrl: nominee.certificateUrl,
          issuedAt: nominee.certificateIssuedAt
        }
      });
    } catch (error) {
      next(error);
    }
  }
);

export default router;
