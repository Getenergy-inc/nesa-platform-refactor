import { prisma } from '@/shared/utils/prisma';
import logger from '@/shared/utils/logger';
import { ExternalServiceError, NotFoundError } from '@/shared/utils/errors';
import cloudinaryService from '@/modules/files/services/CloudinaryService';
import { emailService } from '@/modules/notifications/services/emailService';
import crypto from 'crypto';

export interface CertificateGenerationData {
  nomineeId: string;
  awardCategory: string;
  awardType: string; // 'RECOGNITION', 'ACHIEVEMENT', 'EXCELLENCE'
  approvalCount: number;
}

/**
 * CertificateService - Manages certificate generation and issuance
 * Handles PDF generation, storage, and tracking
 */
class CertificateService {
  /**
   * Generate and issue certificate when nominee reaches 10 approvals
   */
  async generateCertificate(data: CertificateGenerationData): Promise<any> {
    try {
      // Get nominee details
      const nominee = await prisma.nominee.findUnique({
        where: { id: data.nomineeId },
        include: { certificates: true }
      });

      if (!nominee) {
        throw new NotFoundError(`Nominee with ID ${data.nomineeId} not found`);
      }

      // Check if certificate already issued
      if (nominee.certificates && nominee.certificates.length > 0) {
        logger.warn(`Certificate already issued for nominee: ${data.nomineeId}`);
        return nominee.certificates[0];
      }

      // Generate unique certificate number
      const certificateNumber = this.generateCertificateNumber(
        data.awardCategory,
        data.awardType,
        nominee.id
      );

      // Create verification code for certificate authenticity
      const verificationCode = crypto.randomBytes(16).toString('hex').toUpperCase();

      // For now, create a placeholder certificate record
      // In production, this would generate an actual PDF and upload to Cloudinary
      const certificate = await prisma.certificate.create({
        data: {
          nomineeId: data.nomineeId,
          certificateNumber,
          awardCategory: data.awardCategory,
          subcategory: nominee.subcategory,
          certificateType: data.awardType as any,
          certificateUrl: await this.generateCertificateUrl(nominee, certificateNumber),
          publicId: `certificates/${new Date().getFullYear()}/${nominee.id}/${certificateNumber}`,
          issuedAt: new Date(),
          issuedBy: 'NESA-Africa System',
          verificationCode
        }
      });

      // Update nominee with certificate info
      await prisma.nominee.update({
        where: { id: data.nomineeId },
        data: {
          certificateUrl: certificate.certificateUrl,
          certificatePublicId: certificate.publicId,
          certificateNumber: certificate.certificateNumber,
          certificateIssuedAt: certificate.issuedAt
        }
      });

      logger.info(`Certificate generated for nominee: ${data.nomineeId}`);

      // Send certificate issued email
      await this.sendCertificateEmail(nominee, certificate, data.approvalCount);

      return certificate;
    } catch (error) {
      logger.error('Failed to generate certificate:', error);
      throw new ExternalServiceError('Failed to generate certificate');
    }
  }

  /**
   * Generate certificate URL (placeholder - would be actual PDF in production)
   */
  private async generateCertificateUrl(
    nominee: any,
    certificateNumber: string
  ): Promise<string> {
    // In a production system, this would:
    // 1. Use a library like pdfkit to generate PDF
    // 2. Include certificate details, nominee name, award category
    // 3. Add signature/seal graphics
    // 4. Upload to Cloudinary
    // 5. Return the secure URL

    // For now, return a placeholder URL
    const cloudinaryFolder = `certificates/${new Date().getFullYear()}/${nominee.id}`;
    return `https://res.cloudinary.com/${process.env.CLOUDINARY_CLOUD_NAME}/image/upload/${cloudinaryFolder}/${certificateNumber}.pdf`;
  }

  /**
   * Generate unique certificate number
   */
  private generateCertificateNumber(
    awardCategory: string,
    awardType: string,
    nomineeId: string
  ): string {
    const year = new Date().getFullYear();
    const categoryPrefix = this.getCategoryPrefix(awardCategory);
    const typePrefix = awardType.charAt(0);
    const timestamp = Date.now().toString().slice(-6); // Last 6 digits of timestamp

    return `${categoryPrefix}-${year}-${typePrefix}-${timestamp}`;
  }

  /**
   * Get category prefix for certificate number
   */
  private getCategoryPrefix(category: string): string {
    const prefixes: Record<string, string> = {
      'blue-garnet': 'BG',
      'gold-certificate': 'GC',
      'platinum-certificate': 'PC',
      'africa-lifetime-education-icon': 'ALEI',
      'africa-philanthropy-icon': 'API',
      'literary-advocate': 'LA',
      'technical-educator': 'TE'
    };

    return prefixes[category] || category.substring(0, 2).toUpperCase();
  }

  /**
   * Send certificate issued email to nominee
   */
  private async sendCertificateEmail(
    nominee: any,
    certificate: any,
    approvalCount: number
  ): Promise<void> {
    try {
      const downloadLink = `${process.env.FRONTEND_URL}/nominees/certificate/${certificate.id}/download`;

      await emailService.sendCertificateIssuedEmail({
        nomineeEmail: nominee.email,
        nomineeName: nominee.fullName,
        awardCategory: certificate.awardCategory,
        awardType: certificate.certificateType,
        certificateNumber: certificate.certificateNumber,
        downloadLink,
        approvalCount
      });
    } catch (error) {
      logger.error('Failed to send certificate email:', error);
      // Don't throw - certificate was created successfully
    }
  }

  /**
   * Get certificate by ID
   */
  async getCertificateById(id: string): Promise<any> {
    try {
      const certificate = await prisma.certificate.findUnique({
        where: { id },
        include: { nominee: true }
      });

      if (!certificate) {
        throw new NotFoundError(`Certificate with ID ${id} not found`);
      }

      return certificate;
    } catch (error) {
      logger.error('Failed to get certificate:', error);
      throw error;
    }
  }

  /**
   * Get certificate by nominee ID
   */
  async getCertificateByNomineeId(nomineeId: string): Promise<any> {
    try {
      const certificate = await prisma.certificate.findFirst({
        where: { nomineeId },
        include: { nominee: true }
      });

      if (!certificate) {
        throw new NotFoundError(`No certificate found for nominee: ${nomineeId}`);
      }

      return certificate;
    } catch (error) {
      logger.error('Failed to get certificate:', error);
      throw error;
    }
  }

  /**
   * Get certificate by certificate number
   */
  async getCertificateByNumber(certificateNumber: string): Promise<any> {
    try {
      const certificate = await prisma.certificate.findUnique({
        where: { certificateNumber },
        include: { nominee: true }
      });

      if (!certificate) {
        throw new NotFoundError(`Certificate ${certificateNumber} not found`);
      }

      return certificate;
    } catch (error) {
      logger.error('Failed to get certificate:', error);
      throw error;
    }
  }

  /**
   * Verify certificate authenticity using verification code
   */
  async verifyCertificate(certificateNumber: string, verificationCode: string): Promise<boolean> {
    try {
      const certificate = await this.getCertificateByNumber(certificateNumber);

      const isValid = certificate.verificationCode === verificationCode;

      if (isValid) {
        logger.info(`Certificate verified: ${certificateNumber}`);
      } else {
        logger.warn(`Certificate verification failed: ${certificateNumber}`);
      }

      return isValid;
    } catch (error) {
      logger.error('Certificate verification error:', error);
      return false;
    }
  }

  /**
   * Increment certificate download count
   */
  async incrementDownloadCount(certificateId: string): Promise<void> {
    try {
      await prisma.certificate.update({
        where: { id: certificateId },
        data: {
          downloadCount: { increment: 1 },
          lastDownloadedAt: new Date()
        }
      });

      logger.info(`Certificate download tracked: ${certificateId}`);
    } catch (error) {
      logger.error('Failed to update download count:', error);
      // Don't throw - download is still allowed
    }
  }

  /**
   * Get all certificates for a category
   */
  async getCertificatesByCategory(
    awardCategory: string,
    skip = 0,
    take = 20
  ): Promise<any> {
    try {
      const [certificates, total] = await Promise.all([
        prisma.certificate.findMany({
          where: { awardCategory },
          skip,
          take,
          orderBy: { issuedAt: 'desc' },
          include: { nominee: true }
        }),
        prisma.certificate.count({ where: { awardCategory } })
      ]);

      return {
        data: certificates,
        pagination: {
          total,
          skip,
          take,
          pages: Math.ceil(total / take)
        }
      };
    } catch (error) {
      logger.error('Failed to get certificates by category:', error);
      throw error;
    }
  }

  /**
   * Get all certificates for a year
   */
  async getCertificatesByYear(
    year: number,
    skip = 0,
    take = 20
  ): Promise<any> {
    try {
      const startDate = new Date(year, 0, 1);
      const endDate = new Date(year + 1, 0, 1);

      const [certificates, total] = await Promise.all([
        prisma.certificate.findMany({
          where: {
            issuedAt: {
              gte: startDate,
              lt: endDate
            }
          },
          skip,
          take,
          orderBy: { issuedAt: 'desc' },
          include: { nominee: true }
        }),
        prisma.certificate.count({
          where: {
            issuedAt: {
              gte: startDate,
              lt: endDate
            }
          }
        })
      ]);

      return {
        data: certificates,
        pagination: {
          total,
          skip,
          take,
          pages: Math.ceil(total / take)
        }
      };
    } catch (error) {
      logger.error('Failed to get certificates by year:', error);
      throw error;
    }
  }

  /**
   * Get certificate statistics
   */
  async getCertificateStats(): Promise<any> {
    try {
      const currentYear = new Date().getFullYear();
      const startOfYear = new Date(currentYear, 0, 1);

      const [totalCertificates, yearCertificates, byCategory, topDownloads] =
        await Promise.all([
          prisma.certificate.count(),
          prisma.certificate.count({
            where: { issuedAt: { gte: startOfYear } }
          }),
          prisma.certificate.groupBy({
            by: ['awardCategory'],
            _count: { id: true }
          }),
          prisma.certificate.findMany({
            orderBy: { downloadCount: 'desc' },
            take: 5,
            include: { nominee: { select: { fullName: true } } }
          })
        ]);

      return {
        totalCertificates,
        currentYearCertificates: yearCertificates,
        byCategory: byCategory.reduce(
          (acc: Record<string, number>, cat: any) => {
            acc[cat.awardCategory] = cat._count.id;
            return acc;
          },
          {} as Record<string, number>
        ),
        topDownloadedCertificates: topDownloads.map((cert: any) => ({
          certificateNumber: cert.certificateNumber,
          nomineeName: cert.nominee.fullName,
          downloads: cert.downloadCount
        }))
      };
    } catch (error) {
      logger.error('Failed to get certificate statistics:', error);
      throw error;
    }
  }
}

export const certificateService = new CertificateService();
export default certificateService;
