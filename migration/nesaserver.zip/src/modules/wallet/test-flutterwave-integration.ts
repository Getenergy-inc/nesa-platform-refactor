/**
 * Test script for Flutterwave integration
 * Run with: npx ts-node src/modules/wallet/test-flutterwave-integration.ts
 */

import { flutterwaveService } from './services/flutterwaveService';
import { exchangeRateService } from './services/exchangeRateService';
import { config } from '@/config';

async function testFlutterwaveIntegration() {
  console.log('🧪 Testing Flutterwave Multi-Currency Integration\n');

  // Check configuration
  console.log('1. Checking Configuration...');
  if (!config.flutterwave.secretKey) {
    console.error('❌ FLUTTERWAVE_SECRET_KEY not configured');
    console.log('   Add to .env: FLUTTERWAVE_SECRET_KEY=FLWSECK_TEST-xxx');
    return;
  }
  if (!config.flutterwave.publicKey) {
    console.error('❌ FLUTTERWAVE_PUBLIC_KEY not configured');
    console.log('   Add to .env: FLUTTERWAVE_PUBLIC_KEY=FLWPUBK_TEST-xxx');
    return;
  }
  console.log('✅ Configuration OK\n');

  // Test supported currencies
  console.log('2. Testing Supported Currencies...');
  const currencies = flutterwaveService.getSupportedCurrencies();
  console.log(`   Supported: ${currencies.join(', ')}`);
  console.log('✅ Currencies OK\n');

  // Test exchange rates
  console.log('3. Testing Exchange Rates...');
  await exchangeRateService.updateRates();
  const rates = exchangeRateService.getAllRates();
  console.log(`   USD: 1`);
  console.log(`   NGN: ${rates.NGN}`);
  console.log(`   GBP: ${rates.GBP}`);
  console.log(`   EUR: ${rates.EUR}`);
  console.log('✅ Exchange Rates OK\n');

  // Test AGC calculation
  console.log('4. Testing AGC Calculation...');
  const testAmounts = [
    { amount: 1500, currency: 'NGN' },
    { amount: 10, currency: 'USD' },
    { amount: 8, currency: 'GBP' },
    { amount: 9, currency: 'EUR' },
  ];

  testAmounts.forEach(({ amount, currency }) => {
    const agc = exchangeRateService.calculateAGC(amount, currency);
    const usd = exchangeRateService.toUSD(amount, currency);
    console.log(`   ${amount} ${currency} = ${agc.toFixed(2)} AGC ($${usd.toFixed(2)} USD)`);
  });
  console.log('✅ AGC Calculation OK\n');

  // Test pricing tiers
  console.log('5. Testing Pricing Tiers...');
  const ngnTiers = exchangeRateService.getPricingTiers('NGN');
  console.log('   NGN Pricing Tiers:');
  ngnTiers.forEach(tier => {
    console.log(`     ₦${tier.amount.toLocaleString()} = ${tier.agc} AGC ${tier.bonus ? `(+${tier.bonus} bonus)` : ''}`);
  });
  console.log('✅ Pricing Tiers OK\n');

  // Test payment initialization (requires valid Flutterwave keys)
  console.log('6. Testing Payment Initialization...');
  try {
    const testEmail = 'test@example.com';
    const result = await flutterwaveService.initializePayment({
      email: testEmail,
      amount: 1500,
      currency: 'NGN',
      reference: `TEST-${Date.now()}`,
      customer: {
        email: testEmail,
        name: 'Test User',
      },
      customizations: {
        title: 'Test Payment',
        description: 'Testing Flutterwave integration',
      },
      metadata: {
        test: true,
        purpose: 'integration_test',
      },
      redirect_url: 'http://localhost:3000/payment/callback', // Required by Flutterwave
    });

    if (result.status === 'success') {
      console.log('✅ Payment initialization successful');
      console.log(`   Payment Link: ${result.data.link}`);
    } else {
      console.error('❌ Payment initialization failed');
    }
  } catch (error) {
    console.error('❌ Payment initialization error:', error instanceof Error ? error.message : error);
    console.log('   This is expected if using test keys without proper setup');
  }
  console.log();

  console.log('🎉 Integration test complete!\n');
  console.log('Next steps:');
  console.log('1. Add Flutterwave keys to .env file');
  console.log('2. Test with real payment flow');
  console.log('3. Configure webhook URL in Flutterwave dashboard');
  console.log('4. Test webhook with ngrok for local development');
  console.log('\nSupported Currencies:');
  currencies.forEach(curr => {
    const rate = rates[curr];
    console.log(`  - ${curr}: ${rate ? `1 USD = ${rate} ${curr}` : 'Rate not available'}`);
  });
}

// Run the test
testFlutterwaveIntegration()
  .then(() => {
    console.log('\n✅ All tests completed');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ Test failed:', error);
    process.exit(1);
  });
