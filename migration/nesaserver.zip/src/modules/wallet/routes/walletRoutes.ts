import { Router } from 'express';
import { WalletController } from '../wallet.controller';
import { verifyToken } from '@/shared/middleware/auth';

const walletRouter = Router();
const walletController = new WalletController();

/**
 * @swagger
 * tags:
 *   name: Wallet
 *   description: User wallet management, AGC purchases, transfers, and transactions
 */

/**
 * @swagger
 * /wallet/config:
 *   get:
 *     summary: Get wallet configuration
 *     description: Returns Paystack public key and AGC conversion rates for frontend use
 *     tags: [Wallet]
 *     responses:
 *       200:
 *         description: Configuration retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 paystackPublicKey:
 *                   type: string
 *                   description: Paystack public key for frontend integration
 *                   example: "pk_test_xxx"
 *                 agcConversionRate:
 *                   type: number
 *                   description: USD to AGC conversion rate
 *                   example: 20
 *                 userSplit:
 *                   type: number
 *                   description: Percentage of AGC that goes to user
 *                   example: 0.75
 *                 companySplit:
 *                   type: number
 *                   description: Percentage of AGC that goes to company reserve
 *                   example: 0.25
 *                 minPurchaseAmount:
 *                   type: number
 *                   description: Minimum purchase amount in USD
 *                   example: 1
 */
walletRouter.get('/config', walletController.getConfig.bind(walletController));

/**
 * @swagger
 * /wallet/webhook/flutterwave:
 *   post:
 *     summary: Flutterwave webhook handler
 *     description: Receives and processes Flutterwave payment events (internal use)
 *     tags: [Wallet]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *     responses:
 *       200:
 *         description: Webhook processed successfully
 */
walletRouter.post('/webhook/flutterwave', walletController.handleFlutterwaveWebhook.bind(walletController));

// ============================================
// ALL ROUTES BELOW REQUIRE AUTHENTICATION
// ============================================
walletRouter.use(verifyToken);

/**
 * @swagger
 * /wallet/balance:
 *   get:
 *     summary: Get wallet balance
 *     description: Returns the user's wallet balance with purchased AGC (spendable) and bonus AGC (voting only)
 *     tags: [Wallet]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Wallet balance retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 agcWithdrawableBalance:
 *                   type: number
 *                   description: Purchased/earned AGC (can vote, transfer, spend)
 *                   example: 150.0
 *                 agcLockedBalance:
 *                   type: number
 *                   description: Bonus AGC (can vote only, cannot transfer)
 *                   example: 50.0
 *                 lastUpdated:
 *                   type: string
 *                   format: date-time
 *                   example: "2025-11-18T12:00:00Z"
 *       401:
 *         description: Unauthorized - Invalid or missing token
 */
walletRouter.get('/balance', walletController.getWalletBalance.bind(walletController));

/**
 * @swagger
 * /wallet/balance/detailed:
 *   get:
 *     summary: Get detailed wallet balance (UI-friendly)
 *     description: Returns wallet balance with categorized breakdown for UI display
 *     tags: [Wallet]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Detailed wallet balance retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 purchased:
 *                   type: object
 *                   properties:
 *                     amount:
 *                       type: number
 *                       example: 150.0
 *                     label:
 *                       type: string
 *                       example: "Purchased AGC"
 *                     description:
 *                       type: string
 *                       example: "Can vote, transfer, and spend"
 *                     usdValue:
 *                       type: number
 *                       example: 7.5
 *                 bonus:
 *                   type: object
 *                   properties:
 *                     amount:
 *                       type: number
 *                       example: 50.0
 *                     label:
 *                       type: string
 *                       example: "Bonus AGC"
 *                     description:
 *                       type: string
 *                       example: "Can vote only"
 *                 total:
 *                   type: number
 *                   example: 200.0
 *                 conversionRate:
 *                   type: number
 *                   example: 20
 *                 lastUpdated:
 *                   type: string
 *                   format: date-time
 */
walletRouter.get('/balance/detailed', walletController.getDetailedBalance.bind(walletController));

/**
 * @swagger
 * /wallet/transactions:
 *   get:
 *     summary: Get transaction history
 *     description: Returns paginated list of wallet transactions
 *     tags: [Wallet]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Page number
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: Items per page
 *     responses:
 *       200:
 *         description: Transaction history retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   type:
 *                     type: string
 *                     enum: [CREDIT, DEBIT, PURCHASE_USER, PURCHASE_COMPANY, TRANSFER, EARN, SPEND]
 *                   amount:
 *                     type: number
 *                   reason:
 *                     type: string
 *                   description:
 *                     type: string
 *                   status:
 *                     type: string
 *                     enum: [PENDING, COMPLETED, FAILED, CANCELLED]
 *                   createdAt:
 *                     type: string
 *                     format: date-time
 */
walletRouter.get('/transactions', walletController.getTransactions.bind(walletController));

/**
 * @swagger
 * /wallet/transfer:
 *   post:
 *     summary: Transfer AGC to another user
 *     description: Send AGC from your purchased balance to another user. Only agcWithdrawableBalance can be transferred.
 *     tags: [Wallet]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - toUserId
 *               - amount
 *               - description
 *             properties:
 *               toUserId:
 *                 type: string
 *                 description: Recipient user ID
 *                 example: "user_abc123"
 *               amount:
 *                 type: number
 *                 minimum: 0.01
 *                 description: Amount of AGC to transfer
 *                 example: 50
 *               description:
 *                 type: string
 *                 description: Transfer description/note
 *                 example: "Payment for services"
 *               reason:
 *                 type: string
 *                 default: "transfer"
 *                 example: "transfer"
 *     responses:
 *       200:
 *         description: Transfer successful
 *       422:
 *         description: Insufficient balance
 *       400:
 *         description: Invalid request (same wallet, negative amount, etc.)
 */
walletRouter.post('/transfer', walletController.transfer.bind(walletController));

/**
 * @swagger
 * /wallet/purchase/initiate:
 *   post:
 *     summary: Initiate AGC purchase
 *     description: Start AGC purchase process via Paystack. Returns checkout URL. Conversion rate is $1 = 20 AGC (75% to user, 25% to company)
 *     tags: [Wallet]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - amount
 *             properties:
 *               amount:
 *                 type: number
 *                 minimum: 1
 *                 description: Amount in USD (minimum $1)
 *                 example: 10
 *               currency:
 *                 type: string
 *                 enum: [USD, NGN]
 *                 default: USD
 *                 example: USD
 *     responses:
 *       200:
 *         description: Payment initialized successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Payment initialized successfully"
 *                 data:
 *                   type: object
 *                   properties:
 *                     reference:
 *                       type: string
 *                       example: "AGC-1234567890-abc123"
 *                     authorizationUrl:
 *                       type: string
 *                       example: "https://checkout.paystack.com/xxx"
 *                     accessCode:
 *                       type: string
 *                     amount:
 *                       type: number
 *                       example: 10
 *                     currency:
 *                       type: string
 *                       example: "USD"
 *                     agcAmount:
 *                       type: number
 *                       description: Total AGC to be credited (user + company)
 *                       example: 200
 */
walletRouter.post('/purchase/initiate', walletController.initiatePurchase.bind(walletController));

/**
 * @swagger
 * /wallet/purchase/verify/{reference}:
 *   get:
 *     summary: Verify AGC purchase
 *     description: Verify payment status after Paystack checkout and credit wallet if successful
 *     tags: [Wallet]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: reference
 *         required: true
 *         schema:
 *           type: string
 *         description: Payment reference from Paystack
 *         example: "AGC-1234567890-abc123"
 *     responses:
 *       200:
 *         description: Payment verified successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Payment verified successfully"
 *                 data:
 *                   type: object
 *                   properties:
 *                     reference:
 *                       type: string
 *                     status:
 *                       type: string
 *                     agcCredited:
 *                       type: number
 *       400:
 *         description: Payment verification failed
 */
walletRouter.get('/purchase/verify/:reference', walletController.verifyPurchase.bind(walletController));

/**
 * @swagger
 * /wallet/purchases:
 *   get:
 *     summary: Get purchase history
 *     description: Returns paginated list of AGC purchase transactions
 *     tags: [Wallet]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Page number
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: Items per page
 *     responses:
 *       200:
 *         description: Purchase history retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 data:
 *                   type: object
 *                   properties:
 *                     purchases:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           id:
 *                             type: string
 *                           reference:
 *                             type: string
 *                           amount:
 *                             type: number
 *                           currency:
 *                             type: string
 *                           agcAmount:
 *                             type: number
 *                           status:
 *                             type: string
 *                           createdAt:
 *                             type: string
 *                             format: date-time
 *                     pagination:
 *                       type: object
 */
walletRouter.get('/purchases', walletController.getPurchaseHistory.bind(walletController));

/**
 * @swagger
 * /wallet/currencies:
 *   get:
 *     summary: Get supported currencies
 *     description: Returns list of supported currencies with exchange rates
 *     tags: [Wallet]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Supported currencies retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 data:
 *                   type: object
 *                   properties:
 *                     currencies:
 *                       type: array
 *                       items:
 *                         type: string
 *                       example: ["NGN", "USD", "GBP", "EUR", "KES"]
 *                     exchangeRates:
 *                       type: object
 *                     lastUpdated:
 *                       type: string
 *                       format: date-time
 */
walletRouter.get('/currencies', walletController.getSupportedCurrencies.bind(walletController));

/**
 * @swagger
 * /wallet/pricing:
 *   get:
 *     summary: Get pricing tiers for a currency
 *     description: Returns AGC pricing tiers for the specified currency
 *     tags: [Wallet]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: currency
 *         schema:
 *           type: string
 *           default: NGN
 *         description: Currency code (NGN, USD, GBP, etc.)
 *     responses:
 *       200:
 *         description: Pricing tiers retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 data:
 *                   type: object
 *                   properties:
 *                     currency:
 *                       type: string
 *                       example: "NGN"
 *                     tiers:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           amount:
 *                             type: number
 *                             example: 15000
 *                           agc:
 *                             type: number
 *                             example: 200
 *                           bonus:
 *                             type: number
 *                             example: 0
 *                     exchangeRate:
 *                       type: number
 *                       example: 1500
 *                     baseRate:
 *                       type: string
 *                       example: "1 USD = 20 AGC"
 */
walletRouter.get('/pricing', walletController.getPricingTiers.bind(walletController));

export default walletRouter;
