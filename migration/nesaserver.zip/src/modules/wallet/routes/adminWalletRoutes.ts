import { Router } from 'express';
import { adminWalletController } from '../controllers/adminWalletController';
import { verifyToken } from '@/shared/middleware/auth';

const adminWalletRouter = Router();

/**
 * @swagger
 * tags:
 *   name: Admin Wallet
 *   description: Admin wallet management, analytics, and provider health monitoring
 */

// All admin routes require authentication and admin role
// TODO: Add role check middleware (e.g., requireRole(['ADMIN', 'SUPER_ADMIN']))
adminWalletRouter.use(verifyToken);

/**
 * @swagger
 * /wallet/admin/dashboard:
 *   get:
 *     summary: Get admin dashboard summary
 *     description: Returns comprehensive dashboard data including summary, provider health, and real-time metrics
 *     tags: [Admin Wallet]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: days
 *         schema:
 *           type: integer
 *           default: 30
 *         description: Number of days for analytics
 *     responses:
 *       200:
 *         description: Dashboard data retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 data:
 *                   type: object
 *                   properties:
 *                     summary:
 *                       type: object
 *                     providerHealth:
 *                       type: array
 *                     realTimeMetrics:
 *                       type: object
 */
adminWalletRouter.get('/dashboard', adminWalletController.getDashboard.bind(adminWalletController));

/**
 * @swagger
 * /wallet/admin/analytics/transactions:
 *   get:
 *     summary: Get transaction analytics
 *     description: Returns detailed transaction analytics for specified time period
 *     tags: [Admin Wallet]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: days
 *         schema:
 *           type: integer
 *           default: 30
 *         description: Number of days for analytics
 *     responses:
 *       200:
 *         description: Transaction analytics retrieved successfully
 */
adminWalletRouter.get('/analytics/transactions', adminWalletController.getTransactionAnalytics.bind(adminWalletController));

/**
 * @swagger
 * /wallet/admin/analytics/wallets:
 *   get:
 *     summary: Get wallet analytics
 *     description: Returns wallet statistics and distribution data
 *     tags: [Admin Wallet]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Wallet analytics retrieved successfully
 */
adminWalletRouter.get('/analytics/wallets', adminWalletController.getWalletAnalytics.bind(adminWalletController));

/**
 * @swagger
 * /wallet/admin/analytics/purchases:
 *   get:
 *     summary: Get purchase analytics
 *     description: Returns AGC purchase analytics and trends
 *     tags: [Admin Wallet]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: days
 *         schema:
 *           type: integer
 *           default: 30
 *         description: Number of days for analytics
 *     responses:
 *       200:
 *         description: Purchase analytics retrieved successfully
 */
adminWalletRouter.get('/analytics/purchases', adminWalletController.getPurchaseAnalytics.bind(adminWalletController));

/**
 * @swagger
 * /wallet/admin/analytics/revenue:
 *   get:
 *     summary: Get revenue analytics
 *     description: Returns revenue data and financial metrics
 *     tags: [Admin Wallet]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: days
 *         schema:
 *           type: integer
 *           default: 30
 *         description: Number of days for analytics
 *     responses:
 *       200:
 *         description: Revenue analytics retrieved successfully
 */
adminWalletRouter.get('/analytics/revenue', adminWalletController.getRevenueAnalytics.bind(adminWalletController));

/**
 * @swagger
 * /wallet/admin/providers:
 *   get:
 *     summary: Get all provider health statuses
 *     description: Returns health status for all payment providers
 *     tags: [Admin Wallet]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Provider health retrieved successfully
 */
adminWalletRouter.get('/providers', adminWalletController.getProviderHealth.bind(adminWalletController));

/**
 * @swagger
 * /wallet/admin/providers/{providerName}:
 *   get:
 *     summary: Get specific provider health
 *     description: Returns health status for a specific payment provider
 *     tags: [Admin Wallet]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: providerName
 *         required: true
 *         schema:
 *           type: string
 *         description: Provider name (e.g., paystack, stripe)
 *     responses:
 *       200:
 *         description: Provider health retrieved successfully
 *       404:
 *         description: Provider not found
 */
adminWalletRouter.get('/providers/:providerName', adminWalletController.getProviderHealthByName.bind(adminWalletController));

/**
 * @swagger
 * /wallet/admin/providers/{providerName}/toggle:
 *   put:
 *     summary: Toggle provider enabled/disabled
 *     description: Enable or disable a payment provider
 *     tags: [Admin Wallet]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: providerName
 *         required: true
 *         schema:
 *           type: string
 *         description: Provider name
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - enabled
 *             properties:
 *               enabled:
 *                 type: boolean
 *                 description: Enable or disable the provider
 *                 example: true
 *     responses:
 *       200:
 *         description: Provider toggled successfully
 */
adminWalletRouter.put('/providers/:providerName/toggle', adminWalletController.toggleProvider.bind(adminWalletController));

/**
 * @swagger
 * /wallet/admin/providers/{providerName}/check:
 *   post:
 *     summary: Run health check for a provider
 *     description: Manually trigger health check for a payment provider
 *     tags: [Admin Wallet]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: providerName
 *         required: true
 *         schema:
 *           type: string
 *         description: Provider name
 *     responses:
 *       200:
 *         description: Health check completed
 */
adminWalletRouter.post('/providers/:providerName/check', adminWalletController.checkProviderHealth.bind(adminWalletController));

/**
 * @swagger
 * /wallet/admin/providers/{providerName}/metrics:
 *   get:
 *     summary: Get provider metrics
 *     description: Returns performance metrics for a payment provider
 *     tags: [Admin Wallet]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: providerName
 *         required: true
 *         schema:
 *           type: string
 *         description: Provider name
 *       - in: query
 *         name: hours
 *         schema:
 *           type: integer
 *           default: 24
 *         description: Number of hours for metrics
 *     responses:
 *       200:
 *         description: Provider metrics retrieved successfully
 */
adminWalletRouter.get('/providers/:providerName/metrics', adminWalletController.getProviderMetrics.bind(adminWalletController));

/**
 * @swagger
 * /wallet/admin/credit:
 *   post:
 *     summary: Credit AGC to user wallet
 *     description: Manually add AGC to a user's wallet (admin only)
 *     tags: [Admin Wallet]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - userId
 *               - amount
 *               - reason
 *             properties:
 *               userId:
 *                 type: string
 *                 description: User ID to credit
 *                 example: "user_123"
 *               amount:
 *                 type: number
 *                 minimum: 0.01
 *                 description: Amount of AGC to credit
 *                 example: 100
 *               reason:
 *                 type: string
 *                 description: Reason for credit
 *                 example: "Promotional bonus"
 *               description:
 *                 type: string
 *                 description: Additional description
 *     responses:
 *       200:
 *         description: Wallet credited successfully
 */
adminWalletRouter.post('/credit', adminWalletController.creditWallet.bind(adminWalletController));

/**
 * @swagger
 * /wallet/admin/debit:
 *   post:
 *     summary: Debit AGC from user wallet
 *     description: Manually remove AGC from a user's wallet (admin only)
 *     tags: [Admin Wallet]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - userId
 *               - amount
 *               - reason
 *             properties:
 *               userId:
 *                 type: string
 *                 description: User ID to debit
 *                 example: "user_123"
 *               amount:
 *                 type: number
 *                 minimum: 0.01
 *                 description: Amount of AGC to debit
 *                 example: 50
 *               reason:
 *                 type: string
 *                 description: Reason for debit
 *                 example: "Refund processing"
 *               description:
 *                 type: string
 *                 description: Additional description
 *     responses:
 *       200:
 *         description: Wallet debited successfully
 *       422:
 *         description: Insufficient balance
 */
adminWalletRouter.post('/debit', adminWalletController.debitWallet.bind(adminWalletController));

/**
 * @swagger
 * /wallet/admin/wallets:
 *   get:
 *     summary: Get all wallets
 *     description: Returns paginated list of all user wallets with balances
 *     tags: [Admin Wallet]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Page number
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *         description: Items per page
 *     responses:
 *       200:
 *         description: Wallets retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 data:
 *                   type: object
 *                   properties:
 *                     wallets:
 *                       type: array
 *                     pagination:
 *                       type: object
 */
adminWalletRouter.get('/wallets', adminWalletController.getAllWallets.bind(adminWalletController));

/**
 * @swagger
 * /wallet/admin/users/{userId}/balance:
 *   get:
 *     summary: Get user wallet balance
 *     description: Returns specific user's wallet balance with multi-currency display
 *     tags: [Admin Wallet]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *         description: User ID
 *     responses:
 *       200:
 *         description: User wallet balance retrieved successfully
 *       404:
 *         description: User not found
 */
adminWalletRouter.get('/users/:userId/balance', adminWalletController.getUserWalletBalance.bind(adminWalletController));

/**
 * @swagger
 * /wallet/admin/exchange-rates:
 *   get:
 *     summary: Get exchange rates
 *     description: Returns current exchange rates for supported currencies
 *     tags: [Admin Wallet]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Exchange rates retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 data:
 *                   type: object
 */
adminWalletRouter.get('/exchange-rates', adminWalletController.getExchangeRates.bind(adminWalletController));

export default adminWalletRouter;
