// @ts-ignore - paystack-api doesn't have type definitions
import Paystack from 'paystack-api';
import { config } from '@/config';
import logger from '@/shared/utils/logger';

export interface InitializePaymentParams {
  email: string;
  amount: number; // in kobo (NGN) or cents (USD)
  currency?: 'NGN' | 'USD';
  reference?: string;
  metadata?: Record<string, any>;
  callback_url?: string;
}

export interface InitializePaymentResponse {
  status: boolean;
  message: string;
  data: {
    authorization_url: string;
    access_code: string;
    reference: string;
  };
}

export interface VerifyPaymentResponse {
  status: boolean;
  message: string;
  data: {
    id: number;
    domain: string;
    status: 'success' | 'failed' | 'abandoned';
    reference: string;
    amount: number;
    message: string | null;
    gateway_response: string;
    paid_at: string;
    created_at: string;
    channel: string;
    currency: string;
    ip_address: string;
    metadata: Record<string, any>;
    customer: {
      id: number;
      email: string;
      customer_code: string;
    };
    authorization: {
      authorization_code: string;
      bin: string;
      last4: string;
      exp_month: string;
      exp_year: string;
      channel: string;
      card_type: string;
      bank: string;
      country_code: string;
      brand: string;
      reusable: boolean;
      signature: string;
    };
  };
}

class PaystackService {
  private paystack: any;

  constructor() {
    if (!config.paystack.secretKey) {
      logger.warn('⚠️ Paystack secret key not configured. Payment features will be disabled.');
      return;
    }
    this.paystack = Paystack(config.paystack.secretKey);
  }

  /**
   * Initialize a payment transaction
   */
  async initializePayment(params: InitializePaymentParams): Promise<InitializePaymentResponse> {
    try {
      if (!this.paystack) {
        throw new Error('Paystack is not configured');
      }

      const response = await this.paystack.transaction.initialize({
        email: params.email,
        amount: params.amount,
        currency: params.currency || 'NGN',
        reference: params.reference,
        metadata: params.metadata,
        callback_url: params.callback_url,
      });

      logger.info('Payment initialized', { reference: response.data.reference });
      return response;
    } catch (error) {
      logger.error('Failed to initialize payment', error);
      throw new Error('Failed to initialize payment');
    }
  }

  /**
   * Verify a payment transaction
   */
  async verifyPayment(reference: string): Promise<VerifyPaymentResponse> {
    try {
      if (!this.paystack) {
        throw new Error('Paystack is not configured');
      }

      const response = await this.paystack.transaction.verify(reference);
      logger.info('Payment verified', { reference, status: response.data.status });
      return response;
    } catch (error) {
      logger.error('Failed to verify payment', { reference, error });
      throw new Error('Failed to verify payment');
    }
  }

  /**
   * Verify webhook signature
   */
  verifyWebhookSignature(payload: string, signature: string): boolean {
    const crypto = require('crypto');
    const hash = crypto
      .createHmac('sha512', config.paystack.webhookSecret)
      .update(payload)
      .digest('hex');
    
    return hash === signature;
  }

  /**
   * Convert amount from dollars to kobo (for NGN) or cents (for USD)
   * Paystack expects amounts in the smallest currency unit
   */
  convertToSmallestUnit(amount: number, currency: 'NGN' | 'USD' = 'NGN'): number {
    // Both NGN and USD use 100 subunits (kobo/cents)
    return Math.round(amount * 100);
  }

  /**
   * Convert amount from kobo/cents back to main currency unit
   */
  convertFromSmallestUnit(amount: number): number {
    return amount / 100;
  }

  /**
   * Get transaction details
   */
  async getTransaction(transactionId: number): Promise<any> {
    try {
      if (!this.paystack) {
        throw new Error('Paystack is not configured');
      }

      const response = await this.paystack.transaction.get(transactionId);
      return response;
    } catch (error) {
      logger.error('Failed to get transaction', { transactionId, error });
      throw new Error('Failed to get transaction');
    }
  }

  /**
   * List transactions with filters
   */
  async listTransactions(params?: {
    perPage?: number;
    page?: number;
    customer?: string;
    status?: 'success' | 'failed' | 'abandoned';
    from?: string;
    to?: string;
  }): Promise<any> {
    try {
      if (!this.paystack) {
        throw new Error('Paystack is not configured');
      }

      const response = await this.paystack.transaction.list(params);
      return response;
    } catch (error) {
      logger.error('Failed to list transactions', error);
      throw new Error('Failed to list transactions');
    }
  }
}

export const paystackService = new PaystackService();
