import axios from 'axios';
import crypto from 'crypto';
import { config } from '@/config';
import logger from '@/shared/utils/logger';

export interface FlutterwavePaymentParams {
  email: string;
  amount: number;
  currency: string;
  reference: string;
  customer: {
    email: string;
    name?: string;
    phonenumber?: string;
  };
  customizations?: {
    title?: string;
    description?: string;
    logo?: string;
  };
  metadata?: Record<string, any>;
  redirect_url?: string;
}

export interface FlutterwavePaymentResponse {
  status: string;
  message: string;
  data: {
    link: string;
  };
}

export interface FlutterwaveVerificationResponse {
  status: string;
  message: string;
  data: {
    id: number;
    tx_ref: string;
    flw_ref: string;
    amount: number;
    currency: string;
    charged_amount: number;
    status: string;
    payment_type: string;
    customer: {
      email: string;
      name: string;
    };
    meta?: Record<string, any>;
  };
}

class FlutterwaveService {
  private readonly baseUrl = 'https://api.flutterwave.com/v3';
  private readonly secretKey: string;

  constructor() {
    this.secretKey = config.flutterwave?.secretKey || process.env.FLUTTERWAVE_SECRET_KEY || '';
    
    if (!this.secretKey) {
      logger.warn('Flutterwave secret key not configured');
    }
  }

  /**
   * Initialize a payment
   */
  async initializePayment(params: FlutterwavePaymentParams): Promise<FlutterwavePaymentResponse> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/payments`,
        {
          tx_ref: params.reference,
          amount: params.amount,
          currency: params.currency,
          redirect_url: params.redirect_url,
          customer: params.customer,
          customizations: params.customizations || {
            title: 'NESA-Africa AGC Purchase',
            description: 'Purchase AGC tokens',
          },
          meta: params.metadata,
        },
        {
          headers: {
            Authorization: `Bearer ${this.secretKey}`,
            'Content-Type': 'application/json',
          },
        }
      );

      logger.info('Flutterwave payment initialized', {
        reference: params.reference,
        amount: params.amount,
        currency: params.currency,
      });

      return response.data;
    } catch (error) {
      logger.error('Failed to initialize Flutterwave payment', { error, params });
      throw new Error('Failed to initialize payment');
    }
  }

  /**
   * Verify a payment
   */
  async verifyPayment(transactionId: string): Promise<FlutterwaveVerificationResponse> {
    try {
      const response = await axios.get(
        `${this.baseUrl}/transactions/${transactionId}/verify`,
        {
          headers: {
            Authorization: `Bearer ${this.secretKey}`,
          },
        }
      );

      logger.info('Flutterwave payment verified', {
        transactionId,
        status: response.data.data.status,
      });

      return response.data;
    } catch (error) {
      logger.error('Failed to verify Flutterwave payment', { error, transactionId });
      throw new Error('Failed to verify payment');
    }
  }

  /**
   * Verify webhook signature
   */
  verifyWebhookSignature(payload: string, signature: string): boolean {
    const hash = crypto
      .createHmac('sha256', this.secretKey)
      .update(payload)
      .digest('hex');

    return hash === signature;
  }

  /**
   * Get supported currencies
   */
  getSupportedCurrencies(): string[] {
    return [
      'NGN', // Nigerian Naira
      'USD', // US Dollar
      'GBP', // British Pound
      'EUR', // Euro
      'KES', // Kenyan Shilling
      'GHS', // Ghanaian Cedi
      'ZAR', // South African Rand
      'TZS', // Tanzanian Shilling
      'UGX', // Ugandan Shilling
      'XAF', // Central African CFA Franc
      'XOF', // West African CFA Franc
    ];
  }

  /**
   * Check if currency is supported
   */
  isCurrencySupported(currency: string): boolean {
    return this.getSupportedCurrencies().includes(currency.toUpperCase());
  }
}

export const flutterwaveService = new FlutterwaveService();
