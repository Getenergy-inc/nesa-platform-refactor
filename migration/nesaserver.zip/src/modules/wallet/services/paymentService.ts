import { prisma } from '@/shared/database/postgresql';
import { flutterwaveService } from './flutterwaveService';
import { exchangeRateService } from './exchangeRateService';
import { walletService } from './walletService';
import { config } from '@/config';
import logger from '@/shared/utils/logger';
import crypto from 'crypto';
import { WalletTransactionStatus } from '@prisma/client';

export interface InitiatePurchaseParams {
  userId: string;
  email: string;
  amount: number; // Amount in the specified currency
  currency?: string;
  userName?: string;
}

export interface InitiatePurchaseResponse {
  reference: string;
  authorizationUrl: string;
  accessCode: string;
  amount: number;
  currency: string;
  agcAmount: number;
}

class FlutterwavePaymentService {
  private readonly AGC_CONVERSION_RATE = 20; // $1 = 20 AGC
  private readonly USER_SPLIT = 0.75; // 75% to user
  private readonly COMPANY_SPLIT = 0.25; // 25% to company

  /**
   * Generate a unique payment reference
   */
  private generateReference(): string {
    const timestamp = Date.now();
    const random = crypto.randomBytes(4).toString('hex');
    return `AGC-${timestamp}-${random}`;
  }

  /**
   * Calculate AGC amounts from any currency amount
   */
  private calculateAgcAmounts(amount: number, currency: string) {
    const totalAgc = exchangeRateService.calculateAGC(amount, currency);
    const userAgc = totalAgc * this.USER_SPLIT;
    const companyAgc = totalAgc * this.COMPANY_SPLIT;

    return {
      totalAgc,
      userAgc,
      companyAgc,
    };
  }

  /**
   * Initiate a purchase transaction
   */
  async initiatePurchase(params: InitiatePurchaseParams): Promise<InitiatePurchaseResponse> {
    const { userId, email, amount, currency = 'NGN', userName } = params;

    // Validate amount
    if (amount <= 0) {
      throw new Error('Amount must be greater than zero');
    }

    // Validate minimum amount (equivalent to $1 USD)
    const minAmountUSD = 1;
    const amountInUSD = exchangeRateService.toUSD(amount, currency);
    if (amountInUSD < minAmountUSD) {
      const minAmount = Math.ceil(exchangeRateService.fromUSD(minAmountUSD, currency));
      throw new Error(`Minimum purchase amount is ${minAmount} ${currency}`);
    }

    // Calculate AGC amounts
    const { totalAgc, userAgc, companyAgc } = this.calculateAgcAmounts(amount, currency);

    // Generate unique reference
    const reference = this.generateReference();

    // Create pending transaction record
    const wallet = await walletService.getWalletByUserId(userId);
    
    await prisma.walletTransaction.create({
      data: {
        walletId: wallet.id,
        type: 'PURCHASE_USER',
        amount: userAgc,
        reason: 'purchase_pending',
        description: `Pending purchase of ${amount} ${currency} worth of AGC`,
        referenceId: reference,
        status: WalletTransactionStatus.PENDING,
      },
    });

    // Initialize payment with Flutterwave
    const callbackUrl = `${config.frontendUrl}/wallet/payment/callback`;

    const paymentResponse = await flutterwaveService.initializePayment({
      email,
      amount,
      currency,
      reference,
      customer: {
        email,
        ...(userName && { name: userName }),
      },
      customizations: {
        title: 'NESA-Africa AGC Purchase',
        description: `Purchase ${Math.round(totalAgc)} AGC tokens`,
      },
      metadata: {
        userId,
        amount,
        currency,
        totalAgc,
        userAgc,
        companyAgc,
        purpose: 'agc_purchase',
      },
      redirect_url: callbackUrl,
    });

    logger.info('Purchase initiated via Flutterwave', {
      userId,
      reference,
      amount,
      currency,
      totalAgc,
    });

    return {
      reference,
      authorizationUrl: paymentResponse.data.link,
      accessCode: reference,
      amount,
      currency,
      agcAmount: totalAgc,
    };
  }

  /**
   * Verify and complete a purchase transaction
   */
  async verifyPurchase(transactionId: string): Promise<{
    success: boolean;
    message: string;
    data?: any;
  }> {
    try {
      // Verify payment with Flutterwave
      const verification = await flutterwaveService.verifyPayment(transactionId);

      if (verification.status !== 'success') {
        return {
          success: false,
          message: 'Payment verification failed',
        };
      }

      const paymentData = verification.data;

      // Check if payment was successful
      if (paymentData.status !== 'successful') {
        // Update transaction status to failed
        await this.updateTransactionStatus(paymentData.tx_ref, WalletTransactionStatus.FAILED);
        
        return {
          success: false,
          message: `Payment ${paymentData.status}`,
        };
      }

      // Check if already processed (idempotency)
      const existingTransaction = await prisma.walletTransaction.findFirst({
        where: {
          referenceId: paymentData.tx_ref,
          status: WalletTransactionStatus.COMPLETED,
        },
      });

      if (existingTransaction) {
        logger.info('Payment already processed', { reference: paymentData.tx_ref });
        return {
          success: true,
          message: 'Payment already processed',
          data: existingTransaction,
        };
      }

      // Extract metadata
      const metadata = paymentData.meta || {};
      const userId = metadata.userId;
      const userAgc = metadata.userAgc;
      const companyAgc = metadata.companyAgc;
      const amount = paymentData.amount;
      const currency = paymentData.currency;

      // Process the purchase (credit wallets)
      const amountInUSD = exchangeRateService.toUSD(amount, currency);
      await walletService.purchase(userId, amountInUSD);

      // Update transaction status
      await this.updateTransactionStatus(paymentData.tx_ref, WalletTransactionStatus.COMPLETED);

      logger.info('Purchase completed', {
        userId,
        reference: paymentData.tx_ref,
        userAgc,
        companyAgc,
      });

      return {
        success: true,
        message: 'Purchase completed successfully',
        data: {
          reference: paymentData.tx_ref,
          userAgc,
          companyAgc,
          totalAgc: userAgc + companyAgc,
        },
      };
    } catch (error) {
      logger.error('Failed to verify purchase', { transactionId, error });
      throw new Error('Failed to verify purchase');
    }
  }

  /**
   * Update transaction status
   */
  private async updateTransactionStatus(reference: string, status: WalletTransactionStatus) {
    await prisma.walletTransaction.updateMany({
      where: { referenceId: reference },
      data: { status },
    });
  }

  /**
   * Handle Flutterwave webhook events
   */
  async handleWebhook(event: any): Promise<void> {
    const eventType = event.event;
    const data = event.data;

    logger.info('Flutterwave webhook received', { eventType, reference: data.tx_ref });

    switch (eventType) {
      case 'charge.completed':
        if (data.status === 'successful') {
          await this.handleChargeSuccess(data);
        } else {
          await this.handleChargeFailed(data);
        }
        break;
      
      default:
        logger.info('Unhandled webhook event', { eventType });
    }
  }

  /**
   * Handle successful charge webhook
   */
  private async handleChargeSuccess(data: any): Promise<void> {
    const transactionId = data.id;
    
    try {
      await this.verifyPurchase(transactionId.toString());
    } catch (error) {
      logger.error('Failed to process charge.completed webhook', { transactionId, error });
    }
  }

  /**
   * Handle failed charge webhook
   */
  private async handleChargeFailed(data: any): Promise<void> {
    const reference = data.tx_ref;
    
    try {
      await this.updateTransactionStatus(reference, WalletTransactionStatus.FAILED);
      logger.info('Payment marked as failed', { reference });
    } catch (error) {
      logger.error('Failed to process charge.failed webhook', { reference, error });
    }
  }

  /**
   * Get purchase history for a user
   */
  async getPurchaseHistory(userId: string, options?: { page?: number; limit?: number }) {
    const wallet = await walletService.getWalletByUserId(userId);
    const page = options?.page || 1;
    const limit = options?.limit || 10;
    const skip = (page - 1) * limit;

    const [transactions, total] = await Promise.all([
      prisma.walletTransaction.findMany({
        where: {
          walletId: wallet.id,
          type: { in: ['PURCHASE_USER', 'PURCHASE_COMPANY'] },
        },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      prisma.walletTransaction.count({
        where: {
          walletId: wallet.id,
          type: { in: ['PURCHASE_USER', 'PURCHASE_COMPANY'] },
        },
      }),
    ]);

    return {
      transactions,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  /**
   * Get supported currencies
   */
  getSupportedCurrencies(): string[] {
    return flutterwaveService.getSupportedCurrencies();
  }

  /**
   * Get pricing tiers for a currency
   */
  getPricingTiers(currency: string) {
    return exchangeRateService.getPricingTiers(currency);
  }
}

export const flutterwavePaymentService = new FlutterwavePaymentService();
export const paymentService = flutterwavePaymentService; // Default export for backward compatibility
