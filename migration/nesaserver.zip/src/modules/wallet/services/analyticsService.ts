import { prisma } from '@/shared/database/postgresql';
import { WalletTransactionType, WalletTransactionStatus } from '@prisma/client';

export interface TransactionAnalytics {
  totalTransactions: number;
  totalVolume: number;
  averageTransactionSize: number;
  byType: Record<string, { count: number; volume: number }>;
  byStatus: Record<string, number>;
  topUsers: Array<{ userId: string; transactionCount: number; totalVolume: number }>;
}

export interface WalletAnalytics {
  totalWallets: number;
  totalAgcInCirculation: number;
  totalWithdrawableBalance: number;
  totalLockedBalance: number;
  companyReserveBalance: number;
  averageWalletBalance: number;
  walletsWithBalance: number;
  emptyWallets: number;
}

export interface PurchaseAnalytics {
  totalPurchases: number;
  totalRevenue: number; // in AGC
  averagePurchaseSize: number;
  conversionRate: number; // percentage of users who purchased
  topPurchasers: Array<{ userId: string; purchaseCount: number; totalSpent: number }>;
  purchasesByDay: Array<{ date: string; count: number; volume: number }>;
}

export interface RevenueAnalytics {
  userRevenue: number; // 75% of purchases
  companyRevenue: number; // 25% of purchases
  totalRevenue: number;
  revenueByDay: Array<{ date: string; userRevenue: number; companyRevenue: number }>;
}

class AnalyticsService {
  /**
   * Get transaction analytics for a time period
   */
  async getTransactionAnalytics(
    startDate: Date,
    endDate: Date
  ): Promise<TransactionAnalytics> {
    const transactions = await prisma.walletTransaction.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate,
        },
      },
      select: {
        type: true,
        amount: true,
        status: true,
        walletId: true,
        wallet: {
          select: {
            userId: true,
          },
        },
      },
    });

    const totalTransactions = transactions.length;
    const totalVolume = transactions.reduce((sum, t) => sum + t.amount, 0);
    const averageTransactionSize = totalTransactions > 0 ? totalVolume / totalTransactions : 0;

    // Group by type
    const byType: Record<string, { count: number; volume: number }> = {};
    transactions.forEach((t) => {
      if (!byType[t.type]) {
        byType[t.type] = { count: 0, volume: 0 };
      }
      const typeStats = byType[t.type];
      if (typeStats) {
        typeStats.count++;
        typeStats.volume += t.amount;
      }
    });

    // Group by status
    const byStatus: Record<string, number> = {};
    transactions.forEach((t) => {
      byStatus[t.status] = (byStatus[t.status] || 0) + 1;
    });

    // Top users by transaction count
    const userStats = new Map<string, { count: number; volume: number }>();
    transactions.forEach((t) => {
      const userId = t.wallet?.userId;
      if (userId) {
        if (!userStats.has(userId)) {
          userStats.set(userId, { count: 0, volume: 0 });
        }
        const stats = userStats.get(userId)!;
        stats.count++;
        stats.volume += t.amount;
      }
    });

    const topUsers = Array.from(userStats.entries())
      .map(([userId, stats]) => ({
        userId,
        transactionCount: stats.count,
        totalVolume: stats.volume,
      }))
      .sort((a, b) => b.transactionCount - a.transactionCount)
      .slice(0, 10);

    return {
      totalTransactions,
      totalVolume,
      averageTransactionSize,
      byType,
      byStatus,
      topUsers,
    };
  }

  /**
   * Get wallet analytics
   */
  async getWalletAnalytics(): Promise<WalletAnalytics> {
    const [wallets, aggregates, companyWallet] = await Promise.all([
      prisma.wallet.findMany({
        select: {
          agcWithdrawableBalance: true,
          agcLockedBalance: true,
          userId: true,
        },
      }),
      prisma.wallet.aggregate({
        _sum: {
          agcWithdrawableBalance: true,
          agcLockedBalance: true,
        },
        _avg: {
          agcWithdrawableBalance: true,
        },
      }),
      prisma.wallet.findUnique({
        where: { userId: 'company_reserve' },
        select: {
          agcWithdrawableBalance: true,
        },
      }),
    ]);

    const totalWallets = wallets.length;
    const totalWithdrawableBalance = aggregates._sum.agcWithdrawableBalance || 0;
    const totalLockedBalance = aggregates._sum.agcLockedBalance || 0;
    const totalAgcInCirculation = totalWithdrawableBalance + totalLockedBalance;
    const averageWalletBalance = aggregates._avg.agcWithdrawableBalance || 0;
    const companyReserveBalance = companyWallet?.agcWithdrawableBalance || 0;

    const walletsWithBalance = wallets.filter(
      (w) => w.agcWithdrawableBalance > 0 || w.agcLockedBalance > 0
    ).length;
    const emptyWallets = totalWallets - walletsWithBalance;

    return {
      totalWallets,
      totalAgcInCirculation,
      totalWithdrawableBalance,
      totalLockedBalance,
      companyReserveBalance,
      averageWalletBalance,
      walletsWithBalance,
      emptyWallets,
    };
  }

  /**
   * Get purchase analytics
   */
  async getPurchaseAnalytics(startDate: Date, endDate: Date): Promise<PurchaseAnalytics> {
    const purchases = await prisma.walletTransaction.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate,
        },
        type: WalletTransactionType.PURCHASE_USER,
        status: WalletTransactionStatus.COMPLETED,
      },
      select: {
        amount: true,
        createdAt: true,
        wallet: {
          select: {
            userId: true,
          },
        },
      },
    });

    const totalPurchases = purchases.length;
    const totalRevenue = purchases.reduce((sum, p) => sum + p.amount, 0);
    const averagePurchaseSize = totalPurchases > 0 ? totalRevenue / totalPurchases : 0;

    // Calculate conversion rate
    const totalUsers = await prisma.user.count();
    const uniquePurchasers = new Set(purchases.map((p) => p.wallet.userId)).size;
    const conversionRate = totalUsers > 0 ? (uniquePurchasers / totalUsers) * 100 : 0;

    // Top purchasers
    const userPurchases = new Map<string, { count: number; total: number }>();
    purchases.forEach((p) => {
      const userId = p.wallet?.userId;
      if (userId) {
        if (!userPurchases.has(userId)) {
          userPurchases.set(userId, { count: 0, total: 0 });
        }
        const stats = userPurchases.get(userId)!;
        stats.count++;
        stats.total += p.amount;
      }
    });

    const topPurchasers = Array.from(userPurchases.entries())
      .map(([userId, stats]) => ({
        userId,
        purchaseCount: stats.count,
        totalSpent: stats.total,
      }))
      .sort((a, b) => b.totalSpent - a.totalSpent)
      .slice(0, 10);

    // Purchases by day
    const purchasesByDay = this.groupByDay(purchases);

    return {
      totalPurchases,
      totalRevenue,
      averagePurchaseSize,
      conversionRate,
      topPurchasers,
      purchasesByDay,
    };
  }

  /**
   * Get revenue analytics
   */
  async getRevenueAnalytics(startDate: Date, endDate: Date): Promise<RevenueAnalytics> {
    const [userTransactions, companyTransactions] = await Promise.all([
      prisma.walletTransaction.findMany({
        where: {
          createdAt: { gte: startDate, lte: endDate },
          type: WalletTransactionType.PURCHASE_USER,
          status: WalletTransactionStatus.COMPLETED,
        },
        select: { amount: true, createdAt: true },
      }),
      prisma.walletTransaction.findMany({
        where: {
          createdAt: { gte: startDate, lte: endDate },
          type: WalletTransactionType.PURCHASE_COMPANY,
          status: WalletTransactionStatus.COMPLETED,
        },
        select: { amount: true, createdAt: true },
      }),
    ]);

    const userRevenue = userTransactions.reduce((sum, t) => sum + t.amount, 0);
    const companyRevenue = companyTransactions.reduce((sum, t) => sum + t.amount, 0);
    const totalRevenue = userRevenue + companyRevenue;

    // Revenue by day
    const userByDay = this.groupByDay(userTransactions);
    const companyByDay = this.groupByDay(companyTransactions);

    const revenueByDay = userByDay.map((day) => {
      const companyDay = companyByDay.find((d) => d.date === day.date);
      return {
        date: day.date,
        userRevenue: day.volume,
        companyRevenue: companyDay?.volume || 0,
      };
    });

    return {
      userRevenue,
      companyRevenue,
      totalRevenue,
      revenueByDay,
    };
  }

  /**
   * Get dashboard summary
   */
  async getDashboardSummary(days: number = 30) {
    const endDate = new Date();
    const startDate = new Date(endDate.getTime() - days * 24 * 60 * 60 * 1000);

    const [walletAnalytics, transactionAnalytics, purchaseAnalytics, revenueAnalytics] =
      await Promise.all([
        this.getWalletAnalytics(),
        this.getTransactionAnalytics(startDate, endDate),
        this.getPurchaseAnalytics(startDate, endDate),
        this.getRevenueAnalytics(startDate, endDate),
      ]);

    return {
      period: {
        days,
        startDate,
        endDate,
      },
      wallets: walletAnalytics,
      transactions: transactionAnalytics,
      purchases: purchaseAnalytics,
      revenue: revenueAnalytics,
    };
  }

  /**
   * Helper: Group transactions by day
   */
  private groupByDay(
    transactions: Array<{ amount: number; createdAt: Date }>
  ): Array<{ date: string; count: number; volume: number }> {
    const byDay = new Map<string, { count: number; volume: number }>();

    transactions.forEach((t) => {
      const date = t.createdAt.toISOString().split('T')[0];
      if (date) {
        if (!byDay.has(date)) {
          byDay.set(date, { count: 0, volume: 0 });
        }
        const stats = byDay.get(date);
        if (stats) {
          stats.count++;
          stats.volume += t.amount;
        }
      }
    });

    return Array.from(byDay.entries())
      .map(([date, stats]) => ({
        date,
        count: stats.count,
        volume: stats.volume,
      }))
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  /**
   * Get real-time metrics
   */
  async getRealTimeMetrics() {
    const now = new Date();
    const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    const [lastHourTransactions, last24HourTransactions, pendingTransactions] =
      await Promise.all([
        prisma.walletTransaction.count({
          where: { createdAt: { gte: oneHourAgo } },
        }),
        prisma.walletTransaction.count({
          where: { createdAt: { gte: oneDayAgo } },
        }),
        prisma.walletTransaction.count({
          where: { status: WalletTransactionStatus.PENDING },
        }),
      ]);

    return {
      lastHourTransactions,
      last24HourTransactions,
      pendingTransactions,
      timestamp: now,
    };
  }
}

export const analyticsService = new AnalyticsService();
