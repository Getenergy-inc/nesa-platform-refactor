import { prisma } from '@/shared/database/postgresql';

export class SystemWalletService {
  async getCompanyReserveWalletId(): Promise<string> {
    // Check if company reserve wallet exists
    let companyWallet = await prisma.wallet.findFirst({
      where: { userId: 'company_reserve' },
    });

    // If not, create it
    if (!companyWallet) {
      companyWallet = await prisma.wallet.create({
        data: { userId: 'company_reserve' },
      });
    }

    return companyWallet.id;
  }
}

export const systemWalletService = new SystemWalletService();