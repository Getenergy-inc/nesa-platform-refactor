import axios from 'axios';
import logger from '@/shared/utils/logger';

interface ExchangeRates {
  [currency: string]: number;
}

class ExchangeRateService {
  private rates: ExchangeRates = {};
  private lastUpdate: Date | null = null;
  private readonly updateInterval = 3600000; // 1 hour
  private readonly baseUrl = 'https://api.exchangerate-api.com/v4/latest/USD';

  // Fallback rates (updated as of Nov 2024)
  private readonly fallbackRates: ExchangeRates = {
    USD: 1,
    NGN: 1500,
    GBP: 0.79,
    EUR: 0.92,
    KES: 129,
    GHS: 12,
    ZAR: 18,
    TZS: 2500,
    UGX: 3700,
    XAF: 605,
    XOF: 605,
  };

  constructor() {
    this.rates = { ...this.fallbackRates };
    this.startPeriodicUpdates();
  }

  /**
   * Get exchange rate for a currency (relative to USD)
   */
  getRate(currency: string): number {
    const upperCurrency = currency.toUpperCase();
    return this.rates[upperCurrency] || this.fallbackRates[upperCurrency] || 1;
  }

  /**
   * Convert amount from one currency to another
   */
  convert(amount: number, fromCurrency: string, toCurrency: string): number {
    const fromRate = this.getRate(fromCurrency);
    const toRate = this.getRate(toCurrency);
    
    // Convert to USD first, then to target currency
    const amountInUSD = amount / fromRate;
    const convertedAmount = amountInUSD * toRate;
    
    return Math.round(convertedAmount * 100) / 100; // Round to 2 decimal places
  }

  /**
   * Convert any currency to USD
   */
  toUSD(amount: number, fromCurrency: string): number {
    return this.convert(amount, fromCurrency, 'USD');
  }

  /**
   * Convert USD to any currency
   */
  fromUSD(amount: number, toCurrency: string): number {
    return this.convert(amount, 'USD', toCurrency);
  }

  /**
   * Calculate AGC amount from currency amount
   * Base rate: $1 USD = 20 AGC
   */
  calculateAGC(amount: number, currency: string): number {
    const AGC_PER_USD = 20;
    const amountInUSD = this.toUSD(amount, currency);
    return Math.round(amountInUSD * AGC_PER_USD * 100) / 100;
  }

  /**
   * Calculate currency amount from AGC amount
   */
  calculateCurrencyFromAGC(agcAmount: number, currency: string): number {
    const AGC_PER_USD = 20;
    const amountInUSD = agcAmount / AGC_PER_USD;
    return this.fromUSD(amountInUSD, currency);
  }

  /**
   * Get all current rates
   */
  getAllRates(): ExchangeRates {
    return { ...this.rates };
  }

  /**
   * Get last update time
   */
  getLastUpdate(): Date | null {
    return this.lastUpdate;
  }

  /**
   * Update exchange rates from API
   */
  async updateRates(): Promise<void> {
    try {
      const response = await axios.get(this.baseUrl, {
        timeout: 5000,
      });

      if (response.data && response.data.rates) {
        this.rates = {
          USD: 1,
          ...response.data.rates,
        };
        this.lastUpdate = new Date();
        
        logger.info('Exchange rates updated successfully', {
          timestamp: this.lastUpdate,
          currencies: Object.keys(this.rates).length,
        });
      }
    } catch (error) {
      logger.warn('Failed to update exchange rates, using fallback', {
        error: error instanceof Error ? error.message : 'Unknown error',
      });
      
      // Use fallback rates if API fails
      if (Object.keys(this.rates).length === 0) {
        this.rates = { ...this.fallbackRates };
      }
    }
  }

  /**
   * Start periodic rate updates
   */
  startPeriodicUpdates(): void {
    // Update immediately
    this.updateRates();

    // Then update every hour
    setInterval(() => {
      this.updateRates();
    }, this.updateInterval);

    logger.info('Exchange rate periodic updates started');
  }

  /**
   * Get pricing tiers for display
   */
  getPricingTiers(currency: string): Array<{ amount: number; agc: number; bonus?: number }> {
    const tiers = [
      { usd: 10, bonus: 0 },
      { usd: 50, bonus: 5 },
      { usd: 100, bonus: 15 },
      { usd: 500, bonus: 100 },
    ];

    return tiers.map(tier => {
      const amount = this.fromUSD(tier.usd, currency);
      const agc = this.calculateAGC(amount, currency);
      
      return {
        amount: Math.round(amount),
        agc: Math.round(agc),
        bonus: tier.bonus,
      };
    });
  }
}

export const exchangeRateService = new ExchangeRateService();
