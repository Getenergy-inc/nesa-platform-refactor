import { prisma } from '@/shared/database/postgresql';
import { paystackService } from './paystackService';
import logger from '@/shared/utils/logger';

export interface ProviderHealthStatus {
  providerName: string;
  isEnabled: boolean;
  status: 'ACTIVE' | 'DEGRADED' | 'DOWN';
  lastCheckedAt: Date;
  responseTime?: number;
  errorRate?: number;
  lastError?: string;
  notes?: string;
}

export interface HealthCheckResult {
  success: boolean;
  responseTime: number;
  error?: string;
}

class ProviderHealthService {
  private readonly HEALTH_CHECK_INTERVAL = 5 * 60 * 1000; // 5 minutes
  private readonly ERROR_RATE_THRESHOLD = 0.1; // 10%
  private readonly RESPONSE_TIME_THRESHOLD = 5000; // 5 seconds

  /**
   * Check health of a payment provider
   */
  async checkProviderHealth(providerName: string): Promise<HealthCheckResult> {
    const startTime = Date.now();

    try {
      switch (providerName.toLowerCase()) {
        case 'paystack':
          await this.checkPaystackHealth();
          break;
        default:
          throw new Error(`Unknown provider: ${providerName}`);
      }

      const responseTime = Date.now() - startTime;
      return {
        success: true,
        responseTime,
      };
    } catch (error) {
      const responseTime = Date.now() - startTime;
      return {
        success: false,
        responseTime,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Check Paystack health by listing transactions
   */
  private async checkPaystackHealth(): Promise<void> {
    try {
      // Simple health check - list transactions with limit 1
      await paystackService.listTransactions({ perPage: 1 });
    } catch (error) {
      throw new Error('Paystack health check failed');
    }
  }

  /**
   * Update provider health status in database
   */
  async updateProviderHealth(
    providerName: string,
    healthCheck: HealthCheckResult
  ): Promise<void> {
    const status = this.determineStatus(healthCheck);

    await prisma.providerHealth.upsert({
      where: { providerName },
      create: {
        providerName,
        isEnabled: true,
        status,
        lastCheckedAt: new Date(),
        responseTime: healthCheck.responseTime,
        errorRate: healthCheck.success ? 0 : 1,
        lastError: healthCheck.error || null,
      },
      update: {
        status,
        lastCheckedAt: new Date(),
        responseTime: healthCheck.responseTime,
        lastError: healthCheck.error || null,
      },
    });

    logger.info('Provider health updated', {
      providerName,
      status,
      responseTime: healthCheck.responseTime,
    });
  }

  /**
   * Determine provider status based on health check
   */
  private determineStatus(healthCheck: HealthCheckResult): string {
    if (!healthCheck.success) {
      return 'DOWN';
    }

    if (healthCheck.responseTime > this.RESPONSE_TIME_THRESHOLD) {
      return 'DEGRADED';
    }

    return 'ACTIVE';
  }

  /**
   * Get all provider health statuses
   */
  async getAllProviderHealth(): Promise<ProviderHealthStatus[]> {
    const providers = await prisma.providerHealth.findMany({
      orderBy: { providerName: 'asc' },
    });

    return providers.map((p) => ({
      providerName: p.providerName,
      isEnabled: p.isEnabled,
      status: p.status as 'ACTIVE' | 'DEGRADED' | 'DOWN',
      lastCheckedAt: p.lastCheckedAt,
      responseTime: p.responseTime ?? 0,
      errorRate: p.errorRate ?? 0,
      lastError: p.lastError ?? '',
      notes: p.notes ?? '',
    }));
  }

  /**
   * Get specific provider health
   */
  async getProviderHealth(providerName: string): Promise<ProviderHealthStatus | null> {
    const provider = await prisma.providerHealth.findUnique({
      where: { providerName },
    });

    if (!provider) return null;

    return {
      providerName: provider.providerName,
      isEnabled: provider.isEnabled,
      status: provider.status as 'ACTIVE' | 'DEGRADED' | 'DOWN',
      lastCheckedAt: provider.lastCheckedAt,
      responseTime: provider.responseTime ?? 0,
      errorRate: provider.errorRate ?? 0,
      lastError: provider.lastError ?? '',
      notes: provider.notes ?? '',
    };
  }

  /**
   * Enable/disable a provider
   */
  async toggleProvider(providerName: string, enabled: boolean): Promise<void> {
    await prisma.providerHealth.upsert({
      where: { providerName },
      create: {
        providerName,
        isEnabled: enabled,
        status: 'ACTIVE',
      },
      update: {
        isEnabled: enabled,
        notes: enabled ? 'Enabled by admin' : 'Disabled by admin',
      },
    });

    logger.info('Provider toggled', { providerName, enabled });
  }

  /**
   * Run health checks for all providers
   */
  async runHealthChecks(): Promise<void> {
    const providers = ['paystack']; // Add more providers as they're integrated

    for (const provider of providers) {
      try {
        const healthCheck = await this.checkProviderHealth(provider);
        await this.updateProviderHealth(provider, healthCheck);
      } catch (error) {
        logger.error('Health check failed', { provider, error });
      }
    }
  }

  /**
   * Start periodic health checks
   */
  startPeriodicHealthChecks(): void {
    // Run immediately
    this.runHealthChecks();

    // Then run every interval
    setInterval(() => {
      this.runHealthChecks();
    }, this.HEALTH_CHECK_INTERVAL);

    logger.info('Periodic health checks started', {
      interval: this.HEALTH_CHECK_INTERVAL,
    });
  }

  /**
   * Calculate error rate for a provider
   */
  async calculateErrorRate(providerName: string, hours: number = 24): Promise<number> {
    const since = new Date(Date.now() - hours * 60 * 60 * 1000);

    const [total, failed] = await Promise.all([
      prisma.walletTransaction.count({
        where: {
          createdAt: { gte: since },
          type: { in: ['PURCHASE_USER', 'PURCHASE_COMPANY'] },
        },
      }),
      prisma.walletTransaction.count({
        where: {
          createdAt: { gte: since },
          type: { in: ['PURCHASE_USER', 'PURCHASE_COMPANY'] },
          status: 'FAILED',
        },
      }),
    ]);

    if (total === 0) return 0;
    return failed / total;
  }

  /**
   * Get provider metrics
   */
  async getProviderMetrics(providerName: string, hours: number = 24) {
    const since = new Date(Date.now() - hours * 60 * 60 * 1000);

    const [totalTransactions, successfulTransactions, failedTransactions, totalVolume] =
      await Promise.all([
        prisma.walletTransaction.count({
          where: {
            createdAt: { gte: since },
            type: { in: ['PURCHASE_USER', 'PURCHASE_COMPANY'] },
          },
        }),
        prisma.walletTransaction.count({
          where: {
            createdAt: { gte: since },
            type: { in: ['PURCHASE_USER', 'PURCHASE_COMPANY'] },
            status: 'COMPLETED',
          },
        }),
        prisma.walletTransaction.count({
          where: {
            createdAt: { gte: since },
            type: { in: ['PURCHASE_USER', 'PURCHASE_COMPANY'] },
            status: 'FAILED',
          },
        }),
        prisma.walletTransaction.aggregate({
          where: {
            createdAt: { gte: since },
            type: 'PURCHASE_USER',
            status: 'COMPLETED',
          },
          _sum: { amount: true },
        }),
      ]);

    const errorRate = totalTransactions > 0 ? failedTransactions / totalTransactions : 0;
    const successRate = totalTransactions > 0 ? successfulTransactions / totalTransactions : 0;

    return {
      providerName,
      period: `${hours}h`,
      totalTransactions,
      successfulTransactions,
      failedTransactions,
      errorRate: Math.round(errorRate * 10000) / 100, // Percentage with 2 decimals
      successRate: Math.round(successRate * 10000) / 100,
      totalVolume: totalVolume._sum.amount || 0,
    };
  }
}

export const providerHealthService = new ProviderHealthService();
