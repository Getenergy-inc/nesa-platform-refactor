import logger from '@/shared/utils/logger';

export interface CurrencyRates {
  USD: number;
  NGN: number;
  EUR: number;
  GBP: number;
  lastUpdated: Date;
}

export interface ConvertedBalance {
  agc: number;
  usd: number;
  ngn: number;
  eur: number;
  gbp: number;
}

class CurrencyService {
  private readonly AGC_TO_USD_RATE = 0.05; // $1 = 20 AGC, so 1 AGC = $0.05
  
  // Exchange rates (these should be fetched from an API in production)
  private exchangeRates: CurrencyRates = {
    USD: 1,
    NGN: 1550, // 1 USD = 1550 NGN (example rate)
    EUR: 0.92, // 1 USD = 0.92 EUR
    GBP: 0.79, // 1 USD = 0.79 GBP
    lastUpdated: new Date(),
  };

  /**
   * Convert AGC to multiple currencies
   */
  convertAgcToFiat(agcAmount: number): ConvertedBalance {
    const usd = agcAmount * this.AGC_TO_USD_RATE;
    const ngn = usd * this.exchangeRates.NGN;
    const eur = usd * this.exchangeRates.EUR;
    const gbp = usd * this.exchangeRates.GBP;

    return {
      agc: agcAmount,
      usd: Math.round(usd * 100) / 100, // 2 decimal places
      ngn: Math.round(ngn * 100) / 100,
      eur: Math.round(eur * 100) / 100,
      gbp: Math.round(gbp * 100) / 100,
    };
  }

  /**
   * Convert USD to AGC
   */
  convertUsdToAgc(usdAmount: number): number {
    return usdAmount / this.AGC_TO_USD_RATE;
  }

  /**
   * Convert NGN to AGC
   */
  convertNgnToAgc(ngnAmount: number): number {
    const usd = ngnAmount / this.exchangeRates.NGN;
    return this.convertUsdToAgc(usd);
  }

  /**
   * Get current exchange rates
   */
  getExchangeRates(): CurrencyRates {
    return { ...this.exchangeRates };
  }

  /**
   * Update exchange rates (should be called periodically)
   * In production, fetch from a real API like exchangerate-api.com
   */
  async updateExchangeRates(): Promise<void> {
    try {
      // TODO: Fetch from real API
      // For now, using static rates
      
      // Example API call (commented out):
      // const response = await fetch('https://api.exchangerate-api.com/v4/latest/USD');
      // const data = await response.json();
      // this.exchangeRates = {
      //   USD: 1,
      //   NGN: data.rates.NGN,
      //   EUR: data.rates.EUR,
      //   GBP: data.rates.GBP,
      //   lastUpdated: new Date(),
      // };

      this.exchangeRates.lastUpdated = new Date();
      logger.info('Exchange rates updated', this.exchangeRates);
    } catch (error) {
      logger.error('Failed to update exchange rates', error);
    }
  }

  /**
   * Format currency amount
   */
  formatCurrency(amount: number, currency: string): string {
    const formatter = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });

    return formatter.format(amount);
  }

  /**
   * Format AGC amount
   */
  formatAgc(amount: number): string {
    return `${amount.toFixed(2)} AGC`;
  }

  /**
   * Get wallet balance with multi-currency display
   */
  getBalanceWithCurrencies(agcBalance: number) {
    const converted = this.convertAgcToFiat(agcBalance);
    
    return {
      agc: {
        amount: agcBalance,
        formatted: this.formatAgc(agcBalance),
      },
      usd: {
        amount: converted.usd,
        formatted: this.formatCurrency(converted.usd, 'USD'),
      },
      ngn: {
        amount: converted.ngn,
        formatted: this.formatCurrency(converted.ngn, 'NGN'),
      },
      eur: {
        amount: converted.eur,
        formatted: this.formatCurrency(converted.eur, 'EUR'),
      },
      gbp: {
        amount: converted.gbp,
        formatted: this.formatCurrency(converted.gbp, 'GBP'),
      },
      rates: this.getExchangeRates(),
    };
  }

  /**
   * Calculate purchase amount in different currencies
   */
  calculatePurchaseAmounts(usdAmount: number) {
    const agcAmount = this.convertUsdToAgc(usdAmount);
    const userAgc = agcAmount * 0.75;
    const companyAgc = agcAmount * 0.25;

    return {
      input: {
        usd: usdAmount,
        ngn: usdAmount * this.exchangeRates.NGN,
      },
      agc: {
        total: agcAmount,
        user: userAgc,
        company: companyAgc,
      },
      breakdown: {
        userPercentage: 75,
        companyPercentage: 25,
        conversionRate: `$1 = ${1 / this.AGC_TO_USD_RATE} AGC`,
      },
    };
  }

  /**
   * Start periodic rate updates
   */
  startPeriodicUpdates(): void {
    // Update immediately
    this.updateExchangeRates();

    // Update every hour
    setInterval(() => {
      this.updateExchangeRates();
    }, 60 * 60 * 1000);

    logger.info('Currency rate updates started');
  }
}

export const currencyService = new CurrencyService();
