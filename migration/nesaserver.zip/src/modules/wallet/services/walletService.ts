import { prisma } from '@/shared/database/postgresql';
import { config } from '@/config';
import { systemWalletService } from './SystemWalletService';
import { WalletTransactionStatus, WalletTransactionType } from '@prisma/client';
import type { AGCBonus } from '@/modules/auth/utils/intentMapping';

export class WalletService {
  async createForUser(userId: string) {
    const existing = await prisma.wallet.findUnique({ where: { userId } });
    if (existing) return existing;
    return prisma.wallet.create({ data: { userId } });
  }

  async getWalletByUserId(userId: string) {
    let wallet = await prisma.wallet.findUnique({
      where: { userId },
    });

    if (!wallet) {
      // Per PRD, a wallet should always exist. Create it on-the-fly if missing.
      // This makes the system more resilient.
      wallet = await this.createForUser(userId);
    }
    return wallet;
  }

  async getWalletBalance(userId: string) {
    const wallet = await this.getWalletByUserId(userId);
    return {
      agcWithdrawableBalance: wallet.agcWithdrawableBalance,
      agcLockedBalance: wallet.agcLockedBalance,
      lastUpdated: wallet.lastUpdated,
    };
  }

  async getTransactions(walletId: string, { page = 1, limit = 10 }) {
    const skip = (page - 1) * limit;
    return prisma.walletTransaction.findMany({
      where: { walletId },
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' }
    });
  }

  async creditSignupBonus(walletId: string, bonus: AGCBonus) {
    if (bonus.amount <= 0) return;

    await prisma.$transaction(async (tx) => {
      // Record transaction
      await tx.walletTransaction.create({
        data: {
          walletId,
          type: WalletTransactionType.CREDIT,
          amount: bonus.amount,
          reason: 'signup_bonus',
          status: WalletTransactionStatus.COMPLETED,
          description: `Welcome bonus - ${bonus.amount} AGC (for nominations only)`,
        }
      });

      // Update wallet balances
      // Signup bonus is always non-withdrawable (locked) and can only be used for nominations
      if (bonus.type === 'withdrawable') {
        await tx.wallet.update({
          where: { id: walletId },
          data: { agcWithdrawableBalance: { increment: bonus.amount } }
        });
      } else {
        await tx.wallet.update({
          where: { id: walletId },
          data: { agcLockedBalance: { increment: bonus.amount } }
        });
      }
    });
  }

  purchase = async (userId: string, amountInDollars: number): Promise<void> => {
    await prisma.$transaction(async (tx) => {
      const userWallet = await tx.wallet.findUnique({
        where: { userId },
      });

      if (!userWallet) {
        throw new Error('Wallet not found for user');
      }

      const totalAgc = amountInDollars * 20;
      const userAgc = totalAgc * 0.75;
      const companyAgc = totalAgc * 0.25;

      const companyWalletId = await systemWalletService.getCompanyReserveWalletId();

      // Create user transaction
      await tx.walletTransaction.create({
        data: {
          walletId: userWallet.id,
          type: 'PURCHASE_USER' as WalletTransactionType,
          amount: userAgc,
          reason: 'purchase',
          description: `Purchase of ${amountInDollars} USD worth of AGC`,
          status: WalletTransactionStatus.COMPLETED,
        },
      });

      // Create company transaction
      await tx.walletTransaction.create({
        data: {
          walletId: companyWalletId,
          type: 'PURCHASE_COMPANY' as WalletTransactionType,
          amount: companyAgc,
          reason: 'purchase_reserve',
          description: `Reserve from purchase of ${amountInDollars} USD worth of AGC`,
          status: WalletTransactionStatus.COMPLETED,
        },
      });

      // Update user wallet balance
      await tx.wallet.update({
        where: { id: userWallet.id },
        data: { agcWithdrawableBalance: { increment: userAgc } },
      });

      // Update company wallet balance
      await tx.wallet.update({
        where: { id: companyWalletId },
        data: { agcWithdrawableBalance: { increment: companyAgc } },
      });
    });
  }

  debit = async (userId: string, amount: number, reason: string, description: string): Promise<string> => {
    if (amount <= 0) {
      throw new Error('Debit amount must be positive.');
    }

    return prisma.$transaction(async (tx) => {
      const userWallet = await tx.wallet.findUnique({
        where: { userId },
      });

      if (!userWallet) {
        throw new Error('Wallet not found for user');
      }

      if (userWallet.agcWithdrawableBalance < amount) {
        throw new Error('Insufficient withdrawable balance');
      }

      // Update user wallet balance
      await tx.wallet.update({
        where: { id: userWallet.id },
        data: { agcWithdrawableBalance: { decrement: amount } },
      });

      // Create debit transaction
      const transaction = await tx.walletTransaction.create({
        data: {
          walletId: userWallet.id,
          type: WalletTransactionType.DEBIT,
          amount,
          reason,
          description,
          status: WalletTransactionStatus.COMPLETED,
        },
      });

      return transaction.id;
    });
  }

  transfer = async (fromUserId: string, toUserId: string, amount: number, reason: string, description: string) => {
    if (amount <= 0) {
      throw new Error('Transfer amount must be positive.');
    }

    if (fromUserId === toUserId) {
      throw new Error('Cannot transfer to the same wallet.');
    }

    return prisma.$transaction(async (tx) => {
      // 1. Get sender's wallet and check balance
      const fromWallet = await tx.wallet.findUnique({
        where: { userId: fromUserId },
      });

      if (!fromWallet) {
        throw new Error('Sender wallet not found');
      }

      if (fromWallet.agcWithdrawableBalance < amount) {
        throw new Error('Insufficient withdrawable balance');
      }

      // 2. Get receiver's wallet
      const toWallet = await tx.wallet.findUnique({
        where: { userId: toUserId },
      });

      if (!toWallet) {
        throw new Error('Receiver wallet not found');
      }

      // 3. Perform the balance updates
      await tx.wallet.update({
        where: { id: fromWallet.id },
        data: { agcWithdrawableBalance: { decrement: amount } },
      });

      await tx.wallet.update({
        where: { id: toWallet.id },
        data: { agcWithdrawableBalance: { increment: amount } },
      });

      // 4. Create transaction records for both sender (debit) and receiver (credit)
      const [debitTransaction, creditTransaction] = await Promise.all([
        tx.walletTransaction.create({
          data: {
            walletId: fromWallet.id, type: WalletTransactionType.DEBIT, amount, reason,
            description: `Sent ${amount} AGC to ${toUserId}. Note: ${description}`, status: WalletTransactionStatus.COMPLETED
          },
        }),
        tx.walletTransaction.create({
          data: {
            walletId: toWallet.id, type: WalletTransactionType.CREDIT, amount, reason,
            description: `Received ${amount} AGC from ${fromUserId}. Note: ${description}`, status: WalletTransactionStatus.COMPLETED
          },
        }),
      ]);

      return {
        debitTransactionId: debitTransaction.id,
        creditTransactionId: creditTransaction.id,
      };
    });
  }
}

export const walletService = new WalletService();
