/**
 * Test script for Paystack integration
 * Run with: npx ts-node src/modules/wallet/test-paystack-integration.ts
 */

import { paystackService } from './services/paystackService';
import { paymentService } from './services/paymentService';
import { config } from '@/config';

async function testPaystackIntegration() {
  console.log('🧪 Testing Paystack Integration\n');

  // Check configuration
  console.log('1. Checking Configuration...');
  if (!config.paystack.secretKey) {
    console.error('❌ PAYSTACK_SECRET_KEY not configured');
    console.log('   Add to .env: PAYSTACK_SECRET_KEY=sk_test_xxx');
    return;
  }
  if (!config.paystack.publicKey) {
    console.error('❌ PAYSTACK_PUBLIC_KEY not configured');
    console.log('   Add to .env: PAYSTACK_PUBLIC_KEY=pk_test_xxx');
    return;
  }
  console.log('✅ Configuration OK\n');

  // Test amount conversion
  console.log('2. Testing Amount Conversion...');
  const testAmount = 10; // $10
  const kobo = paystackService.convertToSmallestUnit(testAmount, 'NGN');
  const cents = paystackService.convertToSmallestUnit(testAmount, 'USD');
  console.log(`   $${testAmount} = ${kobo} kobo (NGN)`);
  console.log(`   $${testAmount} = ${cents} cents (USD)`);
  console.log('✅ Conversion OK\n');

  // Test AGC calculation
  console.log('3. Testing AGC Calculation...');
  const totalAgc = testAmount * 20; // $1 = 20 AGC
  const userAgc = totalAgc * 0.75;
  const companyAgc = totalAgc * 0.25;
  console.log(`   Total AGC: ${totalAgc}`);
  console.log(`   User gets: ${userAgc} AGC (75%)`);
  console.log(`   Company gets: ${companyAgc} AGC (25%)`);
  console.log('✅ Calculation OK\n');

  // Test payment initialization (requires valid Paystack keys)
  console.log('4. Testing Payment Initialization...');
  try {
    const testEmail = 'test@example.com';
    const result = await paystackService.initializePayment({
      email: testEmail,
      amount: kobo, // Use NGN instead of USD
      currency: 'NGN', // Changed from USD to NGN
      reference: `TEST-${Date.now()}`,
      metadata: {
        test: true,
        purpose: 'integration_test',
      },
    });

    if (result.status) {
      console.log('✅ Payment initialization successful');
      console.log(`   Authorization URL: ${result.data.authorization_url}`);
      console.log(`   Reference: ${result.data.reference}`);
      console.log(`   Access Code: ${result.data.access_code}`);
    } else {
      console.error('❌ Payment initialization failed');
    }
  } catch (error) {
    console.error('❌ Payment initialization error:', error instanceof Error ? error.message : error);
    console.log('   This is expected if using test keys without proper setup');
  }
  console.log();

  // Test webhook signature verification
  console.log('5. Testing Webhook Signature Verification...');
  if (config.paystack.webhookSecret) {
    const testPayload = JSON.stringify({ event: 'charge.success', data: { reference: 'TEST-123' } });
    const crypto = require('crypto');
    const validSignature = crypto
      .createHmac('sha512', config.paystack.webhookSecret)
      .update(testPayload)
      .digest('hex');
    
    const isValid = paystackService.verifyWebhookSignature(testPayload, validSignature);
    if (isValid) {
      console.log('✅ Webhook signature verification working');
    } else {
      console.error('❌ Webhook signature verification failed');
    }
  } else {
    console.log('⚠️  PAYSTACK_WEBHOOK_SECRET not configured');
    console.log('   Add to .env: PAYSTACK_WEBHOOK_SECRET=your_secret');
  }
  console.log();

  console.log('🎉 Integration test complete!\n');
  console.log('Next steps:');
  console.log('1. Add Paystack keys to .env file');
  console.log('2. Test with real payment flow');
  console.log('3. Configure webhook URL in Paystack dashboard');
  console.log('4. Test webhook with ngrok for local development');
}

// Run the test
testPaystackIntegration()
  .then(() => {
    console.log('\n✅ All tests completed');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ Test failed:', error);
    process.exit(1);
  });
