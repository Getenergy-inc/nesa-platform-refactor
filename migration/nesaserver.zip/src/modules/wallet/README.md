# Wallet & Payment System

Complete AGC (AfriGold Coin) wallet system with Paystack payment integration.

## Features

### ✅ Implemented

1. **Auto-Wallet Creation**
   - Every user gets a wallet at signup
   - User ID as unique identifier

2. **Wallet Balances**
   - `agcWithdrawableBalance`: Can be spent/transferred
   - `agcLockedBalance`: Earned bonuses (locked)

3. **Paystack Payment Integration**
   - Purchase AGC with real money
   - Conversion rate: $1 = 20 AGC
   - 75% to user, 25% to company reserve
   - Webhook handling for payment verification

4. **Transfers**
   - Send AGC to other users
   - Balance validation
   - Transaction history

5. **Transaction History**
   - Paginated transaction list
   - Multiple transaction types

## API Endpoints

### Public Endpoints

#### Get Wallet Configuration
```http
GET /api/v1/wallet/config
```

Response:
```json
{
  "paystackPublicKey": "pk_test_xxx",
  "agcConversionRate": 20,
  "userSplit": 0.75,
  "companySplit": 0.25,
  "minPurchaseAmount": 1
}
```

#### Paystack Webhook
```http
POST /api/v1/wallet/webhook/paystack
Headers:
  x-paystack-signature: <signature>
```

### Protected Endpoints (Require Authentication)

#### Get Wallet Balance
```http
GET /api/v1/wallet/balance
Authorization: Bearer <token>
```

Response:
```json
{
  "agcWithdrawableBalance": 150.0,
  "agcLockedBalance": 50.0,
  "lastUpdated": "2025-01-10T12:00:00Z"
}
```

#### Get Transactions
```http
GET /api/v1/wallet/transactions?page=1&limit=10
Authorization: Bearer <token>
```

#### Initiate Purchase
```http
POST /api/v1/wallet/purchase/initiate
Authorization: Bearer <token>
Content-Type: application/json

{
  "amount": 10,
  "currency": "USD"
}
```

Response:
```json
{
  "message": "Payment initialized successfully",
  "data": {
    "reference": "AGC-1234567890-abc123",
    "authorizationUrl": "https://checkout.paystack.com/xxx",
    "accessCode": "xxx",
    "amount": 10,
    "currency": "USD",
    "agcAmount": 200
  }
}
```

#### Verify Purchase
```http
GET /api/v1/wallet/purchase/verify/:reference
Authorization: Bearer <token>
```

Response:
```json
{
  "message": "Purchase completed successfully",
  "data": {
    "reference": "AGC-1234567890-abc123",
    "userAgc": 150,
    "companyAgc": 50,
    "totalAgc": 200
  }
}
```

#### Get Purchase History
```http
GET /api/v1/wallet/purchases?page=1&limit=10
Authorization: Bearer <token>
```

#### Transfer AGC
```http
POST /api/v1/wallet/transfer
Authorization: Bearer <token>
Content-Type: application/json

{
  "toUserId": "user-id-here",
  "amount": 50,
  "description": "Payment for services"
}
```

## Payment Flow

### 1. Frontend Initiates Purchase
```javascript
const response = await fetch('/api/v1/wallet/purchase/initiate', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    amount: 10, // $10
    currency: 'USD'
  })
});

const { data } = await response.json();
// Redirect user to data.authorizationUrl
window.location.href = data.authorizationUrl;
```

### 2. User Completes Payment on Paystack

### 3. Paystack Redirects Back
User is redirected to: `${FRONTEND_URL}/wallet/payment/callback?reference=AGC-xxx`

### 4. Frontend Verifies Payment
```javascript
const reference = new URLSearchParams(window.location.search).get('reference');

const response = await fetch(`/api/v1/wallet/purchase/verify/${reference}`, {
  headers: {
    'Authorization': `Bearer ${token}`
  }
});

const result = await response.json();
if (result.data) {
  // Payment successful
  // Show success message with AGC credited
}
```

### 5. Webhook Confirmation (Background)
Paystack sends webhook to `/api/v1/wallet/webhook/paystack` for additional verification.

## Environment Variables

Add to your `.env` file:

```env
# Paystack Configuration
PAYSTACK_SECRET_KEY=sk_test_your_secret_key
PAYSTACK_PUBLIC_KEY=pk_test_your_public_key
PAYSTACK_WEBHOOK_SECRET=your_webhook_secret
```

## Database Schema

### Wallet
```prisma
model Wallet {
  id                     String             @id @default(cuid())
  userId                 String             @unique
  balance                Float              @default(0)
  agcWithdrawableBalance Float              @default(0)
  agcLockedBalance       Float              @default(0)
  reserved               Float              @default(0)
  lastUpdated            DateTime           @updatedAt
  
  user                   User               @relation(...)
  transactions           WalletTransaction[]
}
```

### WalletTransaction
```prisma
model WalletTransaction {
  id          String                  @id @default(cuid())
  walletId    String
  type        WalletTransactionType
  amount      Float
  reason      String
  description String?
  referenceId String?
  status      WalletTransactionStatus @default(PENDING)
  createdAt   DateTime                @default(now())
  
  wallet      Wallet                  @relation(...)
}

enum WalletTransactionType {
  CREDIT
  DEBIT
  PURCHASE_USER
  PURCHASE_COMPANY
  EARN
  SPEND
  TRANSFER
  DONATION
  ADMIN_ACTION
  SETTLEMENT
  REVERSAL
}

enum WalletTransactionStatus {
  PENDING
  COMPLETED
  FAILED
  CANCELLED
}
```

## Testing

### Test Purchase Flow

1. Get config:
```bash
curl http://localhost:5000/api/v1/wallet/config
```

2. Initiate purchase:
```bash
curl -X POST http://localhost:5000/api/v1/wallet/purchase/initiate \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"amount": 10, "currency": "USD"}'
```

3. Complete payment on Paystack checkout page

4. Verify purchase:
```bash
curl http://localhost:5000/api/v1/wallet/purchase/verify/AGC-xxx \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Test Webhook (Local Development)

Use ngrok to expose your local server:
```bash
ngrok http 5000
```

Then configure webhook URL in Paystack dashboard:
```
https://your-ngrok-url.ngrok.io/api/v1/wallet/webhook/paystack
```

## Security Features

1. **Webhook Signature Verification**: All webhooks are verified using HMAC SHA512
2. **Idempotency**: Duplicate payments are detected and prevented
3. **Transaction Status Tracking**: All transactions have status (PENDING, COMPLETED, FAILED)
4. **Reference Generation**: Unique references for each transaction
5. **Balance Validation**: Insufficient balance checks before transfers

## Error Handling

All endpoints return consistent error responses:

```json
{
  "message": "Error description",
  "error": "Error details"
}
```

Common error codes:
- `400`: Bad request (invalid amount, missing fields)
- `401`: Unauthorized (missing/invalid token)
- `422`: Insufficient funds
- `500`: Server error

## Next Steps

### To Implement:
- [ ] Admin credit/debit endpoints
- [ ] Transaction rollback
- [ ] Wallet freeze controls
- [ ] Settlement system
- [ ] Fraud detection
- [ ] Multi-currency display
- [ ] Rate limiting on wallet endpoints
- [ ] 2FA for large transactions

## Support

For issues or questions, contact the development team.
