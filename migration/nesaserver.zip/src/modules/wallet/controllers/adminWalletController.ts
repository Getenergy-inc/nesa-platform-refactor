import { Request, Response, NextFunction } from "express";
import { analyticsService } from "../services/analyticsService";
import { providerHealthService } from "../services/providerHealthService";
import { currencyService } from "../services/currencyService";
import { walletService } from "../services/walletService";
import { prisma } from "@/shared/database/postgresql";
import { z } from "zod";
import logger from "@/shared/utils/logger";

const creditDebitSchema = z.object({
  userId: z.string().min(1, "User ID is required"),
  amount: z.number().positive("Amount must be positive"),
  reason: z.string().min(1, "Reason is required"),
  description: z.string().optional(),
});

const toggleProviderSchema = z.object({
  enabled: z.boolean(),
});

export class AdminWalletController {
  async getDashboard(req: Request, res: Response, next: NextFunction) {
    try {
      const days = parseInt((req.query.days as string) || "30", 10);

      const [summary, providerHealth, realTimeMetrics] = await Promise.all([
        analyticsService.getDashboardSummary(days),
        providerHealthService.getAllProviderHealth(),
        analyticsService.getRealTimeMetrics(),
      ]);

      res.status(200).json({
        message: "Dashboard data retrieved successfully",
        data: {
          summary,
          providerHealth,
          realTimeMetrics,
        },
      });
    } catch (error) {
      next(error);
    }
  }

  async getTransactionAnalytics(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const days = parseInt((req.query.days as string) || "30", 10);
      const endDate = new Date();
      const startDate = new Date(
        endDate.getTime() - days * 24 * 60 * 60 * 1000
      );

      const analytics = await analyticsService.getTransactionAnalytics(
        startDate,
        endDate
      );

      res.status(200).json({
        message: "Transaction analytics retrieved successfully",
        data: analytics,
      });
    } catch (error) {
      next(error);
    }
  }

  async getWalletAnalytics(req: Request, res: Response, next: NextFunction) {
    try {
      const analytics = await analyticsService.getWalletAnalytics();

      res.status(200).json({
        message: "Wallet analytics retrieved successfully",
        data: analytics,
      });
    } catch (error) {
      next(error);
    }
  }

  async getPurchaseAnalytics(req: Request, res: Response, next: NextFunction) {
    try {
      const days = parseInt((req.query.days as string) || "30", 10);
      const endDate = new Date();
      const startDate = new Date(
        endDate.getTime() - days * 24 * 60 * 60 * 1000
      );

      const analytics = await analyticsService.getPurchaseAnalytics(
        startDate,
        endDate
      );

      res.status(200).json({
        message: "Purchase analytics retrieved successfully",
        data: analytics,
      });
    } catch (error) {
      next(error);
    }
  }

  async getRevenueAnalytics(req: Request, res: Response, next: NextFunction) {
    try {
      const days = parseInt((req.query.days as string) || "30", 10);
      const endDate = new Date();
      const startDate = new Date(
        endDate.getTime() - days * 24 * 60 * 60 * 1000
      );

      const analytics = await analyticsService.getRevenueAnalytics(
        startDate,
        endDate
      );

      res.status(200).json({
        message: "Revenue analytics retrieved successfully",
        data: analytics,
      });
    } catch (error) {
      next(error);
    }
  }

  async getProviderHealth(req: Request, res: Response, next: NextFunction) {
    try {
      const providers = await providerHealthService.getAllProviderHealth();

      res.status(200).json({
        message: "Provider health retrieved successfully",
        data: providers,
      });
    } catch (error) {
      next(error);
    }
  }

  async getProviderHealthByName(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { providerName } = req.params;

      if (!providerName) {
        res.status(400).json({ message: "Provider name is required" });
        return;
      }

      const provider = await providerHealthService.getProviderHealth(
        providerName
      );

      if (!provider) {
        res.status(404).json({ message: "Provider not found" });
        return;
      }

      res.status(200).json({
        message: "Provider health retrieved successfully",
        data: provider,
      });
    } catch (error) {
      next(error);
    }
  }

  async toggleProvider(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { providerName } = req.params;

      if (!providerName) {
        res.status(400).json({ message: "Provider name is required" });
        return;
      }

      const { enabled } = toggleProviderSchema.parse(req.body);

      await providerHealthService.toggleProvider(providerName, enabled);

      res.status(200).json({
        message: `Provider ${enabled ? "enabled" : "disabled"} successfully`,
      });
    } catch (error) {
      next(error);
    }
  }

  async checkProviderHealth(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { providerName } = req.params;

      if (!providerName) {
        res.status(400).json({ message: "Provider name is required" });
        return;
      }

      const healthCheck = await providerHealthService.checkProviderHealth(
        providerName
      );
      await providerHealthService.updateProviderHealth(
        providerName,
        healthCheck
      );

      res.status(200).json({
        message: "Health check completed",
        data: healthCheck,
      });
    } catch (error) {
      next(error);
    }
  }

  async getProviderMetrics(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { providerName } = req.params;

      if (!providerName) {
        res.status(400).json({ message: "Provider name is required" });
        return;
      }

      const hours = parseInt((req.query.hours as string) || "24", 10);

      const metrics = await providerHealthService.getProviderMetrics(
        providerName,
        hours
      );

      res.status(200).json({
        message: "Provider metrics retrieved successfully",
        data: metrics,
      });
    } catch (error) {
      next(error);
    }
  }

  async creditWallet(req: Request, res: Response, next: NextFunction) {
    try {
      const adminUser = (req as any).user;
      const { userId, amount, reason, description } = creditDebitSchema.parse(
        req.body
      );

      const wallet = await walletService.getWalletByUserId(userId);

      await prisma.walletTransaction.create({
        data: {
          walletId: wallet.id,
          type: "ADMIN_ACTION",
          amount,
          reason,
          description: description || `Admin credit by ${adminUser?.email}`,
          status: "COMPLETED",
        },
      });

      await prisma.wallet.update({
        where: { id: wallet.id },
        data: { agcWithdrawableBalance: { increment: amount } },
      });

      logger.info("Admin credited wallet", {
        adminId: adminUser?.id,
        userId,
        amount,
        reason,
      });

      res.status(200).json({
        message: "Wallet credited successfully",
        data: { userId, amount },
      });
    } catch (error) {
      next(error);
    }
  }

  async debitWallet(req: Request, res: Response, next: NextFunction) {
    try {
      const adminUser = (req as any).user;
      const { userId, amount, reason, description } = creditDebitSchema.parse(
        req.body
      );

      const transactionId = await walletService.debit(
        userId,
        amount,
        reason,
        description || `Admin debit by ${adminUser?.email}`
      );

      logger.info("Admin debited wallet", {
        adminId: adminUser?.id,
        userId,
        amount,
        reason,
      });

      res.status(200).json({
        message: "Wallet debited successfully",
        data: { userId, amount, transactionId },
      });
    } catch (error) {
      next(error);
    }
  }

  async getExchangeRates(req: Request, res: Response, next: NextFunction) {
    try {
      const rates = currencyService.getExchangeRates();

      res.status(200).json({
        message: "Exchange rates retrieved successfully",
        data: rates,
      });
    } catch (error) {
      next(error);
    }
  }

  async getUserWalletBalance(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { userId } = req.params;

      if (!userId) {
        res.status(400).json({ message: "User ID is required" });
        return;
      }

      const wallet = await walletService.getWalletByUserId(userId);
      const balanceWithCurrencies = currencyService.getBalanceWithCurrencies(
        wallet.agcWithdrawableBalance
      );

      res.status(200).json({
        message: "User wallet balance retrieved successfully",
        data: {
          userId,
          walletId: wallet.id,
          withdrawable: balanceWithCurrencies,
          locked: currencyService.getBalanceWithCurrencies(
            wallet.agcLockedBalance
          ),
          lastUpdated: wallet.lastUpdated,
        },
      });
    } catch (error) {
      next(error);
    }
  }

  async getAllWallets(req: Request, res: Response, next: NextFunction) {
    try {
      const page = parseInt((req.query.page as string) || "1", 10);
      const limit = parseInt((req.query.limit as string) || "20", 10);
      const skip = (page - 1) * limit;

      const [wallets, total] = await Promise.all([
        prisma.wallet.findMany({
          skip,
          take: limit,
          orderBy: { agcWithdrawableBalance: "desc" },
          include: {
            user: {
              select: {
                id: true,
                email: true,
                firstName: true,
                lastName: true,
                role: true,
              },
            },
          },
        }),
        prisma.wallet.count(),
      ]);

      res.status(200).json({
        message: "Wallets retrieved successfully",
        data: {
          wallets,
          pagination: {
            page,
            limit,
            total,
            totalPages: Math.ceil(total / limit),
          },
        },
      });
    } catch (error) {
      next(error);
    }
  }
}

export const adminWalletController = new AdminWalletController();
