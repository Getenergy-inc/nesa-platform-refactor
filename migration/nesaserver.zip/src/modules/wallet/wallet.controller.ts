import { Request, Response, NextFunction } from 'express';
import { walletService } from './services/walletService';
import { paymentService } from './services/paymentService';
import { exchangeRateService } from './services/exchangeRateService';
import { flutterwaveService } from './services/flutterwaveService';
import { z } from 'zod';
import logger from '@/shared/utils/logger';

const transferSchema = z.object({
  toUserId: z.string().min(1, 'Receiver user ID is required.'),
  amount: z.number().positive('Amount must be a positive number.'),
  reason: z.string().optional().default('transfer'),
  description: z.string().min(1, 'A description for the transfer is required.'),
});

const purchaseSchema = z.object({
  amount: z.number().positive('Amount must be positive'),
  currency: z.string().optional().default('NGN'),
});

export class WalletController {
  async getWalletBalance(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      // Assuming user info is attached to req by an auth middleware
      const userId = (req as any).user?.phoneNumber || (req as any).user?.id;
      if (!userId) {
        res.status(401).json({ message: 'Unauthorized' });
        return;
      }

      const balance = await walletService.getWalletBalance(userId);
      res.status(200).json(balance);
    } catch (error) {
      next(error);
    }
  }

  async getDetailedBalance(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user?.phoneNumber || (req as any).user?.id;
      if (!userId) {
        res.status(401).json({ message: 'Unauthorized' });
        return;
      }

      const balance = await walletService.getWalletBalance(userId);
      const conversionRate = 20; // $1 = 20 AGC

      res.status(200).json({
        purchased: {
          amount: balance.agcWithdrawableBalance,
          label: 'Purchased AGC',
          description: 'Can vote, transfer, and spend',
          usdValue: balance.agcWithdrawableBalance / conversionRate,
        },
        bonus: {
          amount: balance.agcLockedBalance,
          label: 'Bonus AGC',
          description: 'Can vote only',
        },
        total: balance.agcWithdrawableBalance + balance.agcLockedBalance,
        conversionRate,
        lastUpdated: balance.lastUpdated,
      });
    } catch (error) {
      next(error);
    }
  }

  async getTransactions(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user?.phoneNumber || (req as any).user?.id;
      if (!userId) {
        res.status(401).json({ message: 'Unauthorized' });
        return;
      }

      const wallet = await walletService.getWalletByUserId(userId);

      const page = parseInt(req.query.page as string || '1', 10);
      const limit = parseInt(req.query.limit as string || '10', 10);

      const transactions = await walletService.getTransactions(wallet.id, { page, limit });
      res.status(200).json(transactions);
    } catch (error) {
      next(error);
    }
  }

  async transfer(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const fromUserId = (req as any).user?.phoneNumber || (req as any).user?.id;
      if (!fromUserId) {
        res.status(401).json({ message: 'Unauthorized' });
        return;
      }

      const { toUserId, amount, reason, description } = transferSchema.parse(req.body);
      const result = await walletService.transfer(fromUserId, toUserId, amount, reason, description);

      res.status(200).json({ message: 'Transfer successful', data: result });
    } catch (error) {
      next(error);
    }
  }

  async initiatePurchase(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user?.id;
      const email = (req as any).user?.email;
      const userName = `${(req as any).user?.firstName || ''} ${(req as any).user?.lastName || ''}`.trim();
      
      if (!userId || !email) {
        res.status(401).json({ message: 'Unauthorized' });
        return;
      }

      const { amount, currency } = purchaseSchema.parse(req.body);

      // Validate currency is supported
      if (!flutterwaveService.isCurrencySupported(currency)) {
        res.status(400).json({ 
          message: `Currency ${currency} is not supported`,
          supportedCurrencies: flutterwaveService.getSupportedCurrencies(),
        });
        return;
      }

      const result = await paymentService.initiatePurchase({
        userId,
        email,
        amount,
        currency,
        userName,
      });

      res.status(200).json({
        message: 'Payment initialized successfully',
        data: result,
      });
    } catch (error) {
      next(error);
    }
  }

  async verifyPurchase(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { reference } = req.params;

      if (!reference) {
        res.status(400).json({ message: 'Transaction reference is required' });
        return;
      }

      // For Flutterwave, reference is the transaction ID
      const result = await paymentService.verifyPurchase(reference);

      if (result.success) {
        res.status(200).json({
          message: result.message,
          data: result.data,
        });
      } else {
        res.status(400).json({
          message: result.message,
        });
      }
    } catch (error) {
      next(error);
    }
  }

  async handleFlutterwaveWebhook(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      // Get the signature from headers
      const signature = req.headers['verif-hash'] as string;

      if (!signature) {
        logger.warn('Flutterwave webhook received without signature');
        res.status(400).json({ message: 'No signature provided' });
        return;
      }

      // Verify webhook signature
      const payload = JSON.stringify(req.body);
      const isValid = flutterwaveService.verifyWebhookSignature(payload, signature);

      if (!isValid) {
        logger.warn('Invalid Flutterwave webhook signature');
        res.status(400).json({ message: 'Invalid signature' });
        return;
      }

      // Process the webhook
      await paymentService.handleWebhook(req.body);

      // Always return 200 to acknowledge receipt
      res.status(200).json({ message: 'Webhook processed' });
    } catch (error) {
      logger.error('Flutterwave webhook processing error', error);
      // Still return 200 to prevent Flutterwave from retrying
      res.status(200).json({ message: 'Webhook received' });
    }
  }

  async getPurchaseHistory(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user?.id;
      
      if (!userId) {
        res.status(401).json({ message: 'Unauthorized' });
        return;
      }

      const page = parseInt(req.query.page as string || '1', 10);
      const limit = parseInt(req.query.limit as string || '10', 10);

      const result = await paymentService.getPurchaseHistory(userId, { page, limit });

      res.status(200).json({
        message: 'Purchase history retrieved successfully',
        data: result,
      });
    } catch (error) {
      next(error);
    }
  }

  async getSupportedCurrencies(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const currencies = paymentService.getSupportedCurrencies();
      
      res.status(200).json({
        message: 'Supported currencies retrieved successfully',
        data: {
          currencies,
          exchangeRates: exchangeRateService.getAllRates(),
          lastUpdated: exchangeRateService.getLastUpdate(),
        },
      });
    } catch (error) {
      next(error);
    }
  }

  async getPricingTiers(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const currency = (req.query.currency as string) || 'NGN';
      
      if (!flutterwaveService.isCurrencySupported(currency)) {
        res.status(400).json({ 
          message: `Currency ${currency} is not supported`,
          supportedCurrencies: flutterwaveService.getSupportedCurrencies(),
        });
        return;
      }

      const tiers = paymentService.getPricingTiers(currency);
      const exchangeRate = exchangeRateService.getRate(currency);
      
      res.status(200).json({
        message: 'Pricing tiers retrieved successfully',
        data: {
          currency,
          tiers,
          exchangeRate,
          baseRate: '1 USD = 20 AGC',
        },
      });
    } catch (error) {
      next(error);
    }
  }

  async getConfig(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { config } = await import('@/config');
      
      res.status(200).json({
        flutterwavePublicKey: config.flutterwave.publicKey,
        supportedCurrencies: flutterwaveService.getSupportedCurrencies(),
        agcConversionRate: 20, // $1 = 20 AGC
        userSplit: 0.75, // 75% to user
        companySplit: 0.25, // 25% to company
        minPurchaseAmount: 1, // $1 minimum (in USD equivalent)
        exchangeRates: exchangeRateService.getAllRates(),
      });
    } catch (error) {
      next(error);
    }
  }
}