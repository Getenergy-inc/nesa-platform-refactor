import { 
  Nomination, 
  NominationStatus, 
  NominationSource, 
  SupportingDocument,
  NominationFilters,
  NominationResult,
  NominationAnalytics,
  EmailNotification,
  BulkNominationOperation
} from '../types';

export class NominationService {
  private db: any; // Database connection

  constructor(database: any) {
    this.db = database;
  }

  /**
   * Create a new nomination
   */
  async createNomination(nominationData: Partial<Nomination>): Promise<Nomination> {
    try {
      const nomination: Nomination = {
        id: this.generateId(),
        nomineeId: this.generateId(),
        nominatorId: nominationData.nominatorId || '',
        nrcVolunteerId: nominationData.nrcVolunteerId || '',
        fullName: nominationData.fullName!,
        email: nominationData.email!,
        phone: nominationData.phone!,
        country: nominationData.country!,
        stateRegion: nominationData.stateRegion!,
        category: nominationData.category!,
        subcategory: nominationData.subcategory!,
        impactSummary: nominationData.impactSummary!,
        justification: nominationData.justification!,
        nominationSource: nominationData.nominationSource!,
        supportingDocuments: nominationData.supportingDocuments || [],
        status: NominationStatus.PENDING,
        emailSent: false,
        createdAt: new Date(),
        updatedAt: new Date(),
        verificationScore: 0,
        qualityScore: this.calculateInitialQualityScore(nominationData),
        isPublic: false,
        votes: 0,
        viewCount: 0,
        shareCount: 0,
        tags: this.generateTags(nominationData)
      };

      // Only add optional properties if they have values
      if (nominationData.gender) {
        nomination.gender = nominationData.gender;
      }
      if (nominationData.affiliation) {
        nomination.affiliation = nominationData.affiliation;
      }
      if (nominationData.website) {
        nomination.website = nominationData.website;
      }
      if (nominationData.linkedIn) {
        nomination.linkedIn = nominationData.linkedIn;
      }
      if (nominationData.photoUrl) {
        nomination.photoUrl = nominationData.photoUrl;
      }
      if (nominationData.logoUrl) {
        nomination.logoUrl = nominationData.logoUrl;
      }
      if (nominationData.additionalInfo) {
        nomination.additionalInfo = nominationData.additionalInfo;
      }

      await this.db.nominations.create(nomination);

      // If created by NRC volunteer, update their stats
      if (nomination.nrcVolunteerId) {
        await this.updateVolunteerStats(nomination.nrcVolunteerId, 'upload');
      }

      return nomination;
    } catch (error: any) {
      throw new Error(`Failed to create nomination: ${error.message}`);
    }
  }

  /**
   * Get nominations with filtering and pagination
   */
  async getNominations(filters: NominationFilters, page: number = 1, limit: number = 10): Promise<NominationResult> {
    try {
      let query = this.db.nominations.query();

      // Apply filters
      if (filters.country?.length) {
        query = query.whereIn('country', filters.country);
      }
      if (filters.category?.length) {
        query = query.whereIn('category', filters.category);
      }
      if (filters.subcategory?.length) {
        query = query.whereIn('subcategory', filters.subcategory);
      }
      if (filters.status?.length) {
        query = query.whereIn('status', filters.status);
      }
      if (filters.gender?.length) {
        query = query.whereIn('gender', filters.gender);
      }
      if (filters.source?.length) {
        query = query.whereIn('nominationSource', filters.source);
      }
      if (filters.dateRange) {
        query = query.whereBetween('createdAt', [filters.dateRange.start, filters.dateRange.end]);
      }
      if (filters.verificationScore) {
        query = query.whereBetween('verificationScore', [filters.verificationScore.min, filters.verificationScore.max]);
      }
      if (filters.qualityScore) {
        query = query.whereBetween('qualityScore', [filters.qualityScore.min, filters.qualityScore.max]);
      }

      // Get total count
      const total = await query.clone().count();

      // Apply pagination
      const offset = (page - 1) * limit;
      const nominations = await query.offset(offset).limit(limit).orderBy('createdAt', 'desc');

      return {
        nominations,
        total: total[0].count,
        page,
        totalPages: Math.ceil(total[0].count / limit),
        hasNext: page * limit < total[0].count,
        hasPrev: page > 1
      };
    } catch (error: any) {
      throw new Error(`Failed to get nominations: ${error.message}`);
    }
  }

  /**
   * Get nomination by ID
   */
  async getNominationById(nominationId: string): Promise<Nomination | null> {
    try {
      const nomination = await this.db.nominations.findById(nominationId);
      
      if (nomination) {
        // Increment view count
        await this.incrementViewCount(nominationId);
      }
      
      return nomination;
    } catch (error: any) {
      throw new Error(`Failed to get nomination: ${error.message}`);
    }
  }

  /**
   * Update nomination status (approve/reject)
   */
  async updateNominationStatus(
    nominationId: string, 
    status: NominationStatus, 
    approvedBy: string,
    rejectionReason?: string
  ): Promise<void> {
    try {
      const nomination = await this.db.nominations.findById(nominationId);
      if (!nomination) {
        throw new Error('Nomination not found');
      }

      const updateData: Partial<Nomination> = {
        status,
        updatedAt: new Date(),
        approvedBy: status === NominationStatus.APPROVED ? approvedBy : nomination.approvedBy,
        rejectionReason: status === NominationStatus.REJECTED ? (rejectionReason || '') : '',
        isPublic: status === NominationStatus.APPROVED,
        verificationScore: status === NominationStatus.APPROVED ? 100 : nomination.verificationScore
      };

      // Only set approvedAt if status is APPROVED
      if (status === NominationStatus.APPROVED) {
        updateData.approvedAt = new Date();
      }

      await this.db.nominations.update(nominationId, updateData);

      // If approved and has NRC volunteer, award AGC
      if (status === NominationStatus.APPROVED && nomination.nrcVolunteerId) {
        await this.awardAGCForVerification(nomination.nrcVolunteerId, nominationId);
      }

      // Send notification email
      if (status === NominationStatus.APPROVED) {
        await this.sendApprovalEmail(nomination);
      } else if (status === NominationStatus.REJECTED) {
        await this.sendRejectionEmail(nomination, rejectionReason);
      }
    } catch (error: any) {
      throw new Error(`Failed to update nomination status: ${error.message}`);
    }
  }

  /**
   * Upload supporting document
   */
  async uploadSupportingDocument(
    nominationId: string, 
    documentData: Partial<SupportingDocument>
  ): Promise<SupportingDocument> {
    try {
      const document: SupportingDocument = {
        id: this.generateId(),
        filename: documentData.filename!,
        originalName: documentData.originalName!,
        url: documentData.url!,
        type: documentData.type!,
        size: documentData.size!,
        uploadedAt: new Date(),
        description: documentData.description || ''
      };

      // Add document to nomination
      const nomination = await this.db.nominations.findById(nominationId);
      if (!nomination) {
        throw new Error('Nomination not found');
      }

      nomination.supportingDocuments.push(document);
      await this.db.nominations.update(nominationId, nomination);

      return document;
    } catch (error: any) {
      throw new Error(`Failed to upload document: ${error.message}`);
    }
  }

  /**
   * Search nominations
   */
  async searchNominations(
    query: string, 
    filters: NominationFilters, 
    page: number = 1, 
    limit: number = 10
  ): Promise<NominationResult> {
    try {
      let dbQuery = this.db.nominations.query();

      // Add search functionality
      if (query) {
        dbQuery = dbQuery.where((builder: any) => {
          builder
            .where('fullName', 'ilike', `%${query}%`)
            .orWhere('impactSummary', 'ilike', `%${query}%`)
            .orWhere('justification', 'ilike', `%${query}%`)
            .orWhere('affiliation', 'ilike', `%${query}%`);
        });
      }

      // Apply filters (similar to getNominations)
      return await this.getNominations(filters, page, limit);
    } catch (error: any) {
      throw new Error(`Failed to search nominations: ${error.message}`);
    }
  }

  /**
   * Get nomination analytics
   */
  async getNominationAnalytics(): Promise<NominationAnalytics> {
    try {
      const totalNominations = await this.db.nominations.count();
      const pendingNominations = await this.db.nominations.countByStatus(NominationStatus.PENDING);
      const approvedNominations = await this.db.nominations.countByStatus(NominationStatus.APPROVED);
      const rejectedNominations = await this.db.nominations.countByStatus(NominationStatus.REJECTED);

      const byCountry = await this.db.nominations.groupBy('country').count();
      const byCategory = await this.db.nominations.groupBy('category').count();
      const byGender = await this.db.nominations.groupBy('gender').count();
      const bySource = await this.db.nominations.groupBy('nominationSource').count();

      const qualityDistribution = await this.calculateQualityDistribution();
      const timelineData = await this.calculateTimelineData();
      const topContributors = await this.getTopContributors();

      return {
        totalNominations,
        pendingNominations,
        approvedNominations,
        rejectedNominations,
        byCountry: this.formatGroupByResults(byCountry),
        byCategory: this.formatGroupByResults(byCategory),
        byGender: this.formatGroupByResults(byGender),
        bySource: this.formatGroupByResults(bySource),
        qualityDistribution,
        timelineData,
        topContributors
      };
    } catch (error: any) {
      throw new Error(`Failed to get analytics: ${error.message}`);
    }
  }

  /**
   * Bulk operations on nominations
   */
  async bulkOperationNominations(operation: BulkNominationOperation): Promise<void> {
    try {
      switch (operation.operation) {
        case 'approve':
          for (const id of operation.nominationIds) {
            await this.updateNominationStatus(id, NominationStatus.APPROVED, operation.performedBy);
          }
          break;
        
        case 'reject':
          for (const id of operation.nominationIds) {
            await this.updateNominationStatus(id, NominationStatus.REJECTED, operation.performedBy, operation.reason);
          }
          break;

        case 'delete':
          await this.db.nominations.whereIn('id', operation.nominationIds).delete();
          break;

        case 'update_category':
          if (operation.data?.category && operation.data?.subcategory) {
            await this.db.nominations
              .whereIn('id', operation.nominationIds)
              .update({
                category: operation.data.category,
                subcategory: operation.data.subcategory,
                updatedAt: new Date()
              });
          }
          break;

        case 'update_status':
          if (operation.data?.status) {
            await this.db.nominations
              .whereIn('id', operation.nominationIds)
              .update({
                status: operation.data.status,
                updatedAt: new Date()
              });
          }
          break;

        case 'send_email':
          for (const id of operation.nominationIds) {
            const nomination = await this.db.nominations.findById(id);
            if (nomination) {
              await this.sendCustomEmail(nomination, operation.data);
            }
          }
          break;
      }
    } catch (error: any) {
      throw new Error(`Failed to perform bulk operation: ${error.message}`);
    }
  }

  /**
   * Get nominations by volunteer
   */
  async getNominationsByVolunteer(volunteerId: string): Promise<Nomination[]> {
    try {
      return await this.db.nominations.findByVolunteerId(volunteerId);
    } catch (error: any) {
      throw new Error(`Failed to get nominations by volunteer: ${error.message}`);
    }
  }

  // Private helper methods
  private generateId(): string {
    return `nom_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private calculateInitialQualityScore(nominationData: Partial<Nomination>): number {
    let score = 0;
    
    // Impact summary length and quality
    if (nominationData.impactSummary && nominationData.impactSummary.length >= 200) {
      score += 25;
    }
    
    // Justification quality
    if (nominationData.justification && nominationData.justification.length >= 100) {
      score += 20;
    }
    
    // Contact information completeness
    if (nominationData.email && nominationData.phone) {
      score += 15;
    }
    
    // Additional information
    if (nominationData.website || nominationData.linkedIn) {
      score += 10;
    }
    
    if (nominationData.affiliation) {
      score += 10;
    }
    
    // Supporting documents
    if (nominationData.supportingDocuments && nominationData.supportingDocuments.length > 0) {
      score += 20;
    }

    return Math.min(score, 100);
  }

  private generateTags(nominationData: Partial<Nomination>): string[] {
    const tags: string[] = [];
    
    if (nominationData.category) tags.push(nominationData.category.toLowerCase());
    if (nominationData.subcategory) tags.push(nominationData.subcategory.toLowerCase());
    if (nominationData.country) tags.push(nominationData.country.toLowerCase());
    if (nominationData.gender) tags.push(nominationData.gender);
    
    return tags;
  }

  private async updateVolunteerStats(volunteerId: string, action: string): Promise<void> {
    try {
      const volunteer = await this.db.nrcVolunteers.findById(volunteerId);
      if (volunteer) {
        if (action === 'upload') {
          volunteer.totalUploads += 1;
          volunteer.weeklyUploads += 1;
          volunteer.lastActiveAt = new Date();
        }
        await this.db.nrcVolunteers.update(volunteerId, volunteer);
      }
    } catch (error: any) {
      // Log error but don't throw to avoid breaking nomination creation
      console.error('Failed to update volunteer stats:', error);
    }
  }

  private async incrementViewCount(nominationId: string): Promise<void> {
    try {
      await this.db.nominations.increment('viewCount').where('id', nominationId);
    } catch (error: any) {
      // Non-critical operation, just log the error
      console.error('Failed to increment view count:', error);
    }
  }

  private async awardAGCForVerification(volunteerId: string, nominationId: string): Promise<void> {
    try {
      // This would call the NRC service to award AGC
      // await this.nrcService.awardAGCForVerification(volunteerId, nominationId);
    } catch (error: any) {
      console.error('Failed to award AGC:', error);
    }
  }

  private async sendApprovalEmail(nomination: Nomination): Promise<void> {
    try {
      const emailData = {
        nomineeName: nomination.fullName,
        category: nomination.category,
        subcategory: nomination.subcategory,
        nominationReason: nomination.justification,
        membershipUpgradeLink: `${process.env.FRONTEND_URL}/membership/upgrade`,
        walletClaimLink: `${process.env.FRONTEND_URL}/wallet/claim`,
        votingInviteLink: `${process.env.FRONTEND_URL}/voting`
      };

      // This would call the email service
      // await this.emailService.sendApprovalEmail(nomination.email, emailData);
      
      // Update nomination to mark email as sent
      await this.db.nominations.update(nomination.id, {
        emailSent: true,
        emailSentAt: new Date()
      });
    } catch (error: any) {
      console.error('Failed to send approval email:', error);
    }
  }

  private async sendRejectionEmail(nomination: Nomination, reason?: string): Promise<void> {
    try {
      // This would call the email service
      // await this.emailService.sendRejectionEmail(nomination.email, { reason });
    } catch (error: any) {
      console.error('Failed to send rejection email:', error);
    }
  }

  private async sendCustomEmail(nomination: Nomination, data: any): Promise<void> {
    try {
      // This would call the email service
      // await this.emailService.sendCustomEmail(nomination.email, data);
    } catch (error: any) {
      console.error('Failed to send custom email:', error);
    }
  }

  private async calculateQualityDistribution(): Promise<any> {
    // Implementation would calculate quality score distribution
    return {
      excellent: 150, // 90-100
      good: 200,      // 70-89
      average: 180,   // 50-69
      poor: 50        // 0-49
    };
  }

  private async calculateTimelineData(): Promise<any[]> {
    // Implementation would calculate nominations over time
    return [];
  }

  private async getTopContributors(): Promise<any[]> {
    // Implementation would get top contributing volunteers
    return [];
  }

  private formatGroupByResults(results: any[]): Record<string, number> {
    return results.reduce((acc, item) => {
      acc[item.key] = item.count;
      return acc;
    }, {});
  }
}
