import prisma from '@/shared/database/postgresql';
import { ValidationError } from '@/shared/utils/errors';
import logger from '@/shared/utils/logger';
import { fileUploadService } from '@/modules/files/services/FileUploadService';
import { mongoose } from '@/shared/database/mongodb';
import fs from 'fs/promises';

// MongoDB Schema for storing images
const ImageSchema = new mongoose.Schema({
  filename: String,
  contentType: String,
  data: Buffer,
  uploadedAt: { type: Date, default: Date.now },
  uploadedBy: String
});

// Create MongoDB model
const Image = mongoose.model('Image', ImageSchema);

interface NonCompetitiveNominationInput {
  userId: string;
  fullName: string;
  organizationName?: string;
  email: string;
  phone?: string;
  country: string;
  category: string;
  subcategory: string;
  achievementSummary: string;
  impactMetrics: string;
  profileImage?: Express.Multer.File;
  supportingDocuments?: Express.Multer.File;
}

interface NominationQueryParams {
  category?: string;
  subcategory?: string;
}

class NonCompetitiveNominationService {
  async createNomination(data: NonCompetitiveNominationInput): Promise<any> {
    try {
      // Process profile image if provided
      let profileImageId = null;
      let profileImageUrl = null;
      
      if (data.profileImage) {
        // Save image to MongoDB
        const imageBuffer = await fs.readFile(data.profileImage.path);
        const image = new Image({
          filename: data.profileImage.filename,
          contentType: data.profileImage.mimetype,
          data: imageBuffer,
          uploadedBy: data.userId
        });
        
        const savedImage = await image.save();
        profileImageId = savedImage._id.toString();
        
        // Generate URL for the image
        profileImageUrl = `/api/images/${profileImageId}`;
        
        // Delete the temporary file
        await fs.unlink(data.profileImage.path).catch(err => {
          logger.warn(`Failed to delete temporary file ${data.profileImage?.path}:`, err);
        });
      }
      
      // Process supporting documents if provided
      let supportingDocumentUrl = null;
      
      if (data.supportingDocuments) {
        const uploadedFile = await fileUploadService.processUpload(
          data.supportingDocuments,
          data.userId,
          'non-competitive-supporting-document'
        );
        supportingDocumentUrl = uploadedFile.url;
      }
      
      // Create nomination in Prisma
      const nomination = await prisma.nomination.create({
        data: {
          nominatorId: data.userId,
          fullName: data.fullName,
          organizationName: data.organizationName || null,
          email: data.email,
          phone: data.phone || null,
          country: data.country,
          region: 'Non-Competitive', // Default region for non-competitive nominations
          
          // Award Information
          awardCategory: 'Non-Competitive',
          subcategory: data.subcategory,
          achievementSummary: data.achievementSummary,
          impactMetrics: data.impactMetrics,
          
          // Files
          supportingDocuments: supportingDocumentUrl ? [supportingDocumentUrl] : [],
          profileImageUrl: profileImageUrl,
          
          // MongoDB reference
          profileImageId: profileImageId,
          
          // Status
          status: 'SUBMITTED',
          completionScore: 100, // Non-competitive nominations are considered complete upon submission
        }
      });
      
      return nomination;
    } catch (error) {
      logger.error('Failed to create non-competitive nomination:', error);
      throw error;
    }
  }
  
  async getNominations(params: NominationQueryParams): Promise<any[]> {
    try {
      const filter: any = {
        awardCategory: 'Non-Competitive'
      };
      
      if (params.category) {
        filter.category = params.category;
      }
      
      if (params.subcategory) {
        filter.subcategory = params.subcategory;
      }
      
      const nominations = await prisma.nomination.findMany({
        where: filter,
        orderBy: {
          createdAt: 'desc'
        }
      });
      
      return nominations;
    } catch (error) {
      logger.error('Failed to get non-competitive nominations:', error);
      throw error;
    }
  }
  
  async getNominationById(id: string): Promise<any> {
    try {
      const nomination = await prisma.nomination.findUnique({
        where: { id }
      });
      
      if (!nomination) {
        throw new ValidationError('Nomination not found');
      }
      
      return nomination;
    } catch (error) {
      logger.error(`Failed to get non-competitive nomination with ID ${id}:`, error);
      throw error;
    }
  }
}

export const nonCompetitiveNominationService = new NonCompetitiveNominationService();
export default nonCompetitiveNominationService;