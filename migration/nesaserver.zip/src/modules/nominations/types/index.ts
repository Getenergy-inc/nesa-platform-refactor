export interface Nomination {
  id: string;
  nomineeId: string;
  nominatorId?: string;
  nrcVolunteerId?: string;
  fullName: string;
  email: string;
  phone: string;
  country: string;
  stateRegion: string;
  category: string;
  subcategory: string;
  impactSummary: string;
  justification: string;
  nominationSource: NominationSource;
  gender?: Gender;
  affiliation?: string;
  website?: string;
  linkedIn?: string;
  photoUrl?: string;
  logoUrl?: string;
  supportingDocuments: SupportingDocument[];
  status: NominationStatus;
  approvedBy?: string;
  rejectionReason?: string;
  emailSent: boolean;
  emailSentAt?: Date;
  createdAt: Date;
  updatedAt: Date;
  approvedAt?: Date;
  verificationScore: number;
  qualityScore: number;
  isPublic: boolean;
  votes: number;
  viewCount: number;
  shareCount: number;
  tags: string[];
  additionalInfo?: AdditionalNomineeInfo;
}

export interface SupportingDocument {
  id: string;
  filename: string;
  originalName: string;
  url: string;
  type: DocumentType;
  size: number;
  uploadedAt: Date;
  description?: string;
}

export interface AdditionalNomineeInfo {
  dateOfBirth?: Date;
  position?: string;
  yearsOfExperience?: number;
  educationLevel?: string;
  languagesSpoken?: string[];
  socialMediaHandles?: SocialMediaHandles;
  awardsReceived?: string[];
  publicationsAuthored?: string[];
  projectsLed?: string[];
  communitiesServed?: string[];
  impactMetrics?: ImpactMetrics;
}

export interface SocialMediaHandles {
  twitter?: string;
  facebook?: string;
  instagram?: string;
  youtube?: string;
  tiktok?: string;
}

export interface ImpactMetrics {
  studentsImpacted?: number;
  schoolsReached?: number;
  teachersTrained?: number;
  programsLaunched?: number;
  fundsRaised?: number;
  yearsOfService?: number;
}

export interface NominationFilters {
  country?: string[];
  region?: string[];
  category?: string[];
  subcategory?: string[];
  status?: NominationStatus[];
  gender?: Gender[];
  source?: NominationSource[];
  dateRange?: {
    start: Date;
    end: Date;
  };
  verificationScore?: {
    min: number;
    max: number;
  };
  qualityScore?: {
    min: number;
    max: number;
  };
}

export interface NominationSearch {
  query: string;
  filters: NominationFilters;
  sortBy: SortField;
  sortOrder: SortOrder;
  page: number;
  limit: number;
}

export interface NominationResult {
  nominations: Nomination[];
  total: number;
  page: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
}

export interface BulkNominationOperation {
  operation: BulkOperation;
  nominationIds: string[];
  data?: Partial<Nomination>;
  performedBy: string;
  reason?: string;
}

export interface NominationAnalytics {
  totalNominations: number;
  pendingNominations: number;
  approvedNominations: number;
  rejectedNominations: number;
  byCountry: Record<string, number>;
  byCategory: Record<string, number>;
  byGender: Record<Gender, number>;
  bySource: Record<NominationSource, number>;
  qualityDistribution: QualityDistribution;
  timelineData: TimelineData[];
  topContributors: ContributorStats[];
}

export interface QualityDistribution {
  excellent: number; // 90-100
  good: number;      // 70-89
  average: number;   // 50-69
  poor: number;      // 0-49
}

export interface TimelineData {
  date: string;
  count: number;
  approved: number;
  pending: number;
  rejected: number;
}

export interface ContributorStats {
  contributorId: string;
  contributorName: string;
  type: 'volunteer' | 'public';
  count: number;
  approvalRate: number;
  qualityScore: number;
}

export interface EmailNotification {
  nominationId: string;
  recipientEmail: string;
  recipientName: string;
  template: EmailTemplate;
  data: EmailData;
  status: EmailStatus;
  sentAt?: Date;
  openedAt?: Date;
  clickedAt?: Date;
}

export interface EmailData {
  nomineeName: string;
  category: string;
  subcategory: string;
  nominationReason: string;
  recognitionLetter?: string;
  membershipUpgradeLink?: string;
  walletClaimLink?: string;
  votingInviteLink?: string;
  customMessage?: string;
}

export enum NominationStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  REJECTED = 'rejected',
  UNDER_REVIEW = 'under_review',
  NEEDS_INFO = 'needs_info',
  PUBLISHED = 'published'
}

export enum NominationSource {
  NRC_VOLUNTEER = 'nrc_volunteer',
  PUBLIC_NOMINATION = 'public_nomination',
  INSTITUTIONAL = 'institutional',
  SELF_NOMINATION = 'self_nomination',
  PARTNER_REFERRAL = 'partner_referral'
}

export enum Gender {
  MALE = 'male',
  FEMALE = 'female',
  OTHER = 'other',
  NOT_SPECIFIED = 'not_specified'
}

export enum DocumentType {
  PDF = 'pdf',
  IMAGE = 'image',
  VIDEO = 'video',
  AUDIO = 'audio',
  DOCUMENT = 'document',
  SPREADSHEET = 'spreadsheet',
  PRESENTATION = 'presentation'
}

export enum SortField {
  CREATED_AT = 'createdAt',
  UPDATED_AT = 'updatedAt',
  FULL_NAME = 'fullName',
  COUNTRY = 'country',
  CATEGORY = 'category',
  VERIFICATION_SCORE = 'verificationScore',
  QUALITY_SCORE = 'qualityScore',
  VOTES = 'votes'
}

export enum SortOrder {
  ASC = 'asc',
  DESC = 'desc'
}

export enum BulkOperation {
  APPROVE = 'approve',
  REJECT = 'reject',
  DELETE = 'delete',
  UPDATE_CATEGORY = 'update_category',
  UPDATE_STATUS = 'update_status',
  SEND_EMAIL = 'send_email'
}

export enum EmailTemplate {
  NOMINATION_CONFIRMATION = 'nomination_confirmation',
  APPROVAL_NOTIFICATION = 'approval_notification',
  REJECTION_NOTIFICATION = 'rejection_notification',
  VOTING_INVITATION = 'voting_invitation',
  WINNER_ANNOUNCEMENT = 'winner_announcement',
  FOLLOW_UP = 'follow_up'
}

export enum EmailStatus {
  PENDING = 'pending',
  SENT = 'sent',
  DELIVERED = 'delivered',
  OPENED = 'opened',
  CLICKED = 'clicked',
  FAILED = 'failed',
  BOUNCED = 'bounced'
}
