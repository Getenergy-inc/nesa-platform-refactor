/**
 * Simple test to verify nomination validation fixes
 */

import { z } from 'zod';

// Test the validation schemas
const createNominationSchema = z.object({
  body: z.object({
    fullName: z.string().min(1, 'Full name is required'),
    email: z.string().email('Valid email is required'),
    phone: z.string().min(1, 'Phone is required'),
    country: z.string().min(1, 'Country is required'),
    stateRegion: z.string().min(1, 'State/Region is required'),
    category: z.string().min(1, 'Category is required'),
    subcategory: z.string().min(1, 'Subcategory is required'),
    impactSummary: z.string().min(1, 'Impact summary is required'),
    achievementDescription: z.string().min(1, 'Achievement description is required'),
    sdgAlignment: z.array(z.string()).optional(),
    agendaAlignment: z.string().optional(),
    esgAlignment: z.string().optional()
  })
});

function testValidationSchemas() {
  console.log('🧪 Testing nomination validation schemas...');
  
  try {
    // Test valid data
    const validData = {
      body: {
        fullName: 'John Doe',
        email: 'john@example.com',
        phone: '+1234567890',
        country: 'Nigeria',
        stateRegion: 'Lagos',
        category: 'Education',
        subcategory: 'Primary Education',
        impactSummary: 'Improved literacy rates',
        achievementDescription: 'Built 10 schools',
        sdgAlignment: ['SDG 4'],
        agendaAlignment: 'Education for all',
        esgAlignment: 'Social impact'
      }
    };
    
    const result = createNominationSchema.parse(validData);
    console.log('✅ Valid data passed validation:', result.body.fullName);
    
    // Test invalid data
    try {
      const invalidData = {
        body: {
          fullName: '',
          email: 'invalid-email',
          // missing required fields
        }
      };
      
      createNominationSchema.parse(invalidData);
      console.log('❌ Invalid data should have failed validation');
    } catch (error) {
      console.log('✅ Invalid data correctly failed validation');
    }
    
    console.log('🎉 All validation tests passed!');
    
  } catch (error) {
    console.error('❌ Validation test failed:', error);
    throw error;
  }
}

// Run the test if this file is executed directly
if (require.main === module) {
  try {
    testValidationSchemas();
    console.log('\n🏁 Validation test completed successfully');
    process.exit(0);
  } catch (error: any) {
    console.error('\n💥 Validation test failed:', error);
    process.exit(1);
  }
}

export { testValidationSchemas };