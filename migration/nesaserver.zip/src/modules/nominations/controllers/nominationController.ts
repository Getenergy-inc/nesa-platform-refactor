import { Request, Response, NextFunction } from "express";
import prisma from "@/shared/database/postgresql";
import logger from "@/shared/utils/logger";
import { z } from "zod";

// Validation schema for public nominations
const publicNominationSchema = z.object({
  fullName: z.string().min(2, "Full name is required"),
  organizationName: z.string().optional(),
  country: z.string().min(2, "Country is required"),
  // Primary field is 'region', but accept 'stateRegion' as fallback
  region: z.string().min(1, "Region is required"),
  stateRegion: z.string().optional(),
  email: z
    .string()
    .email("Valid email is required")
    .optional(),
  phone: z.string().optional(),
  website: z
    .string()
    .url("Must be a valid URL")
    .optional()
    .or(z.literal("")),
  // Primary field is 'awardCategory', but accept 'category' as fallback
  awardCategory: z.string().min(1, "Award category is required"),
  category: z.string().optional(),
  subcategory: z.string().min(1, "Subcategory is required"),
  // Primary field is 'achievementSummary', but accept 'achievementDescription' as fallback
  achievementSummary: z.string().min(10, "Achievement summary is required"),
  achievementDescription: z.string().optional(),
  // Primary field is 'impactMetrics', but accept 'impactSummary' as fallback
  impactMetrics: z.string().optional(),
  impactSummary: z.string().optional(),
  verificationLinks: z.string().optional(),
  nominatorName: z.string().min(2, "Your name is required"),
  nominatorEmail: z.string().email("Valid email is required"),
  nominatorPhone: z.string().optional(),
  nominatorRelationship: z.string().min(2, "Please describe your relationship"),
  additionalNotes: z.string().optional(),
});

export class NominationController {
  /**
   * Get or create system user for public nominations
   */
  private async getSystemUser(): Promise<string> {
    let systemUser = await prisma.user.findFirst({
      where: { email: "public-nominations@nesa.africa" },
    });

    if (!systemUser) {
      systemUser = await prisma.user.create({
        data: {
          email: "public-nominations@nesa.africa",
          firstName: "Public",
          lastName: "Nominations",
          fullName: "Public Nominations System",
          password: "N/A-SYSTEM-ACCOUNT",
          role: "FREE_MEMBER",
          isVerified: true,
        },
      });
      logger.info("Created system user for public nominations");
    }

    return systemUser.id;
  }

  /**
   * Create a public nomination
   * @route POST /api/v1/nominations/public
   */
  async createPublicNomination(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const validatedData = publicNominationSchema.parse(req.body);
      const userId = (req as any).user?.id;

      // Get nominatorId (authenticated user or system user)
      const nominatorId = userId || (await this.getSystemUser());

      // Normalize data to handle different field names from the payload
      const normalizedData = {
        fullName: validatedData.fullName,
        organizationName: validatedData.organizationName || null,
        email: validatedData.email || null,
        phone: validatedData.phone || null,
        country: validatedData.country,
        region:
          validatedData.region || validatedData.stateRegion || "Not Specified",
        website: validatedData.website || null,
        awardCategory: (validatedData.awardCategory || validatedData.category)!,
        subcategory: validatedData.subcategory,
        achievementSummary: (validatedData.achievementSummary ||
          validatedData.achievementDescription)!,
        impactMetrics:
          validatedData.impactMetrics || validatedData.impactSummary || "",
        verificationLinks: validatedData.verificationLinks || null,
        additionalNotes: validatedData.additionalNotes || null,
        status: "DRAFT" as const,
        completionScore: 75,
        nominator: {
          connect: {
            id: nominatorId,
          },
        },
      };

      const nomination = await prisma.nomination.create({
        data: normalizedData,
      });

      logger.info(`Public nomination created: ${nomination.id}`);

      res.status(201).json({
        success: true,
        message: "Nomination submitted successfully",
        data: nomination,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({
          success: false,
          message: "Validation failed",
          errors: error.errors.map((err) => ({
            field: err.path.join("."),
            message: err.message,
          })),
        });
      } else {
        logger.error("Failed to create public nomination:", error);
        next(error);
      }
    }
  }

  /**
   * Get all nominations with filters
   * @route GET /api/v1/nominations/public
   */
  async getPublicNominations(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const {
        page = "1",
        limit = "12",
        status = "APPROVED",
        country,
        category,
      } = req.query;

      const pageNum = parseInt(page as string);
      const limitNum = parseInt(limit as string);
      const skip = (pageNum - 1) * limitNum;

      const where: any = {};

      if (status) {
        where.status = status;
      }

      if (country) {
        where.country = country;
      }

      if (category) {
        where.awardCategory = category;
      }

      const total = await prisma.nomination.count({ where });

      const nominations = await prisma.nomination.findMany({
        where,
        skip,
        take: limitNum,
        orderBy: {
          createdAt: "desc",
        },
        select: {
          id: true,
          fullName: true,
          organizationName: true,
          country: true,
          region: true,
          awardCategory: true,
          subcategory: true,
          achievementSummary: true,
          impactMetrics: true,
          profileImageUrl: true,
          status: true,
          createdAt: true,
          updatedAt: true,
        },
      });

      res.json({
        success: true,
        data: {
          nominations,
          pagination: {
            page: pageNum,
            limit: limitNum,
            total,
            totalPages: Math.ceil(total / limitNum),
          },
        },
      });
    } catch (error) {
      logger.error("Failed to get public nominations:", error);
      next(error);
    }
  }

  /**
   * Get nomination by ID
   * @route GET /api/v1/nominations/:nominationId
   */
  async getNominationById(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const nominationId = req.params.nominationId as string;

      const nomination = await prisma.nomination.findUnique({
        where: { id: nominationId },
      });

      if (!nomination) {
        res.status(404).json({
          success: false,
          message: "Nomination not found",
        });
        return;
      }

      res.json({
        success: true,
        data: nomination,
      });
    } catch (error) {
      logger.error("Failed to get nomination:", error);
      next(error);
    }
  }

  /**
   * Update nomination status (Admin only)
   * @route PATCH /api/v1/nominations/:nominationId/status
   */
  async updateNominationStatus(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const nominationId = req.params.nominationId as string;
      const { status } = req.body;
      const userId = (req as any).user?.id;

      const nomination = await prisma.nomination.update({
        where: { id: nominationId },
        data: {
          status,
          updatedAt: new Date(),
        },
      });

      logger.info(
        `Nomination ${nominationId} status updated to ${status} by ${userId}`
      );

      res.json({
        success: true,
        message: `Nomination ${status.toLowerCase()} successfully`,
        data: nomination,
      });
    } catch (error) {
      logger.error("Failed to update nomination status:", error);
      next(error);
    }
  }

  /**
   * Create a nomination (authenticated users)
   * @route POST /api/v1/nominations
   */
  async createNomination(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    return this.createPublicNomination(req, res, next);
  }

  /**
   * Get nominations (authenticated users)
   * @route GET /api/v1/nominations
   */
  async getNominations(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    return this.getPublicNominations(req, res, next);
  }
}

export const nominationController = new NominationController();
