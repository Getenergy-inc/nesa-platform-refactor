import { Router } from 'express';
import { z } from 'zod';
import { verifyToken, requireVerification, requireRole } from '@/shared/middleware/auth';
import { validateRequest } from '@/shared/utils/validation';
import { authLimiter, uploadLimiter } from '@/shared/middleware/rateLimiter';
import { validateNomination, validateSupportingDocument, validateBulkOperation } from '../validation/nominationValidation';
import { nominationController } from '../controllers/nominationController';

// Validation schemas
const createNominationSchema = z.object({
  body: z.object({
    fullName: z.string().min(1, 'Full name is required'),
    organizationName: z.string().optional(),
    email: z.string().email('Valid email is required').optional(),
    phone: z.string().optional(),
    country: z.string().min(1, 'Country is required'),
    // Primary field is 'region', but accept 'stateRegion' as fallback
    region: z.string().min(1, 'Region is required'),
    stateRegion: z.string().optional(),
    website: z.string().url('Must be a valid URL').optional().or(z.literal('')),
    // Primary field is 'awardCategory', but accept 'category' as fallback
    awardCategory: z.string().min(1, 'Award category is required'),
    category: z.string().optional(),
    subcategory: z.string().min(1, 'Subcategory is required'),
    // Primary field is 'achievementSummary', but accept 'achievementDescription' as fallback
    achievementSummary: z.string().min(10, 'Achievement summary is required'),
    achievementDescription: z.string().optional(),
    // Primary field is 'impactMetrics', but accept 'impactSummary' as fallback
    impactMetrics: z.string().optional(),
    impactSummary: z.string().optional(),
    verificationLinks: z.string().optional(),
    nominatorName: z.string().min(2, 'Your name is required'),
    nominatorEmail: z.string().email('Valid email is required'),
    nominatorPhone: z.string().optional(),
    nominatorRelationship: z.string().min(2, 'Please describe your relationship'),
    additionalNotes: z.string().optional(),
  })
});

const updateNominationSchema = z.object({
  body: z.object({
    fullName: z.string().optional(),
    email: z.string().email().optional(),
    phone: z.string().optional(),
    country: z.string().optional(),
    stateRegion: z.string().optional(),
    category: z.string().optional(),
    subcategory: z.string().optional(),
    impactSummary: z.string().optional(),
    achievementDescription: z.string().optional(),
    sdgAlignment: z.array(z.string()).optional(),
    agendaAlignment: z.string().optional(),
    esgAlignment: z.string().optional()
  })
});

const reviewNominationSchema = z.object({
  body: z.object({
    status: z.enum(['APPROVED', 'REJECTED']),
    reviewNotes: z.string().optional(),
    rejectionReason: z.string().optional()
  })
});

const bulkOperationSchema = z.object({
  body: z.object({
    operation: z.string().min(1, 'Operation is required'),
    nominationIds: z.array(z.string()).min(1, 'At least one nomination ID is required'),
    data: z.record(z.any()).optional()
  })
});

const supportingDocumentSchema = z.object({
  body: z.object({
    filename: z.string().min(1, 'Filename is required'),
    originalName: z.string().min(1, 'Original name is required'),
    type: z.string().min(1, 'Type is required'),
    size: z.number().min(1, 'Size is required'),
    description: z.string().optional()
  })
});

const router = Router();

// Using the real controller imported above

// Public routes (for public nominations)
router.post('/public', 
  verifyToken,
  requireVerification,
  authLimiter,
  validateRequest(createNominationSchema),
  nominationController.createPublicNomination.bind(nominationController)
);

router.get('/public', nominationController.getPublicNominations.bind(nominationController));
router.get('/public/:nominationId', nominationController.getNominationById.bind(nominationController));

// Protected routes (require authentication)
router.use(verifyToken);

// NRC Volunteer routes
router.post('/', 
  requireVerification,
  authLimiter,
  validateRequest(createNominationSchema),
  nominationController.createNomination
);

router.get('/', 
  requireVerification,
  nominationController.getNominations
);

router.get('/:nominationId', 
  requireVerification,
  nominationController.getNominationById
);

// TODO: Implement these routes when needed
// router.get('/volunteer/:volunteerId', 
//   requireVerification,
//   nominationController.getNominationsByVolunteer
// );

// router.get('/search', 
//   requireVerification,
//   nominationController.searchNominations
// );

// // Document upload routes
// router.post('/:nominationId/documents', 
//   requireVerification,
//   uploadLimiter,
//   validateRequest(supportingDocumentSchema),
//   nominationController.uploadSupportingDocument
// );

// Admin/Validator routes
router.patch('/:nominationId/status', 
  requireRole('ADMIN', 'SUPER_ADMIN'),
  validateRequest(reviewNominationSchema),
  nominationController.updateNominationStatus.bind(nominationController)
);

// TODO: Implement these routes when needed
// router.post('/bulk-operations', 
//   requireRole('ADMIN', 'SUPER_ADMIN'),
//   validateRequest(bulkOperationSchema),
//   nominationController.bulkOperationNominations
// );

// router.get('/analytics/dashboard', 
//   requireRole('ADMIN', 'SUPER_ADMIN'),
//   nominationController.getNominationAnalytics
// );

// Health check
router.get('/health', (req: any, res: any) => {
  res.json({
    success: true,
    message: 'Nominations module is running',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

export default router;
