import { Router, Response } from 'express';
import { verifyToken, requireVerification } from '@/shared/middleware/auth';
import { AuthenticatedRequest } from '@/shared/middleware/auth';
import { ValidationError } from '@/shared/utils/errors';
import logger from '@/shared/utils/logger';
import { fileUploadService } from '@/modules/files/services/FileUploadService';
import { nonCompetitiveNominationService } from '../services/nonCompetitiveNominationService';
import { validateNonCompetitiveNomination } from '../validation/nonCompetitiveValidation';

const router = Router();

// Configure multer middleware
const upload = fileUploadService.getMulterConfig();

// Create non-competitive nomination
router.post('/',
  verifyToken,
  requireVerification,
  upload.fields([
    { name: 'profileImage', maxCount: 1 },
    { name: 'supportingDocuments', maxCount: 1 }
  ]),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const userId = req.user?.id;
      if (!userId) {
        res.status(401).json({
          success: false,
          message: 'User authentication required'
        });
        return;
      }

      // Get uploaded files
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      const profileImage = files['profileImage']?.[0];
      const supportingDocuments = files['supportingDocuments']?.[0];

      // Validate request body
      const validationErrors = validateNonCompetitiveNomination(req.body);
      if (validationErrors.length > 0) {
        res.status(400).json({
          success: false,
          message: 'Validation failed',
          errors: validationErrors
        });
        return;
      }

      // Process the nomination
      const nominationData: any = {
        userId,
        fullName: req.body.fullName,
        organizationName: req.body.organizationName,
        email: req.body.email,
        phone: req.body.phone,
        country: req.body.country,
        category: req.body.category,
        subcategory: req.body.subcategory,
        achievementSummary: req.body.achievementSummary,
        impactMetrics: req.body.impactMetrics,
      };
      
      if (profileImage) {
        nominationData.profileImage = profileImage;
      }
      
      if (supportingDocuments) {
        nominationData.supportingDocuments = supportingDocuments;
      }
      
      const nomination = await nonCompetitiveNominationService.createNomination(nominationData);

      res.status(201).json({
        success: true,
        message: 'Non-competitive nomination created successfully',
        data: nomination
      });
    } catch (error) {
      logger.error('Failed to create non-competitive nomination:', error);
      
      if (error instanceof ValidationError) {
        res.status(400).json({
          success: false,
          message: error.message
        });
      } else {
        res.status(500).json({
          success: false,
          message: 'Failed to create non-competitive nomination'
        });
      }
    }
  }
);

// Get all non-competitive nominations
router.get('/',
  verifyToken,
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const { category, subcategory } = req.query;
      
      const nominations = await nonCompetitiveNominationService.getNominations({
        category: category as string,
        subcategory: subcategory as string
      });

      res.status(200).json({
        success: true,
        data: nominations
      });
    } catch (error) {
      logger.error('Failed to get non-competitive nominations:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to get non-competitive nominations'
      });
    }
  }
);

// Get non-competitive nomination by ID
router.get('/:id',
  verifyToken,
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const { id } = req.params;
      
      if (!id) {
        res.status(400).json({
          success: false,
          message: 'Nomination ID is required'
        });
        return;
      }
      
      const nomination = await nonCompetitiveNominationService.getNominationById(id);
      
      if (!nomination) {
        res.status(404).json({
          success: false,
          message: 'Nomination not found'
        });
        return;
      }

      res.status(200).json({
        success: true,
        data: nomination
      });
    } catch (error) {
      logger.error('Failed to get non-competitive nomination:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to get non-competitive nomination'
      });
    }
  }
);

export default router;