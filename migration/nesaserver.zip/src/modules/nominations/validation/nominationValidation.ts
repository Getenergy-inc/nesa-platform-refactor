import { NominationStatus, NominationSource, Gender, DocumentType } from '../types';

export const validateNomination = {
  create: (data: any) => {
    const errors: string[] = [];
    
    // Required fields
    if (!data.fullName || data.fullName.length < 2 || data.fullName.length > 100) {
      errors.push('fullName is required and must be 2-100 characters');
    }
    if (!data.email || !isValidEmail(data.email)) {
      errors.push('Valid email is required');
    }
    if (!data.phone || data.phone.length < 10 || data.phone.length > 20) {
      errors.push('phone is required and must be 10-20 characters');
    }
    if (!data.country || data.country.length > 100) {
      errors.push('country is required and must be max 100 characters');
    }
    if (!data.stateRegion || data.stateRegion.length > 100) {
      errors.push('stateRegion is required and must be max 100 characters');
    }
    if (!data.category || data.category.length > 100) {
      errors.push('category is required and must be max 100 characters');
    }
    if (!data.subcategory || data.subcategory.length > 100) {
      errors.push('subcategory is required and must be max 100 characters');
    }
    if (!data.impactSummary || data.impactSummary.length < 200 || data.impactSummary.length > 500) {
      errors.push('impactSummary is required and must be 200-500 characters');
    }
    if (!data.justification || data.justification.length < 100 || data.justification.length > 300) {
      errors.push('justification is required and must be 100-300 characters');
    }
    if (!Object.values(NominationSource).includes(data.nominationSource)) {
      errors.push('Invalid nomination source');
    }

    // Optional fields validation
    if (data.gender && !Object.values(Gender).includes(data.gender)) {
      errors.push('Invalid gender');
    }
    if (data.website && !isValidUrl(data.website)) {
      errors.push('Invalid website URL');
    }
    if (data.linkedIn && !isValidUrl(data.linkedIn)) {
      errors.push('Invalid LinkedIn URL');
    }
    if (data.affiliation && data.affiliation.length > 200) {
      errors.push('affiliation must be max 200 characters');
    }

    return { isValid: errors.length === 0, errors };
  },

  update: (data: any) => {
    const errors: string[] = [];
    
    if (data.status && !Object.values(NominationStatus).includes(data.status)) {
      errors.push('Invalid status');
    }
    if (data.rejectionReason && data.rejectionReason.length > 500) {
      errors.push('rejectionReason must be max 500 characters');
    }
    if (data.verificationScore !== undefined && (data.verificationScore < 0 || data.verificationScore > 100)) {
      errors.push('verificationScore must be between 0 and 100');
    }
    if (data.qualityScore !== undefined && (data.qualityScore < 0 || data.qualityScore > 100)) {
      errors.push('qualityScore must be between 0 and 100');
    }

    return { isValid: errors.length === 0, errors };
  },

  search: (data: any) => {
    const errors: string[] = [];
    
    if (data.page && (typeof data.page !== 'number' || data.page < 1)) {
      errors.push('page must be a positive number');
    }
    if (data.limit && (typeof data.limit !== 'number' || data.limit < 1 || data.limit > 100)) {
      errors.push('limit must be between 1 and 100');
    }

    return { isValid: errors.length === 0, errors };
  }
};

export const validateSupportingDocument = {
  upload: (data: any) => {
    const errors: string[] = [];
    
    if (!data.filename || data.filename.length > 255) {
      errors.push('filename is required and must be max 255 characters');
    }
    if (!data.originalName || data.originalName.length > 255) {
      errors.push('originalName is required and must be max 255 characters');
    }
    if (!data.type || !Object.values(DocumentType).includes(data.type)) {
      errors.push('Invalid document type');
    }
    if (typeof data.size !== 'number' || data.size > 10 * 1024 * 1024) { // 10MB
      errors.push('File size must not exceed 10MB');
    }
    if (data.description && data.description.length > 500) {
      errors.push('description must be max 500 characters');
    }

    return { isValid: errors.length === 0, errors };
  }
};

export const validateBulkOperation = {
  nominations: (data: any) => {
    const errors: string[] = [];
    
    if (!data.operation || !['approve', 'reject', 'delete', 'update_category', 'update_status', 'send_email'].includes(data.operation)) {
      errors.push('Invalid operation');
    }
    if (!Array.isArray(data.nominationIds) || data.nominationIds.length === 0) {
      errors.push('nominationIds must be a non-empty array');
    }
    if (data.reason && data.reason.length > 500) {
      errors.push('reason must be max 500 characters');
    }

    return { isValid: errors.length === 0, errors };
  }
};

// Helper functions
function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidUrl(url: string): boolean {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
}
