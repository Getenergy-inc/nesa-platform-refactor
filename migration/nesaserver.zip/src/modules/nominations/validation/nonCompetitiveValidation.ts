import { ValidationError } from '@/shared/utils/errors';

interface NonCompetitiveNominationData {
  fullName: string;
  organizationName?: string;
  email: string;
  phone?: string;
  country: string;
  category: string;
  subcategory: string;
  achievementSummary: string;
  impactMetrics: string;
}

export const validateNonCompetitiveNomination = (data: NonCompetitiveNominationData): string[] => {
  const errors: string[] = [];

  // Required fields
  if (!data.fullName || data.fullName.trim() === '') {
    errors.push('Full name is required');
  }

  if (!data.email || data.email.trim() === '') {
    errors.push('Email is required');
  } else if (!isValidEmail(data.email)) {
    errors.push('Email format is invalid');
  }

  if (!data.country || data.country.trim() === '') {
    errors.push('Country is required');
  }

  if (!data.category || data.category.trim() === '') {
    errors.push('Category is required');
  }

  if (!data.subcategory || data.subcategory.trim() === '') {
    errors.push('Subcategory is required');
  }

  if (!data.achievementSummary || data.achievementSummary.trim() === '') {
    errors.push('Achievement summary is required');
  }

  if (!data.impactMetrics || data.impactMetrics.trim() === '') {
    errors.push('Impact metrics are required');
  }

  return errors;
};

// Helper function to validate email format
function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export const validateNonCompetitiveNominationUpdate = (data: Partial<NonCompetitiveNominationData>): string[] => {
  const errors: string[] = [];

  // Check email format if provided
  if (data.email && !isValidEmail(data.email)) {
    errors.push('Email format is invalid');
  }

  return errors;
};