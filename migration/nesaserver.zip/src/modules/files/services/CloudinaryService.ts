import { v2 as cloudinary, UploadApiResponse, ResourceType } from 'cloudinary';
import logger from '@/shared/utils/logger';
import { config } from '@/config';
import { ValidationError, ExternalServiceError } from '@/shared/utils/errors';

export interface CloudinaryUploadResponse {
  publicId: string;
  secureUrl: string;
  width?: number;
  height?: number;
  fileSize: number;
  resourceType: string;
  format: string;
}

export interface CloudinaryDeleteResponse {
  success: boolean;
  message: string;
}

/**
 * CloudinaryService - Manages cloud-based file uploads and storage
 * Replaces disk-based FileUploadService for scalable image and document storage
 */
class CloudinaryService {
  constructor() {
    this.initializeCloudinary();
  }

  private initializeCloudinary(): void {
    cloudinary.config({
      cloud_name: config.fileUpload.cloudName,
      api_key: config.fileUpload.apiKey,
      api_secret: config.fileUpload.apiSecret
    });
    logger.info('Cloudinary initialized successfully');
  }

  /**
   * Upload nominee profile image to Cloudinary
   * @param file Express Multer file object
   * @param nomineeId ID of the nominee
   * @returns Upload response with Cloudinary details
   */
  async uploadNomineeProfileImage(
    file: Express.Multer.File,
    nomineeId: string
  ): Promise<CloudinaryUploadResponse> {
    try {
      if (!file) {
        throw new ValidationError('No file provided for upload');
      }

      // Validate file type
      const allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
      if (!allowedMimeTypes.includes(file.mimetype)) {
        throw new ValidationError(
          `Invalid file type. Allowed types: ${allowedMimeTypes.join(', ')}`
        );
      }

      // Validate file size (5MB for images)
      const maxSize = 5 * 1024 * 1024; // 5MB
      if (file.size > maxSize) {
        throw new ValidationError(`File size exceeds 5MB limit. Size: ${file.size} bytes`);
      }

      const result = await this.uploadToCloudinary(file, {
        folder: `nominees/profiles/${nomineeId}`,
        resource_type: 'auto',
        quality: 'auto',
        fetch_format: 'auto',
        transformation: [
          {
            width: 500,
            height: 500,
            crop: 'fill',
            gravity: 'face',
            quality: 'auto'
          }
        ]
      });

      logger.info(`Nominee profile image uploaded successfully: ${result.public_id}`);

      return this.formatUploadResponse(result);
    } catch (error) {
      logger.error('Failed to upload nominee profile image:', error);
      if (error instanceof ValidationError) {
        throw error;
      }
      throw new ExternalServiceError('Failed to upload profile image');
    }
  }

  /**
   * Upload supporting document (PDF, Word, Image) for nominee
   * @param file Express Multer file object
   * @param nomineeId ID of the nominee
   * @param documentType Type of document (e.g., 'cv', 'credentials', 'portfolio')
   * @returns Upload response with Cloudinary details
   */
  async uploadSupportingDocument(
    file: Express.Multer.File,
    nomineeId: string,
    documentType?: string
  ): Promise<CloudinaryUploadResponse> {
    try {
      if (!file) {
        throw new ValidationError('No file provided for upload');
      }

      // Validate file type
      const allowedMimeTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'image/jpeg',
        'image/png',
        'image/gif',
        'image/webp'
      ];
      if (!allowedMimeTypes.includes(file.mimetype)) {
        throw new ValidationError(
          `Invalid file type. Allowed types: PDF, DOCX, DOC, JPG, PNG, GIF, WebP`
        );
      }

      // Validate file size (10MB for documents)
      const maxSize = 10 * 1024 * 1024; // 10MB
      if (file.size > maxSize) {
        throw new ValidationError(`File size exceeds 10MB limit. Size: ${file.size} bytes`);
      }

      const folderPath = documentType
        ? `nominees/documents/${nomineeId}/${documentType}`
        : `nominees/documents/${nomineeId}`;

      const result = await this.uploadToCloudinary(file, {
        folder: folderPath,
        resource_type: 'auto'
      });

      logger.info(`Supporting document uploaded successfully: ${result.public_id}`);

      return this.formatUploadResponse(result);
    } catch (error) {
      logger.error('Failed to upload supporting document:', error);
      if (error instanceof ValidationError) {
        throw error;
      }
      throw new ExternalServiceError('Failed to upload document');
    }
  }

  /**
   * Upload certificate (PDF) to Cloudinary
   * @param file Express Multer file object (PDF file)
   * @param nomineeId ID of the nominee
   * @param certificateNumber Unique certificate number
   * @returns Upload response with Cloudinary details
   */
  async uploadCertificate(
    file: Express.Multer.File,
    nomineeId: string,
    certificateNumber: string
  ): Promise<CloudinaryUploadResponse> {
    try {
      if (!file) {
        throw new ValidationError('No file provided for upload');
      }

      // Validate file type - certificates must be PDF
      if (file.mimetype !== 'application/pdf') {
        throw new ValidationError('Certificate must be a PDF file');
      }

      // Validate file size (5MB for PDFs)
      const maxSize = 5 * 1024 * 1024; // 5MB
      if (file.size > maxSize) {
        throw new ValidationError(`File size exceeds 5MB limit. Size: ${file.size} bytes`);
      }

      const currentYear = new Date().getFullYear();
      const result = await this.uploadToCloudinary(file, {
        folder: `certificates/${currentYear}/${nomineeId}`,
        public_id: certificateNumber,
        resource_type: 'auto',
        type: 'upload'
      });

      logger.info(`Certificate uploaded successfully: ${result.public_id}`);

      return this.formatUploadResponse(result);
    } catch (error) {
      logger.error('Failed to upload certificate:', error);
      if (error instanceof ValidationError) {
        throw error;
      }
      throw new ExternalServiceError('Failed to upload certificate');
    }
  }

  /**
   * Delete file from Cloudinary by public ID
   * @param publicId Cloudinary public ID of file to delete
   * @returns Deletion status
   */
  async deleteFile(publicId: string): Promise<CloudinaryDeleteResponse> {
    try {
      if (!publicId) {
        throw new ValidationError('Public ID is required for deletion');
      }

      const result = await cloudinary.uploader.destroy(publicId);

      if (result.result === 'ok') {
        logger.info(`File deleted successfully: ${publicId}`);
        return {
          success: true,
          message: `File ${publicId} deleted successfully`
        };
      } else {
        logger.warn(`File deletion returned unexpected result: ${result.result}`);
        return {
          success: false,
          message: `Failed to delete file: ${result.result}`
        };
      }
    } catch (error) {
      logger.error('Failed to delete file from Cloudinary:', error);
      throw new ExternalServiceError('Failed to delete file');
    }
  }

  /**
   * Delete multiple files from Cloudinary by public IDs
   * @param publicIds Array of Cloudinary public IDs
   * @returns Deletion results
   */
  async deleteFiles(publicIds: string[]): Promise<CloudinaryDeleteResponse[]> {
    try {
      if (!publicIds || publicIds.length === 0) {
        throw new ValidationError('At least one public ID is required');
      }

      const results = await Promise.all(
        publicIds.map(publicId =>
          cloudinary.uploader.destroy(publicId).then(result => ({
            publicId,
            success: result.result === 'ok',
            message: result.result === 'ok' ? 'Deleted successfully' : result.result
          }))
        )
      );

      logger.info(`Deleted ${results.filter(r => r.success).length}/${publicIds.length} files`);

      return results;
    } catch (error) {
      logger.error('Failed to delete multiple files:', error);
      throw new ExternalServiceError('Failed to delete files');
    }
  }

  /**
   * Get file URL with transformations
   * @param publicId Cloudinary public ID
   * @param transformations Optional Cloudinary transformations
   * @returns Secure URL with transformations applied
   */
  getFileUrl(publicId: string, transformations?: any): string {
    try {
      if (!publicId) {
        throw new ValidationError('Public ID is required');
      }

      return cloudinary.url(publicId, {
        secure: true,
        ...(transformations && { transformation: transformations })
      });
    } catch (error) {
      logger.error('Failed to generate file URL:', error);
      throw new ExternalServiceError('Failed to generate file URL');
    }
  }

  /**
   * Get resource information from Cloudinary
   * @param publicId Cloudinary public ID
   * @returns Resource details
   */
  async getResourceInfo(publicId: string): Promise<any> {
    try {
      if (!publicId) {
        throw new ValidationError('Public ID is required');
      }

      const resource = await cloudinary.api.resource(publicId);
      return resource;
    } catch (error) {
      logger.error('Failed to get resource information:', error);
      throw new ExternalServiceError('Failed to retrieve resource information');
    }
  }

  /**
   * List all resources in a folder
   * @param folderPath Cloudinary folder path
   * @returns List of resources
   */
  async listResourcesInFolder(folderPath: string): Promise<any> {
    try {
      if (!folderPath) {
        throw new ValidationError('Folder path is required');
      }

      const resources = await cloudinary.api.resources({
        type: 'upload',
        prefix: folderPath
      });

      return resources;
    } catch (error) {
      logger.error('Failed to list resources:', error);
      throw new ExternalServiceError('Failed to list resources');
    }
  }

  /**
   * Internal helper: Upload file to Cloudinary
   * @param file Express Multer file
   * @param options Cloudinary upload options
   * @returns Cloudinary upload response
   */
  private async uploadToCloudinary(
    file: Express.Multer.File,
    options: any
  ): Promise<UploadApiResponse> {
    return new Promise((resolve, reject) => {
      const upload = cloudinary.uploader.upload_stream(options, (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve(result as UploadApiResponse);
        }
      });

      upload.end(file.buffer);
    });
  }

  /**
   * Format Cloudinary response to standard interface
   * @param result Cloudinary upload response
   * @returns Formatted response
   */
  private formatUploadResponse(result: UploadApiResponse): CloudinaryUploadResponse {
    return {
      publicId: result.public_id,
      secureUrl: result.secure_url,
      width: result.width,
      height: result.height,
      fileSize: result.bytes,
      resourceType: result.resource_type,
      format: result.format
    };
  }
}

// Export singleton instance
export const cloudinaryService = new CloudinaryService();
export default cloudinaryService;
