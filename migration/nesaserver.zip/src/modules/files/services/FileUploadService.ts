import multer from 'multer';
import path from 'path';
import fs from 'fs/promises';
import crypto from 'crypto';
import { ValidationError } from '@/shared/utils/errors';
import logger from '@/shared/utils/logger';
import { config } from '@/config';

export interface UploadedFile {
  id: string;
  originalName: string;
  filename: string;
  mimetype: string;
  size: number;
  url: string;
  uploadedBy: string;
  uploadedAt: Date;
}

class FileUploadService {
  private readonly UPLOAD_DIR = path.join(process.cwd(), 'uploads');
  private readonly MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
  private readonly ALLOWED_MIME_TYPES = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'image/jpeg',
    'image/png',
    'image/gif'
  ];

  constructor() {
    this.ensureUploadDirectory();
  }

  // Ensure upload directory exists
  private async ensureUploadDirectory(): Promise<void> {
    try {
      await fs.access(this.UPLOAD_DIR);
    } catch {
      await fs.mkdir(this.UPLOAD_DIR, { recursive: true });
      logger.info(`Created upload directory: ${this.UPLOAD_DIR}`);
    }
  }

  // Configure multer for file uploads
  getMulterConfig() {
    const storage = multer.diskStorage({
      destination: async (req, file, cb) => {
        await this.ensureUploadDirectory();
        cb(null, this.UPLOAD_DIR);
      },
      filename: (req, file, cb) => {
        // Generate unique filename
        const uniqueSuffix = crypto.randomBytes(16).toString('hex');
        const ext = path.extname(file.originalname);
        const filename = `${Date.now()}-${uniqueSuffix}${ext}`;
        cb(null, filename);
      }
    });

    const fileFilter = (req: any, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
      if (this.ALLOWED_MIME_TYPES.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new ValidationError(`File type ${file.mimetype} not allowed`));
      }
    };

    return multer({
      storage,
      fileFilter,
      limits: {
        fileSize: this.MAX_FILE_SIZE,
        files: 5 // Maximum 5 files per upload
      }
    });
  }

  // Process uploaded file and save metadata
  async processUpload(
    file: Express.Multer.File,
    uploadedBy: string,
    documentType?: string
  ): Promise<UploadedFile> {
    try {
      // Validate file
      if (!file) {
        throw new ValidationError('No file provided');
      }

      if (file.size > this.MAX_FILE_SIZE) {
        throw new ValidationError(`File size exceeds ${this.MAX_FILE_SIZE / 1024 / 1024}MB limit`);
      }

      if (!this.ALLOWED_MIME_TYPES.includes(file.mimetype)) {
        throw new ValidationError(`File type ${file.mimetype} not allowed`);
      }

      // Generate file URL
      const fileUrl = this.generateFileUrl(file.filename);

      // Create file record
      const uploadedFile: UploadedFile = {
        id: crypto.randomUUID(),
        originalName: file.originalname,
        filename: file.filename,
        mimetype: file.mimetype,
        size: file.size,
        url: fileUrl,
        uploadedBy,
        uploadedAt: new Date()
      };

      // TODO: Save file metadata to database
      // await this.saveFileMetadata(uploadedFile, documentType);

      logger.info(`File uploaded successfully: ${file.originalname} by ${uploadedBy}`);
      
      return uploadedFile;
    } catch (error) {
      // Clean up file if processing failed
      if (file?.filename) {
        await this.deleteFile(file.filename).catch(() => {
          // Ignore cleanup errors
        });
      }
      throw error;
    }
  }

  // Process multiple file uploads
  async processMultipleUploads(
    files: Express.Multer.File[],
    uploadedBy: string,
    documentTypes?: string[]
  ): Promise<UploadedFile[]> {
    const uploadedFiles: UploadedFile[] = [];
    const errors: string[] = [];

    for (let i = 0; i < files.length; i++) {
      try {
        const file = files[i];
        if (!file) continue; // Skip undefined files
        const documentType = documentTypes?.[i];
        const uploadedFile = await this.processUpload(file, uploadedBy, documentType);
        uploadedFiles.push(uploadedFile);
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Upload failed';
        errors.push(`File ${i + 1}: ${errorMessage}`);
      }
    }

    if (errors.length > 0 && uploadedFiles.length === 0) {
      throw new ValidationError(`All uploads failed: ${errors.join(', ')}`);
    }

    if (errors.length > 0) {
      logger.warn(`Some uploads failed: ${errors.join(', ')}`);
    }

    return uploadedFiles;
  }

  // Generate file URL
  private generateFileUrl(filename: string): string {
    // Use port-based URL since config.app.baseUrl doesn't exist
    const baseUrl = `http://localhost:${config.port}`;
    return `${baseUrl}/api/v1/files/${filename}`;
  }

  // Delete file from filesystem
  async deleteFile(filename: string): Promise<void> {
    try {
      const filePath = path.join(this.UPLOAD_DIR, filename);
      await fs.unlink(filePath);
      logger.info(`File deleted: ${filename}`);
    } catch (error) {
      logger.error(`Failed to delete file ${filename}:`, error);
      throw error;
    }
  }

  // Get file path for serving
  getFilePath(filename: string): string {
    return path.join(this.UPLOAD_DIR, filename);
  }

  // Validate file exists
  async fileExists(filename: string): Promise<boolean> {
    try {
      const filePath = this.getFilePath(filename);
      await fs.access(filePath);
      return true;
    } catch {
      return false;
    }
  }

  // Get file info
  async getFileInfo(filename: string): Promise<{ size: number; mtime: Date } | null> {
    try {
      const filePath = this.getFilePath(filename);
      const stats = await fs.stat(filePath);
      return {
        size: stats.size,
        mtime: stats.mtime
      };
    } catch {
      return null;
    }
  }

  // Clean up old files (can be run as a cron job)
  async cleanupOldFiles(olderThanDays: number = 30): Promise<number> {
    try {
      const files = await fs.readdir(this.UPLOAD_DIR);
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - olderThanDays);

      let deletedCount = 0;

      for (const filename of files) {
        try {
          const filePath = path.join(this.UPLOAD_DIR, filename);
          const stats = await fs.stat(filePath);
          
          if (stats.mtime < cutoffDate) {
            await fs.unlink(filePath);
            deletedCount++;
            logger.info(`Cleaned up old file: ${filename}`);
          }
        } catch (error) {
          logger.error(`Failed to process file ${filename} during cleanup:`, error);
        }
      }

      logger.info(`Cleanup completed: ${deletedCount} files deleted`);
      return deletedCount;
    } catch (error) {
      logger.error('File cleanup failed:', error);
      throw error;
    }
  }

  // Get allowed file types for frontend
  getAllowedFileTypes(): string[] {
    return [...this.ALLOWED_MIME_TYPES];
  }

  // Get max file size for frontend
  getMaxFileSize(): number {
    return this.MAX_FILE_SIZE;
  }

  // Validate file type
  isAllowedFileType(mimetype: string): boolean {
    return this.ALLOWED_MIME_TYPES.includes(mimetype);
  }

  // Get file extension from mimetype
  getFileExtension(mimetype: string): string {
    const extensions: Record<string, string> = {
      'application/pdf': '.pdf',
      'application/msword': '.doc',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
      'image/jpeg': '.jpg',
      'image/png': '.png',
      'image/gif': '.gif'
    };
    
    return extensions[mimetype] || '';
  }

  // TODO: Save file metadata to database
  private async saveFileMetadata(file: UploadedFile, documentType?: string): Promise<void> {
    // This would save file metadata to the database
    // Including relationship to applications, users, etc.
    logger.info(`TODO: Save file metadata for ${file.id}`);
  }
}

export const fileUploadService = new FileUploadService();
export default fileUploadService;
