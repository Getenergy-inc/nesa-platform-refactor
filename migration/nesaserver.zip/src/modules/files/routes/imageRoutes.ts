import { Router, Request, Response } from "express";
import { mongoose } from "@/shared/database/mongodb";
import logger from "@/shared/utils/logger";

const router = Router();

// MongoDB Schema for images
const ImageSchema = new mongoose.Schema({
  filename: String,
  contentType: String,
  data: Buffer,
  uploadedAt: { type: Date, default: Date.now },
  uploadedBy: String,
});

// Create MongoDB model (if not already created)
const Image = mongoose.models.Image || mongoose.model("Image", ImageSchema);

// Serve image from MongoDB by ID
router.get(
  "/:id",
  async (req: Request, res: Response): Promise<void> => {
    try {
      const { id } = req.params;

      if (!id) {
        res.status(400).json({
          success: false,
          message: "Image ID is required",
        });
        return;
      }

      if (!mongoose.Types.ObjectId.isValid(id)) {
        res.status(400).json({
          success: false,
          message: "Invalid image ID",
        });
        return;
      }

      const image = await (Image as any).findById(id);

      if (!image) {
        res.status(404).json({
          success: false,
          message: "Image not found",
        });
        return;
      }

      // Set appropriate headers
      res.setHeader("Content-Type", image.contentType);
      res.setHeader("Content-Length", image.data.length);
      res.setHeader("Cache-Control", "public, max-age=86400"); // Cache for 24 hours

      // Send the image data
      res.send(image.data);
    } catch (error) {
      logger.error("Failed to serve image:", error);
      res.status(500).json({
        success: false,
        message: "Failed to serve image",
      });
    }
  }
);

// Upload image to MongoDB
router.post(
  "/upload",
  async (req: Request, res: Response): Promise<void> => {
    try {
      if (!req.body || !req.body.imageData) {
        res.status(400).json({
          success: false,
          message: "No image data provided",
        });
        return;
      }

      const { imageData, contentType, filename, uploadedBy } = req.body;

      // Convert base64 to buffer
      const buffer = Buffer.from(imageData.split(",")[1], "base64");

      // Save to MongoDB
      const image = new Image({
        filename: filename || "unnamed-image",
        contentType: contentType || "image/jpeg",
        data: buffer,
        uploadedBy: uploadedBy || "anonymous",
      });

      const savedImage = await image.save();

      res.status(201).json({
        success: true,
        message: "Image uploaded successfully",
        data: {
          id: savedImage._id,
          url: `/api/images/${savedImage._id}`,
          filename: savedImage.filename,
          contentType: savedImage.contentType,
          uploadedAt: savedImage.uploadedAt,
        },
      });
    } catch (error) {
      logger.error("Failed to upload image:", error);
      res.status(500).json({
        success: false,
        message: "Failed to upload image",
      });
    }
  }
);

// Delete image from MongoDB
router.delete(
  "/:id",
  async (req: Request, res: Response): Promise<void> => {
    try {
      const { id } = req.params;

      if (!id) {
        res.status(400).json({
          success: false,
          message: "Image ID is required",
        });
        return;
      }

      if (!mongoose.Types.ObjectId.isValid(id)) {
        res.status(400).json({
          success: false,
          message: "Invalid image ID",
        });
        return;
      }

      const result = await (Image as any).findByIdAndDelete(id);

      if (!result) {
        res.status(404).json({
          success: false,
          message: "Image not found",
        });
        return;
      }

      res.status(200).json({
        success: true,
        message: "Image deleted successfully",
      });
    } catch (error) {
      logger.error("Failed to delete image:", error);
      res.status(500).json({
        success: false,
        message: "Failed to delete image",
      });
    }
  }
);

export default router;
