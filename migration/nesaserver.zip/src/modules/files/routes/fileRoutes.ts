import { Router, Request, Response } from 'express';
import { verifyToken, requireVerification } from '@/shared/middleware/auth';
import { fileUploadService } from '../services/FileUploadService';
import { ValidationError } from '@/shared/utils/errors';
import logger from '@/shared/utils/logger';
import path from 'path';
import { AuthenticatedRequest } from '@/shared/middleware/auth';

const router = Router();

// Configure multer middleware
const upload = fileUploadService.getMulterConfig();

// Upload single file
router.post('/upload',
  verifyToken,
  requireVerification,
  upload.single('file'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const file = req.file;
      const userId = req.user?.id;
      const { documentType } = req.body;

      if (!userId) {
        res.status(401).json({
          success: false,
          message: 'User authentication required'
        });
        return;
      }

      if (!file) {
        res.status(400).json({
          success: false,
          message: 'No file provided'
        });
        return;
      }

      const uploadedFile = await fileUploadService.processUpload(file, userId, documentType);

      res.status(200).json({
        success: true,
        message: 'File uploaded successfully',
        data: {
          file: uploadedFile
        }
      });
    } catch (error) {
      logger.error('File upload failed:', error);
      
      if (error instanceof ValidationError) {
        res.status(400).json({
          success: false,
          message: error.message
        });
      } else {
        res.status(500).json({
          success: false,
          message: 'File upload failed'
        });
      }
    }
  }
);

// Upload multiple files
router.post('/upload-multiple',
  verifyToken,
  requireVerification,
  upload.array('files', 5), // Maximum 5 files
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const files = req.files as Express.Multer.File[];
      const userId = req.user?.id;
      const { documentTypes } = req.body;

      if (!userId) {
        res.status(401).json({
          success: false,
          message: 'User authentication required'
        });
        return;
      }

      if (!files || files.length === 0) {
        res.status(400).json({
          success: false,
          message: 'No files provided'
        });
        return;
      }

      const documentTypesArray = documentTypes ? JSON.parse(documentTypes) : undefined;
      const uploadedFiles = await fileUploadService.processMultipleUploads(files, userId, documentTypesArray);

      res.status(200).json({
        success: true,
        message: `${uploadedFiles.length} file(s) uploaded successfully`,
        data: {
          files: uploadedFiles
        }
      });
    } catch (error) {
      logger.error('Multiple file upload failed:', error);
      
      if (error instanceof ValidationError) {
        res.status(400).json({
          success: false,
          message: error.message
        });
      } else {
        res.status(500).json({
          success: false,
          message: 'File upload failed'
        });
      }
    }
  }
);

// Serve uploaded files
router.get('/:filename',
  async (req: Request, res: Response): Promise<void> => {
    try {
      const filename = (req.params as any)?.filename;
      
      if (!filename) {
        res.status(400).json({
          success: false,
          message: 'Filename is required'
        });
        return;
      }
      
      // Validate filename to prevent directory traversal
      if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
        res.status(400).json({
          success: false,
          message: 'Invalid filename'
        });
        return;
      }

      const fileExists = await fileUploadService.fileExists(filename);
      if (!fileExists) {
        res.status(404).json({
          success: false,
          message: 'File not found'
        });
        return;
      }

      const filePath = fileUploadService.getFilePath(filename);
      const fileInfo = await fileUploadService.getFileInfo(filename);

      if (!fileInfo) {
        res.status(404).json({
          success: false,
          message: 'File not found'
        });
        return;
      }

      // Set appropriate headers
      const ext = path.extname(filename).toLowerCase();
      const mimeTypes: Record<string, string> = {
        '.pdf': 'application/pdf',
        '.doc': 'application/msword',
        '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.png': 'image/png',
        '.gif': 'image/gif'
      };

      const contentType = mimeTypes[ext] || 'application/octet-stream';
      
      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Length', fileInfo.size);
      res.setHeader('Last-Modified', fileInfo.mtime.toUTCString());
      
      // For PDFs and images, allow inline viewing
      if (contentType.startsWith('image/') || contentType === 'application/pdf') {
        res.setHeader('Content-Disposition', `inline; filename="${filename}"`);
      } else {
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      }

      res.sendFile(filePath);
    } catch (error) {
      logger.error('File serving failed:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to serve file'
      });
    }
  }
);

// Delete file (authenticated users only)
router.delete('/:filename',
  verifyToken,
  requireVerification,
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const filename = (req as any).params?.filename;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          success: false,
          message: 'User authentication required'
        });
        return;
      }

      if (!filename) {
        res.status(400).json({
          success: false,
          message: 'Filename is required'
        });
        return;
      }

      // Validate filename
      if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
        res.status(400).json({
          success: false,
          message: 'Invalid filename'
        });
        return;
      }

      const fileExists = await fileUploadService.fileExists(filename);
      if (!fileExists) {
        res.status(404).json({
          success: false,
          message: 'File not found'
        });
        return;
      }

      // TODO: Check if user owns this file or has permission to delete it
      // For now, allow any authenticated user to delete files they uploaded

      await fileUploadService.deleteFile(filename);

      res.status(200).json({
        success: true,
        message: 'File deleted successfully'
      });
    } catch (error) {
      logger.error('File deletion failed:', error);
      res.status(500).json({
        success: false,
        message: 'File deletion failed'
      });
    }
  }
);

// Get file upload configuration (for frontend)
router.get('/config/upload',
  (req: Request, res: Response) => {
    try {
      res.status(200).json({
        success: true,
        data: {
          allowedFileTypes: fileUploadService.getAllowedFileTypes(),
          maxFileSize: fileUploadService.getMaxFileSize(),
          maxFiles: 5
        }
      });
    } catch (error) {
      logger.error('Get upload config failed:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to get upload configuration'
      });
    }
  }
);

// Health check for file service
router.get('/health',
  async (req: Request, res: Response) => {
    try {
      // Check if upload directory is accessible
      const testFilename = 'test-file.txt';
      const canWrite = await fileUploadService.fileExists('non-existent-file.txt');
      
      res.status(200).json({
        success: true,
        message: 'File service is healthy',
        data: {
          uploadDirectory: 'accessible',
          allowedTypes: fileUploadService.getAllowedFileTypes().length,
          maxFileSize: fileUploadService.getMaxFileSize()
        }
      });
    } catch (error) {
      logger.error('File service health check failed:', error);
      res.status(500).json({
        success: false,
        message: 'File service health check failed'
      });
    }
  }
);

export default router;
