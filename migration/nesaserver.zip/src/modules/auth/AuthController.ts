import { Request, Response } from "express";
import { asyncHandler } from "@/shared/utils/errors";
import { unifiedAuthService as service } from "./services/unifiedAuthService";
import { emailService } from "@/modules/notifications/services/emailService";
import { ApiResponse } from "@/shared/types";
import { prisma } from "@/shared/database/postgresql";

export class UnifiedAuthController {
  // ===== Public Auth =====
  register = asyncHandler(async (req: Request, res: Response) => {
    const result = await service.register(req.body);
    const response: ApiResponse = {
      success: true,
      message: result.message,
      data: { user: result.user },
    };
    res.status(201).json(response);
  });

  signupFlow = asyncHandler(async (req: Request, res: Response) => {
    const result = await service.signup(req.body);
    const response: ApiResponse = {
      success: true,
      message:
        "Account created successfully! Please check your email for verification.",
      data: result,
    };
    // No tokens are set during signup - user must verify email first
    res.status(201).json(response);
  });

  login = asyncHandler(async (req: Request, res: Response) => {
    const result = await service.login(req.body);
    const response: ApiResponse = {
      success: true,
      message: "Login successful",
      data: {
        user: result.user,
        tokens: {
          accessToken: result.accessToken,
          refreshToken: result.refreshToken,
          expiresIn: result.expiresIn,
        },
      },
    };

    // Set refresh token as httpOnly cookie (secure)
    res.cookie("refreshToken", result.refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 30 * 24 * 60 * 60 * 1000,
    });

    // Set access token as regular cookie (accessible to JavaScript)
    res.cookie("token", result.accessToken, {
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 24 * 60 * 60 * 1000,
    }); // 1 day

    // Set user ID as regular cookie for convenience
    res.cookie("userId", result.user.id, {
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 24 * 60 * 60 * 1000,
    }); // 1 day

    res.json(response);
  });

  refreshToken = asyncHandler(async (req: Request, res: Response) => {
    const token = req.cookies?.refreshToken || req.body.refreshToken;
    if (!token) {
      res
        .status(401)
        .json({ success: false, message: "Refresh token missing" });
      return;
    }
    const result = await service.refreshToken(token);
    const response: ApiResponse = {
      success: true,
      message: "Token refreshed successfully",
      data: {
        tokens: {
          accessToken: result.accessToken,
          expiresIn: result.expiresIn,
        },
      },
    };
    res.cookie("refreshToken", result.refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 30 * 24 * 60 * 60 * 1000,
    });
    res.json(response);
  });

  logout = asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.id;
    await service.logout(userId);

    // Clear all auth cookies
    res.clearCookie("refreshToken", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
    });
    res.clearCookie("token", {
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
    });
    res.clearCookie("userId", {
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
    });

    const response: ApiResponse = {
      success: true,
      message: "Logout successful",
    };
    res.json(response);
  });

  verifyEmail = asyncHandler(async (req: Request, res: Response) => {
    const result = await service.verifyEmail(req.body);
    const user = await prisma.user.findFirst({
      where: { emailVerificationToken: req.body.token },
      select: { email: true, firstName: true },
    });
    if (user) {
      await emailService.sendWelcomeEmail(user.email, user.firstName || "User");
    }
    const response: ApiResponse = { success: true, message: result.message };
    res.json(response);
  });

  resendVerificationEmail = asyncHandler(
    async (req: Request, res: Response) => {
      const result = await service.resendVerificationEmail(req.body.email);
      const response: ApiResponse = { success: true, message: result.message };
      res.json(response);
    }
  );

  requestPasswordReset = asyncHandler(async (req: Request, res: Response) => {
    const result = await service.requestPasswordReset(req.body);
    const response: ApiResponse = { success: true, message: result.message };
    res.json(response);
  });

  resetPassword = asyncHandler(async (req: Request, res: Response) => {
    const result = await service.resetPassword(req.body);
    const response: ApiResponse = { success: true, message: result.message };
    res.json(response);
  });

  // ===== OTP =====
  sendLoginOtp = asyncHandler(async (req: Request, res: Response) => {
    const { email } = req.body;
    await service.sendOtp(email, "LOGIN");
    const response: ApiResponse = {
      success: true,
      message: "OTP sent to your email",
    };
    res.json(response);
  });

  sendEmailVerificationOtp = asyncHandler(
    async (req: Request, res: Response) => {
      const { email } = req.body;
      await service.sendOtp(email, "VERIFY_EMAIL");
      const response: ApiResponse = {
        success: true,
        message: "Verification OTP sent to your email",
      };
      res.json(response);
    }
  );

  verifyOtp = asyncHandler(async (req: Request, res: Response) => {
    const { email, code, purpose } = req.body;
    const result = await service.verifyOtp(email, code, purpose);
    // If tokens are returned (LOGIN purpose resolved), set cookies
    if (result.tokens) {
      // Set refresh token as httpOnly cookie (secure)
      res.cookie("refreshToken", result.tokens.refreshToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 30 * 24 * 60 * 60 * 1000,
      });

      // Set access token as regular cookie (accessible to JavaScript)
      res.cookie("token", result.tokens.accessToken, {
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 24 * 60 * 60 * 1000,
      }); // 1 day

      // Set user ID as regular cookie for convenience
      if (result.user && result.user.id) {
        res.cookie("userId", result.user.id, {
          secure: process.env.NODE_ENV === "production",
          sameSite: "lax",
          maxAge: 24 * 60 * 60 * 1000,
        }); // 1 day
      }
    }
    const response: ApiResponse = {
      success: true,
      message: "OTP verified successfully",
      data: result,
    };
    res.json(response);
  });

  sendPasswordResetOtp = asyncHandler(async (req: Request, res: Response) => {
    const { email } = req.body;
    await service.sendOtp(email, "PASSWORD_RESET");
    const response: ApiResponse = {
      success: true,
      message: "Password reset OTP sent",
    };
    res.json(response);
  });

  confirmPasswordResetOtp = asyncHandler(
    async (req: Request, res: Response) => {
      const { email, code, newPassword } = req.body;
      const result = await service.verifyOtp(email, code, "PASSWORD_RESET");
      if (result) {
        // Reuse authService.resetPassword shape by delegating to it with tokenless path would require refactor;
        // directly update via service would be better, but keep it simple here by calling a small helper
        const responseFromReset = await service.resetPasswordWithNewPassword(
          email,
          newPassword
        );
        const response: ApiResponse = {
          success: true,
          message: responseFromReset.message,
        };
        return res.json(response);
      }
      return res
        .status(400)
        .json({ success: false, message: "Password reset failed" });
    }
  );

  // ===== Profile =====
  getProfile = asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.id;
    const user = await service.getUserProfile(userId);
    const response: ApiResponse = {
      success: true,
      message: "Profile retrieved successfully",
      data: { user },
    };
    res.json(response);
  });

  // Rich /me summary
  getMe = asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.id;
    const { user, wallet, chapter } = await service.getMe(userId);
    const response: ApiResponse = {
      success: true,
      message: "Profile summary",
      data: { user, wallet, chapter },
    };
    res.json(response);
  });

  updateProfile = asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.id;
    const user = await service.updateUserProfile(userId, req.body);
    const response: ApiResponse = {
      success: true,
      message: "Profile updated successfully",
      data: { user },
    };
    res.json(response);
  });

  changePassword = asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.id;
    const { currentPassword, newPassword } = req.body;
    await service.changePassword(userId, currentPassword, newPassword);
    const response: ApiResponse = {
      success: true,
      message: "Password changed successfully",
    };
    res.json(response);
  });

  deleteAccount = asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.id;
    const { password } = req.body;
    await service.deleteAccount(userId, password);
    const response: ApiResponse = {
      success: true,
      message: "Account deleted successfully",
    };
    res.json(response);
  });

  // ===== Admin (Superadmin-only where specified) =====
  inviteAdmin = asyncHandler(async (req: Request, res: Response) => {
    const inviterId = req.user!.id;
    const result = await service.inviteAdmin(inviterId, req.body);
    const response: ApiResponse = {
      success: true,
      message: result.message,
      data: { invitationId: result.invitationId },
    };
    res.status(201).json(response);
  });

  acceptInvitation = asyncHandler(async (req: Request, res: Response) => {
    const result = await service.acceptInvitation(req.body);
    const response: ApiResponse = {
      success: true,
      message: result.message,
      data: { user: result.user },
    };
    res.status(201).json(response);
  });

  getInvitations = asyncHandler(async (req: Request, res: Response) => {
    const adminId = req.user!.id;
    const invitations = await service.getAdminInvitations(adminId);
    const response: ApiResponse = {
      success: true,
      message: "Invitations retrieved successfully",
      data: { invitations },
    };
    res.json(response);
  });

  revokeInvitation = asyncHandler(async (req: Request, res: Response) => {
    const adminId = req.user!.id;
    const { invitationId } = req.params;
    if (!invitationId) {
      res
        .status(400)
        .json({ success: false, message: "invitationId is required" });
      return;
    }
    const result = await service.revokeInvitation(
      adminId,
      invitationId as string
    );
    const response: ApiResponse = { success: true, message: result.message };
    res.json(response);
  });

  getAdmins = asyncHandler(async (req: Request, res: Response) => {
    const superAdminId = req.user!.id;
    const admins = await service.getAdmins(superAdminId);
    const response: ApiResponse = {
      success: true,
      message: "Admins retrieved successfully",
      data: { admins },
    };
    res.json(response);
  });

  updateAdminSections = asyncHandler(async (req: Request, res: Response) => {
    const superAdminId = req.user!.id;
    const { adminId } = req.params;
    const { sections } = req.body;
    if (!adminId) {
      res.status(400).json({ success: false, message: "adminId is required" });
      return;
    }
    const result = await service.updateAdminSections(
      superAdminId,
      adminId as string,
      sections
    );
    const response: ApiResponse = { success: true, message: result.message };
    res.json(response);
  });

  updateAdminDivision = asyncHandler(async (req: Request, res: Response) => {
    const superAdminId = req.user!.id;
    const { adminId } = req.params;
    if (!adminId) {
      res.status(400).json({ success: false, message: "adminId is required" });
      return;
    }
    const { division, functions } = req.body;
    const result = await service.updateAdminDivision(
      superAdminId,
      adminId as string,
      division ?? null,
      functions ?? null
    );
    const response: ApiResponse = { success: true, message: result.message };
    res.json(response);
  });

  changeAdminPassword = asyncHandler(async (req: Request, res: Response) => {
    const superAdminId = req.user!.id;
    const { adminId } = req.params;
    const { newPassword } = req.body;
    if (!adminId) {
      res.status(400).json({ success: false, message: "adminId is required" });
      return;
    }
    const result = await service.changeAdminPassword(
      superAdminId,
      adminId as string,
      newPassword
    );
    const response: ApiResponse = { success: true, message: result.message };
    res.json(response);
  });

  deactivateAdmin = asyncHandler(async (req: Request, res: Response) => {
    const superAdminId = req.user!.id;
    const { adminId } = req.params;
    if (!adminId) {
      res.status(400).json({ success: false, message: "adminId is required" });
      return;
    }
    const result = await service.deactivateAdmin(
      superAdminId,
      adminId as string
    );
    const response: ApiResponse = { success: true, message: result.message };
    res.json(response);
  });

  reactivateAdmin = asyncHandler(async (req: Request, res: Response) => {
    const superAdminId = req.user!.id;
    const { adminId } = req.params;
    if (!adminId) {
      res.status(400).json({ success: false, message: "adminId is required" });
      return;
    }
    const result = await service.reactivateAdmin(
      superAdminId,
      adminId as string
    );
    const response: ApiResponse = { success: true, message: result.message };
    res.json(response);
  });

  getAdminDashboard = asyncHandler(async (req: Request, res: Response) => {
    const adminId = req.user!.id;
    const role = req.user!.role;
    const dashboardData = await service.getAdminDashboard(adminId, role);
    const response: ApiResponse = {
      success: true,
      message: "Dashboard data retrieved successfully",
      data: dashboardData,
    };
    res.json(response);
  });

  getAdminStats = asyncHandler(async (req: Request, res: Response) => {
    const adminId = req.user!.id;
    const role = req.user!.role;
    const stats = await service.getAdminStats(adminId, role);
    const response: ApiResponse = {
      success: true,
      message: "Admin statistics retrieved successfully",
      data: { stats },
    };
    res.json(response);
  });
}

export const unifiedAuthController = new UnifiedAuthController();
