import { Router } from 'express';
import { unifiedAuthController as authController } from '../AuthController';
import { sendOtpSchema, verifyOtpSchema } from '../validation/otpValidation';
import { otpSendLimiter, otpVerifyLimiter } from '@/shared/middleware/rateLimiter';
import {
  verifyToken,
  requireVerification,
  requireRole
} from '@/shared/middleware/auth';
import { validateRequest } from '@/shared/utils/validation';
import { authLimiter, emailLimiter } from '@/shared/middleware/rateLimiter';
import {
  registerSchema,
  loginSchema,
  emailVerificationSchema,
  passwordResetRequestSchema,
  passwordResetConfirmSchema,
  refreshTokenSchema,
  resendVerificationSchema,
  adminInviteSchema,
  acceptInvitationSchema,
  updateAdminSectionsSchema,
  changeAdminPasswordSchema,
  adminIdParamSchema,
  invitationIdParamSchema,
  deleteAccountSchema
} from '../validation/authValidation';
import { sendPasswordResetOtpSchema, confirmPasswordResetOtpSchema } from '../validation/passwordResetOtpValidation';
import { updateAdminDivisionSchema } from '../validation/adminDivisionValidation';
import { signupFlowSchema } from '../validation/signupFlowValidation';

const router = Router();

// Public authentication routes
router.post('/register', 
  authLimiter,
  validateRequest(registerSchema),
  authController.register
);

// New comprehensive signup flow endpoint
router.post('/signup-flow',
  // authLimiter, // Temporarily disabled for development
  validateRequest(signupFlowSchema),
  authController.signupFlow
);

router.post('/login', 
  authLimiter,
  validateRequest(loginSchema),
  authController.login
);

import { verifyRefreshCsrf } from '@/shared/middleware/csrf';

router.post('/refresh-token', 
  verifyRefreshCsrf,
  validateRequest(refreshTokenSchema),
  authController.refreshToken
);

router.post('/verify-email', 
  validateRequest(emailVerificationSchema),
  authController.verifyEmail
);

// Email token reset flow (existing)
router.post('/request-password-reset', 
  authLimiter,
  validateRequest(passwordResetRequestSchema),
  authController.requestPasswordReset
);

router.post('/reset-password', 
  authLimiter,
  validateRequest(passwordResetConfirmSchema),
  authController.resetPassword
);

// OTP-based password reset flow
router.post('/password-reset/send-otp', otpSendLimiter, validateRequest(sendPasswordResetOtpSchema), authController.sendPasswordResetOtp);
router.post('/password-reset/confirm-otp', otpVerifyLimiter, validateRequest(confirmPasswordResetOtpSchema), authController.confirmPasswordResetOtp);

router.post('/resend-verification', 
  emailLimiter,
  validateRequest(resendVerificationSchema),
  authController.resendVerificationEmail
);

// OTP endpoints
router.post('/otp/send-login', /* otpSendLimiter, */ validateRequest(sendOtpSchema), authController.sendLoginOtp);
router.post('/otp/send-verify-email', /* otpSendLimiter, */ validateRequest(sendOtpSchema), authController.sendEmailVerificationOtp);
router.post('/otp/verify', /* otpVerifyLimiter, */ validateRequest(verifyOtpSchema), authController.verifyOtp);

// Admin invitation acceptance (public)
router.post('/admin/accept-invitation',
  validateRequest(acceptInvitationSchema),
  authController.acceptInvitation
);

// Protected routes (require authentication)
router.use(verifyToken);

router.post('/logout', authController.logout);

router.get('/profile', authController.getProfile);

// Me summary via unified controller
router.get('/me', verifyToken, authController.getMe);

router.put('/profile', 
  requireVerification,
  authController.updateProfile
);

router.post('/change-password', 
  requireVerification,
  authController.changePassword
);

router.delete('/account', 
  requireVerification,
  validateRequest(deleteAccountSchema),
  authController.deleteAccount
);

// Admin routes (require admin role)
router.get('/admin/dashboard',
  requireRole('ADMIN', 'SUPER_ADMIN'),
  authController.getAdminDashboard
);

router.get('/admin/stats',
  requireRole('ADMIN', 'SUPER_ADMIN'),
  authController.getAdminStats
);

// Super admin only routes
router.post('/admin/invite',
  requireRole('SUPER_ADMIN'),
  validateRequest(adminInviteSchema),
  authController.inviteAdmin
);

router.get('/admin/invitations',
  requireRole('SUPER_ADMIN'),
  authController.getInvitations
);

router.delete('/admin/invitations/:invitationId',
  requireRole('SUPER_ADMIN'),
  validateRequest(invitationIdParamSchema),
  authController.revokeInvitation
);

router.get('/admin/list',
  requireRole('SUPER_ADMIN'),
  authController.getAdmins
);

router.put('/admin/:adminId/sections',
  requireRole('SUPER_ADMIN'),
  validateRequest(updateAdminSectionsSchema),
  authController.updateAdminSections
);

// Assign division/functions for admin user
router.put('/admin/:adminId/division',
  requireRole('SUPER_ADMIN'),
  validateRequest(updateAdminDivisionSchema),
  authController.updateAdminDivision
);

router.put('/admin/:adminId/password',
  requireRole('SUPER_ADMIN'),
  validateRequest(changeAdminPasswordSchema),
  authController.changeAdminPassword
);

router.put('/admin/:adminId/deactivate',
  requireRole('SUPER_ADMIN'),
  validateRequest(adminIdParamSchema),
  authController.deactivateAdmin
);

router.put('/admin/:adminId/reactivate',
  requireRole('SUPER_ADMIN'),
  validateRequest(adminIdParamSchema),
  authController.reactivateAdmin
);

export default router;
