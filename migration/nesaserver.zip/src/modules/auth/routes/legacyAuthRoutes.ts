import { Router } from 'express';
import { authLimiter, emailLimiter } from '@/shared/middleware/rateLimiter';
import { validateRequest } from '@/shared/utils/validation';
import { loginSchema, emailVerificationSchema, refreshTokenSchema, resendVerificationSchema } from '../validation/authValidation';
import { signupFlowSchema } from '../validation/signupFlowValidation';
import { unifiedAuthController as authController } from '../AuthController';

// Legacy compatibility routes for older frontend paths (/api/auths/*)
const legacyRouter = Router();

legacyRouter.post('/signup', authLimiter, validateRequest(signupFlowSchema), authController.signupFlow);
legacyRouter.post('/login', authLimiter, validateRequest(loginSchema), authController.login);
legacyRouter.post('/refresh-token', validateRequest(refreshTokenSchema), authController.refreshToken);
legacyRouter.post('/verify-email', validateRequest(emailVerificationSchema), authController.verifyEmail);
legacyRouter.post('/resend-verification', emailLimiter, validateRequest(resendVerificationSchema), authController.resendVerificationEmail);

// OTP compatibility
import { sendOtpSchema, verifyOtpSchema } from '../validation/otpValidation';
import { otpSendLimiter, otpVerifyLimiter } from '@/shared/middleware/rateLimiter';

legacyRouter.post('/send-otp', otpSendLimiter, validateRequest(sendOtpSchema), authController.sendLoginOtp);
legacyRouter.post('/verify-otp', otpVerifyLimiter, validateRequest(verifyOtpSchema), authController.verifyOtp);

export default legacyRouter;