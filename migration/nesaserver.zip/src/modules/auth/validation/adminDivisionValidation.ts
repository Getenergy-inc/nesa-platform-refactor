import { z } from 'zod';

export const updateAdminDivisionSchema = z.object({
  params: z.object({
    adminId: z.string().cuid('Invalid admin ID')
  }),
  body: z.object({
    division: z.string().nullable().optional(),
    functions: z.array(z.string()).nullable().optional()
  })
});