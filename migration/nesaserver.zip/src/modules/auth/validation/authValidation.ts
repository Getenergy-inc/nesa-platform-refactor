import { z } from 'zod';
import { 
  emailSchema, 
  passwordSchema, 
  nameSchema, 
  accountTypeSchema, 
  userIntentSchema,
  countrySchema 
} from '@/shared/utils/validation';

// Registration validation
export const registerSchema = z.object({
  body: z.object({
    email: emailSchema,
    password: passwordSchema,
    firstName: nameSchema.optional(),
    lastName: nameSchema.optional(),
    accountType: accountTypeSchema.optional(),
    intents: z.array(userIntentSchema).optional(),
    country: countrySchema.optional(),
    organizationName: z.string().min(2).max(200).optional(),
    terms: z.boolean().refine(val => val === true, {
      message: 'You must accept the terms and conditions'
    }),
    privacy: z.boolean().refine(val => val === true, {
      message: 'You must accept the privacy policy'
    })
  })
});

// Login validation
export const loginSchema = z.object({
  body: z.object({
    email: emailSchema,
    password: z.string().min(1, 'Password is required')
  })
});

// Email verification validation
export const emailVerificationSchema = z.object({
  body: z.object({
    token: z.string().min(1, 'Verification token is required')
  })
});

// Password reset request validation
export const passwordResetRequestSchema = z.object({
  body: z.object({
    email: emailSchema
  })
});

// Password reset confirm validation
export const passwordResetConfirmSchema = z.object({
  body: z.object({
    token: z.string().min(1, 'Reset token is required'),
    newPassword: passwordSchema
  })
});

// Refresh token validation (optional body, we prefer cookie)
export const refreshTokenSchema = z.object({
  body: z.object({
    refreshToken: z.string().optional()
  })
});

// Resend verification email validation
export const resendVerificationSchema = z.object({
  body: z.object({
    email: emailSchema
  })
});

// Admin invitation validation
export const adminInviteSchema = z.object({
  body: z.object({
    email: emailSchema,
    sections: z.array(z.enum([
      'USER_MANAGEMENT',
      'NRC_VOLUNTEERS',
      'NOMINATIONS',
      'JUDGES',
      'VOTING_SYSTEM',
      'WALLET_MANAGEMENT',
      'CHAPTER_MANAGEMENT',
      'FILE_MANAGEMENT',
      'NOTIFICATIONS',
      'ANALYTICS',
      'SYSTEM_SETTINGS',
      'ALL_SECTIONS'
    ])).min(1, 'At least one section must be selected'),
    permissions: z.array(z.enum([
      'READ',
      'WRITE',
      'DELETE',
      'MANAGE_USERS',
      'MANAGE_PERMISSIONS',
      'VIEW_ANALYTICS',
      'SYSTEM_CONFIG',
      'FULL_ACCESS'
    ])).min(1, 'At least one permission must be selected'),
    message: z.string().max(500).optional(),
    // Optional assignment of division/functions at invite time
    division: z.string().optional(),
    functions: z.array(z.string()).optional()
  })
});

// Accept admin invitation validation
export const acceptInvitationSchema = z.object({
  body: z.object({
    token: z.string().min(1, 'Invitation token is required'),
    password: passwordSchema,
    firstName: nameSchema,
    lastName: nameSchema
  })
});

// Update admin sections validation
export const updateAdminSectionsSchema = z.object({
  body: z.object({
    sections: z.array(z.object({
      section: z.enum([
        'USER_MANAGEMENT',
        'NRC_VOLUNTEERS',
        'NOMINATIONS',
        'JUDGES',
        'VOTING_SYSTEM',
        'WALLET_MANAGEMENT',
        'CHAPTER_MANAGEMENT',
        'FILE_MANAGEMENT',
        'NOTIFICATIONS',
        'ANALYTICS',
        'SYSTEM_SETTINGS',
        'ALL_SECTIONS'
      ]),
      permissions: z.array(z.enum([
        'READ',
        'WRITE',
        'DELETE',
        'MANAGE_USERS',
        'MANAGE_PERMISSIONS',
        'VIEW_ANALYTICS',
        'SYSTEM_CONFIG',
        'FULL_ACCESS'
      ])).min(1)
    })).min(1, 'At least one section must be provided')
  }),
  params: z.object({
    adminId: z.string().cuid('Invalid admin ID')
  })
});

// Change admin password validation
export const changeAdminPasswordSchema = z.object({
  body: z.object({
    newPassword: passwordSchema
  }),
  params: z.object({
    adminId: z.string().cuid('Invalid admin ID')
  })
});

// Admin ID param validation
export const adminIdParamSchema = z.object({
  params: z.object({
    adminId: z.string().cuid('Invalid admin ID')
  })
});

// Invitation ID param validation
export const invitationIdParamSchema = z.object({
  params: z.object({
    invitationId: z.string().cuid('Invalid invitation ID')
  })
});

// Delete account validation
export const deleteAccountSchema = z.object({
  body: z.object({
    password: z.string().min(1, 'Password is required')
  })
});
