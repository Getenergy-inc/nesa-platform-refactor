import { z } from 'zod';

// Permissive schema for comprehensive signup flow
// Validates core required fields; other fields are optional and forwarded
export const signupFlowSchema = z.object({
  body: z.object({
    email: z.string().email('Invalid email'),
    password: z.string().min(8, 'Password must be at least 8 characters'),

    // Minimum to assign chapter
    country: z.string().min(2, 'Country is required'),
    state: z.string().min(1, 'State/Region is required'),

    // Frontend label variants; mapping occurs in service
    accountType: z.string().optional(),
    intents: z.array(z.string()).optional(),

    // Individual fields
    firstName: z.string().optional(),
    lastName: z.string().optional(),
    fullName: z.string().optional(),
    phoneNumber: z.string().optional(),
    gender: z.union([
      z.literal('MALE'), z.literal('FEMALE'), z.literal('OTHER'), z.literal('PREFER_NOT_TO_SAY')
    ]).optional(),
    dateOfBirth: z.string().optional(),

    // Organization fields
    organizationName: z.string().optional(),
    organizationType: z.string().optional(),
    registrationNumber: z.string().optional(),
    contactPersonName: z.string().optional(),
    contactEmail: z.string().email().optional(),
    contactPhone: z.string().optional(),

    // Optional extras for role selection
    division: z.string().optional(),
    functions: z.array(z.string()).optional(),
    referralCode: z.string().optional(),
  })
});