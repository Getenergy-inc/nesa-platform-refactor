import { z } from 'zod';
import { emailSchema, passwordSchema } from '@/shared/utils/validation';

export const sendPasswordResetOtpSchema = z.object({
  body: z.object({
    email: emailSchema
  })
});

export const confirmPasswordResetOtpSchema = z.object({
  body: z.object({
    email: emailSchema,
    code: z.string().min(4).max(10),
    newPassword: passwordSchema
  })
});