import { z } from 'zod';

export const sendOtpSchema = z.object({
  body: z.object({
    email: z.string().email('Invalid email')
  })
});

export const verifyOtpSchema = z.object({
  body: z.object({
    email: z.string().email('Invalid email'),
    code: z.string().min(4).max(10),
    purpose: z.enum(['LOGIN', 'VERIFY_EMAIL', 'PASSWORD_RESET']).optional()
  })
});