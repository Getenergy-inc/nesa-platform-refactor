# Authentication & User Management Module

This module provides comprehensive authentication and user management functionality for the NESA-Africa platform, including admin management with section-based access control.

## 🔐 Features

### Core Authentication
- **User Registration** with email verification
- **User Login** with JWT token generation
- **Password Reset** via email
- **Email Verification** system
- **Token Refresh** mechanism
- **Account Management** (profile updates, password changes)

### Admin Management System
- **Super Admin** creation via database seeding
- **Admin Invitation** system (admins cannot self-register)
- **Section-based Access Control** (admins only access assigned sections)
- **Permission Management** with granular controls
- **Admin Dashboard** with role-specific data

### Security Features
- **Password Hashing** with bcrypt (12 rounds)
- **Rate Limiting** on authentication endpoints
- **Account Locking** after failed login attempts
- **JWT Token Management** with refresh tokens
- **Email Verification** required before account activation

## 📁 Module Structure

```
src/modules/auth/
├── controllers/
│   ├── authController.ts      # Authentication endpoints
│   └── adminController.ts     # Admin management endpoints
├── services/
│   ├── authService.ts         # Core authentication logic
│   └── adminService.ts        # Admin management logic
├── routes/
│   └── authRoutes.ts          # Route definitions
├── validation/
│   └── authValidation.ts      # Request validation schemas
├── auth.test.ts               # Module tests
└── README.md                  # This file
```

## 🛠️ Setup

### 1. Environment Variables

Add to your `.env` file:

```env
# Super Admin Configuration
SUPER_ADMIN_EMAIL=admin@nesa-africa.com
SUPER_ADMIN_PASSWORD=SuperAdmin123!
SUPER_ADMIN_FIRST_NAME=Super
SUPER_ADMIN_LAST_NAME=Admin

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key
JWT_EXPIRES_IN=7d
JWT_REFRESH_SECRET=your-refresh-secret
JWT_REFRESH_EXPIRES_IN=30d

# Email Configuration (SendGrid)
SENDGRID_API_KEY=your-sendgrid-api-key
FROM_EMAIL=noreply@nesa-africa.com
FROM_NAME="NESA-Africa Platform"
```

### 2. Database Setup

Run Prisma migrations:
```bash
npx prisma migrate dev
npx prisma generate
```

### 3. Create Super Admin

Run the seeding script:
```bash
npm run seed
```

## 🔗 API Endpoints

### Public Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/auth/register` | User registration |
| POST | `/api/v1/auth/login` | User login |
| POST | `/api/v1/auth/verify-email` | Email verification |
| POST | `/api/v1/auth/request-password-reset` | Request password reset |
| POST | `/api/v1/auth/reset-password` | Reset password |
| POST | `/api/v1/auth/refresh-token` | Refresh access token |
| POST | `/api/v1/auth/admin/accept-invitation` | Accept admin invitation |

### Protected Endpoints (Require Authentication)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/auth/logout` | User logout |
| GET | `/api/v1/auth/profile` | Get user profile |
| PUT | `/api/v1/auth/profile` | Update user profile |
| POST | `/api/v1/auth/change-password` | Change password |
| DELETE | `/api/v1/auth/account` | Delete account |

### Admin Endpoints (Require Admin Role)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/auth/admin/dashboard` | Admin dashboard |
| GET | `/api/v1/auth/admin/stats` | Admin statistics |

### Super Admin Endpoints (Require Super Admin Role)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/auth/admin/invite` | Invite new admin |
| GET | `/api/v1/auth/admin/invitations` | List invitations |
| DELETE | `/api/v1/auth/admin/invitations/:id` | Revoke invitation |
| GET | `/api/v1/auth/admin/list` | List all admins |
| PUT | `/api/v1/auth/admin/:id/sections` | Update admin sections |
| PUT | `/api/v1/auth/admin/:id/password` | Change admin password |
| PUT | `/api/v1/auth/admin/:id/deactivate` | Deactivate admin |
| PUT | `/api/v1/auth/admin/:id/reactivate` | Reactivate admin |

## 🏗️ Admin System Architecture

### User Roles Hierarchy
1. **Super Admin** - Full system access, can manage other admins
2. **Admin** - Section-specific access based on assignments
3. **Regular Users** - Standard platform users

### Platform Sections
- `USER_MANAGEMENT` - User accounts and profiles
- `NRC_VOLUNTEERS` - NRC volunteer system
- `NOMINATIONS` - Nomination management
- `JUDGES` - Judge applications and management
- `VOTING_SYSTEM` - Voting and results
- `WALLET_MANAGEMENT` - AGC wallet system
- `CHAPTER_MANAGEMENT` - Local chapters
- `FILE_MANAGEMENT` - File uploads and storage
- `NOTIFICATIONS` - Email and notifications
- `ANALYTICS` - Platform analytics
- `SYSTEM_SETTINGS` - System configuration
- `ALL_SECTIONS` - Access to all sections

### Admin Permissions
- `READ` - View data
- `WRITE` - Create and update data
- `DELETE` - Delete data
- `MANAGE_USERS` - User management operations
- `MANAGE_PERMISSIONS` - Permission management
- `VIEW_ANALYTICS` - Access to analytics
- `SYSTEM_CONFIG` - System configuration
- `FULL_ACCESS` - All permissions

## 🔒 Security Features

### Password Security
- Minimum 8 characters required
- Bcrypt hashing with 12 salt rounds
- Password reset tokens expire in 1 hour

### Account Security
- Email verification required
- Account locking after 5 failed login attempts
- 2-hour lockout period
- JWT tokens with configurable expiration

### Rate Limiting
- Authentication endpoints: 5 requests per 15 minutes
- Email endpoints: 20 requests per hour
- General API: 100 requests per 15 minutes

## 📧 Email Templates

The module includes responsive HTML email templates for:
- **Email Verification** - Welcome and verification link
- **Password Reset** - Secure reset instructions
- **Admin Invitation** - Professional invitation with section details
- **Welcome Email** - Post-verification welcome message

## 🧪 Testing

Run the authentication tests:
```bash
npm test -- auth.test.ts
```

## 🔄 Integration with Frontend

Replace the existing `mockSignupService` and other mock authentication services with real API calls to these endpoints. The module provides:

1. **JWT Token Management** - Access and refresh tokens
2. **Role-based Access Control** - Frontend route protection
3. **Email Verification Flow** - Complete verification process
4. **Admin Dashboard Data** - Section-specific admin interfaces

## 📝 Usage Examples

### User Registration
```typescript
const response = await fetch('/api/v1/auth/register', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: 'user@example.com',
    password: 'SecurePassword123!',
    firstName: 'John',
    lastName: 'Doe',
    terms: true,
    privacy: true
  })
});
```

### Admin Invitation
```typescript
const response = await fetch('/api/v1/auth/admin/invite', {
  method: 'POST',
  headers: { 
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${superAdminToken}`
  },
  body: JSON.stringify({
    email: 'admin@example.com',
    sections: ['USER_MANAGEMENT', 'NOMINATIONS'],
    permissions: ['READ', 'WRITE', 'MANAGE_USERS'],
    message: 'Welcome to the admin team!'
  })
});
```

## 🚀 Next Steps

1. **Database Migration** - Run migrations to create the new tables
2. **Super Admin Setup** - Run seeding script to create initial super admin
3. **Frontend Integration** - Replace mock services with real API calls
4. **Email Configuration** - Set up SendGrid for email delivery
5. **Testing** - Comprehensive testing of all authentication flows
