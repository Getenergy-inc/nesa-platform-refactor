/**
 * Unit tests for auth utility functions
 */

import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

describe('Auth Utility Functions', () => {
  describe('Intent Mapping', () => {
    let intentMapping: any;

    beforeAll(async () => {
      intentMapping = await import('../utils/intentMapping');
    });

    describe('mapIntent', () => {
      it('should map valid intent labels to enum values', () => {
        const testCases = [
          { input: 'vote or nominate', expected: 'VOTE_OR_NOMINATE' },
          { input: 'become ambassador', expected: 'BECOME_AMBASSADOR' },
          { input: 'apply as judge', expected: 'APPLY_AS_JUDGE' },
          { input: 'apply as nrc volunteer', expected: 'APPLY_AS_NRC_VOLUNTEER' },
          { input: 'join nesa team', expected: 'JOIN_NESA_TEAM' },
          { input: 'sponsor or csr partner', expected: 'SPONSOR_OR_CSR_PARTNER' },
          { input: 'become chapter lead', expected: 'BECOME_CHAPTER_LEAD' },
          { input: 'become regional coordinator', expected: 'BECOME_REGIONAL_COORDINATOR' },
        ];

        testCases.forEach(({ input, expected }) => {
          expect(intentMapping.mapIntent(input)).toBe(expected);
        });
      });

      it('should return null for invalid intent labels', () => {
        const invalidIntents = [
          'invalid intent',
          'random text',
          '',
          null,
          undefined,
        ];

        invalidIntents.forEach(intent => {
          expect(intentMapping.mapIntent(intent)).toBeNull();
        });
      });

      it('should be case insensitive', () => {
        expect(intentMapping.mapIntent('VOTE OR NOMINATE')).toBe('VOTE_OR_NOMINATE');
        expect(intentMapping.mapIntent('Vote Or Nominate')).toBe('VOTE_OR_NOMINATE');
        expect(intentMapping.mapIntent('vote OR nominate')).toBe('VOTE_OR_NOMINATE');
      });
    });

    describe('mapIntents', () => {
      it('should map array of valid intents', () => {
        const input = ['vote or nominate', 'become ambassador'];
        const expected = ['VOTE_OR_NOMINATE', 'BECOME_AMBASSADOR'];
        
        expect(intentMapping.mapIntents(input)).toEqual(expected);
      });

      it('should filter out invalid intents', () => {
        const input = ['vote or nominate', 'invalid intent', 'become ambassador'];
        const expected = ['VOTE_OR_NOMINATE', 'BECOME_AMBASSADOR'];
        
        expect(intentMapping.mapIntents(input)).toEqual(expected);
      });

      it('should handle empty array', () => {
        expect(intentMapping.mapIntents([])).toEqual([]);
      });

      it('should handle array with all invalid intents', () => {
        const input = ['invalid intent', 'another invalid'];
        expect(intentMapping.mapIntents(input)).toEqual([]);
      });

      it('should remove duplicates', () => {
        const input = ['vote or nominate', 'vote or nominate', 'become ambassador'];
        const expected = ['VOTE_OR_NOMINATE', 'BECOME_AMBASSADOR'];
        
        expect(intentMapping.mapIntents(input)).toEqual(expected);
      });
    });

    describe('mapAccountType', () => {
      it('should map valid account type labels', () => {
        const testCases = [
          { input: 'individual', expected: 'INDIVIDUAL' },
          { input: 'corporation', expected: 'CORPORATION' },
          { input: 'ngo', expected: 'NGO' },
          { input: 'government', expected: 'GOVERNMENT' },
          { input: 'educational institution', expected: 'EDUCATIONAL_INSTITUTION' },
        ];

        testCases.forEach(({ input, expected }) => {
          expect(intentMapping.mapAccountType(input)).toBe(expected);
        });
      });

      it('should return undefined for invalid account types', () => {
        const invalidTypes = ['invalid', 'random', '', null, undefined];
        
        invalidTypes.forEach(type => {
          expect(intentMapping.mapAccountType(type)).toBeUndefined();
        });
      });

      it('should be case insensitive', () => {
        expect(intentMapping.mapAccountType('INDIVIDUAL')).toBe('INDIVIDUAL');
        expect(intentMapping.mapAccountType('Individual')).toBe('INDIVIDUAL');
        expect(intentMapping.mapAccountType('CORPORATION')).toBe('CORPORATION');
      });
    });

    describe('mapGender', () => {
      it('should map valid gender labels', () => {
        const testCases = [
          { input: 'male', expected: 'MALE' },
          { input: 'female', expected: 'FEMALE' },
          { input: 'other', expected: 'OTHER' },
          { input: 'prefer not to say', expected: 'PREFER_NOT_TO_SAY' },
        ];

        testCases.forEach(({ input, expected }) => {
          expect(intentMapping.mapGender(input)).toBe(expected);
        });
      });

      it('should return undefined for invalid gender values', () => {
        const invalidGenders = ['invalid', 'unknown', '', null, undefined];
        
        invalidGenders.forEach(gender => {
          expect(intentMapping.mapGender(gender)).toBeUndefined();
        });
      });

      it('should be case insensitive', () => {
        expect(intentMapping.mapGender('MALE')).toBe('MALE');
        expect(intentMapping.mapGender('Male')).toBe('MALE');
        expect(intentMapping.mapGender('PREFER NOT TO SAY')).toBe('PREFER_NOT_TO_SAY');
      });
    });

    describe('mapDivision', () => {
      it('should map valid division labels', () => {
        const testCases = [
          { input: 'SOBCD', expected: 'SOBCD' },
          { input: 'sobcd', expected: 'SOBCD' },
          { input: 'OMBDD', expected: 'OMBDD' },
          { input: 'ombdd', expected: 'OMBDD' },
          { input: 'RESEARCH', expected: 'RESEARCH' },
          { input: 'research', expected: 'RESEARCH' },
        ];

        testCases.forEach(({ input, expected }) => {
          expect(intentMapping.mapDivision(input)).toBe(expected);
        });
      });

      it('should return undefined for invalid divisions', () => {
        const invalidDivisions = ['invalid', 'unknown', '', null, undefined];
        
        invalidDivisions.forEach(division => {
          expect(intentMapping.mapDivision(division)).toBeUndefined();
        });
      });
    });

    describe('inferRole', () => {
      it('should infer correct roles from intents', () => {
        const testCases = [
          { intents: ['BECOME_AMBASSADOR'], expected: 'AMBASSADOR' },
          { intents: ['APPLY_AS_JUDGE'], expected: 'JUDGE' },
          { intents: ['APPLY_AS_NRC_VOLUNTEER'], expected: 'NRC_VOLUNTEER' },
          { intents: ['JOIN_NESA_TEAM'], expected: 'VOLUNTEER' },
          { intents: ['SPONSOR_OR_CSR_PARTNER'], expected: 'SPONSOR' },
          { intents: ['BECOME_CHAPTER_LEAD'], expected: 'CHAPTER_LEAD' },
          { intents: ['BECOME_REGIONAL_COORDINATOR'], expected: 'REGIONAL_COORDINATOR' },
          { intents: ['VOTE_OR_NOMINATE'], expected: 'FREE_MEMBER' },
        ];

        testCases.forEach(({ intents, expected }) => {
          expect(intentMapping.inferRole(intents)).toBe(expected);
        });
      });

      it('should prioritize higher roles when multiple intents exist', () => {
        const testCases = [
          { 
            intents: ['VOTE_OR_NOMINATE', 'BECOME_AMBASSADOR'], 
            expected: 'AMBASSADOR' 
          },
          { 
            intents: ['JOIN_NESA_TEAM', 'APPLY_AS_JUDGE'], 
            expected: 'JUDGE' 
          },
          { 
            intents: ['VOTE_OR_NOMINATE', 'SPONSOR_OR_CSR_PARTNER'], 
            expected: 'SPONSOR' 
          },
        ];

        testCases.forEach(({ intents, expected }) => {
          expect(intentMapping.inferRole(intents)).toBe(expected);
        });
      });

      it('should return FREE_MEMBER for empty or invalid intents', () => {
        expect(intentMapping.inferRole([])).toBe('FREE_MEMBER');
        expect(intentMapping.inferRole(['INVALID_INTENT'])).toBe('FREE_MEMBER');
        expect(intentMapping.inferRole(null)).toBe('FREE_MEMBER');
        expect(intentMapping.inferRole(undefined)).toBe('FREE_MEMBER');
      });
    });

    describe('computeSignupBonus', () => {
      it('should calculate correct bonus for different account types and intents', () => {
        const testCases = [
          {
            accountType: 'INDIVIDUAL',
            intents: ['VOTE_OR_NOMINATE'],
            expected: { amount: 2, type: 'non-withdrawable' } // base 1 + individual 1
          },
          {
            accountType: 'INDIVIDUAL',
            intents: ['BECOME_AMBASSADOR'],
            expected: { amount: 5, type: 'withdrawable' } // base 1 + individual 1 + ambassador 3
          },
          {
            accountType: 'CORPORATION',
            intents: ['SPONSOR_OR_CSR_PARTNER'],
            expected: { amount: 6, type: 'withdrawable' } // base 1 + sponsor 5
          },
          {
            accountType: 'NGO',
            intents: ['APPLY_AS_JUDGE'],
            expected: { amount: 4, type: 'non-withdrawable' } // base 1 + ngo 1 + judge 2
          },
          {
            accountType: 'EDUCATIONAL_INSTITUTION',
            intents: ['JOIN_NESA_TEAM'],
            expected: { amount: 4, type: 'non-withdrawable' } // base 1 + edu 2 + volunteer 1
          },
        ];

        testCases.forEach(({ accountType, intents, expected }) => {
          const result = intentMapping.computeSignupBonus(accountType, intents);
          expect(result.amount).toBe(expected.amount);
          expect(result.type).toBe(expected.type);
        });
      });

      it('should handle multiple intents correctly', () => {
        const result = intentMapping.computeSignupBonus('INDIVIDUAL', [
          'VOTE_OR_NOMINATE',
          'BECOME_AMBASSADOR',
          'APPLY_AS_JUDGE'
        ]);

        // Should take the highest bonus intent (ambassador = 3)
        expect(result.amount).toBe(5); // base 1 + individual 1 + ambassador 3
        expect(result.type).toBe('withdrawable');
      });

      it('should return minimum bonus for invalid inputs', () => {
        const testCases = [
          { accountType: 'INVALID', intents: [] },
          { accountType: 'INDIVIDUAL', intents: ['INVALID_INTENT'] },
          { accountType: null, intents: null },
        ];

        testCases.forEach(({ accountType, intents }) => {
          const result = intentMapping.computeSignupBonus(accountType, intents);
          expect(result.amount).toBeGreaterThanOrEqual(1); // At least base bonus
          expect(['withdrawable', 'non-withdrawable']).toContain(result.type);
        });
      });
    });
  });

  describe('Password Utilities', () => {
    describe('Password Hashing', () => {
      it('should hash passwords securely', async () => {
        const password = 'TestPassword123!';
        const hashed = await bcrypt.hash(password, 12);

        expect(hashed).not.toBe(password);
        expect(hashed).toMatch(/^\$2[aby]\$12\$/); // bcrypt hash pattern with rounds=12
        expect(hashed.length).toBeGreaterThan(50); // bcrypt hashes are typically 60 chars
      });

      it('should verify correct passwords', async () => {
        const password = 'TestPassword123!';
        const hashed = await bcrypt.hash(password, 12);
        
        const isValid = await bcrypt.compare(password, hashed);
        expect(isValid).toBe(true);
      });

      it('should reject incorrect passwords', async () => {
        const password = 'TestPassword123!';
        const wrongPassword = 'WrongPassword123!';
        const hashed = await bcrypt.hash(password, 12);
        
        const isValid = await bcrypt.compare(wrongPassword, hashed);
        expect(isValid).toBe(false);
      });

      it('should produce different hashes for same password', async () => {
        const password = 'TestPassword123!';
        const hash1 = await bcrypt.hash(password, 12);
        const hash2 = await bcrypt.hash(password, 12);
        
        expect(hash1).not.toBe(hash2);
        
        // But both should verify correctly
        expect(await bcrypt.compare(password, hash1)).toBe(true);
        expect(await bcrypt.compare(password, hash2)).toBe(true);
      });
    });

    describe('Password Strength Validation', () => {
      const validatePasswordStrength = (password: string): boolean => {
        // Minimum 8 characters, at least one uppercase, one lowercase, one number
        const minLength = password.length >= 8;
        const hasUppercase = /[A-Z]/.test(password);
        const hasLowercase = /[a-z]/.test(password);
        const hasNumber = /\d/.test(password);
        
        return minLength && hasUppercase && hasLowercase && hasNumber;
      };

      it('should validate strong passwords', () => {
        const strongPasswords = [
          'ValidPassword123!',
          'AnotherGood1@',
          'Complex$Pass9',
          'MySecure123',
          'Test1234Pass',
        ];

        strongPasswords.forEach(password => {
          expect(validatePasswordStrength(password)).toBe(true);
        });
      });

      it('should reject weak passwords', () => {
        const weakPasswords = [
          '123', // too short
          'password', // no uppercase, no number
          'PASSWORD', // no lowercase, no number
          '12345678', // no letters
          'Password', // no number
          'password123', // no uppercase
          'PASSWORD123', // no lowercase
        ];

        weakPasswords.forEach(password => {
          expect(validatePasswordStrength(password)).toBe(false);
        });
      });
    });
  });

  describe('JWT Token Utilities', () => {
    const JWT_SECRET = process.env.JWT_SECRET || 'test-secret';
    const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'test-refresh-secret';

    describe('Token Generation', () => {
      it('should generate valid JWT tokens', () => {
        const payload = {
          userId: 'user-123',
          email: 'test@example.com',
          role: 'FREE_MEMBER',
        };

        const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '1h' });
        
        expect(token).toMatch(/^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+$/);
        
        const decoded = jwt.verify(token, JWT_SECRET) as any;
        expect(decoded.userId).toBe(payload.userId);
        expect(decoded.email).toBe(payload.email);
        expect(decoded.role).toBe(payload.role);
      });

      it('should generate refresh tokens', () => {
        const payload = {
          userId: 'user-123',
          tokenVersion: 1,
        };

        const refreshToken = jwt.sign(payload, JWT_REFRESH_SECRET, { expiresIn: '7d' });
        
        expect(refreshToken).toMatch(/^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+$/);
        
        const decoded = jwt.verify(refreshToken, JWT_REFRESH_SECRET) as any;
        expect(decoded.userId).toBe(payload.userId);
        expect(decoded.tokenVersion).toBe(payload.tokenVersion);
      });

      it('should include expiration in tokens', () => {
        const payload = { userId: 'user-123' };
        const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '1h' });
        
        const decoded = jwt.verify(token, JWT_SECRET) as any;
        expect(decoded.exp).toBeDefined();
        expect(decoded.iat).toBeDefined();
        expect(decoded.exp).toBeGreaterThan(decoded.iat);
      });
    });

    describe('Token Verification', () => {
      it('should verify valid tokens', () => {
        const payload = { userId: 'user-123', email: 'test@example.com' };
        const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '1h' });
        
        const decoded = jwt.verify(token, JWT_SECRET) as any;
        expect(decoded.userId).toBe(payload.userId);
        expect(decoded.email).toBe(payload.email);
      });

      it('should reject tokens with wrong secret', () => {
        const payload = { userId: 'user-123' };
        const token = jwt.sign(payload, 'wrong-secret', { expiresIn: '1h' });
        
        expect(() => {
          jwt.verify(token, JWT_SECRET);
        }).toThrow('invalid signature');
      });

      it('should reject expired tokens', () => {
        const payload = { userId: 'user-123' };
        const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '-1h' }); // expired
        
        expect(() => {
          jwt.verify(token, JWT_SECRET);
        }).toThrow('jwt expired');
      });

      it('should reject malformed tokens', () => {
        const malformedTokens = [
          'invalid-token',
          'not.a.valid.jwt.token.format',
          '',
          'header.payload', // missing signature
        ];

        malformedTokens.forEach(token => {
          expect(() => {
            jwt.verify(token, JWT_SECRET);
          }).toThrow();
        });
      });
    });

    describe('Token Payload Validation', () => {
      it('should handle different payload structures', () => {
        const payloads = [
          { userId: 'user-123' },
          { userId: 'user-123', email: 'test@example.com' },
          { userId: 'user-123', email: 'test@example.com', role: 'ADMIN' },
          { userId: 'user-123', permissions: ['READ', 'WRITE'] },
        ];

        payloads.forEach(payload => {
          const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '1h' });
          const decoded = jwt.verify(token, JWT_SECRET) as any;
          
          Object.keys(payload).forEach(key => {
            expect(decoded[key]).toEqual(payload[key as keyof typeof payload]);
          });
        });
      });

      it('should preserve data types in payload', () => {
        const payload = {
          userId: 'user-123',
          isVerified: true,
          loginCount: 5,
          permissions: ['READ', 'WRITE'],
          metadata: { lastLogin: '2023-01-01' },
        };

        const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '1h' });
        const decoded = jwt.verify(token, JWT_SECRET) as any;
        
        expect(typeof decoded.userId).toBe('string');
        expect(typeof decoded.isVerified).toBe('boolean');
        expect(typeof decoded.loginCount).toBe('number');
        expect(Array.isArray(decoded.permissions)).toBe(true);
        expect(typeof decoded.metadata).toBe('object');
      });
    });
  });

  describe('Validation Utilities', () => {
    describe('Email Validation', () => {
      const validateEmail = (email: string): boolean => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
      };

      it('should validate correct email formats', () => {
        const validEmails = [
          'test@example.com',
          'user.name@domain.co.uk',
          'user+tag@example.org',
          'firstname.lastname@company.com',
          'email@123.123.123.123', // IP address
          'user@domain-name.com',
          'user_name@domain.com',
        ];

        validEmails.forEach(email => {
          expect(validateEmail(email)).toBe(true);
        });
      });

      it('should reject invalid email formats', () => {
        const invalidEmails = [
          'invalid-email',
          '@example.com',
          'test@',
          'test.example.com',
          'test@.com',
          'test@com',
          'test..test@example.com',
          'test@example.',
          '',
          'test@',
          '@',
        ];

        invalidEmails.forEach(email => {
          expect(validateEmail(email)).toBe(false);
        });
      });
    });

    describe('OTP Code Validation', () => {
      const validateOtpCode = (code: string): boolean => {
        return /^\d{6}$/.test(code);
      };

      it('should validate correct OTP codes', () => {
        const validCodes = [
          '123456',
          '000000',
          '999999',
          '654321',
          '111111',
        ];

        validCodes.forEach(code => {
          expect(validateOtpCode(code)).toBe(true);
        });
      });

      it('should reject invalid OTP codes', () => {
        const invalidCodes = [
          '12345', // too short
          '1234567', // too long
          'abcdef', // not numeric
          '12345a', // mixed
          '', // empty
          '12 345', // with space
          '123-456', // with dash
        ];

        invalidCodes.forEach(code => {
          expect(validateOtpCode(code)).toBe(false);
        });
      });
    });

    describe('Phone Number Validation', () => {
      const validatePhoneNumber = (phone: string): boolean => {
        // Simple international phone number validation
        const phoneRegex = /^\+?[1-9]\d{1,14}$/;
        return phoneRegex.test(phone.replace(/[\s-()]/g, ''));
      };

      it('should validate correct phone numbers', () => {
        const validPhones = [
          '+1234567890',
          '+234 803 123 4567',
          '+44-20-7946-0958',
          '+33 1 42 86 83 26',
          '08031234567',
          '+2348031234567',
        ];

        validPhones.forEach(phone => {
          expect(validatePhoneNumber(phone)).toBe(true);
        });
      });

      it('should reject invalid phone numbers', () => {
        const invalidPhones = [
          '123', // too short
          '+0123456789', // starts with 0 after +
          'abcdefghij', // not numeric
          '', // empty
          '+', // just plus
          '++1234567890', // double plus
        ];

        invalidPhones.forEach(phone => {
          expect(validatePhoneNumber(phone)).toBe(false);
        });
      });
    });
  });

  describe('Data Sanitization', () => {
    describe('User Data Sanitization', () => {
      const sanitizeUserData = (user: any) => {
        const { password, emailVerificationToken, otpCode, ...safeUser } = user;
        return safeUser;
      };

      it('should remove sensitive fields from user data', () => {
        const userData = {
          id: 'user-123',
          email: 'test@example.com',
          firstName: 'John',
          lastName: 'Doe',
          password: 'hashed-password',
          emailVerificationToken: 'secret-token',
          otpCode: '123456',
          role: 'FREE_MEMBER',
        };

        const sanitized = sanitizeUserData(userData);

        expect(sanitized).toHaveProperty('id');
        expect(sanitized).toHaveProperty('email');
        expect(sanitized).toHaveProperty('firstName');
        expect(sanitized).toHaveProperty('lastName');
        expect(sanitized).toHaveProperty('role');
        
        expect(sanitized).not.toHaveProperty('password');
        expect(sanitized).not.toHaveProperty('emailVerificationToken');
        expect(sanitized).not.toHaveProperty('otpCode');
      });

      it('should preserve non-sensitive fields', () => {
        const userData = {
          id: 'user-123',
          email: 'test@example.com',
          firstName: 'John',
          lastName: 'Doe',
          role: 'FREE_MEMBER',
          isVerified: true,
          createdAt: new Date(),
          profilePicture: 'https://example.com/pic.jpg',
        };

        const sanitized = sanitizeUserData(userData);

        Object.keys(userData).forEach(key => {
          expect(sanitized).toHaveProperty(key);
        });
      });
    });
  });
});