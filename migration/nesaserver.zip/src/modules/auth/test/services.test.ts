import bcrypt from 'bcryptjs';
import { createMockUser, createMockSignupData, expectHashedPassword } from './testHelpers';

// Mock the database
const mockPrisma = {
  user: {
    findUnique: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
  },
  wallet: {
    create: jest.fn(),
  },
  adminInvitation: {
    findUnique: jest.fn(),
    create: jest.fn(),
  },
  chapter: {
    findFirst: jest.fn(),
    create: jest.fn(),
  },
  chapterMembership: {
    create: jest.fn(),
    findFirst: jest.fn(),
  },
  $transaction: jest.fn(),
};

const mockEmailService = {
  sendVerificationEmail: jest.fn(),
  sendOtpEmail: jest.fn(),
  sendAdminInvitation: jest.fn(),
};

// Mock modules
jest.mock('@/shared/database/postgresql', () => ({
  prisma: mockPrisma,
}));

jest.mock('@/modules/notifications/services/emailService', () => ({
  emailService: mockEmailService,
}));

jest.mock('@/modules/wallet/services/walletService', () => ({
  walletService: {
    createWallet: jest.fn().mockResolvedValue({
      id: 'wallet-id',
      userId: 'user-id',
      balance: 2,
      withdrawableBalance: 0,
    }),
  },
}));

jest.mock('@/modules/chapters/services/chapterService', () => ({
  chapterService: {
    assign: jest.fn().mockResolvedValue({
      id: 'chapter-membership-id',
      userId: 'user-id',
      chapterId: 'chapter-id',
    }),
  },
}));

describe('Auth Services Tests', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('SignupFlowService', () => {
    let signupFlowService: any;

    beforeAll(async () => {
      const module = await import('../services/signupFlowService');
      signupFlowService = module.signupFlowService;
    });

    describe('signup', () => {
      const baseSignupData = createMockSignupData();

      beforeEach(() => {
        mockPrisma.user.findUnique.mockResolvedValue(null);
        mockPrisma.user.create.mockResolvedValue(createMockUser());
        mockEmailService.sendVerificationEmail.mockResolvedValue(undefined);
      });

      it('should create user with valid data', async () => {
        const result = await signupFlowService.signup(baseSignupData);

        expect(result).toHaveProperty('user');
        expect(result).toHaveProperty('tokens');
        expect(mockPrisma.user.create).toHaveBeenCalled();
        expect(mockEmailService.sendVerificationEmail).toHaveBeenCalled();
      });

      it('should throw error for duplicate email', async () => {
        mockPrisma.user.findUnique.mockResolvedValue(createMockUser());

        await expect(signupFlowService.signup(baseSignupData))
          .rejects
          .toThrow('User with this email already exists');
      });

      it('should throw error for missing required fields', async () => {
        const invalidData = {
          email: 'test@example.com',
        };

        await expect(signupFlowService.signup(invalidData))
          .rejects
          .toThrow('Missing required fields');
      });

      it('should map account types correctly', async () => {
        const corporateData = {
          ...baseSignupData,
          accountType: 'corporation',
          organizationName: 'Test Corp',
        };

        await signupFlowService.signup(corporateData);

        expect(mockPrisma.user.create).toHaveBeenCalledWith({
          data: expect.objectContaining({
            accountType: 'CORPORATION',
            organizationName: 'Test Corp',
          }),
          select: expect.any(Object),
        });
      });

      it('should map intents correctly', async () => {
        const ambassadorData = {
          ...baseSignupData,
          intents: ['become ambassador'],
        };

        await signupFlowService.signup(ambassadorData);

        expect(mockPrisma.user.create).toHaveBeenCalledWith({
          data: expect.objectContaining({
            intents: ['BECOME_AMBASSADOR'],
            role: 'AMBASSADOR',
          }),
          select: expect.any(Object),
        });
      });

      it('should generate fullName from firstName and lastName', async () => {
        await signupFlowService.signup(baseSignupData);

        expect(mockPrisma.user.create).toHaveBeenCalledWith({
          data: expect.objectContaining({
            fullName: 'John Doe',
          }),
          select: expect.any(Object),
        });
      });

      it('should lowercase email', async () => {
        const upperCaseEmailData = {
          ...baseSignupData,
          email: 'TEST@EXAMPLE.COM',
        };

        await signupFlowService.signup(upperCaseEmailData);

        expect(mockPrisma.user.findUnique).toHaveBeenCalledWith({
          where: { email: 'test@example.com' },
        });
      });
    });

    describe('verifyEmail', () => {
      const mockUser = {
        id: 'user-id',
        email: 'test@example.com',
        emailVerificationToken: 'valid-token',
        emailVerificationExpires: new Date(Date.now() + 3600000),
        isVerified: false,
      };

      beforeEach(() => {
        mockPrisma.user.findUnique.mockResolvedValue(mockUser);
        mockPrisma.user.update.mockResolvedValue({
          ...mockUser,
          isVerified: true,
        });
      });

      it('should verify email with valid token', async () => {
        const result = await signupFlowService.verifyEmail('test@example.com', 'valid-token');

        expect(result.message).toBe('Email verified successfully');
        expect(mockPrisma.user.update).toHaveBeenCalledWith({
          where: { id: 'user-id' },
          data: {
            isVerified: true,
            emailVerifiedAt: expect.any(Date),
            emailVerificationToken: null,
            emailVerificationExpires: null,
          },
        });
      });

      it('should throw error for invalid token', async () => {
        await expect(signupFlowService.verifyEmail('test@example.com', 'invalid-token'))
          .rejects
          .toThrow('Invalid verification token');
      });

      it('should throw error for expired token', async () => {
        mockPrisma.user.findUnique.mockResolvedValue({
          ...mockUser,
          emailVerificationExpires: new Date(Date.now() - 3600000),
        });

        await expect(signupFlowService.verifyEmail('test@example.com', 'valid-token'))
          .rejects
          .toThrow('Verification token expired');
      });

      it('should throw error for already verified user', async () => {
        mockPrisma.user.findUnique.mockResolvedValue({
          ...mockUser,
          isVerified: true,
        });

        await expect(signupFlowService.verifyEmail('test@example.com', 'valid-token'))
          .rejects
          .toThrow('Email already verified');
      });
    });
  });

  describe('OtpService', () => {
    let otpService: any;

    beforeAll(async () => {
      const module = await import('../services/otpService');
      otpService = module.otpService;
    });

    describe('sendOtp', () => {
      const mockUser = {
        id: 'user-id',
        email: 'test@example.com',
      };

      beforeEach(() => {
        mockPrisma.user.findUnique.mockResolvedValue(mockUser);
        mockPrisma.user.update.mockResolvedValue({});
        mockEmailService.sendOtpEmail.mockResolvedValue(undefined);
      });

      it('should send OTP successfully', async () => {
        await otpService.sendOtp('test@example.com', 'LOGIN');

        expect(mockPrisma.user.update).toHaveBeenCalledWith({
          where: { id: 'user-id' },
          data: {
            otpCode: expect.stringMatching(/^\d{6}$/),
            otpExpires: expect.any(Date),
            otpPurpose: 'LOGIN',
          },
        });
        expect(mockEmailService.sendOtpEmail).toHaveBeenCalled();
      });

      it('should throw error for non-existent user', async () => {
        mockPrisma.user.findUnique.mockResolvedValue(null);

        await expect(otpService.sendOtp('nonexistent@example.com', 'LOGIN'))
          .rejects
          .toThrow('User not found');
      });

      it('should generate 6-digit code', async () => {
        await otpService.sendOtp('test@example.com', 'LOGIN');

        const updateCall = mockPrisma.user.update.mock.calls[0][0];
        const otpCode = updateCall.data.otpCode;

        expect(otpCode).toMatch(/^\d{6}$/);
        expect(parseInt(otpCode)).toBeGreaterThanOrEqual(100000);
        expect(parseInt(otpCode)).toBeLessThanOrEqual(999999);
      });
    });

    describe('verifyOtp', () => {
      const mockUser = {
        id: 'user-id',
        email: 'test@example.com',
        role: 'FREE_MEMBER',
        isVerified: true,
        otpCode: '123456',
        otpExpires: new Date(Date.now() + 600000),
        otpPurpose: 'LOGIN',
      };

      beforeEach(() => {
        mockPrisma.user.findUnique.mockResolvedValue(mockUser);
        mockPrisma.user.update.mockResolvedValue(mockUser);
      });

      it('should verify OTP successfully for LOGIN', async () => {
        const result = await otpService.verifyOtp('test@example.com', '123456', 'LOGIN');

        expect(result).toHaveProperty('tokens');
        expect(result).toHaveProperty('user');
        expect(mockPrisma.user.update).toHaveBeenCalledWith({
          where: { id: 'user-id' },
          data: {
            otpCode: null,
            otpExpires: null,
            otpPurpose: null,
          },
        });
      });

      it('should verify OTP for EMAIL_VERIFICATION', async () => {
        const unverifiedUser = {
          ...mockUser,
          isVerified: false,
          otpPurpose: 'VERIFY_EMAIL',
        };

        mockPrisma.user.findUnique.mockResolvedValue(unverifiedUser);
        mockPrisma.user.update.mockResolvedValue({
          ...unverifiedUser,
          isVerified: true,
        });

        const result = await otpService.verifyOtp('test@example.com', '123456', 'VERIFY_EMAIL');

        expect(result).toHaveProperty('user');
        expect(mockPrisma.user.update).toHaveBeenCalledWith({
          where: { id: 'user-id' },
          data: {
            isVerified: true,
            emailVerifiedAt: expect.any(Date),
            otpCode: null,
            otpExpires: null,
            otpPurpose: null,
          },
        });
      });

      it('should throw error for invalid code', async () => {
        await expect(otpService.verifyOtp('test@example.com', '654321', 'LOGIN'))
          .rejects
          .toThrow('Invalid OTP code');
      });

      it('should throw error for expired OTP', async () => {
        mockPrisma.user.findUnique.mockResolvedValue({
          ...mockUser,
          otpExpires: new Date(Date.now() - 600000),
        });

        await expect(otpService.verifyOtp('test@example.com', '123456', 'LOGIN'))
          .rejects
          .toThrow('OTP expired');
      });

      it('should throw error for wrong purpose', async () => {
        await expect(otpService.verifyOtp('test@example.com', '123456', 'VERIFY_EMAIL'))
          .rejects
          .toThrow('Invalid OTP purpose');
      });
    });
  });

  describe('Password Utilities', () => {
    it('should hash passwords securely', async () => {
      const password = 'TestPassword123!';
      const hashed = await bcrypt.hash(password, 12);

      expectHashedPassword(hashed, password);

      const isValid = await bcrypt.compare(password, hashed);
      expect(isValid).toBe(true);
    });

    it('should reject incorrect passwords', async () => {
      const password = 'TestPassword123!';
      const wrongPassword = 'WrongPassword123!';
      const hashed = await bcrypt.hash(password, 12);

      const isValid = await bcrypt.compare(wrongPassword, hashed);
      expect(isValid).toBe(false);
    });
  });

  describe('Utility Functions', () => {
    let intentMapping: any;

    beforeAll(async () => {
      intentMapping = await import('../utils/intentMapping');
    });

    describe('Intent Mapping', () => {
      it('should map single intent correctly', () => {
        expect(intentMapping.mapIntent('vote or nominate')).toBe('VOTE_OR_NOMINATE');
        expect(intentMapping.mapIntent('become ambassador')).toBe('BECOME_AMBASSADOR');
        expect(intentMapping.mapIntent('invalid intent')).toBeNull();
      });

      it('should map multiple intents', () => {
        const result = intentMapping.mapIntents(['vote or nominate', 'become ambassador']);
        expect(result).toEqual(['VOTE_OR_NOMINATE', 'BECOME_AMBASSADOR']);
      });

      it('should filter invalid intents', () => {
        const result = intentMapping.mapIntents(['vote or nominate', 'invalid intent']);
        expect(result).toEqual(['VOTE_OR_NOMINATE']);
      });
    });

    describe('Account Type Mapping', () => {
      it('should map account types correctly', () => {
        expect(intentMapping.mapAccountType('individual')).toBe('INDIVIDUAL');
        expect(intentMapping.mapAccountType('corporation')).toBe('CORPORATION');
        expect(intentMapping.mapAccountType('ngo')).toBe('NGO');
        expect(intentMapping.mapAccountType('invalid')).toBeUndefined();
      });
    });

    describe('Gender Mapping', () => {
      it('should map gender values correctly', () => {
        expect(intentMapping.mapGender('male')).toBe('MALE');
        expect(intentMapping.mapGender('female')).toBe('FEMALE');
        expect(intentMapping.mapGender('other')).toBe('OTHER');
        expect(intentMapping.mapGender('prefer not to say')).toBe('PREFER_NOT_TO_SAY');
        expect(intentMapping.mapGender('invalid')).toBeUndefined();
      });
    });

    describe('Division Mapping', () => {
      it('should map division values correctly', () => {
        expect(intentMapping.mapDivision('SOBCD')).toBe('SOBCD');
        expect(intentMapping.mapDivision('sobcd')).toBe('SOBCD');
        expect(intentMapping.mapDivision('OMBDD')).toBe('OMBDD');
        expect(intentMapping.mapDivision('invalid')).toBeUndefined();
      });
    });

    describe('Role Inference', () => {
      it('should infer roles from intents', () => {
        expect(intentMapping.inferRole(['BECOME_AMBASSADOR'])).toBe('AMBASSADOR');
        expect(intentMapping.inferRole(['APPLY_AS_JUDGE'])).toBe('JUDGE');
        expect(intentMapping.inferRole(['APPLY_AS_NRC_VOLUNTEER'])).toBe('NRC_VOLUNTEER');
        expect(intentMapping.inferRole(['JOIN_NESA_TEAM'])).toBe('VOLUNTEER');
        expect(intentMapping.inferRole(['SPONSOR_OR_CSR_PARTNER'])).toBe('SPONSOR');
        expect(intentMapping.inferRole(['VOTE_OR_NOMINATE'])).toBe('FREE_MEMBER');
        expect(intentMapping.inferRole([])).toBe('FREE_MEMBER');
      });

      it('should prioritize higher roles', () => {
        expect(intentMapping.inferRole(['VOTE_OR_NOMINATE', 'BECOME_AMBASSADOR'])).toBe('AMBASSADOR');
        expect(intentMapping.inferRole(['JOIN_NESA_TEAM', 'APPLY_AS_JUDGE'])).toBe('JUDGE');
      });
    });

    describe('Signup Bonus Calculation', () => {
      it('should calculate signup bonus correctly', () => {
        const individualBonus = intentMapping.computeSignupBonus('INDIVIDUAL', ['VOTE_OR_NOMINATE']);
        expect(individualBonus.amount).toBe(2); // base 1 + individual 1

        const ambassadorBonus = intentMapping.computeSignupBonus('INDIVIDUAL', ['BECOME_AMBASSADOR']);
        expect(ambassadorBonus.amount).toBe(5); // base 1 + individual 1 + ambassador 3
        expect(ambassadorBonus.type).toBe('withdrawable');

        const judgeBonus = intentMapping.computeSignupBonus('CORPORATION', ['APPLY_AS_JUDGE']);
        expect(judgeBonus.amount).toBe(3); // base 1 + judge 2
        expect(judgeBonus.type).toBe('non-withdrawable');
      });
    });
  });
});