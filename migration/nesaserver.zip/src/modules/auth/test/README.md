# Auth Module Tests

This directory contains tests for the authentication module of the NESA-Africa platform.

## Test Files

- **`auth.test.ts`** - Main test suite covering API endpoints, validation, and integration tests
- **`services.test.ts`** - Service-level tests focusing on business logic
- **`testHelpers.ts`** - Utility functions for creating mock data and assertions

## Running Tests

### Run All Auth Tests
```bash
npm test -- --testPathPattern="auth"
```

### Run Specific Test Files
```bash
# Run main auth tests
npx jest src/modules/auth/test/auth.test.ts

# Run service tests
npx jest src/modules/auth/test/services.test.ts

# Run with coverage
npx jest src/modules/auth/test --coverage
```

### Watch Mode
```bash
npx jest src/modules/auth/test --watch
```

## Test Coverage

The test suite covers:

### API Endpoints
- ✅ POST /api/v1/auth/signup-flow
- ✅ POST /api/v1/auth/login
- ✅ POST /api/v1/auth/send-otp
- ✅ POST /api/v1/auth/verify-otp
- ✅ GET /api/v1/auth/profile
- ✅ GET /api/v1/auth/me
- ✅ POST /api/v1/auth/admin/invite
- ✅ POST /api/v1/auth/admin/accept-invitation
- ✅ GET /api/v1/auth/admin/dashboard

### Services
- ✅ SignupFlowService - User registration and email verification
- ✅ OtpService - OTP generation and verification
- ✅ Utility functions - Intent mapping, role inference, etc.

### Validation
- ✅ Email format validation
- ✅ Password strength validation
- ✅ OTP code format validation
- ✅ Request data validation

### Security
- ✅ Authentication middleware
- ✅ Rate limiting
- ✅ JWT token validation
- ✅ Sensitive data exclusion
- ✅ Password hashing

### Error Handling
- ✅ Database errors
- ✅ Validation errors
- ✅ Authentication errors
- ✅ Malformed requests

## Test Structure

### Mock Setup
All external dependencies are mocked:
- Database operations (Prisma)
- Email service
- Wallet service

### Test Helpers
The `testHelpers.ts` file provides utilities for:
- Creating mock data
- Validating formats
- Generating test data

### Test Organization
Tests are organized by:
- API endpoints
- Service functions
- Utility functions
- Validation logic
- Security features
- Error scenarios

## Best Practices

1. **Clear Test Names**: Each test has a descriptive name explaining what it tests
2. **Isolated Tests**: Tests don't depend on each other and can run in any order
3. **Mock External Dependencies**: All external services are mocked
4. **Test Edge Cases**: Include tests for error conditions and edge cases
5. **Consistent Setup**: Use beforeEach/afterEach for consistent test setup

## Adding New Tests

When adding new features:

1. Add tests for new API endpoints
2. Add tests for new service methods
3. Add tests for new validation rules
4. Add tests for error conditions
5. Update test helpers if needed

## Debugging Tests

### Common Issues
- **Mock not working**: Ensure mocks are cleared between tests
- **Async issues**: Use proper async/await patterns
- **Import issues**: Check that modules are imported after mocks

### Debug Commands
```bash
# Run with verbose output
npx jest src/modules/auth/test --verbose

# Run specific test
npx jest src/modules/auth/test --testNamePattern="should validate email"

# Debug mode
node --inspect-brk node_modules/.bin/jest src/modules/auth/test
```

## Coverage Goals

- Line Coverage: > 80%
- Function Coverage: > 85%
- Branch Coverage: > 75%

## Contributing

When contributing to tests:
1. Follow existing patterns
2. Add tests for new functionality
3. Ensure tests pass locally
4. Update documentation if needed