import request from 'supertest';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import App from '../../../../app';
import { createMockUser, createMockSignupData, createMockLoginData } from './testHelpers';

// Mock database and services
const mockPrisma = {
  user: {
    findUnique: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
    count: jest.fn(),
  },
  adminInvitation: {
    findUnique: jest.fn(),
    create: jest.fn(),
    count: jest.fn(),
  },
  adminSection: {
    create: jest.fn(),
    findMany: jest.fn(),
  },
  wallet: {
    create: jest.fn(),
    findUnique: jest.fn(),
  },
  chapter: {
    findFirst: jest.fn(),
    create: jest.fn(),
  },
  chapterMembership: {
    create: jest.fn(),
    findFirst: jest.fn(),
  },
  $transaction: jest.fn(),
};

const mockEmailService = {
  sendVerificationEmail: jest.fn(),
  sendOtpEmail: jest.fn(),
  sendAdminInvitation: jest.fn(),
};

const mockWalletService = {
  createWallet: jest.fn(),
};

const mockChapterService = {
  assign: jest.fn(),
};

// Mock modules
jest.mock('@/shared/database/postgresql', () => ({
  prisma: mockPrisma,
}));

jest.mock('@/modules/notifications/services/emailService', () => ({
  emailService: mockEmailService,
}));

jest.mock('@/modules/wallet/services/walletService', () => ({
  walletService: mockWalletService,
}));

jest.mock('@/modules/chapters/services/chapterService', () => ({
  chapterService: mockChapterService,
}));

describe('Auth Module Integration Tests', () => {
  let app: App;

  beforeAll(async () => {
    app = new App();
  });

  beforeEach(() => {
    jest.clearAllMocks();
    
    // Default mock implementations
    mockWalletService.createWallet.mockResolvedValue({
      id: 'wallet-id',
      userId: 'user-id',
      balance: 2,
      withdrawableBalance: 0,
    });
    
    mockChapterService.assign.mockResolvedValue({
      id: 'chapter-membership-id',
      userId: 'user-id',
      chapterId: 'chapter-id',
    });
    
    mockEmailService.sendVerificationEmail.mockResolvedValue(undefined);
    mockEmailService.sendOtpEmail.mockResolvedValue(undefined);
    mockEmailService.sendAdminInvitation.mockResolvedValue(undefined);
  });

  describe('POST /api/v1/auth/signup-flow', () => {
    const validSignupData = createMockSignupData();

    beforeEach(() => {
      mockPrisma.user.findUnique.mockResolvedValue(null); // No existing user
      mockPrisma.user.create.mockResolvedValue({
        ...createMockUser(),
        emailVerificationToken: 'verification-token',
      });
    });

    it('should successfully register a new user', async () => {
      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(validSignupData)
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('User registered successfully');
      expect(response.body.data).toHaveProperty('user');
      expect(response.body.data).toHaveProperty('tokens');
      expect(response.body.data.user).not.toHaveProperty('password');
      expect(response.body.data.user).not.toHaveProperty('emailVerificationToken');
    });

    it('should reject duplicate email registration', async () => {
      mockPrisma.user.findUnique.mockResolvedValue(createMockUser());

      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(validSignupData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('User with this email already exists');
    });

    it('should validate required fields', async () => {
      const invalidData = {
        email: 'test@example.com',
        // missing required fields
      };

      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(invalidData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Validation failed');
    });

    it('should validate email format', async () => {
      const invalidEmailData = {
        ...validSignupData,
        email: 'invalid-email',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(invalidEmailData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Validation failed');
    });

    it('should validate password strength', async () => {
      const weakPasswordData = {
        ...validSignupData,
        password: '123',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(weakPasswordData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Validation failed');
    });

    it('should handle corporate account registration', async () => {
      const corporateData = {
        ...validSignupData,
        accountType: 'corporation',
        organizationName: 'Test Corporation',
        organizationSize: '50-100',
      };

      mockPrisma.user.create.mockResolvedValue({
        ...createMockUser({ accountType: 'CORPORATION' }),
        organizationName: 'Test Corporation',
      });

      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(corporateData)
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.data.user.accountType).toBe('CORPORATION');
    });

    it('should handle ambassador registration', async () => {
      const ambassadorData = {
        ...validSignupData,
        intents: ['become ambassador'],
      };

      mockPrisma.user.create.mockResolvedValue({
        ...createMockUser({ role: 'AMBASSADOR' }),
        intents: ['BECOME_AMBASSADOR'],
      });

      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(ambassadorData)
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.data.user.role).toBe('AMBASSADOR');
    });
  });

  describe('POST /api/v1/auth/login', () => {
    const loginData = createMockLoginData();
    const mockUser = createMockUser({ isVerified: true });

    beforeEach(() => {
      mockPrisma.user.findUnique.mockResolvedValue({
        ...mockUser,
        password: bcrypt.hashSync('ValidPassword123!', 12),
      });
    });

    it('should successfully login with valid credentials', async () => {
      const response = await request(app.app)
        .post('/api/v1/auth/login')
        .send(loginData)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('Login successful');
      expect(response.body.data).toHaveProperty('user');
      expect(response.body.data).toHaveProperty('tokens');
      expect(response.body.data.user).not.toHaveProperty('password');
    });

    it('should reject login with invalid email', async () => {
      mockPrisma.user.findUnique.mockResolvedValue(null);

      const response = await request(app.app)
        .post('/api/v1/auth/login')
        .send(loginData)
        .expect(401);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Invalid credentials');
    });

    it('should reject login with invalid password', async () => {
      const invalidPasswordData = {
        ...loginData,
        password: 'WrongPassword123!',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/login')
        .send(invalidPasswordData)
        .expect(401);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Invalid credentials');
    });

    it('should reject login for unverified user', async () => {
      mockPrisma.user.findUnique.mockResolvedValue({
        ...mockUser,
        isVerified: false,
        password: bcrypt.hashSync('ValidPassword123!', 12),
      });

      const response = await request(app.app)
        .post('/api/v1/auth/login')
        .send(loginData)
        .expect(401);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Please verify your email before logging in');
    });

    it('should validate login data format', async () => {
      const invalidData = {
        email: 'invalid-email',
        password: '',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/login')
        .send(invalidData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Validation failed');
    });
  });

  describe('POST /api/v1/auth/send-otp', () => {
    const mockUser = createMockUser();

    beforeEach(() => {
      mockPrisma.user.findUnique.mockResolvedValue(mockUser);
      mockPrisma.user.update.mockResolvedValue({});
    });

    it('should send OTP for valid user', async () => {
      const otpData = {
        email: 'test@example.com',
        purpose: 'LOGIN',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/send-otp')
        .send(otpData)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('OTP sent successfully');
      expect(mockEmailService.sendOtpEmail).toHaveBeenCalled();
    });

    it('should reject OTP request for non-existent user', async () => {
      mockPrisma.user.findUnique.mockResolvedValue(null);

      const otpData = {
        email: 'nonexistent@example.com',
        purpose: 'LOGIN',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/send-otp')
        .send(otpData)
        .expect(404);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('User not found');
    });

    it('should validate OTP request data', async () => {
      const invalidData = {
        email: 'invalid-email',
        purpose: 'INVALID_PURPOSE',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/send-otp')
        .send(invalidData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Validation failed');
    });

    it('should handle different OTP purposes', async () => {
      const purposes = ['LOGIN', 'VERIFY_EMAIL', 'PASSWORD_RESET'];

      for (const purpose of purposes) {
        const otpData = {
          email: 'test@example.com',
          purpose,
        };

        const response = await request(app.app)
          .post('/api/v1/auth/send-otp')
          .send(otpData)
          .expect(200);

        expect(response.body.success).toBe(true);
      }
    });
  });

  describe('POST /api/v1/auth/verify-otp', () => {
    const mockUser = {
      ...createMockUser(),
      otpCode: '123456',
      otpExpires: new Date(Date.now() + 600000), // 10 minutes from now
      otpPurpose: 'LOGIN',
    };

    beforeEach(() => {
      mockPrisma.user.findUnique.mockResolvedValue(mockUser);
      mockPrisma.user.update.mockResolvedValue(mockUser);
    });

    it('should verify OTP successfully for LOGIN', async () => {
      const verifyData = {
        email: 'test@example.com',
        code: '123456',
        purpose: 'LOGIN',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/verify-otp')
        .send(verifyData)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('OTP verified successfully');
      expect(response.body.data).toHaveProperty('tokens');
      expect(response.body.data).toHaveProperty('user');
    });

    it('should verify OTP for email verification', async () => {
      const unverifiedUser = {
        ...mockUser,
        isVerified: false,
        otpPurpose: 'VERIFY_EMAIL',
      };

      mockPrisma.user.findUnique.mockResolvedValue(unverifiedUser);
      mockPrisma.user.update.mockResolvedValue({
        ...unverifiedUser,
        isVerified: true,
      });

      const verifyData = {
        email: 'test@example.com',
        code: '123456',
        purpose: 'VERIFY_EMAIL',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/verify-otp')
        .send(verifyData)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('Email verified successfully');
    });

    it('should reject invalid OTP code', async () => {
      const verifyData = {
        email: 'test@example.com',
        code: '654321',
        purpose: 'LOGIN',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/verify-otp')
        .send(verifyData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Invalid OTP code');
    });

    it('should reject expired OTP', async () => {
      mockPrisma.user.findUnique.mockResolvedValue({
        ...mockUser,
        otpExpires: new Date(Date.now() - 600000), // 10 minutes ago
      });

      const verifyData = {
        email: 'test@example.com',
        code: '123456',
        purpose: 'LOGIN',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/verify-otp')
        .send(verifyData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('OTP expired');
    });

    it('should validate OTP verification data', async () => {
      const invalidData = {
        email: 'invalid-email',
        code: '12345', // wrong length
        purpose: 'INVALID_PURPOSE',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/verify-otp')
        .send(invalidData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Validation failed');
    });
  });

  describe('GET /api/v1/auth/profile', () => {
    const mockUser = createMockUser();

    it('should get user profile with valid token', async () => {
      const token = jwt.sign(
        { userId: mockUser.id, email: mockUser.email },
        process.env.JWT_SECRET!,
        { expiresIn: '1h' }
      );

      mockPrisma.user.findUnique.mockResolvedValue(mockUser);

      const response = await request(app.app)
        .get('/api/v1/auth/profile')
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.user).toHaveProperty('id', mockUser.id);
      expect(response.body.data.user).not.toHaveProperty('password');
    });

    it('should reject request without token', async () => {
      const response = await request(app.app)
        .get('/api/v1/auth/profile')
        .expect(401);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Access token required');
    });

    it('should reject request with invalid token', async () => {
      const response = await request(app.app)
        .get('/api/v1/auth/profile')
        .set('Authorization', 'Bearer invalid-token')
        .expect(401);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Invalid token');
    });

    it('should reject request with expired token', async () => {
      const expiredToken = jwt.sign(
        { userId: mockUser.id, email: mockUser.email },
        process.env.JWT_SECRET!,
        { expiresIn: '-1h' } // expired
      );

      const response = await request(app.app)
        .get('/api/v1/auth/profile')
        .set('Authorization', `Bearer ${expiredToken}`)
        .expect(401);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Token expired');
    });
  });

  describe('Admin Routes', () => {
    const superAdminUser = createMockUser({ role: 'SUPER_ADMIN' });
    const superAdminToken = jwt.sign(
      { userId: superAdminUser.id, email: superAdminUser.email, role: 'SUPER_ADMIN' },
      process.env.JWT_SECRET!,
      { expiresIn: '1h' }
    );

    describe('POST /api/v1/auth/admin/invite', () => {
      beforeEach(() => {
        mockPrisma.user.findUnique.mockResolvedValue(superAdminUser);
        mockPrisma.adminInvitation.create.mockResolvedValue({
          id: 'invitation-id',
          email: 'admin@example.com',
          token: 'invitation-token',
        });
      });

      it('should allow super admin to invite new admin', async () => {
        const inviteData = {
          email: 'admin@example.com',
          sections: ['USER_MANAGEMENT'],
          permissions: ['READ', 'WRITE'],
          message: 'Welcome to the team',
        };

        const response = await request(app.app)
          .post('/api/v1/auth/admin/invite')
          .set('Authorization', `Bearer ${superAdminToken}`)
          .send(inviteData)
          .expect(201);

        expect(response.body.success).toBe(true);
        expect(response.body.message).toBe('Admin invitation sent successfully');
        expect(mockEmailService.sendAdminInvitation).toHaveBeenCalled();
      });

      it('should reject invitation from non-super-admin', async () => {
        const regularUser = createMockUser({ role: 'ADMIN' });
        const regularToken = jwt.sign(
          { userId: regularUser.id, email: regularUser.email, role: 'ADMIN' },
          process.env.JWT_SECRET!,
          { expiresIn: '1h' }
        );

        mockPrisma.user.findUnique.mockResolvedValue(regularUser);

        const inviteData = {
          email: 'admin@example.com',
          sections: ['USER_MANAGEMENT'],
          permissions: ['READ', 'WRITE'],
        };

        const response = await request(app.app)
          .post('/api/v1/auth/admin/invite')
          .set('Authorization', `Bearer ${regularToken}`)
          .send(inviteData)
          .expect(403);

        expect(response.body.success).toBe(false);
        expect(response.body.message).toBe('Only super admins can invite new admins');
      });

      it('should validate invitation data', async () => {
        const invalidData = {
          email: 'invalid-email',
          sections: [], // should not be empty
          permissions: ['INVALID_PERMISSION'],
        };

        const response = await request(app.app)
          .post('/api/v1/auth/admin/invite')
          .set('Authorization', `Bearer ${superAdminToken}`)
          .send(invalidData)
          .expect(400);

        expect(response.body.success).toBe(false);
        expect(response.body.message).toBe('Validation failed');
      });
    });

    describe('POST /api/v1/auth/admin/accept-invitation', () => {
      const mockInvitation = {
        id: 'invitation-id',
        email: 'admin@example.com',
        token: 'invitation-token',
        expiresAt: new Date(Date.now() + 86400000), // 24 hours from now
        sections: ['USER_MANAGEMENT'],
        permissions: ['READ', 'WRITE'],
      };

      beforeEach(() => {
        mockPrisma.adminInvitation.findUnique.mockResolvedValue(mockInvitation);
        mockPrisma.user.findUnique.mockResolvedValue(null); // No existing user
        mockPrisma.user.create.mockResolvedValue({
          ...createMockUser({ role: 'ADMIN' }),
          email: 'admin@example.com',
        });
      });

      it('should accept valid invitation', async () => {
        const acceptData = {
          invitationToken: 'invitation-token',
          password: 'AdminPassword123!',
          firstName: 'Admin',
          lastName: 'User',
        };

        const response = await request(app.app)
          .post('/api/v1/auth/admin/accept-invitation')
          .send(acceptData)
          .expect(201);

        expect(response.body.success).toBe(true);
        expect(response.body.message).toBe('Admin account created successfully');
        expect(response.body.data).toHaveProperty('user');
        expect(response.body.data).toHaveProperty('tokens');
      });

      it('should reject invalid invitation token', async () => {
        mockPrisma.adminInvitation.findUnique.mockResolvedValue(null);

        const acceptData = {
          invitationToken: 'invalid-token',
          password: 'AdminPassword123!',
          firstName: 'Admin',
          lastName: 'User',
        };

        const response = await request(app.app)
          .post('/api/v1/auth/admin/accept-invitation')
          .send(acceptData)
          .expect(400);

        expect(response.body.success).toBe(false);
        expect(response.body.message).toBe('Invalid invitation token');
      });

      it('should reject expired invitation', async () => {
        mockPrisma.adminInvitation.findUnique.mockResolvedValue({
          ...mockInvitation,
          expiresAt: new Date(Date.now() - 86400000), // 24 hours ago
        });

        const acceptData = {
          invitationToken: 'invitation-token',
          password: 'AdminPassword123!',
          firstName: 'Admin',
          lastName: 'User',
        };

        const response = await request(app.app)
          .post('/api/v1/auth/admin/accept-invitation')
          .send(acceptData)
          .expect(400);

        expect(response.body.success).toBe(false);
        expect(response.body.message).toBe('Invitation expired');
      });
    });

    describe('GET /api/v1/auth/admin/dashboard', () => {
      beforeEach(() => {
        mockPrisma.user.findUnique.mockResolvedValue(superAdminUser);
        mockPrisma.user.count.mockResolvedValue(100);
        mockPrisma.adminInvitation.count.mockResolvedValue(5);
      });

      it('should get admin dashboard data', async () => {
        const response = await request(app.app)
          .get('/api/v1/auth/admin/dashboard')
          .set('Authorization', `Bearer ${superAdminToken}`)
          .expect(200);

        expect(response.body.success).toBe(true);
        expect(response.body.data).toHaveProperty('stats');
        expect(response.body.data.stats).toHaveProperty('totalUsers');
        expect(response.body.data.stats).toHaveProperty('pendingInvitations');
      });

      it('should reject non-admin access', async () => {
        const regularUser = createMockUser({ role: 'FREE_MEMBER' });
        const regularToken = jwt.sign(
          { userId: regularUser.id, email: regularUser.email, role: 'FREE_MEMBER' },
          process.env.JWT_SECRET!,
          { expiresIn: '1h' }
        );

        mockPrisma.user.findUnique.mockResolvedValue(regularUser);

        const response = await request(app.app)
          .get('/api/v1/auth/admin/dashboard')
          .set('Authorization', `Bearer ${regularToken}`)
          .expect(403);

        expect(response.body.success).toBe(false);
        expect(response.body.message).toBe('Admin access required');
      });
    });
  });

  describe('Rate Limiting', () => {
    it('should apply rate limiting to login endpoint', async () => {
      const loginData = createMockLoginData();
      mockPrisma.user.findUnique.mockResolvedValue(null);

      // Make multiple requests quickly
      const requests = Array(10).fill(null).map(() =>
        request(app.app)
          .post('/api/v1/auth/login')
          .send(loginData)
      );

      const responses = await Promise.all(requests);

      // Some requests should be rate limited (429 status)
      const rateLimitedResponses = responses.filter(res => res.status === 429);
      expect(rateLimitedResponses.length).toBeGreaterThan(0);
    });

    it('should apply rate limiting to OTP endpoint', async () => {
      const otpData = {
        email: 'test@example.com',
        purpose: 'LOGIN',
      };

      mockPrisma.user.findUnique.mockResolvedValue(createMockUser());

      // Make multiple requests quickly
      const requests = Array(10).fill(null).map(() =>
        request(app.app)
          .post('/api/v1/auth/send-otp')
          .send(otpData)
      );

      const responses = await Promise.all(requests);

      // Some requests should be rate limited
      const rateLimitedResponses = responses.filter(res => res.status === 429);
      expect(rateLimitedResponses.length).toBeGreaterThan(0);
    });
  });

  describe('Security Headers', () => {
    it('should include security headers in responses', async () => {
      const response = await request(app.app)
        .get('/api/v1/auth/profile')
        .expect(401);

      expect(response.headers).toHaveProperty('x-content-type-options');
      expect(response.headers).toHaveProperty('x-frame-options');
      expect(response.headers).toHaveProperty('x-xss-protection');
    });
  });

  describe('Error Handling', () => {
    it('should handle database connection errors gracefully', async () => {
      mockPrisma.user.findUnique.mockRejectedValue(new Error('Database connection failed'));

      const response = await request(app.app)
        .post('/api/v1/auth/login')
        .send(createMockLoginData())
        .expect(500);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Internal server error');
    });

    it('should handle malformed JSON requests', async () => {
      const response = await request(app.app)
        .post('/api/v1/auth/login')
        .set('Content-Type', 'application/json')
        .send('{ invalid json }')
        .expect(400);

      expect(response.body.success).toBe(false);
    });
  });
});