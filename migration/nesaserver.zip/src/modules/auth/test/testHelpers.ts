/**
 * Simple test helpers for auth module
 */

export const createMockUser = (overrides: any = {}) => ({
  id: 'test-user-id',
  email: 'test@example.com',
  firstName: 'Test',
  lastName: 'User',
  fullName: 'Test User',
  role: 'FREE_MEMBER',
  accountType: 'INDIVIDUAL',
  isVerified: true,
  country: 'Nigeria',
  state: 'Lagos',
  createdAt: new Date(),
  updatedAt: new Date(),
  ...overrides,
});

export const createMockSignupData = (overrides: any = {}) => ({
  email: 'test@example.com',
  password: 'ValidPassword123!',
  firstName: 'John',
  lastName: 'Doe',
  country: 'Nigeria',
  state: 'Lagos',
  accountType: 'individual',
  intents: ['vote or nominate'],
  ...overrides,
});

export const createMockLoginData = (overrides: any = {}) => ({
  email: 'test@example.com',
  password: 'ValidPassword123!',
  ...overrides,
});

export const createMockOtpData = (overrides: any = {}) => ({
  email: 'test@example.com',
  code: '123456',
  purpose: 'LOGIN' as const,
  ...overrides,
});

export const createMockAdminInviteData = (overrides: any = {}) => ({
  email: 'admin@example.com',
  sections: ['USER_MANAGEMENT'],
  permissions: ['READ', 'WRITE'],
  message: 'Welcome to the team',
  ...overrides,
});

export const expectValidEmail = (email: string) => {
  expect(email).toMatch(/^[^\s@]+@[^\s@]+\.[^\s@]+$/);
};

export const expectValidOtpCode = (code: string) => {
  expect(code).toMatch(/^\d{6}$/);
  expect(parseInt(code)).toBeGreaterThanOrEqual(100000);
  expect(parseInt(code)).toBeLessThanOrEqual(999999);
};

export const expectHashedPassword = (hashedPassword: string, originalPassword: string) => {
  expect(hashedPassword).not.toBe(originalPassword);
  expect(hashedPassword).toMatch(/^\$2[aby]\$\d+\$/); // bcrypt hash pattern
};

export const expectValidJWT = (token: string) => {
  expect(token).toMatch(/^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+$/);
};

export const generateRandomEmail = (): string => {
  const randomString = Math.random().toString(36).substring(2, 15);
  return `test-${randomString}@example.com`;
};

export const generateRandomPassword = (): string => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
  let password = '';
  for (let i = 0; i < 12; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return password;
};