import { AccountType, UserIntent, UserRole } from "@/shared/types";

// Map frontend account type labels to backend enums
export function mapAccountType(label?: string): AccountType | undefined {
  if (!label) return undefined;
  const normalized = label.toLowerCase();
  switch (normalized) {
    case "individual":
      return "INDIVIDUAL";
    case "ngo":
      return "NGO";
    case "corporation":
      return "CORPORATION";
    case "government":
      return "GOVERNMENT";
    case "school":
      return "SCHOOL";
    case "diaspora group":
      return "DIASPORA_GROUP";
    default:
      return undefined;
  }
}

// Map frontend intent labels to backend enums
export function mapIntent(label: string): UserIntent | null {
  const normalized = label.toLowerCase();
  
  // Handle both frontend format ("Vote or Nominate") and backend format ("VOTE_OR_NOMINATE")
  switch (normalized) {
    case "vote or nominate":
    case "vote_or_nominate":
      return "VOTE_OR_NOMINATE";
    case "apply for eduaid scholarship":
    case "apply_for_eduaid_scholarship":
      return "APPLY_FOR_EDUAID_SCHOLARSHIP";
    case "become ambassador":
    case "become_ambassador":
      return "BECOME_AMBASSADOR";
    case "join webinar/expo":
    case "join_webinar_expo":
      return "JOIN_WEBINAR_EXPO";
    case "sponsor or csr partner":
    case "sponsor_or_csr_partner":
      return "SPONSOR_OR_CSR_PARTNER";
    case "apply as judge":
    case "apply_as_judge":
      return "APPLY_AS_JUDGE";
    case "join local chapter":
    case "join_local_chapter":
      return "JOIN_LOCAL_CHAPTER";
    case "join nesa team":
    case "join_nesa_team":
      return "JOIN_NESA_TEAM";
    case "get gala ticket":
    case "get_gala_ticket":
      return "GET_GALA_TICKET";
    case "donate":
      return "DONATE";
    case "apply as nrc volunteer":
    case "apply_as_nrc_volunteer":
      return "APPLY_AS_NRC_VOLUNTEER";
    default:
      console.warn(`Unknown intent label: "${label}"`);
      return null;
  }
}

export function mapIntents(labels?: string[]): UserIntent[] | undefined {
  console.log(
    "mapIntents called with:",
    labels,
    "Type:",
    typeof labels,
    "IsArray:",
    Array.isArray(labels)
  );

  if (!labels) {
    console.log("No labels provided, returning undefined");
    return undefined;
  }

  if (!Array.isArray(labels)) {
    console.error("Labels is not an array:", labels);
    return undefined;
  }

  const mapped = labels
    .map((label, index) => {
      console.log(`Mapping intent ${index}: "${label}"`);
      const result = mapIntent(label);
      console.log(`Mapped to: ${result}`);
      return result;
    })
    .filter((x): x is UserIntent => x !== null);

  console.log("Final mapped intents:", mapped);
  return mapped.length ? mapped : undefined;
}

// Map frontend gender labels to backend enum
export function mapGender(
  label?: string
): "MALE" | "FEMALE" | "OTHER" | "PREFER_NOT_TO_SAY" | undefined {
  if (!label) return undefined;
  const normalized = label.toLowerCase();
  switch (normalized) {
    case "male":
      return "MALE";
    case "female":
      return "FEMALE";
    case "other":
      return "OTHER";
    case "prefer not to say":
      return "PREFER_NOT_TO_SAY";
    default:
      return undefined;
  }
}

// Infer a single primary role based on intents
export function inferRole(intents?: UserIntent[]): UserRole {
  if (!intents || intents.length === 0) return "FREE_MEMBER";
  if (intents.includes("BECOME_AMBASSADOR")) return "AMBASSADOR";
  if (intents.includes("APPLY_AS_JUDGE")) return "JUDGE";
  if (intents.includes("APPLY_AS_NRC_VOLUNTEER")) return "NRC_VOLUNTEER";
  if (intents.includes("JOIN_NESA_TEAM")) return "VOLUNTEER";
  if (intents.includes("SPONSOR_OR_CSR_PARTNER")) return "SPONSOR";
  return "FREE_MEMBER";
}

export type AGCBonus = {
  type: "withdrawable" | "non-withdrawable";
  amount: number;
  reason: "signup_bonus";
};

// Map frontend division labels to backend enum
export function mapDivision(
  label?: string
): "SOBCD" | "OMBDD" | "TDSD" | "LSC" | undefined {
  if (!label) return undefined;
  const normalized = label.toUpperCase();
  switch (normalized) {
    case "SOBCD":
      return "SOBCD";
    case "OMBDD":
      return "OMBDD";
    case "TDSD":
      return "TDSD";
    case "LSC":
      return "LSC";
    default:
      return undefined;
  }
}

export function computeSignupBonus(
  accountType?: AccountType,
  intents?: UserIntent[]
): AGCBonus {
  // Fixed signup bonus: 5 AGC for all users
  // This bonus is non-withdrawable and can only be used for nominations
  const amount = 5;
  const type: "withdrawable" | "non-withdrawable" = "non-withdrawable";

  return { type, amount, reason: "signup_bonus" };
}
