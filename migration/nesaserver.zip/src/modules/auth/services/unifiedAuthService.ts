/* eslint-disable @typescript-eslint/no-explicit-any */
import bcrypt from "bcryptjs";
import { prisma } from "@/shared/database/postgresql";
import { config } from "@/config";
import { authService } from "./authService";
import { signupFlowService } from "./signupFlowService";
import { adminService } from "./adminService";
import { otpService } from "./otpService";
import { NotFoundError } from "@/shared/utils/errors";

class UnifiedAuthService {
  private readonly SALT_ROUNDS = config.security.bcryptSaltRounds;

  // Public auth
  register = (data: any) => authService.register(data);
  signup = (data: any) => signupFlowService.signup(data);
  login = (credentials: any) => authService.login(credentials);
  refreshToken = (token: string) => authService.refreshToken(token);
  logout = (userId: string) => authService.logout(userId);
  verifyEmail = (payload: any) => authService.verifyEmail(payload);
  resendVerificationEmail = (email: string) =>
    authService.resendVerificationEmail(email);
  requestPasswordReset = (payload: any) =>
    authService.requestPasswordReset(payload);
  resetPassword = (payload: any) => authService.resetPassword(payload);

  // Helper: reset password directly by email (after OTP verification)
  async resetPasswordWithNewPassword(
    email: string,
    newPassword: string
  ): Promise<{ message: string }> {
    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
    });
    if (!user) throw new NotFoundError("User not found");

    const hashed = await bcrypt.hash(newPassword, this.SALT_ROUNDS);
    await prisma.user.update({
      where: { id: user.id },
      data: {
        password: hashed,
        passwordResetToken: null,
        passwordResetExpires: null,
        otpCode: null,
        otpExpires: null,
        otpPurpose: null,
        refreshToken: null,
        refreshTokenExpires: null,
      },
    });

    return { message: "Password reset successfully" };
  }

  // OTP
  sendOtp = (
    email: string,
    purpose: "LOGIN" | "VERIFY_EMAIL" | "PASSWORD_RESET"
  ) => otpService.sendOtp(email, purpose);
  verifyOtp = (
    email: string,
    code: string,
    purpose?: "LOGIN" | "VERIFY_EMAIL" | "PASSWORD_RESET"
  ) => otpService.verifyOtp(email, code, purpose);

  // Profile
  getUserProfile = (userId: string) => authService.getUserProfile(userId);
  updateUserProfile = (userId: string, data: any) =>
    authService.updateUserProfile(userId, data);
  changePassword = (
    userId: string,
    currentPassword: string,
    newPassword: string
  ) => authService.changePassword(userId, currentPassword, newPassword);
  deleteAccount = (userId: string, password: string) =>
    authService.deleteAccount(userId, password);

  // Rich profile summary (/me)
  async getMe(userId: string) {
    const [user, wallet, membership] = await Promise.all([
      prisma.user.findUnique({
        where: { id: userId },
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          fullName: true,
          role: true,
          accountType: true,
          isVerified: true,
          country: true,
          state: true,
          division: true,
          functions: true,
          referralCode: true,
          createdAt: true,
        },
      }),
      prisma.wallet.findUnique({
        where: { userId },
        select: {
          id: true,
          agcWithdrawableBalance: true,
          agcLockedBalance: true,
          lastUpdated: true,
        },
      }),
      prisma.chapterMembership.findUnique({
        where: { userId },
        select: { chapterId: true, chapter: true },
      }),
    ]);

    return { user, wallet, chapter: membership?.chapter || null };
  }

  // Admin
  inviteAdmin = (inviterId: string, data: any) =>
    adminService.inviteAdmin(inviterId, data);
  acceptInvitation = (payload: any) => adminService.acceptInvitation(payload);
  getAdminInvitations = (adminId: string) =>
    adminService.getAdminInvitations(adminId);
  revokeInvitation = (adminId: string, invitationId: string) =>
    adminService.revokeInvitation(adminId, invitationId);
  getAdmins = (superAdminId: string) => adminService.getAdmins(superAdminId);
  updateAdminSections = (
    superAdminId: string,
    adminId: string,
    sections: any
  ) => adminService.updateAdminSections(superAdminId, adminId, sections);
  changeAdminPassword = (
    superAdminId: string,
    adminId: string,
    newPassword: string
  ) => adminService.changeAdminPassword(superAdminId, adminId, newPassword);
  deactivateAdmin = (superAdminId: string, adminId: string) =>
    adminService.deactivateAdmin(superAdminId, adminId);
  reactivateAdmin = (superAdminId: string, adminId: string) =>
    adminService.reactivateAdmin(superAdminId, adminId);
  getAdminDashboard = (adminId: string, role: string) =>
    adminService.getAdminDashboard(adminId, role);
  getAdminStats = (adminId: string, role: string) =>
    adminService.getAdminStats(adminId, role);

  // Admin division/functions assignment
  updateAdminDivision = (
    superAdminId: string,
    adminId: string,
    division?: string | null,
    functions?: string[] | null
  ) =>
    adminService.updateAdminDivision(
      superAdminId,
      adminId,
      division,
      functions
    );
}

export const unifiedAuthService = new UnifiedAuthService();
