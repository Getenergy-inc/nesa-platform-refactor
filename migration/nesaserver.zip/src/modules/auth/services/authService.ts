/* eslint-disable @typescript-eslint/no-explicit-any */
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { prisma } from '@/shared/database/postgresql';
import {
  AuthTokens,
  LoginCredentials,
  RegisterData,
  PasswordResetRequest,
  PasswordResetConfirm,
  EmailVerification
} from '@/shared/types';
import { 
  generateToken, 
  generateRefreshToken, 
  verifyRefreshToken 
} from '@/shared/middleware/auth';
import { 
  AuthenticationError, 
  ValidationError, 
  NotFoundError, 
  ConflictError 
} from '@/shared/utils/errors';
import { emailService } from '@/modules/notifications/services/emailService';
import { otpService } from './otpService';
import { config } from '@/config';

export class AuthService {
  private readonly SALT_ROUNDS = config.security.bcryptSaltRounds;
  private readonly MAX_LOGIN_ATTEMPTS = 5;
  private readonly LOCK_TIME = 2 * 60 * 60 * 1000; // 2 hours
  private readonly EMAIL_VERIFICATION_EXPIRES = 24 * 60 * 60 * 1000; // 24 hours
  private readonly PASSWORD_RESET_EXPIRES = 60 * 60 * 1000; // 1 hour

  /**
   * Send first-login welcome email asynchronously (don't block login)
   */
  private async sendFirstLoginWelcomeAsync(email: string, firstName: string): Promise<void> {
    try {
      await emailService.sendFirstLoginWelcome(email, firstName);
    } catch (error) {
      console.error('Failed to send first-login welcome email:', error);
      // Don't throw - this is a non-critical operation
    }
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async register(data: RegisterData): Promise<{ user: any; message: string }> {
    const { email, password, ...userData } = data;

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email: email.toLowerCase() }
    });

    if (existingUser) {
      throw new ConflictError('User with this email already exists');
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, this.SALT_ROUNDS);

    // Generate email verification token (kept for legacy/manual verification if needed)
    const emailVerificationToken = crypto.randomBytes(32).toString('hex');
    const emailVerificationExpires = new Date(Date.now() + this.EMAIL_VERIFICATION_EXPIRES);

    // Create user
    const user = await prisma.user.create({
      data: {
        email: email.toLowerCase(),
        password: hashedPassword,
        emailVerificationToken,
        emailVerificationExpires,
        ...userData,
        fullName: userData.firstName && userData.lastName
          ? `${userData.firstName} ${userData.lastName}`
          : null,
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        accountType: true,
        isVerified: true,
        createdAt: true,
      }
    });

    // Send OTP for email verification instead of token link
    await otpService.sendOtp(email, 'VERIFY_EMAIL');

    return {
      user,
      message: 'Registration successful. Enter the OTP sent to your email to verify your account.'
    };
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async login(credentials: LoginCredentials): Promise<AuthTokens & { user: any }> {
    const { email, password } = credentials;

    // Find user with login attempt tracking
    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
      select: {
        id: true,
        email: true,
        password: true,
        role: true,
        firstName: true,
        lastName: true,
        fullName: true,
        isVerified: true,
        isActive: true,
        loginAttempts: true,
        lockUntil: true,
        lastLoginAt: true,
        adminSections: {
          select: {
            section: true,
            permissions: true
          }
        }
      }
    });

    if (!user) {
      throw new AuthenticationError('Invalid email or password');
    }

    if (!user.isActive) {
      throw new AuthenticationError('Account is deactivated');
    }

    // Check if account is locked
    if (user.lockUntil && user.lockUntil > new Date()) {
      throw new AuthenticationError('Account is temporarily locked due to too many failed login attempts');
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, user.password);

    if (!isPasswordValid) {
      // Increment login attempts
      const loginAttempts = user.loginAttempts + 1;
      const updateData: any = { loginAttempts };

      // Lock account if max attempts reached
      if (loginAttempts >= this.MAX_LOGIN_ATTEMPTS) {
        updateData.lockUntil = new Date(Date.now() + this.LOCK_TIME);
      }

      await prisma.user.update({
        where: { id: user.id },
        data: updateData
      });

      throw new AuthenticationError('Invalid email or password');
    }

    if (!user.isVerified) {
      throw new AuthenticationError('Please verify your email before logging in');
    }

    // Check if this is the user's first login
    const isFirstLogin = !user.lastLoginAt;

    // Reset login attempts and update last login
    const refreshToken = generateRefreshToken({ 
      userId: user.id, 
      email: user.email, 
      role: user.role 
    });

    await prisma.user.update({
      where: { id: user.id },
      data: {
        loginAttempts: 0,
        lockUntil: null,
        lastLoginAt: new Date(),
        refreshToken,
        refreshTokenExpires: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days
      }
    });

    // We'll fetch full user details and wallet below; send first-login welcome after we have those details

    // Generate tokens
    const accessToken = generateToken({ 
      userId: user.id, 
      email: user.email, 
      role: user.role 
    });

    // Fetch full user details including wallet, chapter, and profile

    const [fullUser, wallet, chapterMembership] = await Promise.all([
      prisma.user.findUnique({
        where: { id: user.id },
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          fullName: true,
          phone: true,
          role: true,
          accountType: true,
          intents: true,
          isVerified: true,
          isActive: true,
          country: true,
          state: true,
          city: true,
          gender: true,
          dateOfBirth: true,
          division: true,
          functions: true,
          organizationName: true,
          organizationType: true,
          referralCode: true,
          profileImage: true,
          bio: true,
          createdAt: true,
          lastLoginAt: true,
          adminSections: {
            select: {
              section: true,
              permissions: true
            }
          }
        }
      }),
      prisma.wallet.findUnique({
        where: { userId: user.id },
        select: {
          id: true,
          balance: true,
          agcWithdrawableBalance: true,
          agcLockedBalance: true,
          reserved: true,
          lastUpdated: true
        }
      }),
      prisma.chapterMembership.findFirst({
        where: { userId: user.id },
        include: {
          chapter: {
            select: {
              id: true,
              name: true,
              country: true,
              region: true,
              type: true,
              isActive: true
            }
          }
        }
      })
    ]);

    if (!fullUser) {
      throw new NotFoundError('User details not found after login.');
    }

    const userResponse = {
      ...fullUser,
      wallet: wallet ? {
        id: wallet.id,
        balance: wallet.balance,
        agcWithdrawableBalance: wallet.agcWithdrawableBalance,
        agcLockedBalance: wallet.agcLockedBalance,
        totalAgc: (wallet.agcWithdrawableBalance || 0) + (wallet.agcLockedBalance || 0),
        reserved: wallet.reserved,
        lastUpdated: wallet.lastUpdated
      } : null,
      chapter: chapterMembership?.chapter || null,
      chapterJoinedAt: chapterMembership?.joinedAt || null,
      isFirstLogin
    };

    // Send first-login welcome email (async, don't block response) with more context
    if (isFirstLogin) {
      (async () => {
        try {
          const userName = fullUser.firstName || fullUser.fullName?.split(' ')[0] || 'Member';
          const bonusAmount = userResponse.wallet?.totalAgc ?? userResponse.wallet?.agcLockedBalance ?? 0;
          const joinDate = fullUser.createdAt ? new Date(fullUser.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) : undefined;
          await emailService.sendFirstLoginWelcome(user.email, userName, bonusAmount, joinDate);
        } catch (err) {
          console.error('Failed to send first-login welcome email:', err);
        }
      })();
    }

    return {
      accessToken,
      refreshToken,
      expiresIn: 7 * 24 * 60 * 60, // 7 days in seconds
      user: userResponse
    };
  }

  async refreshToken(refreshToken: string): Promise<AuthTokens> {
    try {
      const decoded = verifyRefreshToken(refreshToken);
      
      // Verify refresh token in database
      const user = await prisma.user.findFirst({
        where: {
          id: decoded.userId,
          refreshToken,
          refreshTokenExpires: {
            gt: new Date()
          },
          isActive: true
        }
      });

      if (!user) {
        throw new AuthenticationError('Invalid refresh token');
      }

      // Generate new tokens
      const newAccessToken = generateToken({
        userId: user.id,
        email: user.email,
        role: user.role
      });

      const newRefreshToken = generateRefreshToken({
        userId: user.id,
        email: user.email,
        role: user.role
      });

      // Update refresh token in database
      await prisma.user.update({
        where: { id: user.id },
        data: {
          refreshToken: newRefreshToken,
          refreshTokenExpires: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
        }
      });

      return {
        accessToken: newAccessToken,
        refreshToken: newRefreshToken,
        expiresIn: 7 * 24 * 60 * 60
      };
    } catch (error) {
      throw new AuthenticationError('Invalid refresh token');
    }
  }

  async logout(userId: string): Promise<void> {
    await prisma.user.update({
      where: { id: userId },
      data: {
        refreshToken: null,
        refreshTokenExpires: null
      }
    });
  }

  async verifyEmail(verification: EmailVerification): Promise<{ message: string }> {
    const { token } = verification;

    const user = await prisma.user.findFirst({
      where: {
        emailVerificationToken: token,
        emailVerificationExpires: {
          gt: new Date()
        }
      }
    });

    if (!user) {
      throw new ValidationError('Invalid or expired verification token');
    }

    await prisma.user.update({
      where: { id: user.id },
      data: {
        isVerified: true,
        emailVerifiedAt: new Date(),
        emailVerificationToken: null,
        emailVerificationExpires: null
      }
    });

    return { message: 'Email verified successfully' };
  }

  async requestPasswordReset(request: PasswordResetRequest): Promise<{ message: string }> {
    const { email } = request;

    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase() }
    });

    if (!user) {
      // Don't reveal if email exists
      return { message: 'If an account with that email exists, a password reset link has been sent.' };
    }

    const resetToken = crypto.randomBytes(32).toString('hex');
    const resetExpires = new Date(Date.now() + this.PASSWORD_RESET_EXPIRES);

    await prisma.user.update({
      where: { id: user.id },
      data: {
        passwordResetToken: resetToken,
        passwordResetExpires: resetExpires
      }
    });

    const userName = user.firstName || user.fullName || undefined;
    await emailService.sendPasswordReset(email, resetToken, userName);

    return { message: 'If an account with that email exists, a password reset link has been sent.' };
  }

  async resetPassword(reset: PasswordResetConfirm): Promise<{ message: string }> {
    const { token, newPassword } = reset;

    const user = await prisma.user.findFirst({
      where: {
        passwordResetToken: token,
        passwordResetExpires: {
          gt: new Date()
        }
      }
    });

    if (!user) {
      throw new ValidationError('Invalid or expired reset token');
    }

    const hashedPassword = await bcrypt.hash(newPassword, this.SALT_ROUNDS);

    await prisma.user.update({
      where: { id: user.id },
      data: {
        password: hashedPassword,
        passwordResetToken: null,
        passwordResetExpires: null,
        // Clear refresh tokens to force re-login
        refreshToken: null,
        refreshTokenExpires: null
      }
    });

    return { message: 'Password reset successfully' };
  }

  async resendVerificationEmail(email: string): Promise<{ message: string }> {
    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase() }
    });

    if (!user) {
      throw new NotFoundError('User not found');
    }

    if (user.isVerified) {
      throw new ValidationError('Email is already verified');
    }

    const emailVerificationToken = crypto.randomBytes(32).toString('hex');
    const emailVerificationExpires = new Date(Date.now() + this.EMAIL_VERIFICATION_EXPIRES);

    await prisma.user.update({
      where: { id: user.id },
      data: {
        emailVerificationToken,
        emailVerificationExpires
      }
    });

    await emailService.sendVerificationEmail(email, emailVerificationToken);

    return { message: 'Verification email sent successfully' };
  }

  async getUserByVerificationToken(token: string): Promise<any> {
    return await prisma.user.findFirst({
      where: { emailVerificationToken: token },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true
      }
    });
  }

  async getUserProfile(userId: string): Promise<any> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        fullName: true,
        phone: true,
        dateOfBirth: true,
        gender: true,
        country: true,
        state: true,
        city: true,
        address: true,
        organizationName: true,
        organizationType: true,
        organizationRole: true,
        profileImage: true,
        bio: true,
        website: true,
        linkedinProfile: true,
        preferredLanguage: true,
        intents: true,
        role: true,
        accountType: true,
        isVerified: true,
        createdAt: true,
        adminSections: {
          select: {
            section: true,
            permissions: true
          }
        }
      }
    });

    if (!user) {
      throw new NotFoundError('User not found');
    }

    return user;
  }

  async updateUserProfile(userId: string, updateData: any): Promise<any> {
    const { email, password, role, ...allowedUpdates } = updateData;

    // Prevent updating sensitive fields
    if (email || password || role) {
      throw new ValidationError('Cannot update email, password, or role through this endpoint');
    }

    // Generate fullName if firstName or lastName is updated
    if (allowedUpdates.firstName || allowedUpdates.lastName) {
      const currentUser = await prisma.user.findUnique({
        where: { id: userId },
        select: { firstName: true, lastName: true }
      });

      const firstName = allowedUpdates.firstName || currentUser?.firstName;
      const lastName = allowedUpdates.lastName || currentUser?.lastName;

      if (firstName && lastName) {
        allowedUpdates.fullName = `${firstName} ${lastName}`;
      }
    }

    // Map client fields to DB schema and normalize types
    if (typeof allowedUpdates.phoneNumber === 'string') {
      allowedUpdates.phone = allowedUpdates.phoneNumber;
      delete allowedUpdates.phoneNumber;
    }

    if (allowedUpdates.dateOfBirth) {
      const dob = new Date(allowedUpdates.dateOfBirth);
      if (!isNaN(dob.getTime())) {
        allowedUpdates.dateOfBirth = dob;
      } else {
        // Invalid date provided; drop it instead of causing a failure
        delete allowedUpdates.dateOfBirth;
      }
    }

    const user = await prisma.user.update({
      where: { id: userId },
      data: allowedUpdates,
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        fullName: true,
        phone: true,
        country: true,
        state: true,
        city: true,
        organizationName: true,
        profileImage: true,
        bio: true,
        website: true,
        linkedinProfile: true,
        preferredLanguage: true,
        intents: true,
        role: true,
        accountType: true,
        updatedAt: true
      }
    });

    return user;
  }

  async changePassword(userId: string, currentPassword: string, newPassword: string): Promise<void> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { password: true }
    });

    if (!user) {
      throw new NotFoundError('User not found');
    }

    const isCurrentPasswordValid = await bcrypt.compare(currentPassword, user.password);
    if (!isCurrentPasswordValid) {
      throw new AuthenticationError('Current password is incorrect');
    }

    const hashedNewPassword = await bcrypt.hash(newPassword, this.SALT_ROUNDS);

    await prisma.user.update({
      where: { id: userId },
      data: {
        password: hashedNewPassword,
        // Clear refresh tokens to force re-login on other devices
        refreshToken: null,
        refreshTokenExpires: null
      }
    });
  }

  async deleteAccount(userId: string, password: string): Promise<void> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { password: true, email: true }
    });

    if (!user) {
      throw new NotFoundError('User not found');
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      throw new AuthenticationError('Password is incorrect');
    }

    // Soft delete by deactivating account
    await prisma.user.update({
      where: { id: userId },
      data: {
        isActive: false,
        email: `deleted_${Date.now()}_${user.email}`, // Prevent email conflicts
        refreshToken: null,
        refreshTokenExpires: null
      }
    });
  }
}

export const authService = new AuthService();
