/* eslint-disable @typescript-eslint/no-explicit-any */
import bcrypt from "bcryptjs";
import crypto from "crypto";
import { prisma } from "@/shared/database/postgresql";
import {
  AdminInviteRequest,
  AdminAcceptInvitation,
  PlatformSection,
  AdminPermission,
} from "@/shared/types";
import {
  ValidationError,
  NotFoundError,
  ConflictError,
  AuthorizationError,
} from "@/shared/utils/errors";
import { emailService } from "@/modules/notifications/services/emailService";
import { config } from "@/config";
import { mapDivision } from "@/modules/auth/utils/intentMapping";

export class AdminService {
  private readonly SALT_ROUNDS = config.security.bcryptSaltRounds;
  private readonly INVITATION_EXPIRES = 7 * 24 * 60 * 60 * 1000; // 7 days

  async inviteAdmin(
    inviterId: string,
    inviteData: AdminInviteRequest
  ): Promise<{ message: string; invitationId: string }> {
    const { email, sections, permissions, message } = inviteData;

    // Verify inviter is super admin
    const inviter = await prisma.user.findUnique({
      where: { id: inviterId },
      select: { role: true, firstName: true, lastName: true },
    });

    if (!inviter || inviter.role !== "SUPER_ADMIN") {
      throw new AuthorizationError("Only super admins can invite new admins");
    }

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
    });

    if (existingUser) {
      throw new ConflictError("User with this email already exists");
    }

    // Check for existing pending invitation
    const existingInvitation = await prisma.adminInvitation.findFirst({
      where: {
        email: email.toLowerCase(),
        status: "PENDING",
        expiresAt: { gt: new Date() },
      },
    });

    if (existingInvitation) {
      throw new ConflictError(
        "Pending invitation already exists for this email"
      );
    }

    // Generate invitation token
    const invitationToken = crypto.randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + this.INVITATION_EXPIRES);

    // Create invitation
    const invitation = await prisma.adminInvitation.create({
      data: {
        email: email.toLowerCase(),
        invitationToken,
        sections,
        permissions,
        invitedBy: inviterId,
        expiresAt,
        // Store optional division/functions assignment with invitation
        ...(mapDivision((inviteData as any).division)
          ? { division: mapDivision((inviteData as any).division) }
          : {}),
        ...(Array.isArray((inviteData as any).functions)
          ? { functions: (inviteData as any).functions }
          : {}),
      },
    });

    // Send invitation email
    await emailService.sendAdminInvitation(
      email,
      invitationToken,
      `${inviter.firstName} ${inviter.lastName}`,
      sections,
      message
    );

    return {
      message: "Admin invitation sent successfully",
      invitationId: invitation.id,
    };
  }

  async acceptInvitation(
    acceptData: AdminAcceptInvitation
  ): Promise<{ message: string; user: any }> {
    const { token, password, firstName, lastName } = acceptData;

    // Find valid invitation
    const invitation = await prisma.adminInvitation.findFirst({
      where: {
        invitationToken: token,
        status: "PENDING",
        expiresAt: { gt: new Date() },
      },
    });

    if (!invitation) {
      throw new ValidationError("Invalid or expired invitation token");
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, this.SALT_ROUNDS);

    // Create admin user and accept invitation in transaction
    const result = await prisma.$transaction(async (tx) => {
      // Create user
      const user = await tx.user.create({
        data: {
          email: invitation.email,
          password: hashedPassword,
          firstName,
          lastName,
          fullName: `${firstName} ${lastName}`,
          role: "ADMIN",
          isVerified: true,
          emailVerifiedAt: new Date(),
          invitedBy: invitation.invitedBy,
          invitedAt: invitation.invitedAt,
          // Also apply division/functions if provided with the invitation
          ...((invitation as any).division
            ? { division: (invitation as any).division }
            : {}),
          ...(Array.isArray((invitation as any).functions)
            ? { functions: (invitation as any).functions }
            : {}),
        },
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          role: true,
          createdAt: true,
        },
      });

      // Create admin sections
      for (const section of invitation.sections) {
        await tx.adminSection.create({
          data: {
            userId: user.id,
            section,
            permissions: invitation.permissions,
            assignedBy: invitation.invitedBy,
          },
        });
      }

      // Update invitation status
      await tx.adminInvitation.update({
        where: { id: invitation.id },
        data: {
          status: "ACCEPTED",
          acceptedAt: new Date(),
          userId: user.id,
        },
      });

      return user;
    });

    return {
      message: "Admin account created successfully",
      user: result,
    };
  }

  async getAdminInvitations(adminId: string): Promise<any[]> {
    // Verify admin is super admin
    const admin = await prisma.user.findUnique({
      where: { id: adminId },
      select: { role: true },
    });

    if (!admin || admin.role !== "SUPER_ADMIN") {
      throw new AuthorizationError("Only super admins can view invitations");
    }

    return await prisma.adminInvitation.findMany({
      include: {
        inviter: {
          select: {
            firstName: true,
            lastName: true,
            email: true,
          },
        },
        user: {
          select: {
            firstName: true,
            lastName: true,
            email: true,
          },
        },
      },
      orderBy: { invitedAt: "desc" },
    });
  }

  async revokeInvitation(
    adminId: string,
    invitationId: string
  ): Promise<{ message: string }> {
    // Verify admin is super admin
    const admin = await prisma.user.findUnique({
      where: { id: adminId },
      select: { role: true },
    });

    if (!admin || admin.role !== "SUPER_ADMIN") {
      throw new AuthorizationError("Only super admins can revoke invitations");
    }

    const invitation = await prisma.adminInvitation.findUnique({
      where: { id: invitationId },
    });

    if (!invitation) {
      throw new NotFoundError("Invitation not found");
    }

    if (invitation.status !== "PENDING") {
      throw new ValidationError("Can only revoke pending invitations");
    }

    await prisma.adminInvitation.update({
      where: { id: invitationId },
      data: { status: "REVOKED" },
    });

    return { message: "Invitation revoked successfully" };
  }

  async getAdmins(superAdminId: string): Promise<any[]> {
    // Verify super admin
    const superAdmin = await prisma.user.findUnique({
      where: { id: superAdminId },
      select: { role: true },
    });

    if (!superAdmin || superAdmin.role !== "SUPER_ADMIN") {
      throw new AuthorizationError("Only super admins can view admin list");
    }

    return await prisma.user.findMany({
      where: {
        role: { in: ["ADMIN", "SUPER_ADMIN"] },
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        isActive: true,
        lastLoginAt: true,
        createdAt: true,
        adminSections: {
          select: {
            section: true,
            permissions: true,
            assignedAt: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
    });
  }

  async updateAdminSections(
    superAdminId: string,
    adminId: string,
    sections: { section: PlatformSection; permissions: AdminPermission[] }[]
  ): Promise<{ message: string }> {
    // Verify super admin
    const superAdmin = await prisma.user.findUnique({
      where: { id: superAdminId },
      select: { role: true },
    });

    if (!superAdmin || superAdmin.role !== "SUPER_ADMIN") {
      throw new AuthorizationError(
        "Only super admins can update admin sections"
      );
    }

    // Verify target is admin
    const admin = await prisma.user.findUnique({
      where: { id: adminId },
      select: { role: true },
    });

    if (!admin || admin.role !== "ADMIN") {
      throw new ValidationError("Target user is not an admin");
    }

    // Update sections in transaction
    await prisma.$transaction(async (tx) => {
      // Remove existing sections
      await tx.adminSection.deleteMany({
        where: { userId: adminId },
      });

      // Add new sections
      for (const sectionData of sections) {
        await tx.adminSection.create({
          data: {
            userId: adminId,
            section: sectionData.section,
            permissions: sectionData.permissions,
            assignedBy: superAdminId,
          },
        });
      }
    });

    return { message: "Admin sections updated successfully" };
  }

  // Assign division/functions to an admin (in addition to adminSections)
  async updateAdminDivision(
    superAdminId: string,
    adminId: string,
    division?: string | null,
    functions?: string[] | null
  ): Promise<{ message: string }> {
    // Verify super admin
    const superAdmin = await prisma.user.findUnique({
      where: { id: superAdminId },
      select: { role: true },
    });
    if (!superAdmin || superAdmin.role !== "SUPER_ADMIN") {
      throw new AuthorizationError(
        "Only super admins can update admin division and functions"
      );
    }

    // Verify target user exists and is ADMIN
    const admin = await prisma.user.findUnique({
      where: { id: adminId },
      select: { role: true },
    });
    if (!admin || admin.role !== "ADMIN") {
      throw new ValidationError("Target user is not an admin");
    }

    await prisma.user.update({
      where: { id: adminId },
      data: {
        ...(division !== null
          ? { division: mapDivision(division) || null }
          : { division: null }),
        ...(Array.isArray(functions)
          ? { functions }
          : functions === null
          ? { functions: [] }
          : {}),
      },
    });

    return { message: "Admin division/functions updated successfully" };
  }

  async changeAdminPassword(
    superAdminId: string,
    adminId: string,
    newPassword: string
  ): Promise<{ message: string }> {
    // Verify super admin
    const superAdmin = await prisma.user.findUnique({
      where: { id: superAdminId },
      select: { role: true },
    });

    if (!superAdmin || superAdmin.role !== "SUPER_ADMIN") {
      throw new AuthorizationError(
        "Only super admins can change admin passwords"
      );
    }

    // Verify target is admin
    const admin = await prisma.user.findUnique({
      where: { id: adminId },
      select: { role: true },
    });

    if (!admin || admin.role !== "ADMIN") {
      throw new ValidationError("Target user is not an admin");
    }

    const hashedPassword = await bcrypt.hash(newPassword, this.SALT_ROUNDS);

    await prisma.user.update({
      where: { id: adminId },
      data: {
        password: hashedPassword,
        // Force re-login
        refreshToken: null,
        refreshTokenExpires: null,
      },
    });

    return { message: "Admin password changed successfully" };
  }

  async deactivateAdmin(
    superAdminId: string,
    adminId: string
  ): Promise<{ message: string }> {
    // Verify super admin
    const superAdmin = await prisma.user.findUnique({
      where: { id: superAdminId },
      select: { role: true },
    });

    if (!superAdmin || superAdmin.role !== "SUPER_ADMIN") {
      throw new AuthorizationError("Only super admins can deactivate admins");
    }

    // Verify target is admin
    const admin = await prisma.user.findUnique({
      where: { id: adminId },
      select: { role: true },
    });

    if (!admin || admin.role !== "ADMIN") {
      throw new ValidationError("Target user is not an admin");
    }

    await prisma.user.update({
      where: { id: adminId },
      data: {
        isActive: false,
        refreshToken: null,
        refreshTokenExpires: null,
      },
    });

    return { message: "Admin deactivated successfully" };
  }

  async reactivateAdmin(
    superAdminId: string,
    adminId: string
  ): Promise<{ message: string }> {
    // Verify super admin
    const superAdmin = await prisma.user.findUnique({
      where: { id: superAdminId },
      select: { role: true },
    });

    if (!superAdmin || superAdmin.role !== "SUPER_ADMIN") {
      throw new AuthorizationError("Only super admins can reactivate admins");
    }

    await prisma.user.update({
      where: { id: adminId },
      data: { isActive: true },
    });

    return { message: "Admin reactivated successfully" };
  }

  async getAdminDashboard(adminId: string, role: string): Promise<any> {
    if (role === "SUPER_ADMIN") {
      // Super admin gets full dashboard
      return await this.getSuperAdminDashboard();
    } else {
      // Regular admin gets section-specific dashboard
      return await this.getRegularAdminDashboard(adminId);
    }
  }

  async getAdminStats(adminId: string, role: string): Promise<any> {
    if (role === "SUPER_ADMIN") {
      return await this.getSuperAdminStats();
    } else {
      return await this.getRegularAdminStats(adminId);
    }
  }

  private async getSuperAdminDashboard(): Promise<any> {
    const [
      totalUsers,
      totalAdmins,
      pendingInvitations,
      recentActivity,
    ] = await Promise.all([
      prisma.user.count({ where: { isActive: true } }),
      prisma.user.count({
        where: { role: { in: ["ADMIN", "SUPER_ADMIN"] }, isActive: true },
      }),
      prisma.adminInvitation.count({ where: { status: "PENDING" } }),
      this.getRecentActivity(),
    ]);

    return {
      overview: {
        totalUsers,
        totalAdmins,
        pendingInvitations,
      },
      recentActivity,
    };
  }

  private async getRegularAdminDashboard(adminId: string): Promise<any> {
    const adminSections = await prisma.adminSection.findMany({
      where: { userId: adminId },
      select: { section: true, permissions: true },
    });

    // Get section-specific data based on admin's assigned sections
    const dashboardData: any = {
      sections: adminSections,
      data: {},
    };

    for (const section of adminSections) {
      switch (section.section) {
        case "USER_MANAGEMENT":
          dashboardData.data.users = await this.getUserManagementData();
          break;
        case "NRC_VOLUNTEERS":
          dashboardData.data.nrcVolunteers = await this.getNRCVolunteersData();
          break;
        case "NOMINATIONS":
          dashboardData.data.nominations = await this.getNominationsData();
          break;
        // Add more sections as needed
      }
    }

    return dashboardData;
  }

  private async getSuperAdminStats(): Promise<any> {
    const [userStats, adminStats, systemStats] = await Promise.all([
      this.getUserStats(),
      this.getAdminManagementStats(),
      this.getSystemStats(),
    ]);

    return {
      users: userStats,
      admins: adminStats,
      system: systemStats,
    };
  }

  private async getRegularAdminStats(adminId: string): Promise<any> {
    const adminSections = await prisma.adminSection.findMany({
      where: { userId: adminId },
      select: { section: true },
    });

    const stats: any = {};

    for (const section of adminSections) {
      switch (section.section) {
        case "USER_MANAGEMENT":
          stats.users = await this.getUserStats();
          break;
        case "NRC_VOLUNTEERS":
          stats.nrcVolunteers = await this.getNRCStats();
          break;
        // Add more sections as needed
      }
    }

    return stats;
  }

  private async getRecentActivity(): Promise<any[]> {
    return await prisma.auditLog.findMany({
      take: 10,
      orderBy: { createdAt: "desc" },
      include: {
        user: {
          select: {
            firstName: true,
            lastName: true,
            email: true,
          },
        },
      },
    });
  }

  private async getUserManagementData(): Promise<any> {
    const [totalUsers, newUsersThisMonth, verifiedUsers] = await Promise.all([
      prisma.user.count({ where: { isActive: true } }),
      prisma.user.count({
        where: {
          isActive: true,
          createdAt: {
            gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
          },
        },
      }),
      prisma.user.count({ where: { isActive: true, isVerified: true } }),
    ]);

    return {
      totalUsers,
      newUsersThisMonth,
      verifiedUsers,
      verificationRate: totalUsers > 0 ? (verifiedUsers / totalUsers) * 100 : 0,
    };
  }

  private async getNRCVolunteersData(): Promise<any> {
    // This will be implemented when NRC module is created
    return {
      totalVolunteers: 0,
      activeVolunteers: 0,
      pendingApplications: 0,
    };
  }

  private async getNominationsData(): Promise<any> {
    // This will be implemented when nominations module is created
    return {
      totalNominations: 0,
      pendingNominations: 0,
      approvedNominations: 0,
    };
  }

  private async getUserStats(): Promise<any> {
    const [
      totalUsers,
      activeUsers,
      newUsersToday,
      newUsersThisWeek,
      newUsersThisMonth,
    ] = await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { isActive: true } }),
      prisma.user.count({
        where: {
          createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) },
        },
      }),
      prisma.user.count({
        where: {
          createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
        },
      }),
      prisma.user.count({
        where: {
          createdAt: {
            gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
          },
        },
      }),
    ]);

    return {
      total: totalUsers,
      active: activeUsers,
      newToday: newUsersToday,
      newThisWeek: newUsersThisWeek,
      newThisMonth: newUsersThisMonth,
    };
  }

  private async getAdminManagementStats(): Promise<any> {
    const [
      totalAdmins,
      activeAdmins,
      pendingInvitations,
      expiredInvitations,
    ] = await Promise.all([
      prisma.user.count({ where: { role: { in: ["ADMIN", "SUPER_ADMIN"] } } }),
      prisma.user.count({
        where: { role: { in: ["ADMIN", "SUPER_ADMIN"] }, isActive: true },
      }),
      prisma.adminInvitation.count({ where: { status: "PENDING" } }),
      prisma.adminInvitation.count({ where: { status: "EXPIRED" } }),
    ]);

    return {
      total: totalAdmins,
      active: activeAdmins,
      pendingInvitations,
      expiredInvitations,
    };
  }

  private async getSystemStats(): Promise<any> {
    // Basic system statistics
    return {
      uptime: process.uptime(),
      memoryUsage: process.memoryUsage(),
      nodeVersion: process.version,
    };
  }

  private async getNRCStats(): Promise<any> {
    // This will be implemented when NRC module is created
    return {
      totalApplications: 0,
      approvedVolunteers: 0,
      pendingApplications: 0,
    };
  }
}

export const adminService = new AdminService();
