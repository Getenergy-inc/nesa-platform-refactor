import { prisma } from '@/shared/database/postgresql';
import { emailService } from '@/modules/notifications/services/emailService';
import { ValidationError, NotFoundError } from '@/shared/utils/errors';
import { generateToken, generateRefreshToken } from '@/shared/middleware/auth';

export type OtpPurpose = 'LOGIN' | 'VERIFY_EMAIL' | 'PASSWORD_RESET';

class OtpService {
  private readonly OTP_EXPIRES = 10 * 60 * 1000; // 10 minutes

  private generateCode(): string {
    // 6-digit numeric code
    return (Math.floor(100000 + Math.random() * 900000)).toString();
  }

  /**
   * Send welcome bonus email after email verification (async, don't block)
   */
  private async sendWelcomeBonusEmailAsync(user: any): Promise<void> {
    try {
      // Get user's wallet and AGC bonus info
      const wallet = await prisma.wallet.findUnique({
        where: { userId: user.id },
        select: {
          agcWithdrawableBalance: true,
          agcLockedBalance: true,
        }
      });

      if (!wallet) {
        console.warn(`No wallet found for user ${user.id}, skipping welcome bonus email`);
        return;
      }

      // Determine bonus amount and type
      const withdrawableBonus = wallet.agcWithdrawableBalance || 0;
      const lockedBonus = wallet.agcLockedBalance || 0;
      const totalBonus = withdrawableBonus + lockedBonus;

      if (totalBonus > 0) {
        const bonusType = withdrawableBonus > 0 ? 'withdrawable' : 'non-withdrawable';
        const userName = user.firstName || user.fullName?.split(' ')[0] || 'Member';
        
        await emailService.sendWelcomeWithBonusEmail(
          user.email,
          userName,
          totalBonus,
          bonusType
        );
      }
    } catch (error) {
      console.error('Failed to send welcome bonus email:', error);
      // Don't throw - this is a non-critical operation
    }
  }

  async sendOtp(email: string, purpose: OtpPurpose): Promise<void> {
    if (!email) throw new ValidationError('Email is required');

    const user = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
    if (!user) throw new NotFoundError('User not found');

    // For PASSWORD_RESET purpose, ensure we set a reset token in addition to OTP (optional)
    const code = this.generateCode();
    const otpExpires = new Date(Date.now() + this.OTP_EXPIRES);

    await prisma.user.update({
      where: { id: user.id },
      data: {
        otpCode: code,
        otpExpires,
        otpPurpose: purpose
      }
    });

    // Send via email (include friendly name if available so templates can show it)
    const userName = user.firstName || user.fullName?.split(' ')[0] || user.email;
    await emailService.sendOtpEmail(email, code, purpose, userName);
  }

  async verifyOtp(email: string, code: string, purpose?: OtpPurpose): Promise<{ tokens?: { accessToken: string; refreshToken: string; expiresIn: number }, user?: { id: string; email: string; role: string; isVerified: boolean } }> {
    if (!email || !code) throw new ValidationError('Email and code are required');

    const user = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
    if (!user) throw new NotFoundError('User not found');

    if (!user.otpCode || !user.otpExpires || !user.otpPurpose) {
      throw new ValidationError('No active OTP found');
    }

    // Auto-detect purpose from stored OTP; ignore provided purpose if mismatched
    const resolvedPurpose: OtpPurpose = user.otpPurpose as OtpPurpose;

    if (user.otpExpires < new Date()) {
      throw new ValidationError('OTP expired');
    }

    if (user.otpCode !== code) {
      throw new ValidationError('Invalid OTP code');
    }

    // Clear OTP first
    await prisma.user.update({
      where: { id: user.id },
      data: {
        otpCode: null,
        otpExpires: null,
        otpPurpose: null
      }
    });

    // If verifying email via OTP, mark verified
    if (resolvedPurpose === 'VERIFY_EMAIL' && !user.isVerified) {
      await prisma.user.update({
        where: { id: user.id },
        data: {
          isVerified: true,
          emailVerifiedAt: new Date(),
          emailVerificationToken: null,
          emailVerificationExpires: null
        }
      });

      // Send welcome bonus email after verification (async, don't wait)
      this.sendWelcomeBonusEmailAsync(user).catch(err => {
        console.error('Failed to send welcome bonus email:', err);
      });
    }

    // For LOGIN purpose, issue tokens
    if (resolvedPurpose === 'LOGIN') {
      if (!user.isVerified) {
        throw new ValidationError('Email not verified');
      }

      // Check if this is first login
      const isFirstLogin = !user.lastLoginAt;

      const accessToken = generateToken({ userId: user.id, email: user.email, role: user.role });
      const refreshToken = generateRefreshToken({ userId: user.id, email: user.email, role: user.role });

      await prisma.user.update({
        where: { id: user.id },
        data: {
          refreshToken,
          refreshTokenExpires: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
          lastLoginAt: new Date(),
          loginAttempts: 0,
          lockUntil: null
        }
      });

      // Fetch full user details including wallet, chapter, and profile
      const [fullUser, wallet, chapterMembership] = await Promise.all([
        prisma.user.findUnique({
          where: { id: user.id },
          select: {
            id: true,
            email: true,
            firstName: true,
            lastName: true,
            fullName: true,
            phone: true,
            role: true,
            accountType: true,
            intents: true,
            isVerified: true,
            isActive: true,
            country: true,
            state: true,
            city: true,
            gender: true,
            dateOfBirth: true,
            division: true,
            functions: true,
            organizationName: true,
            organizationType: true,
            referralCode: true,
            profileImage: true,
            bio: true,
            createdAt: true,
            lastLoginAt: true,
            adminSections: {
              select: {
                section: true,
                permissions: true
              }
            }
          }
        }),
        prisma.wallet.findUnique({
          where: { userId: user.id },
          select: {
            id: true,
            balance: true,
            agcWithdrawableBalance: true,
            agcLockedBalance: true,
            reserved: true,
            lastUpdated: true
          }
        }),
        prisma.chapterMembership.findFirst({
          where: { userId: user.id },
          include: {
            chapter: {
              select: {
                id: true,
                name: true,
                country: true,
                region: true,
                type: true,
                leaderId: true,
                memberCount: true,
                createdAt: true,
                updatedAt: true,
                isActive: true
              }
            }
          }
        })
      ]);

      const userResponse = {
        ...fullUser,
        wallet: wallet ? {
          id: wallet.id,
          balance: wallet.balance,
          agcWithdrawableBalance: wallet.agcWithdrawableBalance,
          agcLockedBalance: wallet.agcLockedBalance,
          totalAgc: (wallet.agcWithdrawableBalance || 0) + (wallet.agcLockedBalance || 0),
          reserved: wallet.reserved,
          lastUpdated: wallet.lastUpdated
        } : null,
        chapter: chapterMembership?.chapter || null,
        chapterJoinedAt: chapterMembership?.joinedAt || null,
        isFirstLogin
      };

      return {
        tokens: {
          accessToken,
          refreshToken,
          expiresIn: 7 * 24 * 60 * 60
        },
        user: userResponse as any
      };
    }

    // PASSWORD_RESET or other non-token purposes return empty object
    return {};
  }
}

export const otpService = new OtpService();