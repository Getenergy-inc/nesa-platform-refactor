/* eslint-disable @typescript-eslint/no-explicit-any */
import bcrypt from "bcryptjs";
import crypto from "crypto";
import { prisma } from "@/shared/database/postgresql";
import { otpService } from "./otpService";
import { config } from "@/config";
import { chapterService } from "@/modules/chapters/services/chapterService";
import { walletService } from "@/modules/wallet/services/walletService";
import {
  mapAccountType,
  mapIntents,
  inferRole,
  computeSignupBonus,
  mapGender,
  mapDivision,
} from "@/modules/auth/utils/intentMapping";
import { ConflictError, ValidationError } from "@/shared/utils/errors";
import { AccountType, UserIntent } from "@/shared/types";

export class SignupFlowService {
  private readonly SALT_ROUNDS = config.security.bcryptSaltRounds;
  private readonly EMAIL_VERIFICATION_EXPIRES = 24 * 60 * 60 * 1000; // 24 hours
  private readonly pendingSignups = new Map<string, Promise<any>>(); // Email -> Promise

  // Accepts a superset of registration fields from the comprehensive signup flow
  async signup(data: any) {
    const email = data.email?.toLowerCase();

    // Check if there's already a pending signup for this email
    if (this.pendingSignups.has(email)) {
      console.log(
        `⏳ Signup already in progress for ${email}, waiting for completion...`
      );
      try {
        return await this.pendingSignups.get(email);
      } catch (error) {
        // If the pending signup failed, remove it and continue
        this.pendingSignups.delete(email);
        throw error;
      }
    }

    // Create a new signup promise and store it
    const signupPromise = this.performSignup(data);
    this.pendingSignups.set(email, signupPromise);

    try {
      const result = await signupPromise;
      this.pendingSignups.delete(email);
      return result;
    } catch (error) {
      this.pendingSignups.delete(email);
      throw error;
    }
  }

  private async performSignup(data: any) {
    const {
      email,
      password,
      firstName,
      lastName,
      fullName,
      phoneNumber,
      gender,
      dateOfBirth,
      accountType: accountTypeLabel,
      intents: intentLabels,
      country,
      state,
      organizationName,
      organizationType,
      // optional extras
      division,
      functions,
      referralCode: _referralCode, // TODO: Implement referral system
    } = data;

    console.log("=== BACKEND SIGNUP DATA ===");
    console.log("Received data:", JSON.stringify(data, null, 2));
    console.log("Email:", email);
    console.log(
      "Intent labels:",
      intentLabels,
      "Type:",
      typeof intentLabels,
      "IsArray:",
      Array.isArray(intentLabels)
    );

    if (!email || !password || !country || !state) {
      console.error("Missing required fields:", {
        email: !!email,
        password: !!password,
        country: !!country,
        state: !!state,
      });
      throw new ValidationError(
        "Missing required fields: email, password, country, state"
      );
    }

    // Email uniqueness check with detailed logging
    console.log("Checking for existing user with email:", email.toLowerCase());
    try {
      const existingUser = await prisma.user.findUnique({
        where: { email: email.toLowerCase() },
        select: { id: true, email: true, createdAt: true, isVerified: true },
      });

      if (existingUser) {
        console.log("❌ User already exists:", {
          id: existingUser.id,
          email: existingUser.email,
          createdAt: existingUser.createdAt,
          isVerified: existingUser.isVerified,
        });

        // Provide more helpful error message based on verification status
        if (!existingUser.isVerified) {
          throw new ConflictError(
            `An account with email ${email} exists but is not verified. Please check your email for verification instructions or try logging in.`
          );
        } else {
          throw new ConflictError(
            `An account with email ${email} already exists and is verified. Please try logging in instead.`
          );
        }
      }

      console.log("✅ Email is available for signup");
    } catch (error) {
      if (error instanceof ConflictError) {
        throw error;
      }
      console.error("Database error during user lookup:", error);
      throw new ValidationError("Database error during signup process");
    }

    // Map enums with error handling
    console.log("Mapping account type:", accountTypeLabel);
    const accountType: AccountType | undefined = mapAccountType(
      accountTypeLabel
    );
    console.log("Mapped account type:", accountType);

    console.log("Mapping intents:", intentLabels);
    const intents: UserIntent[] | undefined = mapIntents(intentLabels);
    console.log("Mapped intents:", intents);

    console.log("Mapping division:", division);
    const mappedDivision = mapDivision(division);
    console.log("Mapped division:", mappedDivision);

    // Hash password
    const hashedPassword = await bcrypt.hash(password, this.SALT_ROUNDS);

    // Generate email verification token
    const emailVerificationToken = crypto.randomBytes(32).toString("hex");
    const emailVerificationExpires = new Date(
      Date.now() + this.EMAIL_VERIFICATION_EXPIRES
    );

    // Determine role
    const role = inferRole(intents);

    // Create user (unverified)
    const user = await prisma.user.create({
      data: {
        email: email.toLowerCase(),
        password: hashedPassword,
        firstName,
        lastName,
        fullName:
          fullName ||
          (firstName && lastName ? `${firstName} ${lastName}` : null),
        phone: phoneNumber ?? null,
        gender: mapGender(gender) ?? null,
        dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : null,
        country,
        state,
        accountType: accountType ?? "INDIVIDUAL",
        intents: intents ?? [],
        organizationName: organizationName ?? null,
        organizationType: organizationType ?? null,
        // Optional extras: include only when provided
        ...(mappedDivision ? { division: mappedDivision } : {}),
        ...(Array.isArray(functions)
          ? { functions: { set: functions as string[] } }
          : {}),
        role,
        emailVerificationToken,
        emailVerificationExpires,
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        fullName: true,
        role: true,
        accountType: true,
        isVerified: true,
        country: true,
        state: true,
        createdAt: true,
      },
    });

    // Assign chapter
    const chapter = await chapterService.assign(country, state);
    await chapterService.addMember(user.id, chapter.id);

    // Create wallet + credit bonus
    const wallet = await walletService.createForUser(user.id);
    const agcBonus = computeSignupBonus(
      user.accountType as AccountType,
      intents
    );
    await walletService.creditSignupBonus(wallet.id, agcBonus);

    // Send OTP for email verification instead of token link
    // Welcome bonus email will be sent automatically after OTP verification
    await otpService.sendOtp(user.email, "VERIFY_EMAIL");

    // Generate post-signup actions based on user intents
    const postSignupActions = this.generatePostSignupActions(
      intents || [],
      user.role as string,
      user.accountType as string
    );

    // Create draft applications for approval-based roles
    await this.createDraftApplications(user.id, intents || [], user);

    return {
      user,
      chapter,
      wallet,
      agcBonus,
      message: 'Signup successful! Please check your email for the verification code.',
      postSignupActions,
      dashboardRoute: this.getDashboardRoute(user.role),
      nextSteps: this.getNextSteps(intents || [], user.role),
    };
  }

  // Generate post-signup actions based on user intents
  private generatePostSignupActions(
    intents: UserIntent[],
    userRole: string,
    accountType: string
  ) {
    const actions: Array<{
      type: "application" | "redirect" | "notification";
      action: string;
      data?: any;
    }> = [];

    for (const intent of intents) {
      if (this.requiresApplication(intent)) {
        const applicationType = this.getApplicationType(intent);
        if (applicationType) {
          actions.push({
            type: "application",
            action: "start_application",
            data: {
              applicationType,
              intent,
              message: `Complete your ${intent.toLowerCase()} application to get started.`,
            },
          });
        }
      } else {
        // Direct access intents
        switch (intent) {
          case "VOTE_OR_NOMINATE":
            actions.push({
              type: "redirect",
              action: "/vote",
              data: { message: "You can now vote and nominate candidates!" },
            });
            break;
          case "SPONSOR_OR_CSR_PARTNER":
            actions.push({
              type: "redirect",
              action: "/sponsor/packages",
              data: { message: "Explore our sponsorship packages." },
            });
            break;
          case "JOIN_LOCAL_CHAPTER":
            actions.push({
              type: "redirect",
              action: "/chapters",
              data: { message: "Find and join your local NESA chapter." },
            });
            break;
          default:
            actions.push({
              type: "notification",
              action: "welcome",
              data: {
                message: `Welcome! You can now access ${intent.toLowerCase()} features.`,
              },
            });
        }
      }
    }

    return actions;
  }

  // Check if an intent requires an application process
  private requiresApplication(intent: UserIntent): boolean {
    const applicationRequiredIntents = [
      "APPLY_AS_JUDGE",
      "APPLY_AS_NRC_VOLUNTEER",
      "BECOME_AMBASSADOR",
      "JOIN_NESA_TEAM",
    ];

    return applicationRequiredIntents.includes(intent);
  }

  // Get application type for an intent
  private getApplicationType(intent: UserIntent): string | null {
    const intentToApplicationType: Record<string, string> = {
      APPLY_AS_JUDGE: "JUDGE",
      APPLY_AS_NRC_VOLUNTEER: "NRC_VOLUNTEER",
      BECOME_AMBASSADOR: "AMBASSADOR",
      JOIN_NESA_TEAM: "VOLUNTEER",
    };

    return intentToApplicationType[intent] || null;
  }

  // Create draft applications for approval-based roles
  private async createDraftApplications(
    userId: string,
    intents: UserIntent[],
    user: any
  ) {
    for (const intent of intents) {
      if (this.requiresApplication(intent)) {
        const applicationType = this.getApplicationType(intent);
        if (applicationType) {
          try {
            // Create a draft application with basic user info
            await prisma.application.create({
              data: {
                userId,
                applicationType: applicationType as any,
                status: "DRAFT",
                personalInfo: {
                  fullName:
                    user.fullName ||
                    `${user.firstName} ${user.lastName}`.trim(),
                  email: user.email,
                  phone: user.phone || "",
                  country: user.country,
                  state: user.state,
                  city: user.city,
                },
                professionalInfo: {},
                motivation: {},
              },
            });
          } catch (error) {
            // Log error but don't fail signup
            console.error(
              `Failed to create draft application for ${applicationType}:`,
              error
            );
          }
        }
      }
    }
  }

  // Get dashboard route based on user role
  private getDashboardRoute(userRole: string): string {
    const roleRoutes: Record<string, string> = {
      FREE_MEMBER: "/member/",
      STANDARD_MEMBER: "/member/",
      AMBASSADOR: "/ambassador/dashboard",
      JUDGE: "/judge/dashboard",
      VOLUNTEER: "/volunteer/dashboard",
      NRC_VOLUNTEER: "/get-involved/nrc-volunteer/dashboard",
      INTERN: "/volunteer/dashboard",
      NOMINEE: "/member/",
      SPONSOR: "/sponsor/dashboard",
      CHAPTER_LEADER: "/chapter/dashboard",
      ADMIN: "/admin/dashboard",
      SUPER_ADMIN: "/admin/dashboard",
    };

    return roleRoutes[userRole] || "/member/dashboard";
  }

  // Get next steps based on intents and role
  private getNextSteps(intents: UserIntent[], userRole: string): string[] {
    const steps: string[] = [
      "Verify your email address to activate your account",
      "Complete your profile information",
    ];

    // Add intent-specific steps
    for (const intent of intents) {
      if (this.requiresApplication(intent)) {
        steps.push(
          `Complete your ${intent.toLowerCase().replace("_", " ")} application`
        );
      }
    }

    // Add role-specific steps
    switch (userRole) {
      case "AMBASSADOR":
        steps.push("Set up your ambassador profile and referral links");
        break;
      case "SPONSOR":
        steps.push("Review sponsorship packages and select your tier");
        break;
      case "JUDGE":
        steps.push("Access judge training materials and guidelines");
        break;
      case "NRC_VOLUNTEER":
        steps.push("Review your nominee research targets and guidelines");
        break;
    }

    steps.push("Explore the platform and connect with your local chapter");

    return steps;
  }
}

export const signupFlowService = new SignupFlowService();
