import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

/**
 * Test utilities for auth module
 */

export const testConfig = {
  jwtSecret: 'test-jwt-secret',
  jwtRefreshSecret: 'test-jwt-refresh-secret',
  bcryptSaltRounds: 10,
};

/**
 * Generate a test JWT token
 */
export function generateTestToken(payload: any, expiresIn: string = '1h'): string {
  return jwt.sign(payload, testConfig.jwtSecret, { expiresIn } as jwt.SignOptions);
}

/**
 * Generate a test refresh token
 */
export function generateTestRefreshToken(payload: any, expiresIn: string = '30d'): string {
  return jwt.sign(payload, testConfig.jwtRefreshSecret, { expiresIn } as jwt.SignOptions);
}

/**
 * Hash a password for testing
 */
export async function hashTestPassword(password: string): Promise<string> {
  return bcrypt.hash(password, testConfig.bcryptSaltRounds);
}

/**
 * Create a mock user object
 */
export function createMockUser(overrides: any = {}) {
  return {
    id: 'test-user-id',
    email: 'test@example.com',
    firstName: 'Test',
    lastName: 'User',
    fullName: 'Test User',
    role: 'FREE_MEMBER',
    accountType: 'INDIVIDUAL',
    isVerified: true,
    country: 'Nigeria',
    state: 'Lagos',
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  };
}

/**
 * Create a mock admin user object
 */
export function createMockAdmin(overrides: any = {}) {
  return createMockUser({
    role: 'ADMIN',
    isVerified: true,
    ...overrides,
  });
}

/**
 * Create a mock super admin user object
 */
export function createMockSuperAdmin(overrides: any = {}) {
  return createMockUser({
    role: 'SUPER_ADMIN',
    isVerified: true,
    ...overrides,
  });
}

/**
 * Create a mock admin invitation
 */
export function createMockAdminInvitation(overrides: any = {}) {
  return {
    id: 'invitation-id',
    email: 'admin@example.com',
    invitationToken: 'test-invitation-token',
    sections: ['USER_MANAGEMENT'],
    permissions: ['READ', 'WRITE'],
    invitedBy: 'super-admin-id',
    expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
    invitedAt: new Date(),
    ...overrides,
  };
}

/**
 * Create a mock wallet
 */
export function createMockWallet(overrides: any = {}) {
  return {
    id: 'wallet-id',
    userId: 'test-user-id',
    balance: 100,
    withdrawableBalance: 50,
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  };
}

/**
 * Create a mock chapter
 */
export function createMockChapter(overrides: any = {}) {
  return {
    id: 'chapter-id',
    name: 'Test Chapter',
    type: 'PHYSICAL',
    country: 'Nigeria',
    state: 'Lagos',
    city: 'Lagos',
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  };
}

/**
 * Create mock signup data
 */
export function createMockSignupData(overrides: any = {}) {
  return {
    email: 'test@example.com',
    password: 'ValidPassword123!',
    firstName: 'John',
    lastName: 'Doe',
    country: 'Nigeria',
    state: 'Lagos',
    accountType: 'individual',
    intents: ['vote or nominate'],
    ...overrides,
  };
}

/**
 * Create mock login data
 */
export function createMockLoginData(overrides: any = {}) {
  return {
    email: 'test@example.com',
    password: 'ValidPassword123!',
    ...overrides,
  };
}

/**
 * Create mock OTP data
 */
export function createMockOtpData(overrides: any = {}) {
  return {
    email: 'test@example.com',
    code: '123456',
    purpose: 'LOGIN' as const,
    ...overrides,
  };
}

/**
 * Create mock admin invite data
 */
export function createMockAdminInviteData(overrides: any = {}) {
  return {
    email: 'admin@example.com',
    sections: ['USER_MANAGEMENT'],
    permissions: ['READ', 'WRITE'],
    message: 'Welcome to the team',
    ...overrides,
  };
}

/**
 * Create mock admin accept invitation data
 */
export function createMockAcceptInvitationData(overrides: any = {}) {
  return {
    invitationToken: 'valid-token',
    password: 'AdminPassword123!',
    firstName: 'New',
    lastName: 'Admin',
    ...overrides,
  };
}

/**
 * Mock Prisma transaction
 */
export function mockPrismaTransaction(mockImplementations: any) {
  return jest.fn().mockImplementation(async (callback) => {
    const mockTx = {
      user: {
        create: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        findUnique: jest.fn(),
        findMany: jest.fn(),
        ...mockImplementations.user,
      },
      adminInvitation: {
        create: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        findUnique: jest.fn(),
        ...mockImplementations.adminInvitation,
      },
      adminSection: {
        create: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        findMany: jest.fn(),
        ...mockImplementations.adminSection,
      },
      wallet: {
        create: jest.fn(),
        update: jest.fn(),
        findUnique: jest.fn(),
        ...mockImplementations.wallet,
      },
      ...mockImplementations,
    };
    return callback(mockTx);
  });
}

/**
 * Assert that a password is properly hashed
 */
export function expectHashedPassword(hashedPassword: string, originalPassword: string) {
  expect(hashedPassword).not.toBe(originalPassword);
  expect(hashedPassword).toMatch(/^\$2[aby]\$\d+\$/); // bcrypt hash pattern
}

/**
 * Assert that a token is a valid JWT
 */
export function expectValidJWT(token: string) {
  expect(token).toMatch(/^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+$/);
}

/**
 * Assert that an email is properly formatted
 */
export function expectValidEmail(email: string) {
  expect(email).toMatch(/^[^\s@]+@[^\s@]+\.[^\s@]+$/);
}

/**
 * Assert that a date is within a reasonable range of now
 */
export function expectRecentDate(date: Date, maxAgeMs = 5000) {
  const now = new Date();
  const diff = Math.abs(now.getTime() - date.getTime());
  expect(diff).toBeLessThan(maxAgeMs);
}

/**
 * Assert that an OTP code is valid format
 */
export function expectValidOtpCode(code: string) {
  expect(code).toMatch(/^\d{6}$/);
  expect(parseInt(code)).toBeGreaterThanOrEqual(100000);
  expect(parseInt(code)).toBeLessThanOrEqual(999999);
}

/**
 * Assert that a verification token is valid format
 */
export function expectValidVerificationToken(token: string) {
  expect(token).toMatch(/^[a-f0-9]{64}$/); // 32 bytes hex
}

/**
 * Create a mock Express request object
 */
export function createMockRequest(overrides: any = {}) {
  return {
    body: {},
    params: {},
    query: {},
    headers: {},
    cookies: {},
    user: null,
    ...overrides,
  };
}

/**
 * Create a mock Express response object
 */
export function createMockResponse() {
  const res: any = {
    status: jest.fn().mockReturnThis(),
    json: jest.fn().mockReturnThis(),
    cookie: jest.fn().mockReturnThis(),
    clearCookie: jest.fn().mockReturnThis(),
    send: jest.fn().mockReturnThis(),
  };
  return res;
}

/**
 * Sleep for testing async operations
 */
export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Generate a random email for testing
 */
export function generateRandomEmail(): string {
  const randomString = Math.random().toString(36).substring(2, 15);
  return `test-${randomString}@example.com`;
}

/**
 * Generate a random password for testing
 */
export function generateRandomPassword(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
  let password = '';
  for (let i = 0; i < 12; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return password;
}

export default {
  testConfig,
  generateTestToken,
  generateTestRefreshToken,
  hashTestPassword,
  createMockUser,
  createMockAdmin,
  createMockSuperAdmin,
  createMockAdminInvitation,
  createMockWallet,
  createMockChapter,
  createMockSignupData,
  createMockLoginData,
  createMockOtpData,
  createMockAdminInviteData,
  createMockAcceptInvitationData,
  mockPrismaTransaction,
  expectHashedPassword,
  expectValidJWT,
  expectValidEmail,
  expectRecentDate,
  expectValidOtpCode,
  expectValidVerificationToken,
  createMockRequest,
  createMockResponse,
  sleep,
  generateRandomEmail,
  generateRandomPassword,
};