# Auth Module Tests

This directory contains comprehensive tests for the authentication module of the NESA-Africa platform.

## Test Structure

### Test Files

1. **`auth.test.ts`** - Main unit test suite covering all auth services and utilities
2. **`signupFlowService.test.ts`** - Detailed tests for the signup flow service
3. **`adminService.test.ts`** - Detailed tests for admin management functionality
4. **`otpService.test.ts`** - Detailed tests for OTP (One-Time Password) functionality
5. **`auth.integration.test.ts`** - Integration tests for API endpoints
6. **`testUtils.ts`** - Utility functions and helpers for testing
7. **`runTests.ts`** - Test runner script for selective test execution

### Test Coverage

The test suite covers:

- ✅ **User Registration & Signup Flow**
  - Account creation with various account types
  - Email verification process
  - Intent mapping and role inference
  - Wallet creation and bonus assignment
  - Input validation and error handling

- ✅ **Authentication & Authorization**
  - Login with email/password
  - JWT token generation and validation
  - Refresh token functionality
  - Role-based access control
  - Session management

- ✅ **OTP (One-Time Password) System**
  - OTP generation and sending
  - OTP verification for different purposes (LOGIN, VERIFY_EMAIL, PASSWORD_RESET)
  - Expiration handling
  - Rate limiting

- ✅ **Admin Management**
  - Admin invitation system
  - Invitation acceptance and account creation
  - Division and function assignment
  - Admin dashboard data
  - Super admin privileges

- ✅ **API Endpoints**
  - Request/response validation
  - Authentication middleware
  - Rate limiting
  - Error handling
  - Security measures

- ✅ **Utility Functions**
  - Intent mapping
  - Account type mapping
  - Gender mapping
  - Division mapping
  - Role inference
  - Signup bonus calculation

## Running Tests

### Prerequisites

```bash
# Install dependencies
npm install

# Set up test environment variables
cp .env.example .env.test
```

### Run All Tests

```bash
# Run all auth module tests
npm run test:auth

# Or using Jest directly
npx jest src/modules/auth/test --coverage
```

### Run Specific Test Suites

```bash
# Run only unit tests
npm run test:auth unit

# Run only integration tests
npm run test:auth integration

# Run specific service tests
npm run test:auth signup
npm run test:auth admin
npm run test:auth otp

# Run multiple specific suites
npm run test:auth unit admin
```

### Run Individual Test Files

```bash
# Run signup flow tests
npx jest src/modules/auth/test/signupFlowService.test.ts

# Run admin service tests
npx jest src/modules/auth/test/adminService.test.ts

# Run OTP service tests
npx jest src/modules/auth/test/otpService.test.ts

# Run integration tests
npx jest src/modules/auth/test/auth.integration.test.ts
```

### Watch Mode

```bash
# Run tests in watch mode
npx jest src/modules/auth/test --watch

# Run specific test file in watch mode
npx jest src/modules/auth/test/auth.test.ts --watch
```

## Test Configuration

### Environment Variables

The tests use the following environment variables:

```env
NODE_ENV=test
DATABASE_URL=postgresql://test:test@localhost:5432/nesa_africa_test
MONGODB_URI=mongodb://localhost:27017/nesa_africa_test
JWT_SECRET=test-jwt-secret
JWT_REFRESH_SECRET=test-jwt-refresh-secret
```

### Mocked Services

The following external services are mocked in tests:

- **Database (Prisma)** - All database operations are mocked
- **Email Service** - Email sending is mocked
- **Cloudinary** - File upload service is mocked
- **SendGrid** - Email delivery service is mocked

## Test Utilities

### `testUtils.ts`

This file provides helpful utilities for testing:

```typescript
import {
  createMockUser,
  createMockSignupData,
  generateTestToken,
  expectValidJWT,
  expectHashedPassword
} from './testUtils';

// Create mock data
const user = createMockUser({ role: 'ADMIN' });
const signupData = createMockSignupData();

// Generate test tokens
const token = generateTestToken({ userId: 'user-id' });

// Assertions
expectValidJWT(token);
expectHashedPassword(hashedPassword, originalPassword);
```

### Mock Functions

Common mock patterns used in tests:

```typescript
// Mock Prisma operations
mockedPrisma.user.findUnique.mockResolvedValue(mockUser);
mockedPrisma.user.create.mockResolvedValue(createdUser);

// Mock email service
mockedEmailService.sendVerificationEmail.mockResolvedValue();

// Mock transaction
mockedPrisma.$transaction.mockImplementation(async (callback) => {
  return callback(mockTx);
});
```

## Test Scenarios

### User Registration Tests

- ✅ Valid registration with minimal data
- ✅ Registration with all optional fields
- ✅ Email uniqueness validation
- ✅ Password strength validation
- ✅ Account type mapping
- ✅ Intent mapping and role inference
- ✅ Division and function assignment
- ✅ Wallet creation with signup bonus
- ✅ Email verification token generation

### Authentication Tests

- ✅ Successful login with valid credentials
- ✅ Login failure with invalid credentials
- ✅ Unverified user login prevention
- ✅ JWT token generation and validation
- ✅ Refresh token functionality
- ✅ Token expiration handling
- ✅ Logout and token invalidation

### OTP Tests

- ✅ OTP generation and sending
- ✅ OTP verification for different purposes
- ✅ OTP expiration handling
- ✅ Invalid OTP code handling
- ✅ Rate limiting on OTP requests
- ✅ Email delivery for OTP codes

### Admin Management Tests

- ✅ Admin invitation by super admin
- ✅ Invitation acceptance and account creation
- ✅ Division and function assignment
- ✅ Admin dashboard data retrieval
- ✅ Permission validation
- ✅ Invitation expiration handling

### API Integration Tests

- ✅ Request validation
- ✅ Authentication middleware
- ✅ Rate limiting
- ✅ Error response formatting
- ✅ Security headers
- ✅ Cookie handling

## Coverage Goals

The test suite aims for:

- **Line Coverage**: > 90%
- **Function Coverage**: > 95%
- **Branch Coverage**: > 85%
- **Statement Coverage**: > 90%

## Best Practices

### Writing Tests

1. **Descriptive Test Names**: Use clear, descriptive test names that explain what is being tested
2. **Arrange-Act-Assert**: Structure tests with clear setup, execution, and assertion phases
3. **Mock External Dependencies**: Mock all external services and databases
4. **Test Edge Cases**: Include tests for error conditions and edge cases
5. **Use Test Utilities**: Leverage the provided test utilities for consistency

### Test Organization

1. **Group Related Tests**: Use `describe` blocks to group related test cases
2. **Setup and Teardown**: Use `beforeEach` and `afterEach` for test setup and cleanup
3. **Clear Mocks**: Always clear mocks between tests to avoid interference
4. **Isolated Tests**: Ensure tests can run independently and in any order

### Error Testing

1. **Test Error Conditions**: Include tests for all error scenarios
2. **Validate Error Messages**: Check that appropriate error messages are returned
3. **Test Error Types**: Verify that correct error types are thrown
4. **Handle Async Errors**: Properly test async error conditions

## Debugging Tests

### Common Issues

1. **Mock Not Working**: Ensure mocks are properly cleared between tests
2. **Async Issues**: Use proper async/await patterns in tests
3. **Database Mocks**: Verify that all database operations are mocked
4. **Environment Variables**: Check that test environment variables are set

### Debug Commands

```bash
# Run tests with debug output
DEBUG=* npm run test:auth

# Run specific test with verbose output
npx jest src/modules/auth/test/auth.test.ts --verbose

# Run tests with coverage report
npx jest src/modules/auth/test --coverage --coverageReporters=html
```

## Contributing

When adding new features to the auth module:

1. **Add Tests First**: Write tests for new functionality before implementation
2. **Update Existing Tests**: Modify existing tests if behavior changes
3. **Test Edge Cases**: Include tests for error conditions and edge cases
4. **Update Documentation**: Update this README if adding new test files or utilities
5. **Maintain Coverage**: Ensure test coverage remains above target thresholds

## Continuous Integration

The tests are designed to run in CI/CD environments:

- All external dependencies are mocked
- Tests use deterministic data and timing
- Environment variables are properly configured
- Tests can run in parallel safely
- Coverage reports are generated for monitoring

For more information about the auth module implementation, see the main [Auth Module README](../README.md).