import request from 'supertest';
import App from '../../../../app';
import { prisma } from '@/shared/database/postgresql';
import { emailService } from '@/modules/notifications/services/emailService';
import { 
  createMockUser, 
  createMockSignupData, 
  createMockLoginData,
  createMockOtpData,
  createMockAdminInviteData,
  generateTestToken,
  hashTestPassword
} from './testUtils';

// Mock external services
jest.mock('@/modules/notifications/services/emailService');
jest.mock('@/shared/database/postgresql', () => ({
  prisma: {
    user: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      count: jest.fn(),
    },
    adminInvitation: {
      findUnique: jest.fn(),
      create: jest.fn(),
      count: jest.fn(),
    },
    adminSection: {
      create: jest.fn(),
      findMany: jest.fn(),
    },
    wallet: {
      create: jest.fn(),
      findUnique: jest.fn(),
    },
    chapterMembership: {
      findFirst: jest.fn(),
    },
    $transaction: jest.fn(),
  },
}));

const mockedPrisma = prisma as jest.Mocked<typeof prisma>;
const mockedEmailService = emailService as jest.Mocked<typeof emailService>;

describe('Auth API Integration Tests', () => {
  let app: App;

  beforeAll(async () => {
    app = new App();
  });

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('POST /api/v1/auth/signup-flow', () => {
    beforeEach(() => {
      mockedPrisma.user.findUnique.mockResolvedValue(null);
      mockedPrisma.user.create.mockResolvedValue(createMockUser() as any);
      mockedPrisma.wallet.create.mockResolvedValue({
        id: 'wallet-id',
        userId: 'user-id',
        balance: 2,
        withdrawableBalance: 0,
      } as any);
      mockedEmailService.sendVerificationEmail.mockResolvedValue();
    });

    it('should create user successfully with valid data', async () => {
      const signupData = createMockSignupData();

      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(signupData)
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('Account created successfully! Please check your email for verification.');
      expect(response.body.data).toHaveProperty('user');
      expect(response.body.data).toHaveProperty('tokens');
      expect(response.headers['set-cookie']).toBeDefined(); // refresh token cookie
    });

    it('should validate required fields', async () => {
      const invalidData = {
        email: 'invalid-email',
        password: '123', // too short
        // missing required fields
      };

      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(invalidData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Validation failed');
      expect(response.body.errors).toBeDefined();
    });

    it('should handle duplicate email', async () => {
      mockedPrisma.user.findUnique.mockResolvedValue(createMockUser() as any);

      const signupData = createMockSignupData();

      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(signupData)
        .expect(409);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('already exists');
    });

    it('should validate email format', async () => {
      const signupData = createMockSignupData({
        email: 'invalid-email-format',
      });

      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(signupData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.errors).toContain('Invalid email format');
    });

    it('should validate password strength', async () => {
      const signupData = createMockSignupData({
        password: 'weak',
      });

      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(signupData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.errors).toContain('Password must be at least 8 characters');
    });

    it('should validate account type', async () => {
      const signupData = createMockSignupData({
        accountType: 'invalid-type',
      });

      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(signupData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.errors).toContain('Invalid account type');
    });

    it('should validate intents', async () => {
      const signupData = createMockSignupData({
        intents: ['invalid intent'],
      });

      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(signupData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.errors).toContain('Invalid intent');
    });
  });

  describe('POST /api/v1/auth/login', () => {
    beforeEach(() => {
      const mockUser = createMockUser({
        password: '$2b$12$hashedpassword', // mock hashed password
      });
      mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
    });

    it('should login successfully with valid credentials', async () => {
      const loginData = createMockLoginData();

      // Mock bcrypt comparison to return true
      jest.doMock('bcryptjs', () => ({
        compare: jest.fn().mockResolvedValue(true),
      }));

      const response = await request(app.app)
        .post('/api/v1/auth/login')
        .send(loginData)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('Login successful');
      expect(response.body.data).toHaveProperty('user');
      expect(response.body.data).toHaveProperty('tokens');
      expect(response.headers['set-cookie']).toBeDefined(); // refresh token cookie
    });

    it('should validate login data', async () => {
      const invalidData = {
        email: 'invalid-email',
        password: '',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/login')
        .send(invalidData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Validation failed');
    });

    it('should handle non-existent user', async () => {
      mockedPrisma.user.findUnique.mockResolvedValue(null);

      const loginData = createMockLoginData();

      const response = await request(app.app)
        .post('/api/v1/auth/login')
        .send(loginData)
        .expect(401);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Invalid credentials');
    });

    it('should handle unverified user', async () => {
      const unverifiedUser = createMockUser({ isVerified: false });
      mockedPrisma.user.findUnique.mockResolvedValue(unverifiedUser as any);

      const loginData = createMockLoginData();

      const response = await request(app.app)
        .post('/api/v1/auth/login')
        .send(loginData)
        .expect(401);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('verify your email');
    });
  });

  describe('POST /api/v1/auth/send-otp', () => {
    beforeEach(() => {
      mockedPrisma.user.findUnique.mockResolvedValue(createMockUser() as any);
      mockedPrisma.user.update.mockResolvedValue({} as any);
      mockedEmailService.sendOtpEmail.mockResolvedValue();
    });

    it('should send OTP successfully', async () => {
      const otpData = {
        email: 'test@example.com',
        purpose: 'LOGIN',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/send-otp')
        .send(otpData)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('OTP sent successfully');
    });

    it('should validate OTP request data', async () => {
      const invalidData = {
        email: 'invalid-email',
        purpose: 'INVALID_PURPOSE',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/send-otp')
        .send(invalidData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Validation failed');
    });

    it('should handle non-existent user', async () => {
      mockedPrisma.user.findUnique.mockResolvedValue(null);

      const otpData = {
        email: 'nonexistent@example.com',
        purpose: 'LOGIN',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/send-otp')
        .send(otpData)
        .expect(404);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('User not found');
    });

    it('should apply rate limiting', async () => {
      const otpData = {
        email: 'test@example.com',
        purpose: 'LOGIN',
      };

      // Make multiple requests quickly
      const requests = Array(10).fill(null).map(() =>
        request(app.app)
          .post('/api/v1/auth/send-otp')
          .send(otpData)
      );

      const responses = await Promise.all(requests);

      // Some requests should be rate limited
      const rateLimitedResponses = responses.filter(res => res.status === 429);
      expect(rateLimitedResponses.length).toBeGreaterThan(0);
    });
  });

  describe('POST /api/v1/auth/verify-otp', () => {
    beforeEach(() => {
      const mockUser = createMockUser({
        otpCode: '123456',
        otpExpires: new Date(Date.now() + 600000),
        otpPurpose: 'LOGIN',
      });
      mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
      mockedPrisma.user.update.mockResolvedValue(mockUser as any);
    });

    it('should verify OTP successfully', async () => {
      const otpData = createMockOtpData();

      const response = await request(app.app)
        .post('/api/v1/auth/verify-otp')
        .send(otpData)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('OTP verified successfully');
      expect(response.body.data).toHaveProperty('tokens');
    });

    it('should validate OTP verification data', async () => {
      const invalidData = {
        email: 'invalid-email',
        code: '12345', // wrong length
        purpose: 'INVALID_PURPOSE',
      };

      const response = await request(app.app)
        .post('/api/v1/auth/verify-otp')
        .send(invalidData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Validation failed');
    });

    it('should handle invalid OTP code', async () => {
      const otpData = createMockOtpData({
        code: '654321', // wrong code
      });

      const response = await request(app.app)
        .post('/api/v1/auth/verify-otp')
        .send(otpData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Invalid OTP code');
    });

    it('should handle expired OTP', async () => {
      const expiredUser = createMockUser({
        otpCode: '123456',
        otpExpires: new Date(Date.now() - 600000), // expired
        otpPurpose: 'LOGIN',
      });
      mockedPrisma.user.findUnique.mockResolvedValue(expiredUser as any);

      const otpData = createMockOtpData();

      const response = await request(app.app)
        .post('/api/v1/auth/verify-otp')
        .send(otpData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('OTP expired');
    });
  });

  describe('GET /api/v1/auth/profile', () => {
    it('should require authentication', async () => {
      const response = await request(app.app)
        .get('/api/v1/auth/profile')
        .expect(401);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('token');
    });

    it('should return user profile with valid token', async () => {
      const mockUser = createMockUser();
      const token = generateTestToken({ userId: mockUser.id });

      mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);

      const response = await request(app.app)
        .get('/api/v1/auth/profile')
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('user');
      expect(response.body.data.user.email).toBe(mockUser.email);
    });

    it('should reject invalid token', async () => {
      const response = await request(app.app)
        .get('/api/v1/auth/profile')
        .set('Authorization', 'Bearer invalid-token')
        .expect(401);

      expect(response.body.success).toBe(false);
    });
  });

  describe('GET /api/v1/auth/me', () => {
    it('should require authentication', async () => {
      const response = await request(app.app)
        .get('/api/v1/auth/me')
        .expect(401);

      expect(response.body.success).toBe(false);
    });

    it('should return comprehensive user data', async () => {
      const mockUser = createMockUser();
      const token = generateTestToken({ userId: mockUser.id });

      mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
      mockedPrisma.wallet.findUnique.mockResolvedValue({
        id: 'wallet-id',
        balance: 100,
        withdrawableBalance: 50,
      } as any);
      mockedPrisma.chapterMembership.findFirst.mockResolvedValue({
        chapter: {
          id: 'chapter-id',
          name: 'Test Chapter',
          type: 'PHYSICAL',
        },
      } as any);

      const response = await request(app.app)
        .get('/api/v1/auth/me')
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('user');
      expect(response.body.data).toHaveProperty('wallet');
      expect(response.body.data).toHaveProperty('chapter');
    });
  });

  describe('POST /api/v1/auth/refresh-token', () => {
    it('should refresh token with valid refresh token', async () => {
      const mockUser = createMockUser();
      const refreshToken = generateTestToken({ userId: mockUser.id });

      mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);

      const response = await request(app.app)
        .post('/api/v1/auth/refresh-token')
        .send({ refreshToken })
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('tokens');
      expect(response.headers['set-cookie']).toBeDefined();
    });

    it('should handle missing refresh token', async () => {
      const response = await request(app.app)
        .post('/api/v1/auth/refresh-token')
        .send({})
        .expect(401);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Refresh token missing');
    });

    it('should handle invalid refresh token', async () => {
      const response = await request(app.app)
        .post('/api/v1/auth/refresh-token')
        .send({ refreshToken: 'invalid-token' })
        .expect(401);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Invalid refresh token');
    });
  });

  describe('POST /api/v1/auth/logout', () => {
    it('should require authentication', async () => {
      const response = await request(app.app)
        .post('/api/v1/auth/logout')
        .expect(401);

      expect(response.body.success).toBe(false);
    });

    it('should logout successfully', async () => {
      const mockUser = createMockUser();
      const token = generateTestToken({ userId: mockUser.id });

      mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
      mockedPrisma.user.update.mockResolvedValue(mockUser as any);

      const response = await request(app.app)
        .post('/api/v1/auth/logout')
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('Logged out successfully');
    });
  });

  describe('Admin Routes', () => {
    describe('POST /api/v1/auth/admin/invite', () => {
      it('should require authentication', async () => {
        const inviteData = createMockAdminInviteData();

        const response = await request(app.app)
          .post('/api/v1/auth/admin/invite')
          .send(inviteData)
          .expect(401);

        expect(response.body.success).toBe(false);
      });

      it('should require super admin role', async () => {
        const mockAdmin = createMockUser({ role: 'ADMIN' });
        const token = generateTestToken({ userId: mockAdmin.id });
        const inviteData = createMockAdminInviteData();

        mockedPrisma.user.findUnique.mockResolvedValue(mockAdmin as any);

        const response = await request(app.app)
          .post('/api/v1/auth/admin/invite')
          .set('Authorization', `Bearer ${token}`)
          .send(inviteData)
          .expect(403);

        expect(response.body.success).toBe(false);
        expect(response.body.message).toContain('super admin');
      });

      it('should invite admin successfully', async () => {
        const mockSuperAdmin = createMockUser({ role: 'SUPER_ADMIN' });
        const token = generateTestToken({ userId: mockSuperAdmin.id });
        const inviteData = createMockAdminInviteData();

        mockedPrisma.user.findUnique
          .mockResolvedValueOnce(mockSuperAdmin as any) // auth check
          .mockResolvedValueOnce(mockSuperAdmin as any) // inviter check
          .mockResolvedValueOnce(null); // existing user check
        mockedPrisma.adminInvitation.findUnique.mockResolvedValue(null);
        mockedPrisma.adminInvitation.create.mockResolvedValue({
          id: 'invitation-id',
        } as any);
        mockedEmailService.sendAdminInvitation.mockResolvedValue();

        const response = await request(app.app)
          .post('/api/v1/auth/admin/invite')
          .set('Authorization', `Bearer ${token}`)
          .send(inviteData)
          .expect(201);

        expect(response.body.success).toBe(true);
        expect(response.body.message).toBe('Admin invitation sent successfully');
      });

      it('should validate invitation data', async () => {
        const mockSuperAdmin = createMockUser({ role: 'SUPER_ADMIN' });
        const token = generateTestToken({ userId: mockSuperAdmin.id });

        mockedPrisma.user.findUnique.mockResolvedValue(mockSuperAdmin as any);

        const invalidData = {
          email: 'invalid-email',
          sections: [], // should not be empty
          permissions: ['INVALID_PERMISSION'],
        };

        const response = await request(app.app)
          .post('/api/v1/auth/admin/invite')
          .set('Authorization', `Bearer ${token}`)
          .send(invalidData)
          .expect(400);

        expect(response.body.success).toBe(false);
        expect(response.body.message).toBe('Validation failed');
      });
    });

    describe('GET /api/v1/auth/admin/dashboard', () => {
      it('should require authentication', async () => {
        const response = await request(app.app)
          .get('/api/v1/auth/admin/dashboard')
          .expect(401);

        expect(response.body.success).toBe(false);
      });

      it('should require admin role', async () => {
        const mockUser = createMockUser({ role: 'FREE_MEMBER' });
        const token = generateTestToken({ userId: mockUser.id });

        mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);

        const response = await request(app.app)
          .get('/api/v1/auth/admin/dashboard')
          .set('Authorization', `Bearer ${token}`)
          .expect(403);

        expect(response.body.success).toBe(false);
        expect(response.body.message).toContain('admin');
      });

      it('should return dashboard data for admin', async () => {
        const mockAdmin = createMockUser({ role: 'ADMIN' });
        const token = generateTestToken({ userId: mockAdmin.id });

        mockedPrisma.user.findUnique.mockResolvedValue(mockAdmin as any);
        mockedPrisma.user.count
          .mockResolvedValueOnce(100) // total users
          .mockResolvedValueOnce(5) // pending verifications
          .mockResolvedValueOnce(10); // total admins
        mockedPrisma.adminInvitation.count.mockResolvedValue(3);

        const response = await request(app.app)
          .get('/api/v1/auth/admin/dashboard')
          .set('Authorization', `Bearer ${token}`)
          .expect(200);

        expect(response.body.success).toBe(true);
        expect(response.body.data).toHaveProperty('totalUsers');
        expect(response.body.data).toHaveProperty('pendingVerifications');
        expect(response.body.data).toHaveProperty('totalAdmins');
        expect(response.body.data).toHaveProperty('pendingInvitations');
      });
    });
  });

  describe('Error Handling', () => {
    it('should handle database errors gracefully', async () => {
      mockedPrisma.user.findUnique.mockRejectedValue(new Error('Database connection failed'));

      const loginData = createMockLoginData();

      const response = await request(app.app)
        .post('/api/v1/auth/login')
        .send(loginData)
        .expect(500);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('Internal server error');
    });

    it('should handle email service errors gracefully', async () => {
      mockedPrisma.user.findUnique.mockResolvedValue(null);
      mockedPrisma.user.create.mockResolvedValue(createMockUser() as any);
      mockedPrisma.wallet.create.mockResolvedValue({} as any);
      mockedEmailService.sendVerificationEmail.mockRejectedValue(new Error('Email service unavailable'));

      const signupData = createMockSignupData();

      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(signupData)
        .expect(500);

      expect(response.body.success).toBe(false);
    });

    it('should handle malformed JSON', async () => {
      const response = await request(app.app)
        .post('/api/v1/auth/login')
        .set('Content-Type', 'application/json')
        .send('{ invalid json }')
        .expect(400);

      expect(response.body.success).toBe(false);
    });

    it('should handle missing Content-Type header', async () => {
      const response = await request(app.app)
        .post('/api/v1/auth/login')
        .send('email=test@example.com&password=password')
        .expect(400);

      expect(response.body.success).toBe(false);
    });
  });

  describe('Security', () => {
    it('should not expose sensitive data in responses', async () => {
      const mockUser = createMockUser();
      mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
      mockedPrisma.user.create.mockResolvedValue(mockUser as any);
      mockedPrisma.wallet.create.mockResolvedValue({} as any);
      mockedEmailService.sendVerificationEmail.mockResolvedValue();

      const signupData = createMockSignupData();

      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(signupData)
        .expect(201);

      expect(response.body.data.user).not.toHaveProperty('password');
      expect(response.body.data.user).not.toHaveProperty('emailVerificationToken');
      expect(response.body.data.user).not.toHaveProperty('otpCode');
    });

    it('should set secure cookie flags in production', async () => {
      // Mock production environment
      const originalEnv = process.env.NODE_ENV;
      process.env.NODE_ENV = 'production';

      const mockUser = createMockUser();
      mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
      mockedPrisma.user.create.mockResolvedValue(mockUser as any);
      mockedPrisma.wallet.create.mockResolvedValue({} as any);
      mockedEmailService.sendVerificationEmail.mockResolvedValue();

      const signupData = createMockSignupData();

      const response = await request(app.app)
        .post('/api/v1/auth/signup-flow')
        .send(signupData)
        .expect(201);

      const setCookieHeader = response.headers['set-cookie'];
      if (setCookieHeader) {
        expect(setCookieHeader[0]).toContain('Secure');
        expect(setCookieHeader[0]).toContain('HttpOnly');
      }

      // Restore original environment
      process.env.NODE_ENV = originalEnv;
    });

    it('should validate JWT token format', async () => {
      const response = await request(app.app)
        .get('/api/v1/auth/profile')
        .set('Authorization', 'Bearer not.a.valid.jwt.token.format')
        .expect(401);

      expect(response.body.success).toBe(false);
    });

    it('should handle expired JWT tokens', async () => {
      const expiredToken = generateTestToken({ userId: 'user-id' }, '-1h'); // expired

      const response = await request(app.app)
        .get('/api/v1/auth/profile')
        .set('Authorization', `Bearer ${expiredToken}`)
        .expect(401);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('expired');
    });
  });
});