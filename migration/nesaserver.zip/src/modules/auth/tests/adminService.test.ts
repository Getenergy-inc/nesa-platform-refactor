import { adminService } from '../services/adminService';
import { prisma } from '@/shared/database/postgresql';
import { emailService } from '@/modules/notifications/services/emailService';
import { ConflictError, NotFoundError, AuthorizationError, ValidationError } from '@/shared/utils/errors';

// Mock dependencies
jest.mock('@/shared/database/postgresql');
jest.mock('@/modules/notifications/services/emailService');

const mockedPrisma = prisma as jest.Mocked<typeof prisma>;
const mockedEmailService = emailService as jest.Mocked<typeof emailService>;

describe('AdminService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('inviteAdmin', () => {
    const inviteData = {
      email: 'admin@example.com',
      sections: ['USER_MANAGEMENT'] as any[],
      permissions: ['READ', 'WRITE'] as any[],
      message: 'Welcome to the team',
    };

    const mockSuperAdmin = {
      id: 'super-admin-id',
      role: 'SUPER_ADMIN',
      firstName: 'Super',
      lastName: 'Admin',
    };

    beforeEach(() => {
      mockedPrisma.user.findUnique
        .mockResolvedValueOnce(mockSuperAdmin as any) // inviter check
        .mockResolvedValueOnce(null); // existing user check
      mockedPrisma.adminInvitation.findUnique.mockResolvedValue(null);
      mockedPrisma.adminInvitation.create.mockResolvedValue({
        id: 'invitation-id',
        email: 'admin@example.com',
        invitationToken: 'token',
        sections: ['USER_MANAGEMENT'],
        permissions: ['READ', 'WRITE'],
        invitedBy: 'super-admin-id',
        expiresAt: new Date(),
        invitedAt: new Date(),
      } as any);
      mockedEmailService.sendAdminInvitation.mockResolvedValue();
    });

    it('should invite admin successfully', async () => {
      const result = await adminService.inviteAdmin('super-admin-id', inviteData);

      expect(result.message).toBe('Admin invitation sent successfully');
      expect(result.invitationId).toBe('invitation-id');
      expect(mockedPrisma.adminInvitation.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          email: 'admin@example.com',
          sections: ['USER_MANAGEMENT'],
          permissions: ['READ', 'WRITE'],
          invitedBy: 'super-admin-id',
          invitationToken: expect.any(String),
          expiresAt: expect.any(Date),
        }),
      });
      expect(mockedEmailService.sendAdminInvitation).toHaveBeenCalledWith(
        'admin@example.com',
        expect.any(String),
        'Super Admin',
        ['USER_MANAGEMENT'],
        'Welcome to the team'
      );
    });

    it('should throw AuthorizationError if inviter is not super admin', async () => {
      mockedPrisma.user.findUnique.mockResolvedValueOnce({
        id: 'regular-user-id',
        role: 'FREE_MEMBER',
      } as any);

      await expect(adminService.inviteAdmin('regular-user-id', inviteData))
        .rejects
        .toThrow(AuthorizationError);
    });

    it('should throw NotFoundError if inviter does not exist', async () => {
      mockedPrisma.user.findUnique.mockResolvedValueOnce(null);

      await expect(adminService.inviteAdmin('non-existent-id', inviteData))
        .rejects
        .toThrow(AuthorizationError);
    });

    it('should throw ConflictError if user already exists', async () => {
      mockedPrisma.user.findUnique
        .mockResolvedValueOnce(mockSuperAdmin as any) // inviter check
        .mockResolvedValueOnce({ // existing user check
          id: 'existing-user-id',
          email: 'admin@example.com',
        } as any);

      await expect(adminService.inviteAdmin('super-admin-id', inviteData))
        .rejects
        .toThrow(ConflictError);
    });

    it('should throw ConflictError if pending invitation exists', async () => {
      mockedPrisma.adminInvitation.findUnique.mockResolvedValue({
        id: 'existing-invitation-id',
        email: 'admin@example.com',
      } as any);

      await expect(adminService.inviteAdmin('super-admin-id', inviteData))
        .rejects
        .toThrow(ConflictError);
    });

    it('should handle division and functions in invitation', async () => {
      const inviteDataWithExtras = {
        ...inviteData,
        division: 'SOBCD',
        functions: ['RESEARCH', 'DEVELOPMENT'],
      };

      await adminService.inviteAdmin('super-admin-id', inviteDataWithExtras as any);

      expect(mockedPrisma.adminInvitation.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          division: 'SOBCD',
          functions: ['RESEARCH', 'DEVELOPMENT'],
        }),
      });
    });

    it('should lowercase email before processing', async () => {
      const inviteDataWithUppercaseEmail = {
        ...inviteData,
        email: 'ADMIN@EXAMPLE.COM',
      };

      await adminService.inviteAdmin('super-admin-id', inviteDataWithUppercaseEmail);

      expect(mockedPrisma.user.findUnique).toHaveBeenCalledWith({
        where: { email: 'admin@example.com' },
      });
      expect(mockedPrisma.adminInvitation.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          email: 'admin@example.com',
        }),
      });
    });

    it('should generate secure invitation token', async () => {
      await adminService.inviteAdmin('super-admin-id', inviteData);

      expect(mockedPrisma.adminInvitation.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          invitationToken: expect.stringMatching(/^[a-f0-9]{64}$/), // 32 bytes hex
        }),
      });
    });

    it('should set expiration date 7 days from now', async () => {
      const beforeCall = Date.now();
      await adminService.inviteAdmin('super-admin-id', inviteData);
      const afterCall = Date.now();

      const createCall = mockedPrisma.adminInvitation.create.mock.calls[0][0];
      const expiresAt = createCall.data.expiresAt as Date;
      const expectedMin = new Date(beforeCall + 7 * 24 * 60 * 60 * 1000);
      const expectedMax = new Date(afterCall + 7 * 24 * 60 * 60 * 1000);

      expect(expiresAt.getTime()).toBeGreaterThanOrEqual(expectedMin.getTime());
      expect(expiresAt.getTime()).toBeLessThanOrEqual(expectedMax.getTime());
    });
  });

  describe('acceptInvitation', () => {
    const acceptData = {
      invitationToken: 'valid-token',
      password: 'AdminPassword123!',
      firstName: 'New',
      lastName: 'Admin',
    };

    const mockInvitation = {
      id: 'invitation-id',
      email: 'admin@example.com',
      invitationToken: 'valid-token',
      expiresAt: new Date(Date.now() + 3600000),
      sections: ['USER_MANAGEMENT'],
      permissions: ['READ', 'WRITE'],
      invitedBy: 'super-admin-id',
      invitedAt: new Date(),
    };

    const mockCreatedUser = {
      id: 'new-admin-id',
      email: 'admin@example.com',
      firstName: 'New',
      lastName: 'Admin',
      role: 'ADMIN',
      createdAt: new Date(),
    };

    beforeEach(() => {
      mockedPrisma.adminInvitation.findUnique.mockResolvedValue(mockInvitation as any);
      mockedPrisma.$transaction.mockImplementation(async (callback) => {
        const mockTx = {
          user: {
            create: jest.fn().mockResolvedValue(mockCreatedUser),
          },
          adminSection: {
            create: jest.fn(),
          },
          adminInvitation: {
            delete: jest.fn(),
          },
        };
        return callback(mockTx as any);
      });
    });

    it('should accept invitation successfully', async () => {
      const result = await adminService.acceptInvitation(acceptData);

      expect(result.message).toBe('Admin account created successfully');
      expect(result.user).toEqual(mockCreatedUser);
    });

    it('should create user with correct data', async () => {
      await adminService.acceptInvitation(acceptData);

      const txCallback = mockedPrisma.$transaction.mock.calls[0][0];
      const mockTx = {
        user: { create: jest.fn().mockResolvedValue(mockCreatedUser) },
        adminSection: { create: jest.fn() },
        adminInvitation: { delete: jest.fn() },
      };
      
      await txCallback(mockTx as any);

      expect(mockTx.user.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          email: 'admin@example.com',
          password: expect.any(String), // hashed password
          firstName: 'New',
          lastName: 'Admin',
          fullName: 'New Admin',
          role: 'ADMIN',
          isVerified: true,
          emailVerifiedAt: expect.any(Date),
          invitedBy: 'super-admin-id',
          invitedAt: mockInvitation.invitedAt,
        }),
        select: expect.any(Object),
      });
    });

    it('should create admin sections', async () => {
      await adminService.acceptInvitation(acceptData);

      const txCallback = mockedPrisma.$transaction.mock.calls[0][0];
      const mockTx = {
        user: { create: jest.fn().mockResolvedValue(mockCreatedUser) },
        adminSection: { create: jest.fn() },
        adminInvitation: { delete: jest.fn() },
      };
      
      await txCallback(mockTx as any);

      expect(mockTx.adminSection.create).toHaveBeenCalledWith({
        data: {
          userId: 'new-admin-id',
          section: 'USER_MANAGEMENT',
          permissions: ['READ', 'WRITE'],
          assignedBy: 'super-admin-id',
        },
      });
    });

    it('should delete invitation after acceptance', async () => {
      await adminService.acceptInvitation(acceptData);

      const txCallback = mockedPrisma.$transaction.mock.calls[0][0];
      const mockTx = {
        user: { create: jest.fn().mockResolvedValue(mockCreatedUser) },
        adminSection: { create: jest.fn() },
        adminInvitation: { delete: jest.fn() },
      };
      
      await txCallback(mockTx as any);

      expect(mockTx.adminInvitation.delete).toHaveBeenCalledWith({
        where: { id: 'invitation-id' },
      });
    });

    it('should throw ValidationError for invalid invitation token', async () => {
      mockedPrisma.adminInvitation.findUnique.mockResolvedValue(null);

      await expect(adminService.acceptInvitation(acceptData))
        .rejects
        .toThrow(ValidationError);
    });

    it('should throw ValidationError for expired invitation', async () => {
      const expiredInvitation = {
        ...mockInvitation,
        expiresAt: new Date(Date.now() - 3600000), // expired
      };

      mockedPrisma.adminInvitation.findUnique.mockResolvedValue(expiredInvitation as any);

      await expect(adminService.acceptInvitation(acceptData))
        .rejects
        .toThrow(ValidationError);
    });

    it('should hash password before storing', async () => {
      await adminService.acceptInvitation(acceptData);

      const txCallback = mockedPrisma.$transaction.mock.calls[0][0];
      const mockTx = {
        user: { create: jest.fn().mockResolvedValue(mockCreatedUser) },
        adminSection: { create: jest.fn() },
        adminInvitation: { delete: jest.fn() },
      };
      
      await txCallback(mockTx as any);

      const createCall = mockTx.user.create.mock.calls[0][0];
      const hashedPassword = createCall.data.password;
      
      expect(hashedPassword).not.toBe('AdminPassword123!');
      expect(hashedPassword).toMatch(/^\$2[aby]\$\d+\$/); // bcrypt hash pattern
    });

    it('should handle invitation with division and functions', async () => {
      const invitationWithExtras = {
        ...mockInvitation,
        division: 'SOBCD',
        functions: ['RESEARCH', 'DEVELOPMENT'],
      };

      mockedPrisma.adminInvitation.findUnique.mockResolvedValue(invitationWithExtras as any);

      await adminService.acceptInvitation(acceptData);

      const txCallback = mockedPrisma.$transaction.mock.calls[0][0];
      const mockTx = {
        user: { create: jest.fn().mockResolvedValue(mockCreatedUser) },
        adminSection: { create: jest.fn() },
        adminInvitation: { delete: jest.fn() },
      };
      
      await txCallback(mockTx as any);

      expect(mockTx.user.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          division: 'SOBCD',
          functions: ['RESEARCH', 'DEVELOPMENT'],
        }),
        select: expect.any(Object),
      });
    });
  });

  describe('updateAdminDivision', () => {
    beforeEach(() => {
      mockedPrisma.user.findUnique
        .mockResolvedValueOnce({ // super admin check
          id: 'super-admin-id',
          role: 'SUPER_ADMIN',
        } as any)
        .mockResolvedValueOnce({ // target admin check
          id: 'admin-id',
          role: 'ADMIN',
        } as any);
      mockedPrisma.user.update.mockResolvedValue({} as any);
    });

    it('should update admin division and functions successfully', async () => {
      const result = await adminService.updateAdminDivision(
        'super-admin-id',
        'admin-id',
        'SOBCD',
        ['RESEARCH', 'DEVELOPMENT']
      );

      expect(result.message).toBe('Admin division/functions updated successfully');
      expect(mockedPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'admin-id' },
        data: {
          division: 'SOBCD',
          functions: ['RESEARCH', 'DEVELOPMENT'],
        },
      });
    });

    it('should handle null division (clear division)', async () => {
      await adminService.updateAdminDivision(
        'super-admin-id',
        'admin-id',
        null,
        ['RESEARCH']
      );

      expect(mockedPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'admin-id' },
        data: {
          division: null,
          functions: ['RESEARCH'],
        },
      });
    });

    it('should handle null functions (clear functions)', async () => {
      await adminService.updateAdminDivision(
        'super-admin-id',
        'admin-id',
        'SOBCD',
        null
      );

      expect(mockedPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'admin-id' },
        data: {
          division: 'SOBCD',
          functions: [],
        },
      });
    });

    it('should throw AuthorizationError if requester is not super admin', async () => {
      mockedPrisma.user.findUnique.mockResolvedValueOnce({
        id: 'regular-admin-id',
        role: 'ADMIN',
      } as any);

      await expect(adminService.updateAdminDivision(
        'regular-admin-id',
        'admin-id',
        'SOBCD',
        ['RESEARCH']
      )).rejects.toThrow(AuthorizationError);
    });

    it('should throw ValidationError if target user is not admin', async () => {
      mockedPrisma.user.findUnique
        .mockResolvedValueOnce({ // super admin check
          id: 'super-admin-id',
          role: 'SUPER_ADMIN',
        } as any)
        .mockResolvedValueOnce({ // target user check
          id: 'user-id',
          role: 'FREE_MEMBER',
        } as any);

      await expect(adminService.updateAdminDivision(
        'super-admin-id',
        'user-id',
        'SOBCD',
        ['RESEARCH']
      )).rejects.toThrow(ValidationError);
    });

    it('should throw ValidationError if target user does not exist', async () => {
      mockedPrisma.user.findUnique
        .mockResolvedValueOnce({ // super admin check
          id: 'super-admin-id',
          role: 'SUPER_ADMIN',
        } as any)
        .mockResolvedValueOnce(null); // target user check

      await expect(adminService.updateAdminDivision(
        'super-admin-id',
        'non-existent-id',
        'SOBCD',
        ['RESEARCH']
      )).rejects.toThrow(ValidationError);
    });

    it('should map division string to enum', async () => {
      await adminService.updateAdminDivision(
        'super-admin-id',
        'admin-id',
        'sobcd', // lowercase
        ['RESEARCH']
      );

      expect(mockedPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'admin-id' },
        data: {
          division: 'SOBCD', // should be mapped to uppercase
          functions: ['RESEARCH'],
        },
      });
    });

    it('should handle invalid division gracefully', async () => {
      await adminService.updateAdminDivision(
        'super-admin-id',
        'admin-id',
        'INVALID_DIVISION',
        ['RESEARCH']
      );

      expect(mockedPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'admin-id' },
        data: {
          division: null, // invalid division should be mapped to null
          functions: ['RESEARCH'],
        },
      });
    });
  });

  describe('changeAdminPassword', () => {
    beforeEach(() => {
      mockedPrisma.user.findUnique
        .mockResolvedValueOnce({ // super admin check
          id: 'super-admin-id',
          role: 'SUPER_ADMIN',
        } as any)
        .mockResolvedValueOnce({ // target admin check
          id: 'admin-id',
          role: 'ADMIN',
        } as any);
      mockedPrisma.user.update.mockResolvedValue({} as any);
    });

    it('should change admin password successfully', async () => {
      const result = await adminService.changeAdminPassword(
        'super-admin-id',
        'admin-id',
        'NewPassword123!'
      );

      expect(result.message).toBe('Admin password changed successfully');
      expect(mockedPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'admin-id' },
        data: {
          password: expect.any(String), // hashed password
        },
      });
    });

    it('should hash new password', async () => {
      await adminService.changeAdminPassword(
        'super-admin-id',
        'admin-id',
        'NewPassword123!'
      );

      const updateCall = mockedPrisma.user.update.mock.calls[0][0];
      const hashedPassword = updateCall.data.password;
      
      expect(hashedPassword).not.toBe('NewPassword123!');
      expect(hashedPassword).toMatch(/^\$2[aby]\$\d+\$/); // bcrypt hash pattern
    });

    it('should throw AuthorizationError if requester is not super admin', async () => {
      mockedPrisma.user.findUnique.mockResolvedValueOnce({
        id: 'regular-admin-id',
        role: 'ADMIN',
      } as any);

      await expect(adminService.changeAdminPassword(
        'regular-admin-id',
        'admin-id',
        'NewPassword123!'
      )).rejects.toThrow(AuthorizationError);
    });

    it('should throw ValidationError if target is not admin', async () => {
      mockedPrisma.user.findUnique
        .mockResolvedValueOnce({ // super admin check
          id: 'super-admin-id',
          role: 'SUPER_ADMIN',
        } as any)
        .mockResolvedValueOnce({ // target user check
          id: 'user-id',
          role: 'FREE_MEMBER',
        } as any);

      await expect(adminService.changeAdminPassword(
        'super-admin-id',
        'user-id',
        'NewPassword123!'
      )).rejects.toThrow(ValidationError);
    });
  });

  describe('getAdminDashboard', () => {
    beforeEach(() => {
      mockedPrisma.user.findUnique.mockResolvedValue({
        id: 'admin-id',
        role: 'ADMIN',
      } as any);
      mockedPrisma.user.count
        .mockResolvedValueOnce(100) // total users
        .mockResolvedValueOnce(5) // pending verifications
        .mockResolvedValueOnce(10); // total admins
      mockedPrisma.adminInvitation.count.mockResolvedValue(3); // pending invitations
    });

    it('should return admin dashboard data', async () => {
      const result = await adminService.getAdminDashboard('admin-id');

      expect(result).toEqual({
        totalUsers: 100,
        pendingVerifications: 5,
        totalAdmins: 10,
        pendingInvitations: 3,
      });
    });

    it('should throw AuthorizationError for non-admin user', async () => {
      mockedPrisma.user.findUnique.mockResolvedValue({
        id: 'user-id',
        role: 'FREE_MEMBER',
      } as any);

      await expect(adminService.getAdminDashboard('user-id'))
        .rejects
        .toThrow(AuthorizationError);
    });

    it('should throw NotFoundError for non-existent user', async () => {
      mockedPrisma.user.findUnique.mockResolvedValue(null);

      await expect(adminService.getAdminDashboard('non-existent-id'))
        .rejects
        .toThrow(NotFoundError);
    });
  });
});