#!/usr/bin/env ts-node

/**
 * Test runner for auth module
 * This script can be used to run specific test suites or all tests
 */

import { execSync } from 'child_process';
import path from 'path';

const testDir = __dirname;
const rootDir = path.resolve(__dirname, '../../../../..');

interface TestSuite {
  name: string;
  file: string;
  description: string;
}

const testSuites: TestSuite[] = [
  {
    name: 'unit',
    file: 'auth.test.ts',
    description: 'Unit tests for all auth services and utilities'
  },
  {
    name: 'signup',
    file: 'signupFlowService.test.ts',
    description: 'Detailed tests for signup flow service'
  },
  {
    name: 'admin',
    file: 'adminService.test.ts',
    description: 'Detailed tests for admin service'
  },
  {
    name: 'otp',
    file: 'otpService.test.ts',
    description: 'Detailed tests for OTP service'
  },
  {
    name: 'integration',
    file: 'auth.integration.test.ts',
    description: 'Integration tests for auth API endpoints'
  }
];

function runTests(suiteNames?: string[]) {
  console.log('🧪 Running Auth Module Tests\n');

  const suitesToRun = suiteNames 
    ? testSuites.filter(suite => suiteNames.includes(suite.name))
    : testSuites;

  if (suitesToRun.length === 0) {
    console.error('❌ No matching test suites found');
    console.log('Available test suites:');
    testSuites.forEach(suite => {
      console.log(`  - ${suite.name}: ${suite.description}`);
    });
    process.exit(1);
  }

  let totalPassed = 0;
  let totalFailed = 0;

  for (const suite of suitesToRun) {
    console.log(`\n📋 Running ${suite.name} tests: ${suite.description}`);
    console.log('─'.repeat(60));

    try {
      const testFile = path.join(testDir, suite.file);
      const command = `npx jest "${testFile}" --verbose --coverage --testTimeout=30000`;
      
      execSync(command, {
        cwd: rootDir,
        stdio: 'inherit',
        env: {
          ...process.env,
          NODE_ENV: 'test',
        }
      });

      console.log(`✅ ${suite.name} tests passed\n`);
      totalPassed++;
    } catch (error) {
      console.log(`❌ ${suite.name} tests failed\n`);
      totalFailed++;
    }
  }

  console.log('\n' + '='.repeat(60));
  console.log('📊 Test Summary');
  console.log('='.repeat(60));
  console.log(`✅ Passed: ${totalPassed} test suite(s)`);
  console.log(`❌ Failed: ${totalFailed} test suite(s)`);
  console.log(`📈 Total: ${totalPassed + totalFailed} test suite(s)`);

  if (totalFailed > 0) {
    console.log('\n❌ Some tests failed. Please check the output above.');
    process.exit(1);
  } else {
    console.log('\n🎉 All tests passed!');
  }
}

function showHelp() {
  console.log('Auth Module Test Runner\n');
  console.log('Usage:');
  console.log('  npm run test:auth                    # Run all auth tests');
  console.log('  npm run test:auth unit               # Run unit tests only');
  console.log('  npm run test:auth integration        # Run integration tests only');
  console.log('  npm run test:auth unit admin         # Run unit and admin tests');
  console.log('\nAvailable test suites:');
  testSuites.forEach(suite => {
    console.log(`  ${suite.name.padEnd(12)} - ${suite.description}`);
  });
  console.log('\nOptions:');
  console.log('  --help, -h                          # Show this help message');
}

// Parse command line arguments
const args = process.argv.slice(2);

if (args.includes('--help') || args.includes('-h')) {
  showHelp();
  process.exit(0);
}

// Run tests
runTests(args.length > 0 ? args : undefined);