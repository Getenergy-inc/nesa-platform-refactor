import request from 'supertest';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from '@/shared/database/postgresql';
import { unifiedAuthService } from '../services/unifiedAuthService';
import { signupFlowService } from '../services/signupFlowService';
import { adminService } from '../services/adminService';
import { otpService } from '../services/otpService';
import { emailService } from '@/modules/notifications/services/emailService';
import App from '../../../../app';

// Mock external services
jest.mock('@/modules/notifications/services/emailService');
jest.mock('@/shared/database/postgresql', () => ({
  prisma: {
    user: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
      count: jest.fn(),
    },
    adminInvitation: {
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    adminSection: {
      create: jest.fn(),
      findMany: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    wallet: {
      create: jest.fn(),
      findUnique: jest.fn(),
    },
    chapterMembership: {
      findFirst: jest.fn(),
    },
    $transaction: jest.fn(),
  },
}));

const mockedPrisma = prisma as jest.Mocked<typeof prisma>;
const mockedEmailService = emailService as jest.Mocked<typeof emailService>;

describe('Authentication Module', () => {
  let app: App;

  beforeAll(async () => {
    app = new App();
  });

  beforeEach(() => {
    jest.clearAllMocks();
  });

  afterAll(async () => {
    // Clean up
  });

  describe('SignupFlowService', () => {
    describe('signup', () => {
      const validSignupData = {
        email: 'test@example.com',
        password: 'ValidPassword123!',
        firstName: 'John',
        lastName: 'Doe',
        country: 'Nigeria',
        state: 'Lagos',
        accountType: 'individual',
        intents: ['vote or nominate'],
      };

      beforeEach(() => {
        mockedPrisma.user.findUnique.mockResolvedValue(null);
        mockedPrisma.wallet.create.mockResolvedValue({
          id: 'wallet-id',
          userId: 'user-id',
          balance: 2,
          withdrawableBalance: 0,
          createdAt: new Date(),
          updatedAt: new Date(),
        });
        mockedEmailService.sendVerificationEmail.mockResolvedValue();
      });

      it('should create a new user successfully', async () => {
        const mockUser = {
          id: 'user-id',
          email: 'test@example.com',
          firstName: 'John',
          lastName: 'Doe',
          fullName: 'John Doe',
          role: 'FREE_MEMBER',
          accountType: 'INDIVIDUAL',
          isVerified: false,
          country: 'Nigeria',
          state: 'Lagos',
          createdAt: new Date(),
        };

        mockedPrisma.user.create.mockResolvedValue(mockUser as any);

        const result = await signupFlowService.signup(validSignupData);

        expect(result).toHaveProperty('user');
        expect(result).toHaveProperty('tokens');
        expect(result.user.email).toBe('test@example.com');
        expect(result.user.role).toBe('FREE_MEMBER');
        expect(mockedPrisma.user.create).toHaveBeenCalledWith({
          data: expect.objectContaining({
            email: 'test@example.com',
            firstName: 'John',
            lastName: 'Doe',
            fullName: 'John Doe',
            country: 'Nigeria',
            state: 'Lagos',
            accountType: 'INDIVIDUAL',
            intents: ['VOTE_OR_NOMINATE'],
            role: 'FREE_MEMBER',
            isVerified: false,
          }),
          select: expect.any(Object),
        });
        expect(mockedEmailService.sendVerificationEmail).toHaveBeenCalled();
      });

      it('should throw ConflictError if user already exists', async () => {
        mockedPrisma.user.findUnique.mockResolvedValue({
          id: 'existing-user',
          email: 'test@example.com',
        } as any);

        await expect(signupFlowService.signup(validSignupData))
          .rejects
          .toThrow('User with this email already exists');
      });

      it('should throw ValidationError for missing required fields', async () => {
        const invalidData = {
          email: 'test@example.com',
          // missing password, country, state
        };

        await expect(signupFlowService.signup(invalidData as any))
          .rejects
          .toThrow('Missing required fields');
      });

      it('should map account types correctly', async () => {
        const corporateData = {
          ...validSignupData,
          accountType: 'corporation',
          organizationName: 'Test Corp',
        };

        const mockUser = {
          id: 'user-id',
          email: 'test@example.com',
          accountType: 'CORPORATION',
          organizationName: 'Test Corp',
        };

        mockedPrisma.user.create.mockResolvedValue(mockUser as any);

        await signupFlowService.signup(corporateData);

        expect(mockedPrisma.user.create).toHaveBeenCalledWith({
          data: expect.objectContaining({
            accountType: 'CORPORATION',
            organizationName: 'Test Corp',
          }),
          select: expect.any(Object),
        });
      });

      it('should handle division assignment for admin users', async () => {
        const adminData = {
          ...validSignupData,
          division: 'SOBCD',
          functions: ['RESEARCH', 'DEVELOPMENT'],
        };

        const mockUser = {
          id: 'user-id',
          email: 'test@example.com',
          division: 'SOBCD',
          functions: ['RESEARCH', 'DEVELOPMENT'],
        };

        mockedPrisma.user.create.mockResolvedValue(mockUser as any);

        await signupFlowService.signup(adminData);

        expect(mockedPrisma.user.create).toHaveBeenCalledWith({
          data: expect.objectContaining({
            division: 'SOBCD',
            functions: { set: ['RESEARCH', 'DEVELOPMENT'] },
          }),
          select: expect.any(Object),
        });
      });

      it('should assign correct role based on intents', async () => {
        const ambassadorData = {
          ...validSignupData,
          intents: ['become ambassador'],
        };

        const mockUser = {
          id: 'user-id',
          role: 'AMBASSADOR',
        };

        mockedPrisma.user.create.mockResolvedValue(mockUser as any);

        await signupFlowService.signup(ambassadorData);

        expect(mockedPrisma.user.create).toHaveBeenCalledWith({
          data: expect.objectContaining({
            role: 'AMBASSADOR',
            intents: ['BECOME_AMBASSADOR'],
          }),
          select: expect.any(Object),
        });
      });
    });

    describe('verifyEmail', () => {
      it('should verify email successfully', async () => {
        const mockUser = {
          id: 'user-id',
          email: 'test@example.com',
          emailVerificationToken: 'valid-token',
          emailVerificationExpires: new Date(Date.now() + 3600000),
          isVerified: false,
        };

        mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
        mockedPrisma.user.update.mockResolvedValue({
          ...mockUser,
          isVerified: true,
          emailVerifiedAt: new Date(),
        } as any);

        const result = await signupFlowService.verifyEmail('test@example.com', 'valid-token');

        expect(result.message).toBe('Email verified successfully');
        expect(mockedPrisma.user.update).toHaveBeenCalledWith({
          where: { id: 'user-id' },
          data: {
            isVerified: true,
            emailVerifiedAt: expect.any(Date),
            emailVerificationToken: null,
            emailVerificationExpires: null,
          },
        });
      });

      it('should throw error for invalid token', async () => {
        const mockUser = {
          id: 'user-id',
          emailVerificationToken: 'different-token',
        };

        mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);

        await expect(signupFlowService.verifyEmail('test@example.com', 'invalid-token'))
          .rejects
          .toThrow('Invalid verification token');
      });

      it('should throw error for expired token', async () => {
        const mockUser = {
          id: 'user-id',
          emailVerificationToken: 'valid-token',
          emailVerificationExpires: new Date(Date.now() - 3600000), // expired
        };

        mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);

        await expect(signupFlowService.verifyEmail('test@example.com', 'valid-token'))
          .rejects
          .toThrow('Verification token expired');
      });
    });
  });

  describe('UnifiedAuthService', () => {
    describe('login', () => {
      const loginData = {
        email: 'test@example.com',
        password: 'password123',
      };

      it('should login successfully with valid credentials', async () => {
        const hashedPassword = await bcrypt.hash('password123', 12);
        const mockUser = {
          id: 'user-id',
          email: 'test@example.com',
          password: hashedPassword,
          role: 'FREE_MEMBER',
          isVerified: true,
          firstName: 'John',
          lastName: 'Doe',
        };

        mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);

        const result = await unifiedAuthService.login(loginData);

        expect(result).toHaveProperty('user');
        expect(result).toHaveProperty('accessToken');
        expect(result).toHaveProperty('refreshToken');
        expect(result.user.email).toBe('test@example.com');
      });

      it('should throw error for non-existent user', async () => {
        mockedPrisma.user.findUnique.mockResolvedValue(null);

        await expect(unifiedAuthService.login(loginData))
          .rejects
          .toThrow('Invalid credentials');
      });

      it('should throw error for incorrect password', async () => {
        const hashedPassword = await bcrypt.hash('different-password', 12);
        const mockUser = {
          id: 'user-id',
          email: 'test@example.com',
          password: hashedPassword,
        };

        mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);

        await expect(unifiedAuthService.login(loginData))
          .rejects
          .toThrow('Invalid credentials');
      });

      it('should throw error for unverified user', async () => {
        const hashedPassword = await bcrypt.hash('password123', 12);
        const mockUser = {
          id: 'user-id',
          email: 'test@example.com',
          password: hashedPassword,
          isVerified: false,
        };

        mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);

        await expect(unifiedAuthService.login(loginData))
          .rejects
          .toThrow('Please verify your email before logging in');
      });
    });

    describe('refreshToken', () => {
      it('should refresh token successfully', async () => {
        const mockUser = {
          id: 'user-id',
          email: 'test@example.com',
          role: 'FREE_MEMBER',
        };

        // Mock JWT verification
        jest.spyOn(jwt, 'verify').mockReturnValue({ userId: 'user-id' } as any);
        mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);

        const result = await unifiedAuthService.refreshToken('valid-refresh-token');

        expect(result).toHaveProperty('accessToken');
        expect(result).toHaveProperty('refreshToken');
        expect(result).toHaveProperty('expiresIn');
      });

      it('should throw error for invalid refresh token', async () => {
        jest.spyOn(jwt, 'verify').mockImplementation(() => {
          throw new Error('Invalid token');
        });

        await expect(unifiedAuthService.refreshToken('invalid-token'))
          .rejects
          .toThrow('Invalid refresh token');
      });
    });

    describe('getMe', () => {
      it('should return user profile with wallet and chapter info', async () => {
        const mockUser = {
          id: 'user-id',
          email: 'test@example.com',
          firstName: 'John',
          lastName: 'Doe',
          role: 'FREE_MEMBER',
        };

        const mockWallet = {
          id: 'wallet-id',
          balance: 100,
          withdrawableBalance: 50,
        };

        const mockChapter = {
          id: 'chapter-id',
          name: 'Lagos Chapter',
          type: 'PHYSICAL',
        };

        mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
        mockedPrisma.wallet.findUnique.mockResolvedValue(mockWallet as any);
        mockedPrisma.chapterMembership.findFirst.mockResolvedValue({
          chapter: mockChapter,
        } as any);

        const result = await unifiedAuthService.getMe('user-id');

        expect(result.user).toEqual(mockUser);
        expect(result.wallet).toEqual(mockWallet);
        expect(result.chapter).toEqual(mockChapter);
      });
    });
  });

  describe('AdminService', () => {
    describe('inviteAdmin', () => {
      const inviteData = {
        email: 'admin@example.com',
        sections: ['USER_MANAGEMENT'] as any[],
        permissions: ['READ', 'WRITE'] as any[],
        message: 'Welcome to the team',
      };

      beforeEach(() => {
        mockedPrisma.user.findUnique
          .mockResolvedValueOnce({ // inviter check
            id: 'super-admin-id',
            role: 'SUPER_ADMIN',
            firstName: 'Super',
            lastName: 'Admin',
          } as any)
          .mockResolvedValueOnce(null) // existing user check
          .mockResolvedValueOnce(null); // existing invitation check

        mockedPrisma.adminInvitation.findUnique.mockResolvedValue(null);
        mockedPrisma.adminInvitation.create.mockResolvedValue({
          id: 'invitation-id',
          email: 'admin@example.com',
        } as any);
        mockedEmailService.sendAdminInvitation.mockResolvedValue();
      });

      it('should invite admin successfully', async () => {
        const result = await adminService.inviteAdmin('super-admin-id', inviteData);

        expect(result.message).toBe('Admin invitation sent successfully');
        expect(result.invitationId).toBe('invitation-id');
        expect(mockedPrisma.adminInvitation.create).toHaveBeenCalled();
        expect(mockedEmailService.sendAdminInvitation).toHaveBeenCalled();
      });

      it('should throw error if inviter is not super admin', async () => {
        mockedPrisma.user.findUnique.mockResolvedValueOnce({
          id: 'regular-user-id',
          role: 'FREE_MEMBER',
        } as any);

        await expect(adminService.inviteAdmin('regular-user-id', inviteData))
          .rejects
          .toThrow('Only super admins can invite new admins');
      });

      it('should throw error if user already exists', async () => {
        mockedPrisma.user.findUnique
          .mockResolvedValueOnce({ // inviter check
            id: 'super-admin-id',
            role: 'SUPER_ADMIN',
            firstName: 'Super',
            lastName: 'Admin',
          } as any)
          .mockResolvedValueOnce({ // existing user check
            id: 'existing-user-id',
            email: 'admin@example.com',
          } as any);

        await expect(adminService.inviteAdmin('super-admin-id', inviteData))
          .rejects
          .toThrow('User with this email already exists');
      });

      it('should throw error if pending invitation exists', async () => {
        mockedPrisma.user.findUnique
          .mockResolvedValueOnce({ // inviter check
            id: 'super-admin-id',
            role: 'SUPER_ADMIN',
            firstName: 'Super',
            lastName: 'Admin',
          } as any)
          .mockResolvedValueOnce(null); // existing user check

        mockedPrisma.adminInvitation.findUnique.mockResolvedValue({
          id: 'existing-invitation-id',
        } as any);

        await expect(adminService.inviteAdmin('super-admin-id', inviteData))
          .rejects
          .toThrow('Pending invitation already exists for this email');
      });
    });

    describe('acceptInvitation', () => {
      const acceptData = {
        invitationToken: 'valid-token',
        password: 'AdminPassword123!',
        firstName: 'New',
        lastName: 'Admin',
      };

      it('should accept invitation successfully', async () => {
        const mockInvitation = {
          id: 'invitation-id',
          email: 'admin@example.com',
          invitationToken: 'valid-token',
          expiresAt: new Date(Date.now() + 3600000),
          sections: ['USER_MANAGEMENT'],
          permissions: ['READ', 'WRITE'],
          invitedBy: 'super-admin-id',
          invitedAt: new Date(),
        };

        const mockCreatedUser = {
          id: 'new-admin-id',
          email: 'admin@example.com',
          firstName: 'New',
          lastName: 'Admin',
          role: 'ADMIN',
          createdAt: new Date(),
        };

        mockedPrisma.adminInvitation.findUnique.mockResolvedValue(mockInvitation as any);
        mockedPrisma.$transaction.mockImplementation(async (callback) => {
          return callback({
            user: {
              create: jest.fn().mockResolvedValue(mockCreatedUser),
            },
            adminSection: {
              create: jest.fn(),
            },
            adminInvitation: {
              delete: jest.fn(),
            },
          });
        });

        const result = await adminService.acceptInvitation(acceptData);

        expect(result.message).toBe('Admin account created successfully');
        expect(result.user).toEqual(mockCreatedUser);
      });

      it('should throw error for invalid invitation token', async () => {
        mockedPrisma.adminInvitation.findUnique.mockResolvedValue(null);

        await expect(adminService.acceptInvitation(acceptData))
          .rejects
          .toThrow('Invalid or expired invitation');
      });

      it('should throw error for expired invitation', async () => {
        const expiredInvitation = {
          id: 'invitation-id',
          invitationToken: 'valid-token',
          expiresAt: new Date(Date.now() - 3600000), // expired
        };

        mockedPrisma.adminInvitation.findUnique.mockResolvedValue(expiredInvitation as any);

        await expect(adminService.acceptInvitation(acceptData))
          .rejects
          .toThrow('Invalid or expired invitation');
      });
    });

    describe('updateAdminDivision', () => {
      it('should update admin division and functions successfully', async () => {
        mockedPrisma.user.findUnique
          .mockResolvedValueOnce({ // super admin check
            id: 'super-admin-id',
            role: 'SUPER_ADMIN',
          } as any)
          .mockResolvedValueOnce({ // target admin check
            id: 'admin-id',
            role: 'ADMIN',
          } as any);

        mockedPrisma.user.update.mockResolvedValue({} as any);

        const result = await adminService.updateAdminDivision(
          'super-admin-id',
          'admin-id',
          'SOBCD',
          ['RESEARCH', 'DEVELOPMENT']
        );

        expect(result.message).toBe('Admin division/functions updated successfully');
        expect(mockedPrisma.user.update).toHaveBeenCalledWith({
          where: { id: 'admin-id' },
          data: {
            division: 'SOBCD',
            functions: ['RESEARCH', 'DEVELOPMENT'],
          },
        });
      });

      it('should throw error if requester is not super admin', async () => {
        mockedPrisma.user.findUnique.mockResolvedValueOnce({
          id: 'regular-admin-id',
          role: 'ADMIN',
        } as any);

        await expect(adminService.updateAdminDivision(
          'regular-admin-id',
          'admin-id',
          'SOBCD',
          ['RESEARCH']
        )).rejects.toThrow('Only super admins can update admin division and functions');
      });
    });
  });

  describe('OtpService', () => {
    describe('sendOtp', () => {
      beforeEach(() => {
        mockedPrisma.user.findUnique.mockResolvedValue({
          id: 'user-id',
          email: 'test@example.com',
        } as any);
        mockedPrisma.user.update.mockResolvedValue({} as any);
        mockedEmailService.sendOtpEmail.mockResolvedValue();
      });

      it('should send OTP successfully', async () => {
        await otpService.sendOtp('test@example.com', 'LOGIN');

        expect(mockedPrisma.user.update).toHaveBeenCalledWith({
          where: { id: 'user-id' },
          data: {
            otpCode: expect.any(String),
            otpExpires: expect.any(Date),
            otpPurpose: 'LOGIN',
          },
        });
        expect(mockedEmailService.sendOtpEmail).toHaveBeenCalledWith(
          'test@example.com',
          expect.any(String),
          'LOGIN'
        );
      });

      it('should throw error for non-existent user', async () => {
        mockedPrisma.user.findUnique.mockResolvedValue(null);

        await expect(otpService.sendOtp('nonexistent@example.com', 'LOGIN'))
          .rejects
          .toThrow('User not found');
      });
    });

    describe('verifyOtp', () => {
      it('should verify OTP successfully for LOGIN purpose', async () => {
        const mockUser = {
          id: 'user-id',
          email: 'test@example.com',
          role: 'FREE_MEMBER',
          otpCode: '123456',
          otpExpires: new Date(Date.now() + 600000),
          otpPurpose: 'LOGIN',
          isVerified: true,
        };

        mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
        mockedPrisma.user.update.mockResolvedValue(mockUser as any);

        const result = await otpService.verifyOtp('test@example.com', '123456', 'LOGIN');

        expect(result).toHaveProperty('tokens');
        expect(result.tokens).toHaveProperty('accessToken');
        expect(result.tokens).toHaveProperty('refreshToken');
        expect(result).toHaveProperty('user');
      });

      it('should verify OTP successfully for EMAIL_VERIFICATION purpose', async () => {
        const mockUser = {
          id: 'user-id',
          email: 'test@example.com',
          otpCode: '123456',
          otpExpires: new Date(Date.now() + 600000),
          otpPurpose: 'VERIFY_EMAIL',
          isVerified: false,
        };

        mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
        mockedPrisma.user.update.mockResolvedValue({
          ...mockUser,
          isVerified: true,
        } as any);

        const result = await otpService.verifyOtp('test@example.com', '123456', 'VERIFY_EMAIL');

        expect(result.user).toBeDefined();
        expect(mockedPrisma.user.update).toHaveBeenCalledWith({
          where: { id: 'user-id' },
          data: {
            isVerified: true,
            emailVerifiedAt: expect.any(Date),
            otpCode: null,
            otpExpires: null,
            otpPurpose: null,
          },
        });
      });

      it('should throw error for invalid OTP code', async () => {
        const mockUser = {
          id: 'user-id',
          otpCode: '123456',
          otpExpires: new Date(Date.now() + 600000),
          otpPurpose: 'LOGIN',
        };

        mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);

        await expect(otpService.verifyOtp('test@example.com', '654321', 'LOGIN'))
          .rejects
          .toThrow('Invalid OTP code');
      });

      it('should throw error for expired OTP', async () => {
        const mockUser = {
          id: 'user-id',
          otpCode: '123456',
          otpExpires: new Date(Date.now() - 600000), // expired
          otpPurpose: 'LOGIN',
        };

        mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);

        await expect(otpService.verifyOtp('test@example.com', '123456', 'LOGIN'))
          .rejects
          .toThrow('OTP expired');
      });

      it('should throw error for wrong OTP purpose', async () => {
        const mockUser = {
          id: 'user-id',
          otpCode: '123456',
          otpExpires: new Date(Date.now() + 600000),
          otpPurpose: 'LOGIN',
        };

        mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);

        await expect(otpService.verifyOtp('test@example.com', '123456', 'VERIFY_EMAIL'))
          .rejects
          .toThrow('Invalid OTP purpose');
      });
    });
  });

  describe('API Endpoints', () => {
    describe('POST /api/v1/auth/signup-flow', () => {
      it('should validate signup data', async () => {
        const response = await request(app.app)
          .post('/api/v1/auth/signup-flow')
          .send({
            email: 'invalid-email',
            password: '123', // Too short
            country: '', // Required
            state: '', // Required
          })
          .expect(400);

        expect(response.body.success).toBe(false);
        expect(response.body.message).toBe('Validation failed');
        expect(response.body.errors).toBeDefined();
      });

      it('should accept valid signup data structure', async () => {
        const validData = {
          email: 'test@example.com',
          password: 'ValidPassword123!',
          firstName: 'John',
          lastName: 'Doe',
          country: 'Nigeria',
          state: 'Lagos',
          accountType: 'individual',
          intents: ['vote or nominate'],
        };

        const response = await request(app.app)
          .post('/api/v1/auth/signup-flow')
          .send(validData);

        // Should not be a validation error (400)
        expect(response.status).not.toBe(400);
      });
    });

    describe('POST /api/v1/auth/login', () => {
      it('should validate login data', async () => {
        const response = await request(app.app)
          .post('/api/v1/auth/login')
          .send({
            email: 'invalid-email',
            password: '',
          })
          .expect(400);

        expect(response.body.success).toBe(false);
        expect(response.body.message).toBe('Validation failed');
      });

      it('should accept valid login data structure', async () => {
        const validData = {
          email: 'test@example.com',
          password: 'ValidPassword123!',
        };

        const response = await request(app.app)
          .post('/api/v1/auth/login')
          .send(validData);

        // Should not be a validation error (400)
        expect(response.status).not.toBe(400);
      });
    });

    describe('POST /api/v1/auth/send-otp', () => {
      it('should validate OTP request data', async () => {
        const response = await request(app.app)
          .post('/api/v1/auth/send-otp')
          .send({
            email: 'invalid-email',
            purpose: 'INVALID_PURPOSE',
          })
          .expect(400);

        expect(response.body.success).toBe(false);
        expect(response.body.message).toBe('Validation failed');
      });

      it('should accept valid OTP request', async () => {
        const validData = {
          email: 'test@example.com',
          purpose: 'LOGIN',
        };

        const response = await request(app.app)
          .post('/api/v1/auth/send-otp')
          .send(validData);

        // Should not be a validation error (400)
        expect(response.status).not.toBe(400);
      });
    });

    describe('POST /api/v1/auth/verify-otp', () => {
      it('should validate OTP verification data', async () => {
        const response = await request(app.app)
          .post('/api/v1/auth/verify-otp')
          .send({
            email: 'invalid-email',
            code: '12345', // Should be 6 digits
            purpose: 'INVALID_PURPOSE',
          })
          .expect(400);

        expect(response.body.success).toBe(false);
        expect(response.body.message).toBe('Validation failed');
      });
    });

    describe('GET /api/v1/auth/profile', () => {
      it('should require authentication', async () => {
        const response = await request(app.app)
          .get('/api/v1/auth/profile')
          .expect(401);

        expect(response.body.success).toBe(false);
      });

      it('should reject invalid token', async () => {
        const response = await request(app.app)
          .get('/api/v1/auth/profile')
          .set('Authorization', 'Bearer invalid-token')
          .expect(401);

        expect(response.body.success).toBe(false);
      });
    });

    describe('GET /api/v1/auth/me', () => {
      it('should require authentication', async () => {
        const response = await request(app.app)
          .get('/api/v1/auth/me')
          .expect(401);

        expect(response.body.success).toBe(false);
      });
    });

    describe('Admin Routes', () => {
      describe('POST /api/v1/auth/admin/invite', () => {
        it('should require authentication', async () => {
          const response = await request(app.app)
            .post('/api/v1/auth/admin/invite')
            .send({
              email: 'admin@example.com',
              sections: ['USER_MANAGEMENT'],
              permissions: ['READ', 'WRITE'],
            })
            .expect(401);

          expect(response.body.success).toBe(false);
        });

        it('should validate invitation data', async () => {
          const response = await request(app.app)
            .post('/api/v1/auth/admin/invite')
            .set('Authorization', 'Bearer fake-token')
            .send({
              email: 'invalid-email',
              sections: [], // Should not be empty
              permissions: ['INVALID_PERMISSION'],
            });

          // Should be validation error or auth error, not 404
          expect(response.status).not.toBe(404);
        });
      });

      describe('POST /api/v1/auth/admin/accept-invitation', () => {
        it('should validate invitation acceptance data', async () => {
          const response = await request(app.app)
            .post('/api/v1/auth/admin/accept-invitation')
            .send({
              invitationToken: '', // Required
              password: '123', // Too short
              firstName: '', // Required
              lastName: '', // Required
            })
            .expect(400);

          expect(response.body.success).toBe(false);
          expect(response.body.message).toBe('Validation failed');
        });
      });

      describe('PUT /api/v1/auth/admin/:adminId/division', () => {
        it('should require authentication', async () => {
          const response = await request(app.app)
            .put('/api/v1/auth/admin/admin-id/division')
            .send({
              division: 'SOBCD',
              functions: ['RESEARCH'],
            })
            .expect(401);

          expect(response.body.success).toBe(false);
        });

        it('should validate division update data', async () => {
          const response = await request(app.app)
            .put('/api/v1/auth/admin/admin-id/division')
            .set('Authorization', 'Bearer fake-token')
            .send({
              division: 'INVALID_DIVISION',
              functions: 'not-an-array',
            });

          // Should be validation error or auth error, not 404
          expect(response.status).not.toBe(404);
        });
      });

      describe('GET /api/v1/auth/admin/dashboard', () => {
        it('should require authentication', async () => {
          const response = await request(app.app)
            .get('/api/v1/auth/admin/dashboard')
            .expect(401);

          expect(response.body.success).toBe(false);
        });
      });
    });

    describe('Rate Limiting', () => {
      it('should apply rate limiting to auth endpoints', async () => {
        // Make multiple requests to test rate limiting
        const requests = Array(5).fill(null).map(() =>
          request(app.app)
            .post('/api/v1/auth/login')
            .send({
              email: 'test@example.com',
              password: 'password',
            })
        );

        const responses = await Promise.all(requests);

        // All requests should get through (not 404), some might be rate limited
        responses.forEach(response => {
          expect(response.status).not.toBe(404);
        });
      });
    });
  });

  describe('Utility Functions', () => {
    describe('Intent Mapping', () => {
      const { mapIntent, mapIntents, mapAccountType, mapGender, mapDivision, inferRole } = require('../utils/intentMapping');

      describe('mapIntent', () => {
        it('should map intent labels correctly', () => {
          expect(mapIntent('vote or nominate')).toBe('VOTE_OR_NOMINATE');
          expect(mapIntent('become ambassador')).toBe('BECOME_AMBASSADOR');
          expect(mapIntent('invalid intent')).toBeNull();
        });
      });

      describe('mapIntents', () => {
        it('should map multiple intents', () => {
          const result = mapIntents(['vote or nominate', 'become ambassador']);
          expect(result).toEqual(['VOTE_OR_NOMINATE', 'BECOME_AMBASSADOR']);
        });

        it('should filter out invalid intents', () => {
          const result = mapIntents(['vote or nominate', 'invalid intent']);
          expect(result).toEqual(['VOTE_OR_NOMINATE']);
        });
      });

      describe('mapAccountType', () => {
        it('should map account type labels correctly', () => {
          expect(mapAccountType('individual')).toBe('INDIVIDUAL');
          expect(mapAccountType('corporation')).toBe('CORPORATION');
          expect(mapAccountType('ngo')).toBe('NGO');
          expect(mapAccountType('invalid')).toBeUndefined();
        });
      });

      describe('mapGender', () => {
        it('should map gender labels correctly', () => {
          expect(mapGender('male')).toBe('MALE');
          expect(mapGender('female')).toBe('FEMALE');
          expect(mapGender('other')).toBe('OTHER');
          expect(mapGender('prefer not to say')).toBe('PREFER_NOT_TO_SAY');
          expect(mapGender('invalid')).toBeUndefined();
        });
      });

      describe('mapDivision', () => {
        it('should map division labels correctly', () => {
          expect(mapDivision('SOBCD')).toBe('SOBCD');
          expect(mapDivision('sobcd')).toBe('SOBCD');
          expect(mapDivision('OMBDD')).toBe('OMBDD');
          expect(mapDivision('invalid')).toBeUndefined();
        });
      });

      describe('inferRole', () => {
        it('should infer role from intents correctly', () => {
          expect(inferRole(['BECOME_AMBASSADOR'])).toBe('AMBASSADOR');
          expect(inferRole(['APPLY_AS_JUDGE'])).toBe('JUDGE');
          expect(inferRole(['APPLY_AS_NRC_VOLUNTEER'])).toBe('NRC_VOLUNTEER');
          expect(inferRole(['JOIN_NESA_TEAM'])).toBe('VOLUNTEER');
          expect(inferRole(['SPONSOR_OR_CSR_PARTNER'])).toBe('SPONSOR');
          expect(inferRole(['VOTE_OR_NOMINATE'])).toBe('FREE_MEMBER');
          expect(inferRole([])).toBe('FREE_MEMBER');
        });
      });
    });
  });
});