import { otpService } from '../services/otpService';
import { prisma } from '@/shared/database/postgresql';
import { emailService } from '@/modules/notifications/services/emailService';
import { ValidationError, NotFoundError } from '@/shared/utils/errors';

// Mock dependencies
jest.mock('@/shared/database/postgresql');
jest.mock('@/modules/notifications/services/emailService');

const mockedPrisma = prisma as jest.Mocked<typeof prisma>;
const mockedEmailService = emailService as jest.Mocked<typeof emailService>;

describe('OtpService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('sendOtp', () => {
    const mockUser = {
      id: 'user-id',
      email: 'test@example.com',
      firstName: 'John',
      lastName: 'Doe',
    };

    beforeEach(() => {
      mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
      mockedPrisma.user.update.mockResolvedValue({} as any);
      mockedEmailService.sendOtpEmail.mockResolvedValue();
    });

    it('should send OTP for LOGIN purpose', async () => {
      await otpService.sendOtp('test@example.com', 'LOGIN');

      expect(mockedPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data: {
          otpCode: expect.stringMatching(/^\d{6}$/), // 6-digit code
          otpExpires: expect.any(Date),
          otpPurpose: 'LOGIN',
        },
      });
      expect(mockedEmailService.sendOtpEmail).toHaveBeenCalledWith(
        'test@example.com',
        expect.stringMatching(/^\d{6}$/),
        'LOGIN'
      );
    });

    it('should send OTP for VERIFY_EMAIL purpose', async () => {
      await otpService.sendOtp('test@example.com', 'VERIFY_EMAIL');

      expect(mockedPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data: {
          otpCode: expect.stringMatching(/^\d{6}$/),
          otpExpires: expect.any(Date),
          otpPurpose: 'VERIFY_EMAIL',
        },
      });
    });

    it('should send OTP for PASSWORD_RESET purpose', async () => {
      await otpService.sendOtp('test@example.com', 'PASSWORD_RESET');

      expect(mockedPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data: {
          otpCode: expect.stringMatching(/^\d{6}$/),
          otpExpires: expect.any(Date),
          otpPurpose: 'PASSWORD_RESET',
        },
      });
    });

    it('should set OTP expiration to 10 minutes from now', async () => {
      const beforeCall = Date.now();
      await otpService.sendOtp('test@example.com', 'LOGIN');
      const afterCall = Date.now();

      const updateCall = mockedPrisma.user.update.mock.calls[0][0];
      const otpExpires = updateCall.data.otpExpires as Date;
      const expectedMin = new Date(beforeCall + 10 * 60 * 1000);
      const expectedMax = new Date(afterCall + 10 * 60 * 1000);

      expect(otpExpires.getTime()).toBeGreaterThanOrEqual(expectedMin.getTime());
      expect(otpExpires.getTime()).toBeLessThanOrEqual(expectedMax.getTime());
    });

    it('should generate 6-digit numeric code', async () => {
      await otpService.sendOtp('test@example.com', 'LOGIN');

      const updateCall = mockedPrisma.user.update.mock.calls[0][0];
      const otpCode = updateCall.data.otpCode;

      expect(otpCode).toMatch(/^\d{6}$/);
      expect(parseInt(otpCode)).toBeGreaterThanOrEqual(100000);
      expect(parseInt(otpCode)).toBeLessThanOrEqual(999999);
    });

    it('should throw ValidationError for empty email', async () => {
      await expect(otpService.sendOtp('', 'LOGIN'))
        .rejects
        .toThrow(ValidationError);
    });

    it('should throw NotFoundError for non-existent user', async () => {
      mockedPrisma.user.findUnique.mockResolvedValue(null);

      await expect(otpService.sendOtp('nonexistent@example.com', 'LOGIN'))
        .rejects
        .toThrow(NotFoundError);
    });

    it('should lowercase email before processing', async () => {
      await otpService.sendOtp('TEST@EXAMPLE.COM', 'LOGIN');

      expect(mockedPrisma.user.findUnique).toHaveBeenCalledWith({
        where: { email: 'test@example.com' },
      });
    });

    it('should generate different codes on multiple calls', async () => {
      const codes = new Set();
      
      // Generate multiple OTPs
      for (let i = 0; i < 10; i++) {
        mockedPrisma.user.update.mockClear();
        await otpService.sendOtp('test@example.com', 'LOGIN');
        
        const updateCall = mockedPrisma.user.update.mock.calls[0][0];
        codes.add(updateCall.data.otpCode);
      }

      // Should generate different codes (very unlikely to get duplicates)
      expect(codes.size).toBeGreaterThan(5);
    });
  });

  describe('verifyOtp', () => {
    const mockUser = {
      id: 'user-id',
      email: 'test@example.com',
      role: 'FREE_MEMBER',
      isVerified: true,
      otpCode: '123456',
      otpExpires: new Date(Date.now() + 600000), // 10 minutes from now
      otpPurpose: 'LOGIN',
    };

    beforeEach(() => {
      mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
      mockedPrisma.user.update.mockResolvedValue(mockUser as any);
    });

    it('should verify OTP successfully for LOGIN purpose', async () => {
      const result = await otpService.verifyOtp('test@example.com', '123456', 'LOGIN');

      expect(result).toHaveProperty('tokens');
      expect(result.tokens).toHaveProperty('accessToken');
      expect(result.tokens).toHaveProperty('refreshToken');
      expect(result.tokens).toHaveProperty('expiresIn');
      expect(result).toHaveProperty('user');
      expect(result.user).toMatchObject({
        id: 'user-id',
        email: 'test@example.com',
        role: 'FREE_MEMBER',
        isVerified: true,
      });

      expect(mockedPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data: {
          otpCode: null,
          otpExpires: null,
          otpPurpose: null,
        },
      });
    });

    it('should verify OTP successfully for VERIFY_EMAIL purpose', async () => {
      const unverifiedUser = {
        ...mockUser,
        isVerified: false,
        otpPurpose: 'VERIFY_EMAIL',
      };

      mockedPrisma.user.findUnique.mockResolvedValue(unverifiedUser as any);
      mockedPrisma.user.update.mockResolvedValue({
        ...unverifiedUser,
        isVerified: true,
      } as any);

      const result = await otpService.verifyOtp('test@example.com', '123456', 'VERIFY_EMAIL');

      expect(result).toHaveProperty('user');
      expect(result.user.isVerified).toBe(true);

      expect(mockedPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data: {
          isVerified: true,
          emailVerifiedAt: expect.any(Date),
          otpCode: null,
          otpExpires: null,
          otpPurpose: null,
        },
      });
    });

    it('should verify OTP successfully for PASSWORD_RESET purpose', async () => {
      const userWithPasswordReset = {
        ...mockUser,
        otpPurpose: 'PASSWORD_RESET',
      };

      mockedPrisma.user.findUnique.mockResolvedValue(userWithPasswordReset as any);

      const result = await otpService.verifyOtp('test@example.com', '123456', 'PASSWORD_RESET');

      expect(result).toHaveProperty('user');
      expect(result.user).toMatchObject({
        id: 'user-id',
        email: 'test@example.com',
      });

      expect(mockedPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data: {
          otpCode: null,
          otpExpires: null,
          otpPurpose: null,
        },
      });
    });

    it('should throw ValidationError for empty email', async () => {
      await expect(otpService.verifyOtp('', '123456', 'LOGIN'))
        .rejects
        .toThrow(ValidationError);
    });

    it('should throw ValidationError for empty code', async () => {
      await expect(otpService.verifyOtp('test@example.com', '', 'LOGIN'))
        .rejects
        .toThrow(ValidationError);
    });

    it('should throw NotFoundError for non-existent user', async () => {
      mockedPrisma.user.findUnique.mockResolvedValue(null);

      await expect(otpService.verifyOtp('nonexistent@example.com', '123456', 'LOGIN'))
        .rejects
        .toThrow(NotFoundError);
    });

    it('should throw ValidationError when no active OTP found', async () => {
      const userWithoutOtp = {
        ...mockUser,
        otpCode: null,
        otpExpires: null,
        otpPurpose: null,
      };

      mockedPrisma.user.findUnique.mockResolvedValue(userWithoutOtp as any);

      await expect(otpService.verifyOtp('test@example.com', '123456', 'LOGIN'))
        .rejects
        .toThrow(ValidationError);
    });

    it('should throw ValidationError for wrong OTP purpose', async () => {
      await expect(otpService.verifyOtp('test@example.com', '123456', 'VERIFY_EMAIL'))
        .rejects
        .toThrow(ValidationError);
    });

    it('should throw ValidationError for expired OTP', async () => {
      const userWithExpiredOtp = {
        ...mockUser,
        otpExpires: new Date(Date.now() - 600000), // 10 minutes ago
      };

      mockedPrisma.user.findUnique.mockResolvedValue(userWithExpiredOtp as any);

      await expect(otpService.verifyOtp('test@example.com', '123456', 'LOGIN'))
        .rejects
        .toThrow(ValidationError);
    });

    it('should throw ValidationError for invalid OTP code', async () => {
      await expect(otpService.verifyOtp('test@example.com', '654321', 'LOGIN'))
        .rejects
        .toThrow(ValidationError);
    });

    it('should lowercase email before processing', async () => {
      await otpService.verifyOtp('TEST@EXAMPLE.COM', '123456', 'LOGIN');

      expect(mockedPrisma.user.findUnique).toHaveBeenCalledWith({
        where: { email: 'test@example.com' },
      });
    });

    it('should clear OTP data after successful verification', async () => {
      await otpService.verifyOtp('test@example.com', '123456', 'LOGIN');

      expect(mockedPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data: {
          otpCode: null,
          otpExpires: null,
          otpPurpose: null,
        },
      });
    });

    it('should not return tokens for non-LOGIN purposes', async () => {
      const userWithEmailVerification = {
        ...mockUser,
        isVerified: false,
        otpPurpose: 'VERIFY_EMAIL',
      };

      mockedPrisma.user.findUnique.mockResolvedValue(userWithEmailVerification as any);

      const result = await otpService.verifyOtp('test@example.com', '123456', 'VERIFY_EMAIL');

      expect(result.tokens).toBeUndefined();
      expect(result).toHaveProperty('user');
    });

    it('should handle case-sensitive OTP codes', async () => {
      // OTP codes are numeric, so case shouldn't matter, but test the exact match
      await expect(otpService.verifyOtp('test@example.com', '123456', 'LOGIN'))
        .resolves
        .toBeDefined();

      // Different code should fail
      await expect(otpService.verifyOtp('test@example.com', '123457', 'LOGIN'))
        .rejects
        .toThrow(ValidationError);
    });

    it('should validate OTP code format', async () => {
      // Test with non-numeric code
      await expect(otpService.verifyOtp('test@example.com', 'abcdef', 'LOGIN'))
        .rejects
        .toThrow(ValidationError);

      // Test with wrong length
      await expect(otpService.verifyOtp('test@example.com', '12345', 'LOGIN'))
        .rejects
        .toThrow(ValidationError);

      await expect(otpService.verifyOtp('test@example.com', '1234567', 'LOGIN'))
        .rejects
        .toThrow(ValidationError);
    });
  });

  describe('Edge Cases', () => {
    it('should handle concurrent OTP requests', async () => {
      const mockUser = {
        id: 'user-id',
        email: 'test@example.com',
      };

      mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
      mockedPrisma.user.update.mockResolvedValue({} as any);
      mockedEmailService.sendOtpEmail.mockResolvedValue();

      // Send multiple OTPs concurrently
      const promises = Array(5).fill(null).map(() =>
        otpService.sendOtp('test@example.com', 'LOGIN')
      );

      await Promise.all(promises);

      // Should have called update 5 times
      expect(mockedPrisma.user.update).toHaveBeenCalledTimes(5);
      expect(mockedEmailService.sendOtpEmail).toHaveBeenCalledTimes(5);
    });

    it('should handle database errors gracefully', async () => {
      mockedPrisma.user.findUnique.mockRejectedValue(new Error('Database error'));

      await expect(otpService.sendOtp('test@example.com', 'LOGIN'))
        .rejects
        .toThrow('Database error');
    });

    it('should handle email service errors gracefully', async () => {
      const mockUser = {
        id: 'user-id',
        email: 'test@example.com',
      };

      mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
      mockedPrisma.user.update.mockResolvedValue({} as any);
      mockedEmailService.sendOtpEmail.mockRejectedValue(new Error('Email service error'));

      await expect(otpService.sendOtp('test@example.com', 'LOGIN'))
        .rejects
        .toThrow('Email service error');
    });

    it('should handle very long email addresses', async () => {
      const longEmail = 'a'.repeat(100) + '@example.com';
      const mockUser = {
        id: 'user-id',
        email: longEmail,
      };

      mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
      mockedPrisma.user.update.mockResolvedValue({} as any);
      mockedEmailService.sendOtpEmail.mockResolvedValue();

      await expect(otpService.sendOtp(longEmail, 'LOGIN'))
        .resolves
        .toBeUndefined();
    });

    it('should handle special characters in email', async () => {
      const specialEmail = 'test+special@example.com';
      const mockUser = {
        id: 'user-id',
        email: specialEmail,
      };

      mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
      mockedPrisma.user.update.mockResolvedValue({} as any);
      mockedEmailService.sendOtpEmail.mockResolvedValue();

      await expect(otpService.sendOtp(specialEmail, 'LOGIN'))
        .resolves
        .toBeUndefined();
    });
  });
});