import { signupFlowService } from '../services/signupFlowService';
import { prisma } from '@/shared/database/postgresql';
import { emailService } from '@/modules/notifications/services/emailService';
import { walletService } from '@/modules/wallet/services/walletService';
import { ConflictError, ValidationError } from '@/shared/utils/errors';

// Mock dependencies
jest.mock('@/shared/database/postgresql');
jest.mock('@/modules/notifications/services/emailService');
jest.mock('@/modules/wallet/services/walletService');

const mockedPrisma = prisma as jest.Mocked<typeof prisma>;
const mockedEmailService = emailService as jest.Mocked<typeof emailService>;
const mockedWalletService = walletService as jest.Mocked<typeof walletService>;

describe('SignupFlowService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('signup', () => {
    const baseSignupData = {
      email: 'test@example.com',
      password: 'ValidPassword123!',
      firstName: 'John',
      lastName: 'Doe',
      country: 'Nigeria',
      state: 'Lagos',
    };

    beforeEach(() => {
      mockedPrisma.user.findUnique.mockResolvedValue(null);
      mockedPrisma.user.create.mockResolvedValue({
        id: 'user-id',
        email: 'test@example.com',
        firstName: 'John',
        lastName: 'Doe',
        fullName: 'John Doe',
        role: 'FREE_MEMBER',
        accountType: 'INDIVIDUAL',
        isVerified: false,
        country: 'Nigeria',
        state: 'Lagos',
        createdAt: new Date(),
      } as any);
      mockedWalletService.createWallet.mockResolvedValue({
        id: 'wallet-id',
        userId: 'user-id',
        balance: 2,
        withdrawableBalance: 0,
      } as any);
      mockedEmailService.sendVerificationEmail.mockResolvedValue();
    });

    it('should create user with minimal required data', async () => {
      const result = await signupFlowService.signup(baseSignupData);

      expect(result).toHaveProperty('user');
      expect(result).toHaveProperty('tokens');
      expect(result.user.email).toBe('test@example.com');
      expect(mockedPrisma.user.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          email: 'test@example.com',
          firstName: 'John',
          lastName: 'Doe',
          fullName: 'John Doe',
          country: 'Nigeria',
          state: 'Lagos',
          role: 'FREE_MEMBER',
          accountType: 'INDIVIDUAL',
          isVerified: false,
        }),
        select: expect.any(Object),
      });
    });

    it('should handle full signup data with all optional fields', async () => {
      const fullSignupData = {
        ...baseSignupData,
        fullName: 'John Michael Doe',
        phoneNumber: '+2348012345678',
        gender: 'male',
        dateOfBirth: '1990-01-01',
        accountType: 'corporation',
        intents: ['become ambassador', 'vote or nominate'],
        organizationName: 'Test Corp',
        organizationType: 'Technology',
        division: 'SOBCD',
        functions: ['RESEARCH', 'DEVELOPMENT'],
      };

      await signupFlowService.signup(fullSignupData);

      expect(mockedPrisma.user.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          fullName: 'John Michael Doe',
          phone: '+2348012345678',
          gender: 'MALE',
          dateOfBirth: new Date('1990-01-01'),
          accountType: 'CORPORATION',
          intents: ['BECOME_AMBASSADOR', 'VOTE_OR_NOMINATE'],
          organizationName: 'Test Corp',
          organizationType: 'Technology',
          division: 'SOBCD',
          functions: { set: ['RESEARCH', 'DEVELOPMENT'] },
          role: 'AMBASSADOR', // Inferred from intents
        }),
        select: expect.any(Object),
      });
    });

    it('should generate fullName from firstName and lastName if not provided', async () => {
      await signupFlowService.signup(baseSignupData);

      expect(mockedPrisma.user.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          fullName: 'John Doe',
        }),
        select: expect.any(Object),
      });
    });

    it('should create wallet with signup bonus', async () => {
      await signupFlowService.signup({
        ...baseSignupData,
        accountType: 'individual',
        intents: ['become ambassador'],
      });

      expect(mockedWalletService.createWallet).toHaveBeenCalledWith(
        'user-id',
        expect.objectContaining({
          type: 'withdrawable',
          amount: expect.any(Number),
          reason: 'signup_bonus',
        })
      );
    });

    it('should send verification email', async () => {
      await signupFlowService.signup(baseSignupData);

      expect(mockedEmailService.sendVerificationEmail).toHaveBeenCalledWith(
        'test@example.com',
        expect.any(String),
        'John Doe'
      );
    });

    it('should throw ConflictError if user already exists', async () => {
      mockedPrisma.user.findUnique.mockResolvedValue({
        id: 'existing-user',
        email: 'test@example.com',
      } as any);

      await expect(signupFlowService.signup(baseSignupData))
        .rejects
        .toThrow(ConflictError);
    });

    it('should throw ValidationError for missing required fields', async () => {
      const invalidData = {
        email: 'test@example.com',
        password: 'ValidPassword123!',
        // missing firstName, lastName, country, state
      };

      await expect(signupFlowService.signup(invalidData as any))
        .rejects
        .toThrow(ValidationError);
    });

    it('should handle invalid account type gracefully', async () => {
      const dataWithInvalidAccountType = {
        ...baseSignupData,
        accountType: 'invalid-type',
      };

      await signupFlowService.signup(dataWithInvalidAccountType);

      expect(mockedPrisma.user.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          accountType: 'INDIVIDUAL', // Should default to INDIVIDUAL
        }),
        select: expect.any(Object),
      });
    });

    it('should handle invalid intents gracefully', async () => {
      const dataWithInvalidIntents = {
        ...baseSignupData,
        intents: ['invalid intent', 'become ambassador'],
      };

      await signupFlowService.signup(dataWithInvalidIntents);

      expect(mockedPrisma.user.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          intents: ['BECOME_AMBASSADOR'], // Should filter out invalid intents
          role: 'AMBASSADOR',
        }),
        select: expect.any(Object),
      });
    });

    it('should handle invalid division gracefully', async () => {
      const dataWithInvalidDivision = {
        ...baseSignupData,
        division: 'INVALID_DIVISION',
      };

      await signupFlowService.signup(dataWithInvalidDivision);

      expect(mockedPrisma.user.create).toHaveBeenCalledWith({
        data: expect.not.objectContaining({
          division: expect.anything(),
        }),
        select: expect.any(Object),
      });
    });

    it('should lowercase email before processing', async () => {
      const dataWithUppercaseEmail = {
        ...baseSignupData,
        email: 'TEST@EXAMPLE.COM',
      };

      mockedPrisma.user.findUnique.mockResolvedValue(null);

      await signupFlowService.signup(dataWithUppercaseEmail);

      expect(mockedPrisma.user.findUnique).toHaveBeenCalledWith({
        where: { email: 'test@example.com' },
      });
      expect(mockedPrisma.user.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          email: 'test@example.com',
        }),
        select: expect.any(Object),
      });
    });
  });

  describe('verifyEmail', () => {
    const mockUser = {
      id: 'user-id',
      email: 'test@example.com',
      emailVerificationToken: 'valid-token',
      emailVerificationExpires: new Date(Date.now() + 3600000),
      isVerified: false,
    };

    beforeEach(() => {
      mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
      mockedPrisma.user.update.mockResolvedValue({
        ...mockUser,
        isVerified: true,
        emailVerifiedAt: new Date(),
      } as any);
    });

    it('should verify email successfully with valid token', async () => {
      const result = await signupFlowService.verifyEmail('test@example.com', 'valid-token');

      expect(result.message).toBe('Email verified successfully');
      expect(mockedPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data: {
          isVerified: true,
          emailVerifiedAt: expect.any(Date),
          emailVerificationToken: null,
          emailVerificationExpires: null,
        },
      });
    });

    it('should throw error for non-existent user', async () => {
      mockedPrisma.user.findUnique.mockResolvedValue(null);

      await expect(signupFlowService.verifyEmail('nonexistent@example.com', 'token'))
        .rejects
        .toThrow('User not found');
    });

    it('should throw error for already verified user', async () => {
      mockedPrisma.user.findUnique.mockResolvedValue({
        ...mockUser,
        isVerified: true,
      } as any);

      await expect(signupFlowService.verifyEmail('test@example.com', 'token'))
        .rejects
        .toThrow('Email already verified');
    });

    it('should throw error for invalid token', async () => {
      await expect(signupFlowService.verifyEmail('test@example.com', 'invalid-token'))
        .rejects
        .toThrow('Invalid verification token');
    });

    it('should throw error for expired token', async () => {
      mockedPrisma.user.findUnique.mockResolvedValue({
        ...mockUser,
        emailVerificationExpires: new Date(Date.now() - 3600000), // expired
      } as any);

      await expect(signupFlowService.verifyEmail('test@example.com', 'valid-token'))
        .rejects
        .toThrow('Verification token expired');
    });

    it('should handle missing verification token', async () => {
      mockedPrisma.user.findUnique.mockResolvedValue({
        ...mockUser,
        emailVerificationToken: null,
      } as any);

      await expect(signupFlowService.verifyEmail('test@example.com', 'token'))
        .rejects
        .toThrow('No verification token found');
    });

    it('should lowercase email before processing', async () => {
      await signupFlowService.verifyEmail('TEST@EXAMPLE.COM', 'valid-token');

      expect(mockedPrisma.user.findUnique).toHaveBeenCalledWith({
        where: { email: 'test@example.com' },
      });
    });
  });

  describe('resendVerificationEmail', () => {
    const mockUser = {
      id: 'user-id',
      email: 'test@example.com',
      firstName: 'John',
      lastName: 'Doe',
      isVerified: false,
    };

    beforeEach(() => {
      mockedPrisma.user.findUnique.mockResolvedValue(mockUser as any);
      mockedPrisma.user.update.mockResolvedValue({
        ...mockUser,
        emailVerificationToken: 'new-token',
        emailVerificationExpires: new Date(Date.now() + 3600000),
      } as any);
      mockedEmailService.sendVerificationEmail.mockResolvedValue();
    });

    it('should resend verification email successfully', async () => {
      const result = await signupFlowService.resendVerificationEmail('test@example.com');

      expect(result.message).toBe('Verification email sent');
      expect(mockedPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data: {
          emailVerificationToken: expect.any(String),
          emailVerificationExpires: expect.any(Date),
        },
      });
      expect(mockedEmailService.sendVerificationEmail).toHaveBeenCalled();
    });

    it('should throw error for non-existent user', async () => {
      mockedPrisma.user.findUnique.mockResolvedValue(null);

      await expect(signupFlowService.resendVerificationEmail('nonexistent@example.com'))
        .rejects
        .toThrow('User not found');
    });

    it('should throw error for already verified user', async () => {
      mockedPrisma.user.findUnique.mockResolvedValue({
        ...mockUser,
        isVerified: true,
      } as any);

      await expect(signupFlowService.resendVerificationEmail('test@example.com'))
        .rejects
        .toThrow('Email already verified');
    });

    it('should generate new verification token', async () => {
      await signupFlowService.resendVerificationEmail('test@example.com');

      expect(mockedPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data: {
          emailVerificationToken: expect.stringMatching(/^[a-f0-9]{64}$/), // 32 bytes hex
          emailVerificationExpires: expect.any(Date),
        },
      });
    });
  });
});