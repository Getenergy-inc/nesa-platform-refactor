import { prisma } from '@/shared/database/postgresql';
import { walletService } from '@/modules/wallet/services/walletService';
import { WalletTransactionType, WalletTransactionStatus } from '@prisma/client';
import logger from '@/shared/utils/logger';

export interface CastVoteParams {
  voterId: string;
  nominationId: string;
  ipAddress?: string | undefined;
  userAgent?: string | undefined;
}

export interface VoteResult {
  voteId: string;
  nominationId: string;
  nomineeName: string;
  nomineeCategory: string;
  agcAmount: number;
  weight: number;
  totalVotesForNomination: number;
  totalAgcSpent: number;
  userRemainingBalance: number;
}

export interface VotingStats {
  nominationId: string;
  totalVotes: number;
  totalAgcSpent: number;
  uniqueVoters: number;
  averageVoteAmount: number;
  topVoters: Array<{
    voterId: string;
    voterName: string;
    totalAgcSpent: number;
    voteCount: number;
  }>;
}

class VotingService {
  private readonly VOTE_COST = 3; // Fixed cost: 3 AGC per vote

  /**
   * Cast a vote for a nomination
   * Users can vote multiple times for the same nomination
   * Fixed cost: 3 AGC per vote
   */
  async castVote(params: CastVoteParams): Promise<VoteResult> {
    const { voterId, nominationId, ipAddress, userAgent } = params;
    const agcAmount = this.VOTE_COST; // Always 3 AGC per vote

    // Check if nomination exists and is eligible for voting
    const nomination = await prisma.nomination.findUnique({
      where: { id: nominationId },
      select: { 
        id: true, 
        status: true, 
        fullName: true,
        awardCategory: true,
        subcategory: true,
      },
    });

    if (!nomination) {
      throw new Error('Nomination not found');
    }

    // Check if voting is frozen globally
    const freezeControl = await prisma.freezeControl.findFirst({
      orderBy: { createdAt: 'desc' },
    });

    if (freezeControl?.freezeVoting) {
      throw new Error('Voting is currently frozen. Please try again later.');
    }

    // Use transaction to ensure atomicity
    return await prisma.$transaction(async (tx) => {
      // 1. Check user's wallet balance
      const wallet = await walletService.getWalletByUserId(voterId);
      const totalAvailable = wallet.agcWithdrawableBalance + wallet.agcLockedBalance;

      if (totalAvailable < agcAmount) {
        throw new Error(
          `Insufficient AGC balance. You have ${totalAvailable} AGC but need ${agcAmount} AGC to vote.`
        );
      }

      // 2. Deduct AGC from wallet (prefer withdrawable first, then locked)
      let remainingToDeduct = agcAmount;
      let deductedWithdrawable = 0;
      let deductedLocked = 0;

      if (wallet.agcWithdrawableBalance >= remainingToDeduct) {
        // Deduct all from withdrawable
        deductedWithdrawable = remainingToDeduct;
        await tx.wallet.update({
          where: { id: wallet.id },
          data: { agcWithdrawableBalance: { decrement: remainingToDeduct } },
        });
      } else {
        // Deduct from both
        deductedWithdrawable = wallet.agcWithdrawableBalance;
        deductedLocked = remainingToDeduct - wallet.agcWithdrawableBalance;

        await tx.wallet.update({
          where: { id: wallet.id },
          data: {
            agcWithdrawableBalance: 0,
            agcLockedBalance: { decrement: deductedLocked },
          },
        });
      }

      // 3. Create wallet transaction
      await tx.walletTransaction.create({
        data: {
          walletId: wallet.id,
          type: WalletTransactionType.SPEND,
          amount: agcAmount,
          reason: 'vote',
          description: `Vote for ${nomination.fullName} (${agcAmount} AGC)`,
          referenceId: nominationId,
          status: WalletTransactionStatus.COMPLETED,
        },
      });

      // 4. Calculate vote weight (1 AGC = 1 weight)
      const weight = agcAmount;

      // 5. Create vote record
      const vote = await tx.vote.create({
        data: {
          voterId,
          nominationId,
          agcAmount,
          weight,
          ipAddress: ipAddress || null,
          userAgent: userAgent || null,
        },
      });

      // 6. Get voting statistics for this nomination
      const stats = await tx.vote.aggregate({
        where: { nominationId },
        _count: true,
        _sum: { agcAmount: true },
      });

      // 7. Get updated wallet balance
      const updatedWallet = await tx.wallet.findUnique({
        where: { id: wallet.id },
        select: {
          agcWithdrawableBalance: true,
          agcLockedBalance: true,
        },
      });

      logger.info('Vote cast successfully', {
        voteId: vote.id,
        voterId,
        nominationId,
        agcAmount,
        weight,
      });

      const result = {
        voteId: vote.id,
        nominationId,
        nomineeName: nomination.fullName,
        nomineeCategory: `${nomination.awardCategory} - ${nomination.subcategory}`,
        agcAmount,
        weight,
        totalVotesForNomination: stats._count,
        totalAgcSpent: stats._sum.agcAmount || 0,
        userRemainingBalance:
          (updatedWallet?.agcWithdrawableBalance || 0) +
          (updatedWallet?.agcLockedBalance || 0),
      };

      return result;
    });
  }

  /**
   * Get all votes by a user
   */
  async getUserVotes(
    userId: string,
    options?: { page?: number; limit?: number }
  ) {
    const page = options?.page || 1;
    const limit = options?.limit || 20;
    const skip = (page - 1) * limit;

    const [votes, total] = await Promise.all([
      prisma.vote.findMany({
        where: { voterId: userId },
        include: {
          nomination: {
            select: {
              id: true,
              fullName: true,
              awardCategory: true,
              subcategory: true,
              status: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.vote.count({
        where: { voterId: userId },
      }),
    ]);

    // Calculate user's total spending on votes
    const totalSpent = await prisma.vote.aggregate({
      where: { voterId: userId },
      _sum: { agcAmount: true },
      _count: true,
    });

    return {
      votes,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
      summary: {
        totalVotes: totalSpent._count,
        totalAgcSpent: totalSpent._sum.agcAmount || 0,
      },
    };
  }

  /**
   * Get all votes for a specific nomination
   */
  async getNominationVotes(
    nominationId: string,
    options?: { page?: number; limit?: number }
  ) {
    const page = options?.page || 1;
    const limit = options?.limit || 20;
    const skip = (page - 1) * limit;

    const [votes, total] = await Promise.all([
      prisma.vote.findMany({
        where: { nominationId },
        include: {
          voter: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              fullName: true,
              email: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.vote.count({
        where: { nominationId },
      }),
    ]);

    return {
      votes,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  /**
   * Get voting statistics for a nomination
   */
  async getVotingStats(nominationId: string): Promise<VotingStats> {
    // Get basic stats
    const stats = await prisma.vote.aggregate({
      where: { nominationId },
      _count: true,
      _sum: { agcAmount: true },
    });

    // Get unique voters count
    const uniqueVoters = await prisma.vote.findMany({
      where: { nominationId },
      select: { voterId: true },
      distinct: ['voterId'],
    });

    // Get top voters
    const topVotersData = await prisma.vote.groupBy({
      by: ['voterId'],
      where: { nominationId },
      _sum: { agcAmount: true },
      _count: true,
      orderBy: { _sum: { agcAmount: 'desc' } },
      take: 10,
    });

    // Fetch voter details
    const voterIds = topVotersData.map((v) => v.voterId);
    const voters = await prisma.user.findMany({
      where: { id: { in: voterIds } },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        fullName: true,
      },
    });

    const voterMap = new Map(voters.map((v) => [v.id, v]));

    const topVoters = topVotersData.map((v) => {
      const voter = voterMap.get(v.voterId);
      return {
        voterId: v.voterId,
        voterName: voter?.fullName || `${voter?.firstName} ${voter?.lastName}` || 'Anonymous',
        totalAgcSpent: v._sum.agcAmount || 0,
        voteCount: v._count,
      };
    });

    const totalVotes = stats._count;
    const totalAgcSpent = stats._sum.agcAmount || 0;
    const averageVoteAmount = totalVotes > 0 ? totalAgcSpent / totalVotes : 0;

    return {
      nominationId,
      totalVotes,
      totalAgcSpent,
      uniqueVoters: uniqueVoters.length,
      averageVoteAmount,
      topVoters,
    };
  }

  /**
   * Get user's voting summary
   */
  async getUserVotingSummary(userId: string) {
    const [totalStats, nominationsVotedFor] = await Promise.all([
      prisma.vote.aggregate({
        where: { voterId: userId },
        _count: true,
        _sum: { agcAmount: true },
      }),
      prisma.vote.findMany({
        where: { voterId: userId },
        select: { nominationId: true },
        distinct: ['nominationId'],
      }),
    ]);

    return {
      totalVotes: totalStats._count,
      totalAgcSpent: totalStats._sum.agcAmount || 0,
      nominationsVotedFor: nominationsVotedFor.length,
      averageVoteAmount:
        totalStats._count > 0
          ? (totalStats._sum.agcAmount || 0) / totalStats._count
          : 0,
    };
  }

  /**
   * Check if voting is currently allowed
   */
  async isVotingAllowed(): Promise<{ allowed: boolean; reason?: string }> {
    const freezeControl = await prisma.freezeControl.findFirst({
      orderBy: { createdAt: 'desc' },
    });

    if (freezeControl?.freezeVoting) {
      return {
        allowed: false,
        reason: freezeControl.reason || 'Voting is temporarily frozen',
      };
    }

    return { allowed: true };
  }

  /**
   * Get leaderboard of top voters (across all nominations)
   */
  async getTopVoters(limit: number = 10) {
    const topVotersData = await prisma.vote.groupBy({
      by: ['voterId'],
      _sum: { agcAmount: true },
      _count: true,
      orderBy: { _sum: { agcAmount: 'desc' } },
      take: limit,
    });

    const voterIds = topVotersData.map((v) => v.voterId);
    const voters = await prisma.user.findMany({
      where: { id: { in: voterIds } },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        fullName: true,
        country: true,
      },
    });

    const voterMap = new Map(voters.map((v) => [v.id, v]));

    return topVotersData.map((v, index) => {
      const voter = voterMap.get(v.voterId);
      return {
        rank: index + 1,
        voterId: v.voterId,
        voterName: voter?.fullName || `${voter?.firstName} ${voter?.lastName}` || 'Anonymous',
        country: voter?.country || 'Unknown',
        totalAgcSpent: v._sum.agcAmount || 0,
        totalVotes: v._count,
      };
    });
  }

  /**
   * Get global voting statistics
   */
  async getGlobalStats() {
    // Get total nominations count
    const totalNominations = await prisma.nomination.count();

    // Get approved nominations count
    const approvedNominations = await prisma.nomination.count({
      where: { status: 'APPROVED' },
    });

    // Get total votes cast
    const totalVotesCast = await prisma.vote.count();

    // Get total AGC spent on voting
    const agcStats = await prisma.vote.aggregate({
      _sum: { agcAmount: true },
    });

    // Get unique voters count
    const uniqueVoters = await prisma.vote.groupBy({
      by: ['voterId'],
    });

    return {
      totalNominations,
      approvedNominations,
      totalVotesCast,
      totalAgcSpent: agcStats._sum.agcAmount || 0,
      uniqueVoters: uniqueVoters.length,
    };
  }
}

export const votingService = new VotingService();
