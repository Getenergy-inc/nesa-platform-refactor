# Voting System

Complete voting system with AGC wallet integration. Users can vote multiple times for any nomination using their AGC balance.

## Features

### ✅ Implemented

1. **Multiple Votes Per Nomination**
   - Users can vote as many times as they want for the same nomination
   - Each vote costs AGC (minimum 1 AGC)
   - No unique constraint - unlimited voting

2. **AGC Integration**
   - Votes deduct from user's wallet balance
   - Uses withdrawable balance first, then locked balance
   - Transaction recorded for each vote
   - Real-time balance updates

3. **Vote Weight System**
   - 1 AGC = 1 vote weight
   - More AGC = more influence
   - Transparent and fair

4. **Fraud Prevention**
   - IP address tracking
   - User agent tracking
   - Vote freezing capability
   - Transaction audit trail

5. **Voting Statistics**
   - Total votes per nomination
   - Total AGC spent
   - Unique voters count
   - Average vote amount
   - Top voters leaderboard

6. **User Voting History**
   - View all votes cast
   - Total AGC spent
   - Nominations voted for
   - Paginated results

## API Endpoints

### Public Endpoints

#### Check Voting Status
```http
GET /api/v1/voting/status
```

Response:
```json
{
  "success": true,
  "data": {
    "allowed": true
  }
}
```

#### Get Leaderboard
```http
GET /api/v1/voting/leaderboard?limit=10
```

Response:
```json
{
  "success": true,
  "data": [
    {
      "rank": 1,
      "voterId": "user-id",
      "voterName": "John Doe",
      "country": "Nigeria",
      "totalAgcSpent": 500,
      "totalVotes": 25
    }
  ]
}
```

#### Get Nomination Voting Stats
```http
GET /api/v1/voting/stats/:nominationId
```

Response:
```json
{
  "success": true,
  "data": {
    "nominationId": "nom-123",
    "totalVotes": 150,
    "totalAgcSpent": 2500,
    "uniqueVoters": 45,
    "averageVoteAmount": 16.67,
    "topVoters": [
      {
        "voterId": "user-1",
        "voterName": "Jane Smith",
        "totalAgcSpent": 200,
        "voteCount": 10
      }
    ]
  }
}
```

#### Get Nomination Votes
```http
GET /api/v1/voting/nomination/:nominationId?page=1&limit=20
```

Response:
```json
{
  "success": true,
  "data": {
    "votes": [
      {
        "id": "vote-123",
        "voterId": "user-1",
        "agcAmount": 10,
        "weight": 10,
        "createdAt": "2025-01-10T12:00:00Z",
        "voter": {
          "id": "user-1",
          "fullName": "John Doe",
          "email": "john@example.com"
        }
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 150,
      "totalPages": 8
    }
  }
}
```

### Protected Endpoints (Require Authentication)

#### Cast a Vote
```http
POST /api/v1/voting/cast
Authorization: Bearer <token>
Content-Type: application/json

{
  "nominationId": "nom-123",
  "agcAmount": 10
}
```

Response:
```json
{
  "success": true,
  "message": "Vote cast successfully!",
  "data": {
    "voteId": "vote-456",
    "nominationId": "nom-123",
    "agcAmount": 10,
    "weight": 10,
    "totalVotesForNomination": 151,
    "totalAgcSpent": 2510,
    "userRemainingBalance": 140
  }
}
```

#### Get My Votes
```http
GET /api/v1/voting/my-votes?page=1&limit=20
Authorization: Bearer <token>
```

Response:
```json
{
  "success": true,
  "data": {
    "votes": [
      {
        "id": "vote-123",
        "nominationId": "nom-123",
        "agcAmount": 10,
        "weight": 10,
        "createdAt": "2025-01-10T12:00:00Z",
        "nomination": {
          "id": "nom-123",
          "fullName": "Jane Smith",
          "awardCategory": "Best Entrepreneur",
          "subcategory": "Technology",
          "status": "APPROVED"
        }
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 5,
      "totalPages": 1
    },
    "summary": {
      "totalVotes": 5,
      "totalAgcSpent": 50
    }
  }
}
```

#### Get My Voting Summary
```http
GET /api/v1/voting/my-summary
Authorization: Bearer <token>
```

Response:
```json
{
  "success": true,
  "data": {
    "totalVotes": 5,
    "totalAgcSpent": 50,
    "nominationsVotedFor": 3,
    "averageVoteAmount": 10
  }
}
```

## Voting Flow

### 1. User Initiates Vote

```javascript
const response = await fetch('/api/v1/voting/cast', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    nominationId: 'nom-123',
    agcAmount: 10
  })
});

const result = await response.json();
```

### 2. System Validates

- ✅ User is authenticated
- ✅ Nomination exists
- ✅ Voting is not frozen
- ✅ User has sufficient AGC balance
- ✅ Vote amount is within limits (1-1000 AGC)

### 3. System Processes Vote

1. Deduct AGC from wallet (withdrawable first, then locked)
2. Create wallet transaction (SPEND type)
3. Create vote record
4. Update voting statistics
5. Return confirmation

### 4. User Receives Confirmation

```json
{
  "success": true,
  "message": "Vote cast successfully!",
  "data": {
    "voteId": "vote-456",
    "agcAmount": 10,
    "weight": 10,
    "totalVotesForNomination": 151,
    "userRemainingBalance": 140
  }
}
```

## Vote Weight System

**Simple Formula**: 1 AGC = 1 Vote Weight

```
Vote Weight = AGC Amount

Examples:
- 1 AGC = 1 weight
- 10 AGC = 10 weight
- 100 AGC = 100 weight
```

This ensures:
- Transparent and fair
- Easy to understand
- Proportional influence

## AGC Balance Usage

### Priority Order

1. **Withdrawable Balance** (used first)
2. **Locked Balance** (used if withdrawable insufficient)

### Example

User has:
- Withdrawable: 30 AGC
- Locked: 20 AGC
- Total: 50 AGC

User votes with 40 AGC:
- Deduct 30 AGC from withdrawable (now 0)
- Deduct 10 AGC from locked (now 10)
- Total remaining: 10 AGC

## Voting Limits

### Per Vote Limits

- **Minimum**: 1 AGC per vote
- **Maximum**: 1,000 AGC per vote

### No Frequency Limits

- ✅ Vote as many times as you want
- ✅ Vote for same nomination multiple times
- ✅ No cooldown period
- ✅ No daily/weekly limits

### Only Limit: Your AGC Balance

## Fraud Prevention

### Tracking

- **IP Address**: Recorded for each vote
- **User Agent**: Browser/device information
- **Timestamp**: Exact time of vote
- **Transaction ID**: Linked to wallet transaction

### Admin Controls

- **Freeze Voting**: Temporarily disable all voting
- **View Vote History**: Audit trail of all votes
- **Suspicious Pattern Detection**: Monitor for unusual activity

## Error Handling

### Common Errors

**Insufficient Balance**:
```json
{
  "success": false,
  "message": "Insufficient AGC balance. You have 5 AGC but need 10 AGC to vote."
}
```

**Voting Frozen**:
```json
{
  "success": false,
  "message": "Voting is currently frozen. Please try again later."
}
```

**Invalid Amount**:
```json
{
  "success": false,
  "message": "Minimum vote amount is 1 AGC"
}
```

**Nomination Not Found**:
```json
{
  "success": false,
  "message": "Nomination not found"
}
```

## Database Schema

### Vote Model

```prisma
model Vote {
  id            String      @id @default(cuid())
  voterId       String
  nominationId  String
  agcAmount     Float
  weight        Float       @default(1.0)
  ipAddress     String?
  userAgent     String?
  createdAt     DateTime    @default(now())

  voter         User        @relation(...)
  nomination    Nomination  @relation(...)

  @@index([voterId])
  @@index([nominationId])
  @@index([createdAt])
}
```

**Note**: No unique constraint on `[voterId, nominationId]` - allows multiple votes!

### Wallet Transaction

Each vote creates a transaction:
```typescript
{
  type: 'SPEND',
  amount: agcAmount,
  reason: 'vote',
  description: 'Vote for [Nominee Name] (10 AGC)',
  referenceId: nominationId,
  status: 'COMPLETED'
}
```

## Testing

### Test Voting Flow

1. **Check Balance**:
```bash
curl http://localhost:5000/api/v1/wallet/balance \
  -H "Authorization: Bearer TOKEN"
```

2. **Cast Vote**:
```bash
curl -X POST http://localhost:5000/api/v1/voting/cast \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"nominationId": "nom-123", "agcAmount": 10}'
```

3. **Check Updated Balance**:
```bash
curl http://localhost:5000/api/v1/wallet/balance \
  -H "Authorization: Bearer TOKEN"
```

4. **View Vote History**:
```bash
curl http://localhost:5000/api/v1/voting/my-votes \
  -H "Authorization: Bearer TOKEN"
```

### Test Multiple Votes

```bash
# Vote 1
curl -X POST http://localhost:5000/api/v1/voting/cast \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"nominationId": "nom-123", "agcAmount": 5}'

# Vote 2 (same nomination)
curl -X POST http://localhost:5000/api/v1/voting/cast \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"nominationId": "nom-123", "agcAmount": 10}'

# Vote 3 (same nomination)
curl -X POST http://localhost:5000/api/v1/voting/cast \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"nominationId": "nom-123", "agcAmount": 15}'
```

All three votes will succeed!

## Security

### Transaction Atomicity

All vote operations use database transactions:
- Balance check
- AGC deduction
- Vote creation
- Transaction recording

If any step fails, entire operation rolls back.

### Audit Trail

Every vote is tracked:
- Who voted (voterId)
- What they voted for (nominationId)
- How much they spent (agcAmount)
- When they voted (createdAt)
- Where they voted from (ipAddress)
- What device (userAgent)

### Admin Monitoring

Admins can:
- View all votes
- See voting patterns
- Detect suspicious activity
- Freeze voting if needed

## Performance

### Optimizations

- **Indexed Queries**: Fast lookups by voterId, nominationId
- **Aggregated Stats**: Cached voting statistics
- **Paginated Results**: Efficient data loading
- **Transaction Batching**: Atomic operations

### Expected Performance

- Vote casting: < 500ms
- Vote history: < 200ms
- Statistics: < 300ms
- Leaderboard: < 400ms

## Future Enhancements

### Potential Features

1. **Vote Campaigns**
   - Bonus AGC for voting during campaigns
   - Special voting events

2. **Vote Notifications**
   - Email when someone votes for your nomination
   - Push notifications for vote milestones

3. **Vote Analytics**
   - Voting trends over time
   - Category-wise analysis
   - Geographic distribution

4. **Social Features**
   - Share votes on social media
   - Vote with friends
   - Group voting

5. **Gamification**
   - Badges for voting milestones
   - Voter levels and rewards
   - Voting challenges

## Support

For issues or questions:
- **Email**: support@nesa-africa.com
- **Documentation**: `/docs`
- **API Reference**: This file

---

**Last Updated**: January 2025
**Version**: 1.0.0
**Status**: Production Ready
