import { Request, Response, NextFunction } from "express";
import { votingService } from "../services/votingService";
import { z } from "zod";
import logger from "@/shared/utils/logger";

const castVoteSchema = z.object({
  nominationId: z.string().min(1, "Nomination ID is required"),
});

export class VotingController {
  /**
   * Send vote confirmation email asynchronously (don't block response)
   */
  private async sendVoteConfirmationEmailAsync(
    email: string,
    voterName: string,
    nomineeName: string,
    nomineeCategory: string,
    agcSpent: number,
    voteWeight: number,
    remainingBalance: number,
    totalVotesForNominee: number
  ): Promise<void> {
    try {
      const { emailService } = await import(
        "@/modules/notifications/services/emailService"
      );
      await emailService.sendVoteConfirmationEmail(
        email,
        voterName,
        nomineeName,
        nomineeCategory,
        agcSpent,
        voteWeight,
        remainingBalance,
        totalVotesForNominee
      );
    } catch (error) {
      logger.error("Failed to send vote confirmation email:", error);
      // Don't throw - this is a non-critical operation
    }
  }

  /**
   * @description Cast a vote for a nomination
   * @route POST /api/v1/voting/cast
   */
  async castVote(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const userId = (req as any).user?.id;
      const email = (req as any).user?.email;

      if (!userId) {
        res.status(401).json({ message: "Unauthorized" });
        return;
      }

      const { nominationId } = castVoteSchema.parse(req.body);

      // Get IP and user agent for fraud detection
      const ipAddress =
        req.ip || (req.headers["x-forwarded-for"] as string) || undefined;
      const userAgent = req.headers["user-agent"];

      const result = await votingService.castVote({
        voterId: userId,
        nominationId,
        ipAddress: ipAddress || undefined,
        userAgent: userAgent || undefined,
      });

      logger.info("Vote cast", {
        userId,
        email,
        nominationId,
        voteId: result.voteId,
      });

      // Send vote confirmation email (async, don't wait)
      const userName =
        (req as any).user?.firstName || (req as any).user?.fullName || "Member";
      this.sendVoteConfirmationEmailAsync(
        email,
        userName,
        result.nomineeName,
        result.nomineeCategory,
        result.agcAmount,
        result.weight,
        result.userRemainingBalance,
        result.totalVotesForNomination
      ).catch((err) => {
        logger.error("Failed to send vote confirmation email:", err);
      });

      res.status(201).json({
        success: true,
        message: "Vote cast successfully!",
        data: result,
      });
    } catch (error) {
      if (error instanceof Error) {
        logger.error("Failed to cast vote", { error: error.message });
        res.status(400).json({
          success: false,
          message: error.message,
        });
      } else {
        next(error);
      }
    }
  }

  /**
   * @description Get current user's votes
   * @route GET /api/v1/voting/my-votes
   */
  async getMyVotes(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const userId = (req as any).user?.id;

      if (!userId) {
        res.status(401).json({ message: "Unauthorized" });
        return;
      }

      const page = parseInt((req.query.page as string) || "1", 10);
      const limit = parseInt((req.query.limit as string) || "20", 10);

      const result = await votingService.getUserVotes(userId, { page, limit });

      res.status(200).json({
        success: true,
        message: "User votes retrieved successfully",
        data: result,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * @description Get votes for a specific nomination
   * @route GET /api/v1/voting/nomination/:nominationId
   */
  async getNominationVotes(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { nominationId } = req.params;

      if (!nominationId) {
        res.status(400).json({ message: "Nomination ID is required" });
        return;
      }

      const page = parseInt((req.query.page as string) || "1", 10);
      const limit = parseInt((req.query.limit as string) || "20", 10);

      const result = await votingService.getNominationVotes(nominationId, {
        page,
        limit,
      });

      res.status(200).json({
        success: true,
        message: "Nomination votes retrieved successfully",
        data: result,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * @description Get voting statistics for a nomination
   * @route GET /api/v1/voting/stats/:nominationId
   */
  async getVotingStats(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { nominationId } = req.params;

      if (!nominationId) {
        res.status(400).json({ message: "Nomination ID is required" });
        return;
      }

      const stats = await votingService.getVotingStats(nominationId);

      res.status(200).json({
        success: true,
        message: "Voting statistics retrieved successfully",
        data: stats,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * @description Get current user's voting summary
   * @route GET /api/v1/voting/my-summary
   */
  async getMySummary(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const userId = (req as any).user?.id;

      if (!userId) {
        res.status(401).json({ message: "Unauthorized" });
        return;
      }

      const summary = await votingService.getUserVotingSummary(userId);

      res.status(200).json({
        success: true,
        message: "Voting summary retrieved successfully",
        data: summary,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * @description Check if voting is currently allowed
   * @route GET /api/v1/voting/status
   */
  async getVotingStatus(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const status = await votingService.isVotingAllowed();

      res.status(200).json({
        success: true,
        data: status,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * @description Get leaderboard of top voters
   * @route GET /api/v1/voting/leaderboard
   */
  async getLeaderboard(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const limit = parseInt((req.query.limit as string) || "10", 10);

      const leaderboard = await votingService.getTopVoters(limit);

      res.status(200).json({
        success: true,
        message: "Leaderboard retrieved successfully",
        data: leaderboard,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * @description Get global voting statistics
   * @route GET /api/v1/voting/global-stats
   */
  async getGlobalStats(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const stats = await votingService.getGlobalStats();

      res.status(200).json({
        success: true,
        message: "Global statistics retrieved successfully",
        data: stats,
      });
    } catch (error) {
      next(error);
    }
  }
}

export const votingController = new VotingController();
