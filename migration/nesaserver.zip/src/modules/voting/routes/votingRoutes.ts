import { Router } from 'express';
import { votingController } from '../controllers/votingController';
import { verifyToken } from '@/shared/middleware/auth';

const votingRouter = Router();

// Public routes
votingRouter.get('/status', votingController.getVotingStatus.bind(votingController));
votingRouter.get('/global-stats', votingController.getGlobalStats.bind(votingController));
votingRouter.get('/leaderboard', votingController.getLeaderboard.bind(votingController));
votingRouter.get('/stats/:nominationId', votingController.getVotingStats.bind(votingController));
votingRouter.get('/nomination/:nominationId', votingController.getNominationVotes.bind(votingController));

// Protected routes (require authentication)
votingRouter.use(verifyToken);

votingRouter.post('/cast', votingController.castVote.bind(votingController));
votingRouter.get('/my-votes', votingController.getMyVotes.bind(votingController));
votingRouter.get('/my-summary', votingController.getMySummary.bind(votingController));

export default votingRouter;
