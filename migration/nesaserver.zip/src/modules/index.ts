// Import route modules (will be created later)
// import authRoutes from './src/modules/auth/routes';
// import nrcRoutes from './src/modules/nrc/routes';
// import nominationRoutes from './src/modules/nominations/routes';
// import judgeRoutes from './src/modules/judges/routes';
// import walletRoutes from './src/modules/wallet/routes';
// import fileRoutes from './src/modules/files/routes';
// import notificationRoutes from './src/modules/notifications/routes';
// import adminRoutes from './src/modules/admin/routes';