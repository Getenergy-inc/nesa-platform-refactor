import { 
  NRCTask, 
  AGCTransaction, 
  NRCDashboardStats, 
  NRCActivity,
  NRCReport,
  NRCLeaderboard,
  NRCVolunteer,
  NRCVolunteerInput,
  VolunteerLevel,
  NRCRole,
  TransactionType,
  TransactionStatus,
  ActivityType,
  TaskStatus,
  TaskPriority
} from '../types/index';
import { NRCUtils } from '../utils/nrcUtils';

// Create a more specific type for registration data that includes the phone property.
type NRCVolunteerRegistrationData = NRCVolunteerInput & { phone?: string };

export class NRCService {
  protected db: any; // This should be your database connection

  constructor(database: any) {
    this.db = database;
  }

  /**
   * Register a new NRC volunteer
   */
  async registerVolunteer(volunteerData: NRCVolunteerRegistrationData): Promise<NRCVolunteer> {
    try {
      // First, create an NRC application if it doesn't exist
      let application = await this.db.nRCApplication.findUnique({
        where: { userId: volunteerData.userId! }
      });

      if (!application) {
        application = await this.db.nRCApplication.create({
          data: {
            userId: volunteerData.userId!,
            fullName: volunteerData.fullName || 'Unknown',
            email: volunteerData.email || '',
            phone: volunteerData.phone || '',
            country: volunteerData.country!,
            region: volunteerData.region,
            volunteerType: 'REGIONAL_VOLUNTEER',
            status: 'APPROVED',
            motivation: 'Auto-generated application',
            experience: 'N/A',
            availability: 'Available',
            skills: [],
            commitment: true,
            terms: true,
            submittedAt: new Date(),
            reviewedAt: new Date(),
            approvedAt: new Date()
          }
        });
      }

      // Create the volunteer record
      const volunteerRecord = await this.db.nRCVolunteer.create({
        data: {
          applicationId: application.id,
          userId: volunteerData.userId!,
          fullName: volunteerData.fullName || 'Unknown',
          email: volunteerData.email || '',
          country: volunteerData.country!,
          region: volunteerData.region,
          volunteerType: 'REGIONAL_VOLUNTEER',
          approvalDate: new Date(),
          nomineesUploaded: 0,
          targetNominees: 200,
          completionRate: 0,
          lastActive: new Date(),
          status: 'ACTIVE',
          assignedRegions: volunteerData.region ? [volunteerData.region] : [],
          assignedCategories: [],
          assignedSubcategories: [],
          weeklyTarget: 50,
          qualityScore: 0,
          achievementLevel: 'BRONZE',
          agcTokensEarned: 0
        }
      });

      // Convert to the expected return type
      const volunteer: NRCVolunteer = {
        id: volunteerRecord.id,
        userId: volunteerRecord.userId,
        role: NRCRole.VOLUNTEER,
        region: volunteerRecord.region || '',
        country: volunteerRecord.country,
        agcBalance: volunteerRecord.agcTokensEarned,
        agcWithdrawable: 0,
        totalUploads: volunteerRecord.nomineesUploaded,
        verifiedUploads: 0,
        weeklyUploads: 0,
        isActive: volunteerRecord.status === 'ACTIVE',
        joinedAt: volunteerRecord.approvalDate,
        lastActiveAt: volunteerRecord.lastActive,
        level: VolunteerLevel.BRONZE
      };

      return volunteer;
    } catch (error) {
      throw new Error(`Failed to register volunteer: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Get volunteer dashboard statistics
   */
  async getVolunteerDashboard(volunteerId: string): Promise<NRCDashboardStats> {
    try {
      const volunteer = await this.db.nRCVolunteer.findUnique({
        where: { id: volunteerId }
      });
      if (!volunteer) {
        throw new Error('Volunteer not found');
      }

      // For now, return empty activities until we implement the activities model
      const recentActivities: any[] = [];

      const allVolunteers = await this.db.nRCVolunteer.findMany();
      const rank = this.calculateRank(volunteer, allVolunteers);
      const nextLevelProgress = this.calculateLevelProgress(volunteer);

      return {
        totalUploads: volunteer.totalUploads,
        verifiedUploads: volunteer.verifiedUploads,
        pendingUploads: volunteer.totalUploads - volunteer.verifiedUploads,
        rejectedUploads: 0, // Calculate from nominations
        agcEarned: volunteer.agcBalance + volunteer.agcWithdrawable,
        agcWithdrawable: volunteer.agcWithdrawable,
        currentWeekUploads: volunteer.weeklyUploads,
        rank,
        level: volunteer.level,
        nextLevelProgress,
        recentActivities
      };
    } catch (error) {
      throw new Error(`Failed to get dashboard: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Create a new task for volunteers
   */
  async createTask(taskData: Partial<NRCTask>, createdBy: string): Promise<NRCTask> {
    try {
      const task: NRCTask = {
        id: this.generateId(),
        title: taskData.title!,
        description: taskData.description!,
        assignedTo: taskData.assignedTo!,
        priority: taskData.priority!,
        deadline: taskData.deadline!,
        status: TaskStatus.PENDING,
        category: taskData.category!,
        agcReward: taskData.agcReward!,
        createdBy,
        createdAt: new Date()
      } as NRCTask;  // Using type assertion since we'll add optional props

      // Add optional fields if they exist
      if (taskData.country) task.country = taskData.country;
      if (taskData.region) task.region = taskData.region;

      // Add optional fields if they exist
      if (taskData.country) task.country = taskData.country;
      if (taskData.region) task.region = taskData.region;

      await this.db.nrcTasks.create(task);

      // Notify assigned volunteers
      for (const volunteerId of task.assignedTo) {
        await this.logActivity({
          volunteerId,
          type: ActivityType.TASK_COMPLETED,
          description: `New task assigned: ${task.title}`,
          timestamp: new Date()
        });
      }

      return task;
    } catch (error) {
      throw new Error(`Failed to create task: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Process AGC transaction
   */
  async processAGCTransaction(transactionData: Partial<AGCTransaction>): Promise<AGCTransaction> {
    try {
      const volunteer = await this.db.nrcVolunteers.findById(transactionData.volunteerId!);
      if (!volunteer) {
        throw new Error('Volunteer not found');
      }

      const transaction: AGCTransaction = {
        id: this.generateId(),
        volunteerId: transactionData.volunteerId!,
        type: transactionData.type!,
        amount: transactionData.amount!,
        description: transactionData.description!,
        isWithdrawable: transactionData.isWithdrawable || false,
        timestamp: new Date(),
        status: TransactionStatus.COMPLETED,
        ...(transactionData.nominationId && { nominationId: transactionData.nominationId })
      };

      // Update volunteer balance
      if (transaction.isWithdrawable) {
        volunteer.agcWithdrawable += transaction.amount;
      } else {
        volunteer.agcBalance += transaction.amount;
      }

      // Update volunteer level if needed
      const newLevel = NRCUtils.calculateVolunteerLevel(
        volunteer.verifiedUploads, 
        volunteer.agcBalance + volunteer.agcWithdrawable
      );
      
      if (newLevel !== volunteer.level) {
        volunteer.level = newLevel;
        await this.logActivity({
          volunteerId: volunteer.id,
          type: ActivityType.LEVEL_UP,
          description: `Level up to ${newLevel}`,
          timestamp: new Date()
        });
      }

      await this.db.nrcVolunteers.update(volunteer.id, volunteer);
      await this.db.agcTransactions.create(transaction);

      return transaction;
    } catch (error) {
      throw new Error(`Failed to process AGC transaction: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Get leaderboard data
   */
  async getLeaderboard(type: 'weekly' | 'monthly' | 'allTime' = 'monthly', limit: number = 10): Promise<NRCLeaderboard> {
    try {
      const volunteers = await this.db.nrcVolunteers.findAll();
      
      const sortedVolunteers = volunteers
        .filter((v: NRCVolunteer) => v.isActive)
        .sort((a: NRCVolunteer, b: NRCVolunteer) => {
          switch (type) {
            case 'weekly':
              return b.weeklyUploads - a.weeklyUploads;
            case 'monthly':
              return b.totalUploads - a.totalUploads; // Should be monthly uploads
            default:
              return (b.agcBalance + b.agcWithdrawable) - (a.agcBalance + a.agcWithdrawable);
          }
        })
        .slice(0, limit)
        .map((v: NRCVolunteer, index: number) => ({
          volunteerId: v.id,
          name: v.displayName || 'Unknown',
          uploads: type === 'weekly' ? v.weeklyUploads : v.totalUploads,
          verificationRate: Math.round((v.verifiedUploads / v.totalUploads) * 100) || 0,
          agcEarned: v.agcBalance + v.agcWithdrawable,
          rank: index + 1,
          badge: v.badge
        }));

      return {
        weekly: type === 'weekly' ? sortedVolunteers : [],
        monthly: type === 'monthly' ? sortedVolunteers : [],
        allTime: type === 'allTime' ? sortedVolunteers : [],
        byCountry: {},
        byRegion: {}
      };
    } catch (error) {
      throw new Error(`Failed to get leaderboard: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Generate comprehensive NRC report
   */
  async generateReport(period: { start: Date; end: Date }): Promise<NRCReport> {
    try {
      const volunteers = await this.db.nrcVolunteers.findAll();
      const activeVolunteers = volunteers.filter((v: NRCVolunteer) => v.isActive);
      const nominations = await this.db.nominations.findByDateRange(period.start, period.end);

      const countryDistribution = this.calculateCountryDistribution(nominations);
      const categoryDistribution = this.calculateCategoryDistribution(nominations);
      const performanceMetrics = this.calculatePerformanceMetrics(volunteers, nominations);
      const topPerformers = this.getTopPerformers(volunteers, 10);

      return {
        period: `${period.start.toISOString()} - ${period.end.toISOString()}`,
        totalVolunteers: volunteers.length,
        activeVolunteers: activeVolunteers.length,
        totalNominations: nominations.length,
        verifiedNominations: nominations.filter((n: { status: string }) => n.status === 'approved').length,
        countryDistribution,
        categoryDistribution,
        performanceMetrics,
        topPerformers
      };
    } catch (error) {
      throw new Error(`Failed to generate report: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Award AGC for verified nomination
   */
  async awardAGCForVerification(volunteerId: string, nominationId: string): Promise<void> {
    try {
      const volunteer = await this.db.nrcVolunteers.findById(volunteerId);
      if (!volunteer) {
        throw new Error('Volunteer not found');
      }

      // Check if this is one of first 10 uploads
      const isFirstTen = volunteer.verifiedUploads < 10;
      const reward = NRCUtils.calculateAGCReward('VERIFIED_UPLOAD', volunteer.level, isFirstTen);

      await this.processAGCTransaction({
        volunteerId,
        type: isFirstTen ? TransactionType.FIRST_UPLOAD : TransactionType.VERIFIED_UPLOAD,
        amount: reward,
        description: `AGC reward for verified nomination ${nominationId}`,
        nominationId,
        isWithdrawable: isFirstTen
      });

      // Update volunteer stats
      volunteer.verifiedUploads += 1;
      volunteer.lastActiveAt = new Date();
      
      await this.db.nrcVolunteers.update(volunteerId, volunteer);
    } catch (error) {
      throw new Error(`Failed to award AGC: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Process weekly bonuses
   */
  async processWeeklyBonuses(): Promise<void> {
    try {
      const volunteers = await this.db.nrcVolunteers.findAll();
      
      // Find best performer of the week
      const bestPerformer = volunteers
        .filter((v: NRCVolunteer) => v.isActive && v.weeklyUploads > 0)
        .sort((a: NRCVolunteer, b: NRCVolunteer) => b.weeklyUploads - a.weeklyUploads)[0];

      if (bestPerformer) {
        await this.processAGCTransaction({
          volunteerId: bestPerformer.id,
          type: TransactionType.WEEKLY_BONUS,
          amount: 3,
          description: 'Weekly best researcher bonus',
          isWithdrawable: true
        });
      }

      // Reset weekly uploads for all volunteers
      for (const volunteer of volunteers) {
        volunteer.weeklyUploads = 0;
        await this.db.nrcVolunteers.update(volunteer.id, volunteer);
      }
    } catch (error) {
      throw new Error(`Failed to process weekly bonuses: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Get volunteers by region or country
   */
  async getVolunteersByLocation(region?: string, country?: string): Promise<NRCVolunteer[]> {
    try {
      let query = this.db.nrcVolunteers.findAll();
      
      if (region) {
        query = query.where('region', region);
      }
      if (country) {
        query = query.where('country', country);
      }

      return await query;
    } catch (error) {
      throw new Error(`Failed to get volunteers by location: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Update volunteer role
   */
  async updateVolunteerRole(volunteerId: string, newRole: NRCRole, updatedBy: string): Promise<void> {
    try {
      const volunteer = await this.db.nrcVolunteers.findById(volunteerId);
      if (!volunteer) {
        throw new Error('Volunteer not found');
      }

      const oldRole = volunteer.role;
      volunteer.role = newRole;
      
      await this.db.nrcVolunteers.update(volunteerId, volunteer);

      await this.logActivity({
        volunteerId,
        type: ActivityType.NOMINATION_VERIFIED,
        description: `Role updated from ${oldRole} to ${newRole} by ${updatedBy}`,
        timestamp: new Date()
      });
    } catch (error) {
      throw new Error(`Failed to update volunteer role: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  // Private helper methods
  private generateId(): string {
    return `nrc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private async logActivity(activity: Partial<NRCActivity>): Promise<void> {
    const activityRecord: NRCActivity = {
      id: this.generateId(),
      volunteerId: activity.volunteerId!,
      type: activity.type!,
      description: activity.description!,
      timestamp: activity.timestamp || new Date(),
      ...(activity.agcReward && { agcReward: activity.agcReward }),
      ...(activity.nominationId && { nominationId: activity.nominationId }),
      ...(activity.status && { status: activity.status })
    };

    await this.db.nrcActivities.create(activityRecord);
  }

  private calculateRank(volunteer: NRCVolunteer, allVolunteers: NRCVolunteer[]): number {
    const sorted = allVolunteers
      .filter(v => v.isActive)
      .sort((a, b) => b.totalUploads - a.totalUploads);
    
    return sorted.findIndex(v => v.id === volunteer.id) + 1;
  }

  private calculateLevelProgress(volunteer: NRCVolunteer): number {
    const levelRequirements = {
      [VolunteerLevel.BRONZE]: 0,
      [VolunteerLevel.SILVER]: 10,
      [VolunteerLevel.GOLD]: 25,
      [VolunteerLevel.PLATINUM]: 50,
      [VolunteerLevel.DIAMOND]: 100
    };

    const currentRequirement = levelRequirements[volunteer.level];
    const nextLevel = Object.keys(levelRequirements).find(
      level => levelRequirements[level as VolunteerLevel] > currentRequirement
    ) as VolunteerLevel;

    if (!nextLevel) return 100; // Already at max level

    const nextRequirement = levelRequirements[nextLevel];
    return Math.round((volunteer.verifiedUploads / nextRequirement) * 100);
  }

  private calculateCountryDistribution(nominations: any[]): any[] {
    const distribution = nominations.reduce((acc, nomination) => {
      const country = nomination.country;
      if (!acc[country]) {
        acc[country] = { total: 0, verified: 0 };
      }
      acc[country].total += 1;
      if (nomination.status === 'approved') {
        acc[country].verified += 1;
      }
      return acc;
    }, {});

    return Object.entries(distribution).map(([country, stats]: [string, any]) => ({
      country,
      totalNominations: stats.total,
      verifiedNominations: stats.verified,
      activeVolunteers: 0, // This would need to be calculated
      coveragePercentage: Math.round((stats.verified / stats.total) * 100)
    }));
  }

  private calculateCategoryDistribution(nominations: any[]): any[] {
    const distribution = nominations.reduce((acc, nomination) => {
      const key = `${nomination.category}|${nomination.subcategory}`;
      if (!acc[key]) {
        acc[key] = {
          category: nomination.category,
          subcategory: nomination.subcategory,
          count: 0,
          male: 0,
          female: 0,
          other: 0,
          notSpecified: 0
        };
      }
      acc[key].count += 1;
      
      switch (nomination.gender) {
        case 'male': acc[key].male += 1; break;
        case 'female': acc[key].female += 1; break;
        case 'other': acc[key].other += 1; break;
        default: acc[key].notSpecified += 1;
      }
      
      return acc;
    }, {});

    const total = nominations.length;
    return Object.values(distribution).map((item: any) => ({
      ...item,
      percentage: Math.round((item.count / total) * 100),
      genderDistribution: {
        male: item.male,
        female: item.female,
        other: item.other,
        notSpecified: item.notSpecified
      }
    }));
  }

  private calculatePerformanceMetrics(volunteers: any[], nominations: any[]): any {
    const totalUploads = volunteers.reduce((sum, v) => sum + v.totalUploads, 0);
    const totalVerified = volunteers.reduce((sum, v) => sum + v.verifiedUploads, 0);
    const avgUploads = totalUploads / volunteers.length || 0;
    const verificationRate = totalUploads > 0 ? (totalVerified / totalUploads) * 100 : 0;

    return {
      averageUploadsPerVolunteer: Math.round(avgUploads),
      verificationRate: Math.round(verificationRate),
      completionRate: 85, // This would be calculated from tasks
      qualityScore: 78, // This would be calculated from nomination quality scores
      timeToVerification: 2.5 // Average days to verification
    };
  }

  private getTopPerformers(volunteers: any[], limit: number): any[] {
    return volunteers
      .filter(v => v.isActive)
      .sort((a, b) => b.verifiedUploads - a.verifiedUploads)
      .slice(0, limit)
      .map((v, index) => ({
        volunteerId: v.id,
        name: v.name || 'Unknown',
        uploads: v.totalUploads,
        verificationRate: Math.round((v.verifiedUploads / v.totalUploads) * 100) || 0,
        agcEarned: v.agcBalance + v.agcWithdrawable,
        rank: index + 1,
        badge: v.badge
      }));
  }

  /**
   * Check volunteer status for a user
   */
  async checkVolunteerStatus(userId: string): Promise<any> {
    try {
      // Check if user is a volunteer and their status
      const volunteer = await this.db.nRCVolunteer.findFirst({
        where: { userId: userId },
        include: {
          user: {
            select: {
              id: true,
              email: true,
              firstName: true,
              lastName: true,
              country: true,
              phone: true
            }
          }
        }
      });

      if (!volunteer) {
        return {
          isVolunteer: false,
          volunteerId: null,
          status: 'not_found',
          canAccessDashboard: false,
          profile: null
        };
      }

      // Calculate completion rate
      const completionRate = volunteer.totalUploads > 0 
        ? Math.round((volunteer.verifiedUploads / volunteer.totalUploads) * 100)
        : 0;

      return {
        isVolunteer: true,
        volunteerId: volunteer.id,
        status: volunteer.isActive ? 'active' : 'inactive',
        canAccessDashboard: volunteer.isActive,
        profile: {
          id: volunteer.id,
          userId: volunteer.userId,
          fullName: volunteer.user ? `${volunteer.user.firstName} ${volunteer.user.lastName}` : 'Unknown',
          email: volunteer.user?.email || 'Unknown',
          phone: volunteer.user?.phone || 'Unknown',
          country: volunteer.country,
          region: volunteer.region,
          role: volunteer.role,
          agcBalance: volunteer.agcBalance || 0,
          agcWithdrawable: volunteer.agcWithdrawable || 0,
          totalUploads: volunteer.totalUploads || 0,
          verifiedUploads: volunteer.verifiedUploads || 0,
          weeklyUploads: volunteer.weeklyUploads || 0,
          completionRate: completionRate,
          level: volunteer.level || 'BRONZE',
          joinedAt: volunteer.joinedAt,
          lastActiveAt: volunteer.lastActiveAt,
          isActive: volunteer.isActive
        }
      };
    } catch (error) {
      throw new Error(`Status check failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Get volunteer nominees
   */
  async getVolunteerNominees(
    volunteerId: string,
    filters: any = {},
    pagination: { page: number; limit: number } = { page: 1, limit: 20 }
  ): Promise<any> {
    try {
      console.log(`🔍 Getting nominees for volunteer: ${volunteerId}`);
      console.log(`🔍 Filters:`, filters);
      console.log(`🔍 Pagination:`, pagination);
      
      // First, get the NRC volunteer record to get the volunteer's ID
      const volunteer = await this.db.nRCVolunteer.findUnique({
        where: { userId: volunteerId }
      });
      
      if (!volunteer) {
        console.log(`❌ Volunteer not found for userId: ${volunteerId}`);
        return {
          nominees: [],
          pagination: {
            page: pagination.page,
            limit: pagination.limit,
            total: 0,
            totalPages: 0
          }
        };
      }
      
      console.log(`✅ Found volunteer with ID: ${volunteer.id}`);
      
      // Prepare filter conditions
      const where: any = { volunteerId: volunteer.id };
      
      // Add additional filters if provided
      if (filters.status) {
        where.status = filters.status;
      }
      if (filters.awardCategory) {
        where.awardCategory = filters.awardCategory;
      }
      if (filters.country) {
        where.country = filters.country;
      }
      
      console.log(`🔍 Query conditions:`, where);

      // Calculate pagination
      const skip = (pagination.page - 1) * pagination.limit;
      
      // Get total count for pagination
      const totalCount = await this.db.nomineeProfile.count({ where });
      console.log(`📊 Total nominees count: ${totalCount}`);
      
      // Get nominees with pagination
      const nominees = await this.db.nomineeProfile.findMany({
        where,
        skip,
        take: pagination.limit,
        orderBy: { createdAt: 'desc' }
      });
      
      console.log(`📋 Retrieved ${nominees.length} nominees`);

      return {
        nominees,
        pagination: {
          page: pagination.page,
          limit: pagination.limit,
          total: totalCount,
          totalPages: Math.ceil(totalCount / pagination.limit)
        }
      };
    } catch (error: any) {
      console.error(`❌ Error getting nominees: ${error.message}`, error);
      throw new Error(`Failed to get nominees: ${error.message}`);
    }
  }
}
