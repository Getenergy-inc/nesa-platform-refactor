import { Request, Response, NextFunction } from 'express';
import { NRCService } from '../services/nrcService';
import { validateNRCVolunteer, validateNRCTask, validateAGCTransaction } from '../validation/nrcValidation2';

export class NRCController {
  private nrcService: NRCService;
  private db: any;

  constructor(nrcService: NRCService) {
    this.nrcService = nrcService;
    this.db = nrcService['db']; // Access the database from the service
  }
  
  /**
   * Calculate completion score for nominee data
   * @param data Nominee data
   * @returns Completion score between 0 and 100
   */
  private calculateCompletionScore(data: any): number {
    const requiredFields = [
      'fullName',
      'country',
      'awardCategory',
      'achievementSummary',
      'impactMetrics'
    ];
    
    const optionalFields = [
      'organizationName',
      'region',
      'email',
      'phone',
      'website',
      'linkedinProfile',
      'subcategory',
      'beneficiariesCount',
      'yearsOfImpact',
      'sdgAlignment',
      'agendaAlignment',
      'esgAlignment',
      'verificationLinks',
      'mediaLinks',
      'additionalNotes'
    ];
    
    // Calculate required fields score (60% of total)
    const requiredScore = requiredFields.reduce((score, field) => {
      return score + (data[field] ? (60 / requiredFields.length) : 0);
    }, 0);
    
    // Calculate optional fields score (40% of total)
    const optionalScore = optionalFields.reduce((score, field) => {
      return score + (data[field] ? (40 / optionalFields.length) : 0);
    }, 0);
    
    // Return total score rounded to 2 decimal places
    return Math.round((requiredScore + optionalScore) * 100) / 100;
  }

  /**
   * Register a new NRC volunteer
   */
  async registerVolunteer(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const validation = validateNRCVolunteer.create(req.body);
      if (!validation.isValid) {
        res.status(400).json({
          success: false,
          message: 'Validation failed',
          errors: validation.errors
        });
        return;
      }

      const volunteer = await this.nrcService.registerVolunteer(req.body);
      
      res.status(201).json({
        success: true,
        message: 'Volunteer registered successfully',
        data: volunteer
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Get volunteer dashboard
   */
  async getVolunteerDashboard(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId } = req.params;
      if (!volunteerId) {
        res.status(400).json({
          success: false,
          message: 'Volunteer ID is required'
        });
        return;
      }
      const dashboard = await this.nrcService.getVolunteerDashboard(volunteerId);
      
      res.json({
        success: true,
        data: dashboard
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Get all volunteers with filtering and pagination
   */
  async getVolunteers(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { 
        role, 
        region, 
        country, 
        isActive, 
        level, 
        page = 1, 
        limit = 10,
        sortBy = 'totalUploads',
        sortOrder = 'desc'
      } = req.query;

      const filters = {
        role: role as string,
        region: region as string,
        country: country as string,
        isActive: isActive === 'true',
        level: level as string
      };

      // This would be implemented in the service
      const volunteers = await this.nrcService.getVolunteersByLocation(
        filters.region,
        filters.country
      );

      res.json({
        success: true,
        data: {
          volunteers,
          pagination: {
            page: Number(page),
            limit: Number(limit),
            total: volunteers.length,
            totalPages: Math.ceil(volunteers.length / Number(limit))
          }
        }
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Update volunteer information
   */
  async updateVolunteer(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId } = req.params;
      const validation = validateNRCVolunteer.update(req.body);
      
      if (!validation.isValid) {
        res.status(400).json({
          success: false,
          message: 'Validation failed',
          errors: validation.errors
        });
        return;
      }

      // This would be implemented in the service
      // await this.nrcService.updateVolunteer(volunteerId, req.body);
      
      res.json({
        success: true,
        message: 'Volunteer updated successfully'
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Create a new task
   */
  async createTask(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const validation = validateNRCTask.create(req.body);
      if (!validation.isValid) {
        res.status(400).json({
          success: false,
          message: 'Validation failed',
          errors: validation.errors
        });
        return;
      }

      const createdBy = req.user?.id; // Assuming user info is in req.user
      if (!createdBy) {
        res.status(401).json({
          success: false,
          message: 'User must be authenticated to create a task'
        });
        return;
      }
      const task = await this.nrcService.createTask(req.body, createdBy);
      
      res.status(201).json({
        success: true,
        message: 'Task created successfully',
        data: task
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Get tasks for a volunteer
   */
  async getVolunteerTasks(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId } = req.params;
      const { status, priority, page = 1, limit = 10 } = req.query;

      interface Task {
        id: string;
        title: string;
        status: string;
        priority: string;
        // Add other task properties as needed
      }

      // This would be implemented in the service
      const tasks: Task[] = []; // await this.nrcService.getTasksForVolunteer(volunteerId, filters);
      
      res.json({
        success: true,
        data: {
          tasks,
          pagination: {
            page: Number(page),
            limit: Number(limit),
            total: tasks.length,
            totalPages: Math.ceil(tasks.length / Number(limit))
          }
        }
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Complete a task
   */
  async completeTask(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { taskId } = req.params;
      const { completionNotes } = req.body;
      const completedBy = req.user?.id;

      // This would be implemented in the service
      // await this.nrcService.completeTask(taskId, completedBy, completionNotes);
      
      res.json({
        success: true,
        message: 'Task completed successfully'
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Process AGC transaction
   */
  async processAGCTransaction(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const validation = validateAGCTransaction.create(req.body);
      if (!validation.isValid) {
        res.status(400).json({
          success: false,
          message: 'Validation failed',
          errors: validation.errors
        });
        return;
      }

      const transaction = await this.nrcService.processAGCTransaction(req.body);
      
      res.status(201).json({
        success: true,
        message: 'AGC transaction processed successfully',
        data: transaction
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Get AGC transaction history
   */
  async getAGCTransactions(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId } = req.params;
      const { type, page = 1, limit = 20 } = req.query;

      interface AGCTransaction {
        id: string;
        amount: number;
        type: string;
        date: Date;
        // Add other transaction properties as needed
      }

      // This would be implemented in the service
      const transactions: AGCTransaction[] = []; // await this.nrcService.getAGCTransactions(volunteerId, filters);
      
      res.json({
        success: true,
        data: {
          transactions,
          pagination: {
            page: Number(page),
            limit: Number(limit),
            total: transactions.length,
            totalPages: Math.ceil(transactions.length / Number(limit))
          }
        }
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Withdraw AGC
   */
  async withdrawAGC(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId } = req.params;
      const validation = validateAGCTransaction.withdraw(req.body);
      
      if (!validation.isValid) {
        res.status(400).json({
          success: false,
          message: 'Validation failed',
          errors: validation.errors
        });
        return;
      }

      // This would be implemented in the service
      // await this.nrcService.withdrawAGC(volunteerId, req.body.amount, req.body.walletAddress);
      
      res.json({
        success: true,
        message: 'AGC withdrawal processed successfully'
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Get leaderboard
   */
  async getLeaderboard(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { type = 'monthly', country, region, limit = 10 } = req.query;
      
      const leaderboard = await this.nrcService.getLeaderboard(
        type as 'weekly' | 'monthly' | 'allTime',
        Number(limit)
      );
      
      res.json({
        success: true,
        data: leaderboard
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Generate reports
   */
  async generateReport(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { period } = req.body;
      
      if (!period || !period.start || !period.end) {
        res.status(400).json({
          success: false,
          message: 'Period with start and end dates is required'
        });
        return;
      }

      const report = await this.nrcService.generateReport({
        start: new Date(period.start),
        end: new Date(period.end)
      });
      
      res.json({
        success: true,
        data: report
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Award AGC for verified nomination
   */
  async awardAGCForVerification(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId, nominationId } = req.body;
      
      if (!volunteerId || !nominationId) {
        res.status(400).json({
          success: false,
          message: 'volunteerId and nominationId are required'
        });
        return;
      }

      await this.nrcService.awardAGCForVerification(volunteerId, nominationId);
      
      res.json({
        success: true,
        message: 'AGC awarded successfully'
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Process weekly bonuses (admin only)
   */
  async processWeeklyBonuses(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      await this.nrcService.processWeeklyBonuses();
      
      res.json({
        success: true,
        message: 'Weekly bonuses processed successfully'
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Update volunteer role (admin only)
   */
  async updateVolunteerRole(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId } = req.params;
      const { role } = req.body;
      const updatedBy = req.user?.id;

      if (!volunteerId || !role || !updatedBy) {
        res.status(400).json({
          success: false,
          message: 'Volunteer ID, role and authenticated user are required'
        });
        return;
      }

      await this.nrcService.updateVolunteerRole(volunteerId, role, updatedBy);
      
      res.json({
        success: true,
        message: 'Volunteer role updated successfully'
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Get NRC analytics dashboard
   */
  async getAnalyticsDashboard(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { period = 'month', country, region } = req.query;

      // This would calculate comprehensive analytics
      const analytics = {
        overview: {
          totalVolunteers: 45,
          activeVolunteers: 38,
          totalUploads: 1250,
          verifiedUploads: 1125,
          avgQualityScore: 85,
          countryCoverage: 42
        },
        trends: {
          uploadsOverTime: [],
          verificationRate: [],
          volunteerGrowth: []
        },
        performance: {
          topPerformers: [],
          countryStats: [],
          categoryDistribution: []
        }
      };
      
      res.json({
        success: true,
        data: analytics
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Bulk operations on volunteers
   */
  async bulkVolunteerOperations(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { operation, volunteerIds, data, reason } = req.body;

      if (!operation || !volunteerIds || !Array.isArray(volunteerIds)) {
        res.status(400).json({
          success: false,
          message: 'Operation and volunteerIds array are required'
        });
        return;
      }

      // This would be implemented in the service
      // await this.nrcService.bulkVolunteerOperation(operation, volunteerIds, data, reason);
      
      res.json({
        success: true,
        message: `Bulk operation '${operation}' completed successfully`,
        data: {
          affected: volunteerIds.length
        }
      });
    } catch (error: any) {
      next(error);
    }
  }

  // ==================== ADDITIONAL ENDPOINTS ====================

  /**
   * Create nominee
   */
  async createNominee(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = req.user?.id;
      if (!userId) {
        res.status(401).json({
          success: false,
          message: 'Authentication required'
        });
        return;
      }

      console.log('Nominee creation endpoint hit');
      console.log('Request body keys:', Object.keys(req.body));
      console.log('Request body sample:', { 
        fullName: req.body.fullName, 
        country: req.body.country,
        status: req.body.status
      });
      
      // Check if files were uploaded
      const hasFiles = req.files && Object.keys(req.files).length > 0;
      console.log('Files received:', hasFiles ? 'Yes' : 'No');
      
      // Get the volunteer record
      const volunteer = await this.db.nRCVolunteer.findUnique({
        where: { userId }
      });
      
      if (!volunteer) {
        res.status(404).json({
          success: false,
          message: 'Volunteer record not found'
        });
        return;
      }
      
      console.log('Volunteer ID:', volunteer.id);
      
      // Handle file uploads if any
      let profileImageUrl = '';
      const supportingDocuments: string[] = [];

      if (req.files) {
        const files = req.files as { [fieldname: string]: Express.Multer.File[] };

        if (files.profileImage && files.profileImage.length > 0 && files.profileImage[0]) {
          // The path is already handled by multer's diskStorage
          profileImageUrl = `/uploads/nominees/${files.profileImage[0].filename}`;
          console.log('Profile image URL:', profileImageUrl);
        }

        if (files.supportingDocuments && files.supportingDocuments.length > 0) {
          console.log(`Processing ${files.supportingDocuments.length} supporting documents`);
          files.supportingDocuments.forEach(doc => {
            const docUrl = `/uploads/nominees/${doc.filename}`;
            supportingDocuments.push(docUrl);
            console.log('Supporting document URL:', docUrl);
          });
        }
      }

      // Prepare nominee data for database
      const nomineeData = {
        volunteerId: volunteer.id,
        fullName: req.body.fullName,
        country: req.body.country,
        achievementSummary: req.body.achievementSummary || '',
        impactMetrics: req.body.impactMetrics || '',
        sdgAlignment: Array.isArray(req.body.sdgAlignment) ? req.body.sdgAlignment : 
                      req.body.sdgAlignment ? [req.body.sdgAlignment] : [],
        profileImageUrl,
        status: req.body.status?.toUpperCase() || 'DRAFT',
        completionScore: this.calculateCompletionScore(req.body) || 0,
        qualityScore: 0,
        verificationStatus: 'PENDING',
        submittedAt: req.body.status?.toUpperCase() === 'SUBMITTED' ? new Date() : null,
        // Add other fields from req.body
        awardCategory: req.body.awardCategory || '',
        supportingDocuments,
        organizationName: req.body.organizationName || '',
        region: req.body.region || '',
        email: req.body.email || '',
        phone: req.body.phone || '',
        website: req.body.website || '',
        linkedinProfile: req.body.linkedinProfile || '',
        subcategory: req.body.subcategory || '',
        beneficiariesCount: req.body.beneficiariesCount || '',
        yearsOfImpact: req.body.yearsOfImpact || '',
        agendaAlignment: req.body.agendaAlignment || '',
        esgAlignment: req.body.esgAlignment || '',
        verificationLinks: req.body.verificationLinks || '',
        mediaLinks: req.body.mediaLinks || '',
      };
      
      // Create the nominee in the database
      const nominee = await this.db.nomineeProfile.create({
        data: nomineeData
      });
      
      // Update the volunteer's nomineesUploaded count
      await this.db.nRCVolunteer.update({
        where: { id: volunteer.id },
        data: {
          nomineesUploaded: {
            increment: 1
          }
        }
      });
      
      res.status(201).json({
        success: true,
        message: 'Nominee created successfully',
        data: nominee
      });
    } catch (error: any) {
      console.error('Error creating nominee:', error);
      next(error);
    }
  }

  /**
   * Get volunteer nominees
   */
  async getVolunteerNominees(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId } = req.params;
      const { status, category, country, page = 1, limit = 20 } = req.query;

      console.log(`📋 NRC Get Nominees - Endpoint hit for volunteerId: ${volunteerId}`);

      if (!volunteerId) {
        res.status(400).json({
          success: false,
          message: 'Volunteer ID is required in the URL path.',
        });
        return;
      }
      console.log(`📋 NRC Get Nominees - Query params:`, req.query);

      // Convert query parameters to the right format
      const filters: any = {};
      if (status) filters.status = status;
      if (category) filters.awardCategory = category;
      if (country) filters.country = country;

      const pagination = {
        page: Number(page),
        limit: Number(limit)
      };

      console.log(`📋 NRC Get Nominees - Calling service with filters:`, filters);
      console.log(`📋 NRC Get Nominees - Pagination:`, pagination);

      // Get nominees from the database through the service
      const result = await this.nrcService.getVolunteerNominees(
        volunteerId,
        filters,
        pagination
      );

      console.log(`📋 NRC Get Nominees - Service returned ${result.nominees?.length || 0} nominees`);
      
      res.json({
        success: true,
        data: result
      });
    } catch (error: any) {
      console.error('❌ Error fetching nominees:', error);
      next(error);
    }
  }

  /**
   * Update nominee
   */
  async updateNominee(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { nomineeId } = req.params;
      const updateData = {
        ...req.body,
        completionScore: this.calculateCompletionScore(req.body),
        updatedAt: new Date().toISOString()
      };

      // Mock implementation - replace with actual service call
      const nominee = { id: nomineeId, ...updateData };
      
      res.json({
        success: true,
        message: 'Nominee updated successfully',
        data: nominee
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Delete nominee
   */
  async deleteNominee(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { nomineeId } = req.params;
      
      // Mock implementation - replace with actual service call
      
      res.json({
        success: true,
        message: 'Nominee deleted successfully'
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Bulk nominee operations
   */
  async bulkNomineeOperations(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { operation, nomineeIds, data } = req.body;
      
      // Mock implementation - replace with actual service call
      const results = nomineeIds.map((id: string) => ({ nomineeId: id, success: true }));
      
      res.json({
        success: true,
        message: `Bulk ${operation} completed successfully`,
        data: { results, affected: nomineeIds.length }
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Get volunteer progress
   */
  async getVolunteerProgress(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId } = req.params;
      
      // Mock implementation - replace with actual service call
      const progress = {
        milestones: [],
        achievements: [],
        metrics: {},
        insights: {}
      };
      
      res.json({
        success: true,
        data: progress
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Update milestone
   */
  async updateMilestone(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId, milestoneId } = req.params;
      const updateData = req.body;
      
      // Mock implementation - replace with actual service call
      const milestone = { id: milestoneId, ...updateData };
      
      res.json({
        success: true,
        message: 'Milestone updated successfully',
        data: milestone
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Get volunteer achievements
   */
  async getVolunteerAchievements(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId } = req.params;
      
      // Mock implementation - replace with actual service call
      const achievements: any[] = [];
      
      res.json({
        success: true,
        data: achievements
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Get volunteer notifications
   */
  async getVolunteerNotifications(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId } = req.params;
      const { unread, category, page = 1, limit = 20 } = req.query;

      // Mock implementation - replace with actual service call
      const notifications: any[] = [];
      
      res.json({
        success: true,
        data: {
          notifications,
          pagination: {
            page: Number(page),
            limit: Number(limit),
            total: notifications.length,
            totalPages: Math.ceil(notifications.length / Number(limit))
          }
        }
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Mark notification as read
   */
  async markNotificationAsRead(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { notificationId } = req.params;
      
      // Mock implementation - replace with actual service call
      
      res.json({
        success: true,
        message: 'Notification marked as read'
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Mark all notifications as read
   */
  async markAllNotificationsAsRead(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId } = req.params;
      
      // Mock implementation - replace with actual service call
      
      res.json({
        success: true,
        message: 'All notifications marked as read'
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Delete notification
   */
  async deleteNotification(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { notificationId } = req.params;
      
      // Mock implementation - replace with actual service call
      
      res.json({
        success: true,
        message: 'Notification deleted successfully'
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Export volunteer data
   */
  async exportVolunteerData(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId } = req.params;
      const { format, type } = req.body;
      
      // Mock implementation - replace with actual service call
      const exportData = {
        data: 'mock-export-data',
        filename: `volunteer-${type}-${new Date().toISOString().split('T')[0]}.${format}`,
        contentType: this.getContentType(format)
      };
      
      res.json({
        success: true,
        message: 'Data exported successfully',
        data: exportData
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Generate volunteer report
   */
  async generateVolunteerReport(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId } = req.params;
      const { period } = req.body;
      
      // Mock implementation - replace with actual service call
      const report = {
        volunteerId,
        period,
        summary: {},
        generatedAt: new Date()
      };
      
      res.json({
        success: true,
        message: 'Report generated successfully',
        data: report
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Export all data (admin only)
   */
  async exportAllData(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { type, format } = req.body;
      
      // Mock implementation - replace with actual service call
      const exportData = {
        data: 'mock-export-data',
        filename: `nrc-${type}-${new Date().toISOString().split('T')[0]}.${format}`,
        contentType: this.getContentType(format)
      };
      
      res.json({
        success: true,
        message: 'Data exported successfully',
        data: exportData
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Get comprehensive analytics
   */
  async getComprehensiveAnalytics(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { period, country, region } = req.query;
      
      // Mock implementation - replace with actual service call
      const analytics = {
        overview: {},
        trends: {},
        geography: {},
        categories: {},
        performance: {}
      };
      
      res.json({
        success: true,
        data: analytics
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Get volunteer metrics
   */
  async getVolunteerMetrics(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId } = req.params;
      
      // Mock implementation - replace with actual service call
      const metrics = {
        productivity: 85,
        quality: 90,
        consistency: 78,
        engagement: 92,
        overall: 86
      };
      
      res.json({
        success: true,
        data: metrics
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Get geography analytics
   */
  async getGeographyAnalytics(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      // Mock implementation - replace with actual service call
      const analytics = {
        countries: {},
        regions: {},
        coverage: {}
      };
      
      res.json({
        success: true,
        data: analytics
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Get category analytics
   */
  async getCategoryAnalytics(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      // Mock implementation - replace with actual service call
      const analytics = {
        distribution: {},
        trends: {},
        performance: {}
      };
      
      res.json({
        success: true,
        data: analytics
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Get volunteer profile
   */
  async getVolunteerProfile(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId } = req.params;
      
      // Mock implementation - replace with actual service call
      const profile = {
        basic: {},
        stats: {},
        progress: {},
        preferences: {}
      };
      
      res.json({
        success: true,
        data: profile
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Update volunteer profile
   */
  async updateVolunteerProfile(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { volunteerId } = req.params;
      const updateData = req.body;
      
      // Mock implementation - replace with actual service call
      const profile = { id: volunteerId, ...updateData, updatedAt: new Date() };
      
      res.json({
        success: true,
        message: 'Profile updated successfully',
        data: profile
      });
    } catch (error: any) {
      next(error);
    }
  }

  /**
   * Check volunteer status
   */
  async checkVolunteerStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = req.user?.id;
      if (!userId) {
        res.status(401).json({
          success: false,
          message: 'Authentication required'
        });
        return;
      }

      const status = await this.nrcService.checkVolunteerStatus(userId);
      
      res.json({
        success: true,
        data: status,
        message: status.isVolunteer ? 'Volunteer status found' : 'User is not an NRC volunteer'
      });
    } catch (error: any) {
      next(error);
    }
  }

  // ==================== HELPER METHODS ====================

  private getContentType(format: string): string {
    switch (format) {
      case 'csv':
        return 'text/csv';
      case 'json':
        return 'application/json';
      case 'pdf':
        return 'application/pdf';
      default:
        return 'application/octet-stream';
    }
  }
}
