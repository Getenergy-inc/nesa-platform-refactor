import { VolunteerLevel, NRCRole } from "../types/index";

export class NRCUtils {
  /**
   * Calculate volunteer level based on verified uploads and AGC earned
   */
  static calculateVolunteerLevel(
    verifiedUploads: number,
    agcEarned: number
  ): VolunteerLevel {
    if (verifiedUploads >= 100 && agcEarned >= 200)
      return VolunteerLevel.DIAMOND;
    if (verifiedUploads >= 50 && agcEarned >= 100)
      return VolunteerLevel.PLATINUM;
    if (verifiedUploads >= 25 && agcEarned >= 50) return VolunteerLevel.GOLD;
    if (verifiedUploads >= 10 && agcEarned >= 20) return VolunteerLevel.SILVER;
    return VolunteerLevel.BRONZE;
  }

  /**
   * Calculate AGC reward based on transaction type and volunteer level
   */
  static calculateAGCReward(
    type: string,
    level: VolunteerLevel,
    isFirstTen: boolean = false
  ): number {
    const baseRewards = {
      FIRST_UPLOAD: isFirstTen ? 5 : 0.5,
      VERIFIED_UPLOAD: 0.5,
      WEEKLY_BONUS: 3,
      TASK_COMPLETION: 2,
    };

    const multiplier = this.getLevelMultiplier(level);
    return (baseRewards[type as keyof typeof baseRewards] || 0) * multiplier;
  }

  /**
   * Get level multiplier for AGC rewards
   */
  private static getLevelMultiplier(level: VolunteerLevel): number {
    switch (level) {
      case VolunteerLevel.DIAMOND:
        return 2.0;
      case VolunteerLevel.PLATINUM:
        return 1.5;
      case VolunteerLevel.GOLD:
        return 1.2;
      case VolunteerLevel.SILVER:
        return 1.1;
      default:
        return 1.0;
    }
  }

  /**
   * Check if volunteer can perform action based on role
   */
  static canPerformAction(role: NRCRole, action: string): boolean {
    const permissions = {
      [NRCRole.VOLUNTEER]: ["upload", "view_own", "edit_own"],
      [NRCRole.TEAM_LEAD]: [
        "upload",
        "view_own",
        "edit_own",
        "view_team",
        "assign_tasks",
      ],
      [NRCRole.COORDINATOR]: [
        "upload",
        "view_own",
        "edit_own",
        "view_team",
        "assign_tasks",
        "view_region",
        "approve_uploads",
      ],
      [NRCRole.VALIDATOR]: [
        "upload",
        "view_own",
        "edit_own",
        "view_all",
        "approve_uploads",
        "reject_uploads",
      ],
      [NRCRole.ADMIN]: ["*"], // All permissions
    };

    const rolePermissions = permissions[role] || [];
    return rolePermissions.includes("*") || rolePermissions.includes(action);
  }

  /**
   * Generate performance badge based on metrics
   */
  static generateBadge(
    verifiedUploads: number,
    verificationRate: number,
    weeklyUploads: number
  ): string | undefined {
    if (verifiedUploads >= 50 && verificationRate >= 95)
      return "Quality Champion";
    if (weeklyUploads >= 20) return "Speed Demon";
    if (verifiedUploads >= 100) return "Upload Master";
    if (verificationRate >= 90 && verifiedUploads >= 20)
      return "Accuracy Expert";
    if (verifiedUploads >= 25) return "Rising Star";
    return undefined;
  }

  /**
   * Calculate quality score based on various factors
   */
  static calculateQualityScore(
    verificationRate: number,
    completenessScore: number,
    timelinessScore: number,
    accuracyScore: number
  ): number {
    const weights = {
      verification: 0.3,
      completeness: 0.25,
      timeliness: 0.2,
      accuracy: 0.25,
    };

    return Math.round(
      verificationRate * weights.verification +
        completenessScore * weights.completeness +
        timelinessScore * weights.timeliness +
        accuracyScore * weights.accuracy
    );
  }

  /**
   * Format volunteer stats for display
   */
  static formatVolunteerStats(volunteer: any) {
    return {
      name: volunteer.name,
      level: volunteer.level,
      uploads: volunteer.totalUploads,
      verified: volunteer.verifiedUploads,
      verificationRate:
        Math.round(
          (volunteer.verifiedUploads / volunteer.totalUploads) * 100
        ) || 0,
      agcBalance: volunteer.agcBalance,
      rank: volunteer.rank,
      badge: volunteer.badge,
      joinedDays: Math.floor(
        (new Date().getTime() - new Date(volunteer.joinedAt).getTime()) /
          (1000 * 60 * 60 * 24)
      ),
    };
  }

  /**
   * Generate weekly report summary
   */
  static generateWeeklyReportSummary(volunteers: any[], nominations: any[]) {
    const totalVolunteers = volunteers.length;
    const activeVolunteers = volunteers.filter((v) => v.weeklyUploads > 0)
      .length;
    const totalUploads = volunteers.reduce(
      (sum, v) => sum + v.weeklyUploads,
      0
    );
    const totalVerified = nominations.filter((n) => n.status === "approved")
      .length;
    const avgQuality =
      nominations.reduce((sum, n) => sum + n.qualityScore, 0) /
        nominations.length || 0;

    return {
      period: this.getCurrentWeekRange(),
      totalVolunteers,
      activeVolunteers,
      activityRate: Math.round((activeVolunteers / totalVolunteers) * 100),
      totalUploads,
      totalVerified,
      verificationRate: Math.round((totalVerified / totalUploads) * 100) || 0,
      avgQualityScore: Math.round(avgQuality),
      topPerformer:
        volunteers.sort((a, b) => b.weeklyUploads - a.weeklyUploads)[0]?.name ||
        "N/A",
    };
  }

  /**
   * Get current week date range
   */
  private static getCurrentWeekRange(): string {
    const now = new Date();
    const startOfWeek = new Date(now.setDate(now.getDate() - now.getDay()));
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);

    return `${startOfWeek.toLocaleDateString()} - ${endOfWeek.toLocaleDateString()}`;
  }

  /**
   * Validate country coverage requirements
   */
  static validateCountryCoverage(
    nominations: any[]
  ): {
    covered: string[];
    missing: string[];
    coveragePercentage: number;
  } {
    const africanCountries = [
      "Algeria",
      "Angola",
      "Benin",
      "Botswana",
      "Burkina Faso",
      "Burundi",
      "Cameroon",
      "Cape Verde",
      "Central African Republic",
      "Chad",
      "Comoros",
      "Congo",
      "Democratic Republic of Congo",
      "Djibouti",
      "Egypt",
      "Equatorial Guinea",
      "Eritrea",
      "Eswatini",
      "Ethiopia",
      "Gabon",
      "Gambia",
      "Ghana",
      "Guinea",
      "Guinea-Bissau",
      "Ivory Coast",
      "Kenya",
      "Lesotho",
      "Liberia",
      "Libya",
      "Madagascar",
      "Malawi",
      "Mali",
      "Mauritania",
      "Mauritius",
      "Morocco",
      "Mozambique",
      "Namibia",
      "Niger",
      "Nigeria",
      "Rwanda",
      "Sao Tome and Principe",
      "Senegal",
      "Seychelles",
      "Sierra Leone",
      "Somalia",
      "South Africa",
      "South Sudan",
      "Sudan",
      "Tanzania",
      "Togo",
      "Tunisia",
      "Uganda",
      "Zambia",
      "Zimbabwe",
    ];

    const nominationCountries = [...new Set(nominations.map((n) => n.country))];
    const covered = nominationCountries.filter((c) =>
      africanCountries.includes(c)
    );
    const missing = africanCountries.filter((c) => !covered.includes(c));

    return {
      covered,
      missing,
      coveragePercentage: Math.round(
        (covered.length / africanCountries.length) * 100
      ),
    };
  }

  /**
   * Generate recommendation for volunteer assignment
   */
  static recommendVolunteerAssignment(task: any, volunteers: any[]): any[] {
    return volunteers
      .filter((v) => v.isActive && this.canPerformAction(v.role, "upload"))
      .filter((v) => !task.country || v.country === task.country)
      .filter((v) => !task.region || v.region === task.region)
      .sort((a, b) => {
        // Score based on workload, performance, and availability
        const scoreA = this.calculateAssignmentScore(a, task);
        const scoreB = this.calculateAssignmentScore(b, task);
        return scoreB - scoreA;
      })
      .slice(0, 5); // Top 5 recommendations
  }

  /**
   * Calculate assignment score for volunteer recommendation
   */
  private static calculateAssignmentScore(volunteer: any, task: any): number {
    let score = 0;

    // Performance factors
    score += volunteer.verificationRate || 0;
    score += volunteer.agcBalance / 10; // AGC balance indicates experience
    score += volunteer.level === VolunteerLevel.DIAMOND ? 30 : 0;
    score += volunteer.level === VolunteerLevel.PLATINUM ? 20 : 0;
    score += volunteer.level === VolunteerLevel.GOLD ? 10 : 0;

    // Workload factors (lower current load = higher score)
    score -= (volunteer.currentTasks || 0) * 5;
    score -= (volunteer.weeklyUploads || 0) * 2;

    // Availability factors
    score += volunteer.isActive ? 10 : -50;
    score +=
      volunteer.lastActiveAt &&
      new Date().getTime() - new Date(volunteer.lastActiveAt).getTime() <
        24 * 60 * 60 * 1000
        ? 15
        : 0;

    return score;
  }
}
