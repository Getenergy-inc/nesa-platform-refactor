import { Router, Request, Response } from "express";
import { NRCController } from "../controllers/NRCController";
import { NRCService } from "../services/nrcService";
import {
  verifyToken,
  requireRole,
  requireVerification,
} from "../../../shared/middleware/auth";
import { authLimiter } from "../../../shared/middleware/rateLimiter";
import { prisma } from "../../../shared/database/postgresql";
import {
  validateNRCVolunteer,
  validateNRCTask,
  validateAGCTransaction,
} from "../validation/nrcValidation2";

const router = Router();

// Initialize service and controller with database
const nrcService = new NRCService(prisma);
const nrcController = new NRCController(nrcService);

// Public routes (health check)
router.get("/health", (req: any, res: any) => {
  res.json({
    success: true,
    message: "NRC module is running",
    timestamp: new Date().toISOString(),
    version: "1.0.0",
  });
});

// Protected routes (require authentication)
router.use(verifyToken);

// Volunteer Management Routes
router.post(
  "/volunteers/register",
  authLimiter,
  requireVerification,
  nrcController.registerVolunteer.bind(nrcController)
);

router.get(
  "/volunteers",
  requireVerification,
  nrcController.getVolunteers.bind(nrcController)
);

router.get(
  "/volunteers/:volunteerId/dashboard",
  requireVerification,
  nrcController.getVolunteerDashboard.bind(nrcController)
);

router.put(
  "/volunteers/:volunteerId",
  requireVerification,
  nrcController.updateVolunteer.bind(nrcController)
);

// Admin only routes
router.put(
  "/volunteers/:volunteerId/role",
  requireRole("ADMIN"),
  nrcController.updateVolunteerRole.bind(nrcController)
);

router.post(
  "/volunteers/bulk-operations",
  requireRole("ADMIN"),
  nrcController.bulkVolunteerOperations.bind(nrcController)
);

// Task Management Routes
router.post(
  "/tasks",
  requireRole("ADMIN"),
  nrcController.createTask.bind(nrcController)
);

router.get(
  "/volunteers/:volunteerId/tasks",
  requireVerification,
  nrcController.getVolunteerTasks.bind(nrcController)
);

router.put(
  "/tasks/:taskId/complete",
  requireVerification,
  nrcController.completeTask.bind(nrcController)
);

// AGC & Rewards Routes
router.post(
  "/agc/transactions",
  requireVerification,
  nrcController.processAGCTransaction.bind(nrcController)
);

router.get(
  "/volunteers/:volunteerId/agc/transactions",
  requireVerification,
  nrcController.getAGCTransactions.bind(nrcController)
);

router.post(
  "/volunteers/:volunteerId/agc/withdraw",
  requireVerification,
  nrcController.withdrawAGC.bind(nrcController)
);

// Admin routes for AGC management
router.post(
  "/agc/award-verification",
  requireRole("ADMIN"),
  nrcController.awardAGCForVerification.bind(nrcController)
);

router.post(
  "/agc/process-weekly-bonuses",
  requireRole("ADMIN"),
  nrcController.processWeeklyBonuses.bind(nrcController)
);

// Analytics & Reporting Routes
router.get(
  "/leaderboard",
  requireVerification,
  nrcController.getLeaderboard.bind(nrcController)
);

router.post(
  "/reports/generate",
  requireRole("ADMIN"),
  nrcController.generateReport.bind(nrcController)
);

router.get(
  "/analytics/dashboard",
  requireRole("ADMIN"),
  nrcController.getAnalyticsDashboard.bind(nrcController)
);

// ==================== ADDITIONAL ENDPOINTS ====================

// ==================== ADDITIONAL ENDPOINTS ====================

// Nominee Management
router.post(
  "/nominees",
  requireVerification,
  nrcController.createNominee.bind(nrcController)
);

router.get(
  "/volunteers/:volunteerId/nominees",
  requireVerification,
  nrcController.getVolunteerNominees.bind(nrcController)
);

router.put(
  "/nominees/:nomineeId",
  requireVerification,
  nrcController.updateNominee.bind(nrcController)
);

router.delete(
  "/nominees/:nomineeId",
  requireVerification,
  nrcController.deleteNominee.bind(nrcController)
);

router.post(
  "/nominees/bulk",
  requireVerification,
  nrcController.bulkNomineeOperations.bind(nrcController)
);

// Progress Tracking
router.get(
  "/volunteers/:volunteerId/progress",
  requireVerification,
  nrcController.getVolunteerProgress.bind(nrcController)
);

router.put(
  "/volunteers/:volunteerId/milestones/:milestoneId",
  requireVerification,
  nrcController.updateMilestone.bind(nrcController)
);

router.get(
  "/volunteers/:volunteerId/achievements",
  requireVerification,
  nrcController.getVolunteerAchievements.bind(nrcController)
);

// Notifications
router.get(
  "/volunteers/:volunteerId/notifications",
  requireVerification,
  nrcController.getVolunteerNotifications.bind(nrcController)
);

router.put(
  "/notifications/:notificationId/read",
  requireVerification,
  nrcController.markNotificationAsRead.bind(nrcController)
);

router.put(
  "/volunteers/:volunteerId/notifications/read-all",
  requireVerification,
  nrcController.markAllNotificationsAsRead.bind(nrcController)
);

router.delete(
  "/notifications/:notificationId",
  requireVerification,
  nrcController.deleteNotification.bind(nrcController)
);

// Export & Reporting
router.post(
  "/volunteers/:volunteerId/export",
  requireVerification,
  nrcController.exportVolunteerData.bind(nrcController)
);

router.post(
  "/volunteers/:volunteerId/reports",
  requireVerification,
  nrcController.generateVolunteerReport.bind(nrcController)
);

router.post(
  "/export",
  requireRole("ADMIN"),
  nrcController.exportAllData.bind(nrcController)
);

// Analytics
router.get(
  "/analytics/comprehensive",
  requireRole("ADMIN"),
  nrcController.getComprehensiveAnalytics.bind(nrcController)
);

router.get(
  "/volunteers/:volunteerId/metrics",
  requireVerification,
  nrcController.getVolunteerMetrics.bind(nrcController)
);

router.get(
  "/analytics/geography",
  requireRole("ADMIN"),
  nrcController.getGeographyAnalytics.bind(nrcController)
);

router.get(
  "/analytics/categories",
  requireRole("ADMIN"),
  nrcController.getCategoryAnalytics.bind(nrcController)
);

// Volunteer Profile
router.get(
  "/volunteers/:volunteerId/profile",
  requireVerification,
  nrcController.getVolunteerProfile.bind(nrcController)
);

router.put(
  "/volunteers/:volunteerId/profile",
  requireVerification,
  nrcController.updateVolunteerProfile.bind(nrcController)
);

router.get(
  "/volunteers/check-status",
  requireVerification,
  nrcController.checkVolunteerStatus.bind(nrcController)
);

// Health check route
router.get("/health", (req, res) => {
  res.json({
    success: true,
    message: "NRC module is running",
    timestamp: new Date().toISOString(),
    version: "1.0.0",
  });
});

export default router;
