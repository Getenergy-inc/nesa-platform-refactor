import { Router } from "express";
import {
  verifyToken,
  requireVerification,
} from "../../../shared/middleware/auth";
import { nrcRegistrationLimiter } from "../../../shared/middleware/rateLimiter";
import { NRCService } from "../services/nrcService";
import { prisma } from "../../../shared/database/postgresql";

const router = Router();

// Health check route
router.get("/health", (req, res) => {
  res.json({
    success: true,
    message: "NRC module is running",
    timestamp: new Date().toISOString(),
    version: "1.0.0",
  });
});

// Protected routes (require authentication)
router.use(verifyToken);

// Check volunteer status endpoint
router.get("/volunteers/check-status", async (req, res, next) => {
  try {
    console.log("🔍 NRC Check Status - Endpoint hit");
    const userId = req.user?.id;
    console.log("🔍 NRC Check Status - User ID:", userId);

    if (!userId) {
      console.log("❌ NRC Check Status - No user ID found");
      res.status(401).json({
        success: false,
        message: "User ID not found in token",
      });
      return;
    }

    // Check if volunteer exists
    console.log("🔍 NRC Check Status - Querying database for userId:", userId);
    const volunteer = await prisma.nRCVolunteer.findUnique({
      where: { userId },
      include: {
        application: true,
      },
    });

    console.log("🔍 NRC Check Status - Volunteer found:", !!volunteer);

    if (!volunteer) {
      console.log("❌ NRC Check Status - Volunteer not found, returning 404");
      res.status(404).json({
        success: false,
        message: "Volunteer not found",
        data: null,
      });
      return;
    }

    console.log("✅ NRC Check Status - Returning volunteer data");
    res.json({
      success: true,
      message: "Volunteer status retrieved successfully",
      data: {
        profile: volunteer,
        isRegistered: true,
        status: volunteer.status,
      },
    });
  } catch (error) {
    console.error("❌ NRC Check Status - Error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to check volunteer status",
      error: error instanceof Error ? error.message : String(error),
    });
  }
});

// Volunteer registration endpoint
router.post(
  "/volunteers/register",
  nrcRegistrationLimiter,
  requireVerification,
  async (req, res, next) => {
    try {
      const { userId, fullName, email, phone, country, region } = req.body;

      // Validation
      if (!userId || !country) {
        res.status(400).json({
          success: false,
          message: "userId and country are required",
        });
        return;
      }

      // Get user info from the authenticated user if not provided
      const userInfo = await prisma.user.findUnique({
        where: { id: userId },
        select: { email: true },
      });

      // Check if application already exists for this user
      let application = await prisma.nRCApplication.findUnique({
        where: { userId },
      });

      if (!application) {
        application = await prisma.nRCApplication.create({
          data: {
            userId,
            fullName: fullName || userInfo?.email?.split("@")[0] || "Volunteer",
            email: userInfo?.email || "",
            phone: phone || "",
            country,
            motivation: "Auto-generated application",
            experience: "N/A",
            availability: "Available",
            skills: [],
            commitment: true,
            terms: true,
            status: "APPROVED",
            reviewedBy: "system",
            reviewDate: new Date(),
            reviewNotes: "Auto-approved for authenticated user",
          },
        });
      }

      // Check if volunteer already exists
      const existingVolunteer = await prisma.nRCVolunteer.findUnique({
        where: { userId },
      });

      if (existingVolunteer) {
        // Update existing volunteer with better data if needed
        const updatedVolunteer = await prisma.nRCVolunteer.update({
          where: { userId },
          data: {
            targetNominees: 200, // Update to correct target
            fullName:
              fullName && fullName !== "Unknown"
                ? fullName
                : existingVolunteer.fullName,
            email: email || existingVolunteer.email || userInfo?.email || "",
            lastActive: new Date()
          },
        });

        res.status(409).json({
          success: false,
          message: "Volunteer already registered",
          data: updatedVolunteer, // Include updated data
        });
        return;
      }

      // Create the volunteer record
      const volunteer = await prisma.nRCVolunteer.create({
        data: {
          applicationId: application.id,
          userId,
          fullName: fullName || userInfo?.email?.split("@")[0] || "Volunteer",
          email: email || userInfo?.email || "",
          country,
          approvalDate: new Date(),
          nomineesUploaded: 0,
          targetNominees: 200, // Updated to match the form target
          completionRate: 0,
          lastActive: new Date(),
          status: "ACTIVE",
        },
      });

      res.status(201).json({
        success: true,
        message: "Volunteer registered successfully",
        data: volunteer,
      });
    } catch (error) {
      console.error("Volunteer registration error:", error);
      res.status(500).json({
        success: false,
        message: "Failed to register volunteer",
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }
);

// File upload middleware
import multer from 'multer';

// Configure multer for file uploads
import path from 'path';
import fs from 'fs';

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, '../../../uploads/nominees');
try {
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
    console.log(`Created uploads directory: ${uploadsDir}`);
  }
} catch (err) {
  console.error(`Error creating uploads directory: ${err}`);
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + '-' + file.originalname);
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

// Nominee creation endpoint
router.post(
  "/nominees",
  requireVerification,
  upload.fields([
    { name: 'profileImage', maxCount: 1 },
    { name: 'supportingDocuments', maxCount: 5 }
  ]),
  async (req, res, next) => {
    try {
      console.log('Nominee creation endpoint hit');
      console.log('Request body keys:', Object.keys(req.body));
      console.log('Request body sample:', {
        fullName: req.body.fullName,
        country: req.body.country,
        status: req.body.status
      });
      console.log('Files received:', req.files ? 'Yes' : 'No');
      if (req.files) {
        const files = req.files as { [fieldname: string]: Express.Multer.File[] };
        console.log('Profile image:', files.profileImage ? `${files.profileImage.length} files` : 'None');
        console.log('Supporting documents:', files.supportingDocuments ? `${files.supportingDocuments.length} files` : 'None');
      }
      
      const volunteerId = req.user?.id;
      console.log('Volunteer ID:', volunteerId);
      if (!volunteerId) {
        console.log('Authentication failed: No volunteer ID');
        res.status(401).json({
          success: false,
          message: 'Authentication required'
        });
        return;
      }

      // Get status from request body or default to 'draft'
      const status = (req.body.status || 'draft').toUpperCase();
      
      // Calculate completion score
      let score = 0;
      const fields = [
        'fullName', 'country', 'region', 'awardCategory', 'subcategory',
        'achievementSummary', 'impactMetrics', 'sdgAlignment'
      ];

      fields.forEach(field => {
        if (req.body[field]) {
          if (field === 'sdgAlignment' && req.body[field].includes(',')) {
            score += req.body[field].split(',').length > 0 ? 10 : 0;
          } else {
            score += req.body[field].length > 0 ? 10 : 0;
          }
        }
      });

      // Bonus points for optional fields
      const optionalFields = ['email', 'phone', 'website', 'linkedinProfile', 'verificationLinks'];
      optionalFields.forEach(field => {
        if (req.body[field] && req.body[field].length > 0) {
          score += 2.5;
        }
      });

      const completionScore = Math.min(100, score);
      
      // Handle file uploads if any
      let profileImagePath = '';
      let supportingDocumentsPaths: string[] = [];

      // Check if files were uploaded and process them
      if (req.files) {
        const files = req.files as { [fieldname: string]: Express.Multer.File[] };
        
        if (files.profileImage && files.profileImage.length > 0 && files.profileImage[0]) {
          profileImagePath = files.profileImage[0].path;
        }
        
        if (files.supportingDocuments && files.supportingDocuments.length > 0) {
          console.log(`Processing ${files.supportingDocuments.length} supporting documents`);
          supportingDocumentsPaths = files.supportingDocuments
            .filter(doc => doc)
            .map(doc => {
              console.log(`Document path: ${doc.path}`);
              return doc.path;
            });
        } else {
          console.log('No supporting documents found in request');
        }
      }

      // Create nominee data object
      const nomineeData = {
        ...req.body,
        volunteerId,
        status,
        dateCreated: new Date().toISOString(),
        completionScore,
        profileImagePath,
        supportingDocumentsPaths
      };

      // Mock implementation - replace with actual database call
      const nominee = { id: 'nominee-' + Date.now(), ...nomineeData };
      
      res.status(201).json({
        success: true,
        message: 'Nominee created successfully',
        data: nominee
      });
    } catch (error) {
      console.error('Error creating nominee:', error);
      
      // Provide more detailed error information
      let errorMessage = 'Failed to create nominee';
      let statusCode = 500;
      
      if (error instanceof Error) {
        if (error.message.includes('ENOENT')) {
          errorMessage = 'File upload directory not found. Please contact support.';
        } else if (error.message.includes('EACCES')) {
          errorMessage = 'Permission denied when saving files. Please contact support.';
        }
      }
      
      res.status(statusCode).json({
        success: false,
        message: errorMessage,
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }
);

// Get nominees for a specific volunteer
router.get(
  "/volunteers/:volunteerId/nominees",
  requireVerification,
  async (req, res, next) => {
    try {
      const { volunteerId } = req.params;
      const { status, awardCategory, country, page = 1, limit = 20 } = req.query;

      if (!volunteerId) {
        res.status(400).json({
          success: false,
          message: "Volunteer ID is required",
        });
        return;
      }

      console.log(`🔍 Getting nominees for volunteer: ${volunteerId}`);

      const filters = {
        status: status as string | undefined,
        awardCategory: awardCategory as string | undefined,
        country: country as string | undefined,
      };

      const pagination = {
        page: Number(page),
        limit: Number(limit),
      };

      const nrcService = new NRCService(prisma);
      const result = await nrcService.getVolunteerNominees(volunteerId, filters, pagination);

      res.json({
        success: true,
        message: "Nominees retrieved successfully",
        data: result,
      });
    } catch (error) {
      console.error("❌ Error fetching volunteer nominees:", error);
      res.status(500).json({
        success: false,
        message: "Failed to retrieve nominees",
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }
);


export default router;
