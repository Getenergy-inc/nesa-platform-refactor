export interface NRCVolunteer {
  id: string;
  userId: string;
  role: NRCRole;
  region: string;
  country: string;
  agcBalance: number;
  agcWithdrawable: number;
  totalUploads: number;
  verifiedUploads: number;
  weeklyUploads: number;
  isActive: boolean;
  joinedAt: Date;
  lastActiveAt: Date;
  level: VolunteerLevel;
  badge?: string;
  coordinator?: string;
  teamLeadId?: string;
  displayName?: string;
}

export interface NRCVolunteerInput {
  userId: string;
  fullName?: string;
  email?: string;
  role?: NRCRole;
  region: string;
  country: string;
  coordinator?: string;
  teamLeadId?: string;
  displayName?: string;
  badge?: string;
}

export interface NRCVolunteerCreate {
  userId: string;
  role?: NRCRole;
  region: string;
  country: string;
  coordinator?: string;
  teamLeadId?: string;
  displayName?: string;
  badge?: string;
}

export interface NRCDashboardStats {
  totalUploads: number;
  verifiedUploads: number;
  pendingUploads: number;
  rejectedUploads: number;
  agcEarned: number;
  agcWithdrawable: number;
  currentWeekUploads: number;
  rank: number;
  level: VolunteerLevel;
  nextLevelProgress: number;
  recentActivities: NRCActivity[];
}

export interface NRCActivity {
  id: string;
  volunteerId: string;
  type: ActivityType;
  description: string;
  agcReward?: number;
  timestamp: Date;
  nominationId?: string;
  status?: ActivityStatus;
}

export interface NRCTask {
  id: string;
  title: string;
  description: string;
  assignedTo: string[];
  priority: TaskPriority;
  deadline: Date;
  status: TaskStatus;
  category: string;
  country?: string;
  region?: string;
  agcReward: number;
  completedBy?: string;
  completedAt?: Date;
  createdBy: string;
  createdAt: Date;
}

export interface NRCReport {
  period: string;
  totalVolunteers: number;
  activeVolunteers: number;
  totalNominations: number;
  verifiedNominations: number;
  countryDistribution: CountryStats[];
  categoryDistribution: CategoryStats[];
  performanceMetrics: PerformanceMetrics;
  topPerformers: VolunteerPerformance[];
}

export interface CountryStats {
  country: string;
  totalNominations: number;
  verifiedNominations: number;
  activeVolunteers: number;
  coveragePercentage: number;
}

export interface CategoryStats {
  category: string;
  subcategory: string;
  count: number;
  percentage: number;
  genderDistribution: GenderStats;
}

export interface GenderStats {
  male: number;
  female: number;
  other: number;
  notSpecified: number;
}

export interface PerformanceMetrics {
  averageUploadsPerVolunteer: number;
  verificationRate: number;
  completionRate: number;
  qualityScore: number;
  timeToVerification: number;
}

export interface VolunteerPerformance {
  volunteerId: string;
  name: string;
  uploads: number;
  verificationRate: number;
  agcEarned: number;
  rank: number;
  badge?: string;
}

export interface AGCTransaction {
  id: string;
  volunteerId: string;
  type: TransactionType;
  amount: number;
  description: string;
  nominationId?: string;
  isWithdrawable: boolean;
  timestamp: Date;
  status: TransactionStatus;
}

export enum NRCRole {
  VOLUNTEER = 'VOLUNTEER',
  TEAM_LEAD = 'TEAM_LEAD',
  COORDINATOR = 'COORDINATOR',
  VALIDATOR = 'VALIDATOR',
  ADMIN = 'ADMIN'
}

export enum VolunteerLevel {
  BRONZE = 'BRONZE',
  SILVER = 'SILVER',
  GOLD = 'GOLD',
  PLATINUM = 'PLATINUM',
  DIAMOND = 'DIAMOND'
}

export enum ActivityType {
  NOMINATION_UPLOAD = 'NOMINATION_UPLOAD',
  NOMINATION_VERIFIED = 'NOMINATION_VERIFIED',
  NOMINATION_REJECTED = 'NOMINATION_REJECTED',
  AGC_EARNED = 'AGC_EARNED',
  AGC_WITHDRAWN = 'AGC_WITHDRAWN',
  LEVEL_UP = 'LEVEL_UP',
  BADGE_EARNED = 'BADGE_EARNED',
  TASK_COMPLETED = 'TASK_COMPLETED'
}

export enum ActivityStatus {
  PENDING = 'PENDING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED'
}

export enum TaskPriority {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  URGENT = 'URGENT'
}

export enum TaskStatus {
  PENDING = 'PENDING',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED'
}

export enum TransactionType {
  FIRST_UPLOAD = 'FIRST_UPLOAD',
  VERIFIED_UPLOAD = 'VERIFIED_UPLOAD',
  WEEKLY_BONUS = 'WEEKLY_BONUS',
  TASK_COMPLETION = 'TASK_COMPLETION',
  WITHDRAWAL = 'WITHDRAWAL',
  PENALTY = 'PENALTY'
}

export enum TransactionStatus {
  PENDING = 'PENDING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED'
}

export interface NRCLeaderboard {
  weekly: VolunteerPerformance[];
  monthly: VolunteerPerformance[];
  allTime: VolunteerPerformance[];
  byCountry: Record<string, VolunteerPerformance[]>;
  byRegion: Record<string, VolunteerPerformance[]>;
}

export interface NRCConfiguration {
  agcRewards: {
    firstTenUploads: number;
    verifiedUpload: number;
    weeklyBestResearcher: number;
    taskCompletion: number;
  };
  thresholds: {
    minimumUploadsPerWeek: number;
    verificationThreshold: number;
    levelUpRequirements: Record<VolunteerLevel, number>;
  };
  regions: string[];
  countries: string[];
  categories: string[];
  subcategories: Record<string, string[]>;
}
