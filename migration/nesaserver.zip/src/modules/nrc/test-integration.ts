/**
 * Simple integration test for NRC endpoints
 * Run this to verify the NRC module is working correctly
 */

import { NRCController } from './controllers/NRCController';
import { NRCService } from './services/nrcService';
import { prisma } from '../../shared/database/postgresql';

async function testNRCIntegration() {
  console.log('🧪 Testing NRC Integration...');
  
  try {
    // Initialize service and controller
    const nrcService = new NRCService(prisma);
    const nrcController = new NRCController(nrcService);
    
    console.log('✅ NRC Service and Controller initialized successfully');
    
    // Test basic functionality
    const mockReq = {
      user: { id: 'test-user-123' },
      params: { volunteerId: 'test-volunteer-123' },
      query: {},
      body: {
        fullName: 'Test Nominee',
        country: 'Nigeria',
        region: 'Lagos',
        awardCategory: 'Educational Leadership',
        subcategory: 'Primary Education',
        achievementSummary: 'Outstanding contribution to primary education in Lagos',
        impactMetrics: 'Reached 5000+ students',
        sdgAlignment: ['SDG 4: Quality Education']
      }
    } as any;
    
    const mockRes = {
      status: (code: number) => ({
        json: (data: any) => {
          console.log(`📤 Response ${code}:`, JSON.stringify(data, null, 2));
          return mockRes;
        }
      }),
      json: (data: any) => {
        console.log('📤 Response:', JSON.stringify(data, null, 2));
        return mockRes;
      }
    } as any;
    
    const mockNext = (error?: any) => {
      if (error) {
        console.error('❌ Error:', error);
      }
    };
    
    // Test nominee creation
    console.log('\n🔬 Testing nominee creation...');
    await nrcController.createNominee(mockReq, mockRes, mockNext);
    
    // Test volunteer nominees retrieval
    console.log('\n🔬 Testing volunteer nominees retrieval...');
    await nrcController.getVolunteerNominees(mockReq, mockRes, mockNext);
    
    // Test volunteer progress
    console.log('\n🔬 Testing volunteer progress...');
    await nrcController.getVolunteerProgress(mockReq, mockRes, mockNext);
    
    // Test volunteer metrics
    console.log('\n🔬 Testing volunteer metrics...');
    await nrcController.getVolunteerMetrics(mockReq, mockRes, mockNext);
    
    console.log('\n✅ All NRC integration tests passed!');
    console.log('\n🎉 NRC module is ready for frontend integration');
    
  } catch (error) {
    console.error('❌ NRC Integration test failed:', error);
    throw error;
  }
}

// Run the test if this file is executed directly
if (require.main === module) {
  testNRCIntegration()
    .then(() => {
      console.log('\n🏁 Test completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Test failed:', error);
      process.exit(1);
    });
}

export { testNRCIntegration };