import { NRCRole, VolunteerLevel, TaskPriority, TaskStatus, TransactionType } from '../types/index';
import Joi from 'joi';

// Simple validation functions without external dependencies
export const validateNRCVolunteer = {
  create: (data: any) => {
    const errors: string[] = [];
    
    if (!data.userId) errors.push('userId is required');
    if (!data.region || data.region.length > 100) errors.push('region is required and must be max 100 characters');
    if (!data.country || data.country.length > 100) errors.push('country is required and must be max 100 characters');
    if (data.coordinator && data.coordinator.length > 200) errors.push('coordinator must be max 200 characters');
    
    return { isValid: errors.length === 0, errors };
  },

  update: (data: any) => {
    const errors: string[] = [];
    
    if (data.role && !Object.values(NRCRole).includes(data.role)) {
      errors.push('Invalid role');
    }
    if (data.region && data.region.length > 100) {
      errors.push('region must be max 100 characters');
    }
    if (data.country && data.country.length > 100) {
      errors.push('country must be max 100 characters');
    }
    
    return { isValid: errors.length === 0, errors };
  }
};

export const validateNRCTask = {
  create: (data: any) => {
    const errors: string[] = [];
    
    if (!data.title || data.title.length < 5 || data.title.length > 200) {
      errors.push('title is required and must be 5-200 characters');
    }
    if (!data.description || data.description.length < 10 || data.description.length > 1000) {
      errors.push('description is required and must be 10-1000 characters');
    }
    if (!data.assignedTo || !Array.isArray(data.assignedTo) || data.assignedTo.length === 0) {
      errors.push('assignedTo is required and must be a non-empty array');
    }
    if (!Object.values(TaskPriority).includes(data.priority)) {
      errors.push('Invalid priority');
    }
    if (!data.deadline || new Date(data.deadline) <= new Date()) {
      errors.push('deadline must be in the future');
    }
    if (typeof data.agcReward !== 'number' || data.agcReward < 0 || data.agcReward > 50) {
      errors.push('agcReward must be a number between 0 and 50');
    }
    
    return { isValid: errors.length === 0, errors };
  }
};

export const validateAGCTransaction = {
  create: (data: any) => {
    const errors: string[] = [];
    
    if (!data.volunteerId) errors.push('volunteerId is required');
    if (!Object.values(TransactionType).includes(data.type)) {
      errors.push('Invalid transaction type');
    }
    if (typeof data.amount !== 'number') errors.push('amount must be a number');
    if (!data.description || data.description.length > 500) {
      errors.push('description is required and must be max 500 characters');
    }
    
    return { isValid: errors.length === 0, errors };
  },

  withdraw: (data: any) => {
    const errors: string[] = [];
    
    if (typeof data.amount !== 'number' || data.amount <= 0) {
      errors.push('amount must be a positive number');
    }
    if (!data.walletAddress || data.walletAddress.length < 20 || data.walletAddress.length > 100) {
      errors.push('walletAddress must be 20-100 characters');
    }
    
    return { isValid: errors.length === 0, errors };
  }
};

export const nrcTaskValidation = {
  create: Joi.object({
    title: Joi.string().required().min(5).max(200),
    description: Joi.string().required().min(10).max(1000),
    assignedTo: Joi.array().items(Joi.string().uuid()).min(1).required(),
    priority: Joi.string().valid(...Object.values(TaskPriority)).required(),
    deadline: Joi.date().greater('now').required(),
    category: Joi.string().required().max(100),
    country: Joi.string().max(100).optional(),
    region: Joi.string().max(100).optional(),
    agcReward: Joi.number().min(0).max(50).required()
  }),

  update: Joi.object({
    title: Joi.string().min(5).max(200).optional(),
    description: Joi.string().min(10).max(1000).optional(),
    assignedTo: Joi.array().items(Joi.string().uuid()).min(1).optional(),
    priority: Joi.string().valid(...Object.values(TaskPriority)).optional(),
    deadline: Joi.date().greater('now').optional(),
    status: Joi.string().valid(...Object.values(TaskStatus)).optional(),
    category: Joi.string().max(100).optional(),
    country: Joi.string().max(100).optional(),
    region: Joi.string().max(100).optional(),
    agcReward: Joi.number().min(0).max(50).optional()
  }),

  query: Joi.object({
    assignedTo: Joi.string().uuid().optional(),
    priority: Joi.string().valid(...Object.values(TaskPriority)).optional(),
    status: Joi.string().valid(...Object.values(TaskStatus)).optional(),
    category: Joi.string().optional(),
    country: Joi.string().optional(),
    region: Joi.string().optional(),
    deadline: Joi.object({
      start: Joi.date(),
      end: Joi.date().greater(Joi.ref('start'))
    }).optional(),
    page: Joi.number().integer().min(1).default(1),
    limit: Joi.number().integer().min(1).max(50).default(10)
  })
};

export const agcTransactionValidation = {
  create: Joi.object({
    volunteerId: Joi.string().uuid().required(),
    type: Joi.string().valid(...Object.values(TransactionType)).required(),
    amount: Joi.number().required(),
    description: Joi.string().required().max(500),
    nominationId: Joi.string().uuid().optional(),
    isWithdrawable: Joi.boolean().default(false)
  }),

  withdraw: Joi.object({
    amount: Joi.number().positive().required(),
    walletAddress: Joi.string().required().min(20).max(100)
  }),

  query: Joi.object({
    volunteerId: Joi.string().uuid().optional(),
    type: Joi.string().valid(...Object.values(TransactionType)).optional(),
    dateRange: Joi.object({
      start: Joi.date(),
      end: Joi.date().greater(Joi.ref('start'))
    }).optional(),
    page: Joi.number().integer().min(1).default(1),
    limit: Joi.number().integer().min(1).max(100).default(20)
  })
};

export const dashboardValidation = {
  analytics: Joi.object({
    period: Joi.string().valid('week', 'month', 'quarter', 'year').default('month'),
    country: Joi.string().optional(),
    region: Joi.string().optional(),
    volunteerId: Joi.string().uuid().optional()
  }),

  leaderboard: Joi.object({
    type: Joi.string().valid('weekly', 'monthly', 'allTime').default('monthly'),
    country: Joi.string().optional(),
    region: Joi.string().optional(),
    limit: Joi.number().integer().min(1).max(50).default(10)
  })
};

export const reportValidation = {
  generate: Joi.object({
    type: Joi.string().valid('performance', 'country', 'category', 'volunteer', 'agc').required(),
    period: Joi.object({
      start: Joi.date().required(),
      end: Joi.date().greater(Joi.ref('start')).required()
    }).required(),
    filters: Joi.object({
      country: Joi.array().items(Joi.string()).optional(),
      region: Joi.array().items(Joi.string()).optional(),
      volunteerId: Joi.array().items(Joi.string().uuid()).optional(),
      role: Joi.array().items(Joi.string().valid(...Object.values(NRCRole))).optional()
    }).optional(),
    format: Joi.string().valid('json', 'csv', 'pdf').default('json')
  })
};

export const bulkOperationValidation = {
  volunteers: Joi.object({
    operation: Joi.string().valid('activate', 'deactivate', 'promote', 'demote', 'transfer').required(),
    volunteerIds: Joi.array().items(Joi.string().uuid()).min(1).required(),
    data: Joi.object().optional(),
    reason: Joi.string().max(500).optional()
  }),

  tasks: Joi.object({
    operation: Joi.string().valid('assign', 'complete', 'cancel', 'reassign').required(),
    taskIds: Joi.array().items(Joi.string().uuid()).min(1).required(),
    assignTo: Joi.array().items(Joi.string().uuid()).optional(),
    reason: Joi.string().max(500).optional()
  })
};
