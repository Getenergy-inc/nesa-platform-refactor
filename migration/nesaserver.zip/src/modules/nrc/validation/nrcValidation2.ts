import { NRCRole, VolunteerLevel, TaskPriority, TaskStatus, TransactionType } from '../types/index';

// Simple validation functions without external dependencies
export const validateNRCVolunteer = {
  create: (data: any) => {
    const errors: string[] = [];
    
    if (!data.userId) errors.push('userId is required');
    if (!data.region || data.region.length > 100) errors.push('region is required and must be max 100 characters');
    if (!data.country || data.country.length > 100) errors.push('country is required and must be max 100 characters');
    if (data.coordinator && data.coordinator.length > 200) errors.push('coordinator must be max 200 characters');
    
    return { isValid: errors.length === 0, errors };
  },

  update: (data: any) => {
    const errors: string[] = [];
    
    if (data.role && !Object.values(NRCRole).includes(data.role)) {
      errors.push('Invalid role');
    }
    if (data.region && data.region.length > 100) {
      errors.push('region must be max 100 characters');
    }
    if (data.country && data.country.length > 100) {
      errors.push('country must be max 100 characters');
    }
    
    return { isValid: errors.length === 0, errors };
  }
};

export const validateNRCTask = {
  create: (data: any) => {
    const errors: string[] = [];
    
    if (!data.title || data.title.length < 5 || data.title.length > 200) {
      errors.push('title is required and must be 5-200 characters');
    }
    if (!data.description || data.description.length < 10 || data.description.length > 1000) {
      errors.push('description is required and must be 10-1000 characters');
    }
    if (!data.assignedTo || !Array.isArray(data.assignedTo) || data.assignedTo.length === 0) {
      errors.push('assignedTo is required and must be a non-empty array');
    }
    if (!Object.values(TaskPriority).includes(data.priority)) {
      errors.push('Invalid priority');
    }
    if (!data.deadline || new Date(data.deadline) <= new Date()) {
      errors.push('deadline must be in the future');
    }
    if (typeof data.agcReward !== 'number' || data.agcReward < 0 || data.agcReward > 50) {
      errors.push('agcReward must be a number between 0 and 50');
    }
    
    return { isValid: errors.length === 0, errors };
  }
};

export const validateAGCTransaction = {
  create: (data: any) => {
    const errors: string[] = [];
    
    if (!data.volunteerId) errors.push('volunteerId is required');
    if (!Object.values(TransactionType).includes(data.type)) {
      errors.push('Invalid transaction type');
    }
    if (typeof data.amount !== 'number') errors.push('amount must be a number');
    if (!data.description || data.description.length > 500) {
      errors.push('description is required and must be max 500 characters');
    }
    
    return { isValid: errors.length === 0, errors };
  },

  withdraw: (data: any) => {
    const errors: string[] = [];
    
    if (typeof data.amount !== 'number' || data.amount <= 0) {
      errors.push('amount must be a positive number');
    }
    if (!data.walletAddress || data.walletAddress.length < 20 || data.walletAddress.length > 100) {
      errors.push('walletAddress must be 20-100 characters');
    }
    
    return { isValid: errors.length === 0, errors };
  }
};
