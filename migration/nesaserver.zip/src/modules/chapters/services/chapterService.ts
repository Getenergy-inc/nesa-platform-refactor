import { prisma } from '@/shared/database/postgresql';
import { Chapter } from '@prisma/client';

// Basic chapter assignment: find or create an online chapter by country+region
export class ChapterService {
  async assign(country: string, region: string): Promise<Chapter> {
    if (!country || !region) {
      throw new Error('Country and region are required for chapter assignment');
    }

    const name = `NESA Online Chapter – ${country} (${region})`;

    // Try to find an existing chapter
    let chapter = await prisma.chapter.findFirst({
      where: { country, region, type: 'ONLINE' }
    });

    // Create if not exists
    if (!chapter) {
      chapter = await prisma.chapter.create({
        data: {
          name,
          country,
          region,
          type: 'ONLINE',
          memberCount: 0,
          isActive: true,
        }
      });
    }

    return chapter;
  }

  async addMember(userId: string, chapterId: string): Promise<void> {
    // Upsert membership and increment count
    const existing = await prisma.chapterMembership.findUnique({ where: { userId } });
    if (!existing) {
      await prisma.$transaction([
        prisma.chapterMembership.create({ data: { userId, chapterId } }),
        prisma.chapter.update({ where: { id: chapterId }, data: { memberCount: { increment: 1 } } })
      ]);
    }
  }
}

export const chapterService = new ChapterService();