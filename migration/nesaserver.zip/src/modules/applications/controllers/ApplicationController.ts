import { Request, Response } from 'express';
import { applicationService, ApplicationData } from '../services/ApplicationService';
import { ValidationError, NotFoundError, ConflictError } from '@/shared/utils/errors';
import logger from '@/shared/utils/logger';
import { AuthenticatedRequest } from '@/shared/middleware/auth';

class ApplicationController {
  // Submit new application
  async submitApplication(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const userId = req.user?.id;
      if (!userId) {
        res.status(401).json({
          success: false,
          message: 'User authentication required'
        });
        return;
      }

      const applicationData = {
        ...req.body,
        userId
      };

      const application = await applicationService.submitApplication(applicationData);

      res.status(201).json({
        success: true,
        message: 'Application submitted successfully',
        data: {
          application,
          nextSteps: [
            'Your application has been submitted for review',
            'You will receive email updates on the status',
            'Review typically takes 5-7 business days'
          ]
        }
      });
    } catch (error) {
      logger.error('Application submission failed:', error);
      
      if (error instanceof ConflictError) {
        res.status(409).json({
          success: false,
          message: error.message
        });
      } else if (error instanceof ValidationError) {
        res.status(400).json({
          success: false,
          message: error.message
        });
      } else {
        res.status(500).json({
          success: false,
          message: 'Application submission failed'
        });
      }
    }
  }

  // Save application as draft
  async saveDraft(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const userId = req.user?.id;
      if (!userId) {
        res.status(401).json({
          success: false,
          message: 'User authentication required'
        });
        return;
      }

      const applicationData = {
        ...req.body,
        userId
      };

      const application = await applicationService.saveDraft(applicationData);

      res.status(200).json({
        success: true,
        message: 'Draft saved successfully',
        data: { application }
      });
    } catch (error) {
      logger.error('Draft save failed:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to save draft'
      });
    }
  }

  // Get user's applications
  async getUserApplications(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const userId = (req as any).params?.userId;
      const requestingUserId = req.user?.id;

      if (!userId) {
        res.status(400).json({
          success: false,
          message: 'User ID is required'
        });
        return;
      }

      // Users can only access their own applications unless they're admin
      if (userId !== requestingUserId && !req.user?.role?.includes('ADMIN')) {
        res.status(403).json({
          success: false,
          message: 'Access denied'
        });
        return;
      }

      const applications = await applicationService.getUserApplications(userId);

      res.status(200).json({
        success: true,
        message: 'Applications retrieved successfully',
        data: {
          applications,
          pagination: {
            page: 1,
            limit: applications.length,
            total: applications.length,
            totalPages: 1
          }
        }
      });
    } catch (error) {
      logger.error('Get user applications failed:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to retrieve applications'
      });
    }
  }

  // Get specific application
  async getApplication(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const applicationId = (req as any).params?.applicationId;
      
      if (!applicationId) {
        res.status(400).json({
          success: false,
          message: 'Application ID is required'
        });
        return;
      }

      const application = await applicationService.getApplication(applicationId);

      // Check if user can access this application
      if (application.userId !== req.user?.id && !req.user?.role?.includes('ADMIN')) {
        res.status(403).json({
          success: false,
          message: 'Access denied'
        });
        return;
      }

      res.status(200).json({
        success: true,
        message: 'Application retrieved successfully',
        data: { application }
      });
    } catch (error) {
      logger.error('Get application failed:', error);
      
      if (error instanceof NotFoundError) {
        res.status(404).json({
          success: false,
          message: error.message
        });
      } else {
        res.status(500).json({
          success: false,
          message: 'Failed to retrieve application'
        });
      }
    }
  }

  // Update application
  async updateApplication(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const applicationId = (req as any).params?.applicationId;
      const updates = req.body;

      if (!applicationId) {
        res.status(400).json({
          success: false,
          message: 'Application ID is required'
        });
        return;
      }

      // Get application to check ownership
      const existingApplication = await applicationService.getApplication(applicationId);
      
      if (existingApplication.userId !== req.user?.id && !req.user?.role?.includes('ADMIN')) {
        res.status(403).json({
          success: false,
          message: 'Access denied'
        });
        return;
      }

      const application = await applicationService.updateApplication(applicationId, updates);

      res.status(200).json({
        success: true,
        message: 'Application updated successfully',
        data: { application }
      });
    } catch (error) {
      logger.error('Application update failed:', error);
      
      if (error instanceof NotFoundError) {
        res.status(404).json({
          success: false,
          message: error.message
        });
      } else if (error instanceof ValidationError) {
        res.status(400).json({
          success: false,
          message: error.message
        });
      } else {
        res.status(500).json({
          success: false,
          message: 'Application update failed'
        });
      }
    }
  }

  // Withdraw application
  async withdrawApplication(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const applicationId = (req as any).params?.applicationId;
      const { reason } = req.body;

      if (!applicationId) {
        res.status(400).json({
          success: false,
          message: 'Application ID is required'
        });
        return;
      }

      // Get application to check ownership
      const existingApplication = await applicationService.getApplication(applicationId);
      
      if (existingApplication.userId !== req.user?.id) {
        res.status(403).json({
          success: false,
          message: 'Access denied'
        });
        return;
      }

      const application = await applicationService.withdrawApplication(applicationId, reason);

      res.status(200).json({
        success: true,
        message: 'Application withdrawn successfully',
        data: { application }
      });
    } catch (error) {
      logger.error('Application withdrawal failed:', error);
      
      if (error instanceof NotFoundError) {
        res.status(404).json({
          success: false,
          message: error.message
        });
      } else {
        res.status(500).json({
          success: false,
          message: 'Application withdrawal failed'
        });
      }
    }
  }

  // Upload document for application
  async uploadDocument(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const { applicationId, documentType } = req.body;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          success: false,
          message: 'User authentication required'
        });
        return;
      }

      if (!applicationId) {
        res.status(400).json({
          success: false,
          message: 'Application ID is required'
        });
        return;
      }

      // Verify user owns the application
      const application = await applicationService.getApplication(applicationId);
      if (application.userId !== userId) {
        res.status(403).json({
          success: false,
          message: 'Access denied'
        });
        return;
      }

      // For now, return a placeholder response
      // The actual file upload will be handled by the file upload service
      res.status(200).json({
        success: true,
        message: 'Document upload endpoint ready',
        data: {
          applicationId,
          documentType,
          uploadUrl: `/api/v1/files/upload`,
          instructions: 'Use the file upload endpoint to upload documents, then update the application with the file URLs'
        }
      });
    } catch (error) {
      logger.error('Document upload failed:', error);
      res.status(500).json({
        success: false,
        message: 'Document upload failed'
      });
    }
  }

  // Get application requirements
  async getApplicationRequirements(req: Request, res: Response): Promise<void> {
    try {
      const { applicationType } = req.params;

      // Static requirements for now - could be moved to database
      const requirements = {
        'JUDGE': {
          minimumExperience: 5,
          requiredDocuments: ['resume', 'cover_letter'],
          requiredFields: ['education', 'experience', 'expertise'],
          eligibilityCriteria: [
            'Minimum 5 years of relevant experience',
            'Advanced degree preferred',
            'Experience in education or related field'
          ]
        },
        'NRC_VOLUNTEER': {
          minimumExperience: 2,
          requiredDocuments: ['resume'],
          requiredFields: ['motivation', 'availability', 'skills'],
          eligibilityCriteria: [
            'Minimum 2 years of research experience',
            'Strong analytical skills',
            'Commitment to volunteer 10+ hours per month'
          ]
        },
        'AMBASSADOR': {
          minimumExperience: 3,
          requiredDocuments: ['resume'],
          requiredFields: ['community_experience', 'leadership_experience'],
          eligibilityCriteria: [
            'Demonstrated community leadership',
            'Strong communication skills',
            'Commitment to NESA mission'
          ]
        },
        'CHAPTER_LEADER': {
          minimumExperience: 5,
          requiredDocuments: ['resume', 'leadership_portfolio'],
          requiredFields: ['leadership_experience', 'chapter_plan'],
          eligibilityCriteria: [
            'Proven leadership experience',
            'Local community connections',
            'Ability to organize events and activities'
          ]
        }
      };

      const typeRequirements = requirements[applicationType as keyof typeof requirements];
      
      if (!typeRequirements) {
        res.status(400).json({
          success: false,
          message: 'Invalid application type'
        });
        return;
      }

      res.status(200).json({
        success: true,
        data: {
          applicationType,
          requirements: typeRequirements
        }
      });
    } catch (error) {
      logger.error('Get requirements failed:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to get requirements'
      });
    }
  }

  // Check eligibility
  async checkEligibility(req: Request, res: Response): Promise<void> {
    try {
      const { applicationType } = req.params;
      const { userId } = req.query;

      // TODO: Implement actual eligibility checking logic
      // For now, return basic eligibility check
      
      res.status(200).json({
        success: true,
        data: {
          eligible: true,
          reasons: [],
          recommendations: [
            'Ensure all required documents are ready',
            'Review application requirements carefully',
            'Prepare detailed responses for motivation questions'
          ]
        }
      });
    } catch (error) {
      logger.error('Eligibility check failed:', error);
      res.status(500).json({
        success: false,
        message: 'Eligibility check failed'
      });
    }
  }

  // Admin: Get all applications
  async getAllApplications(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const { applicationType, status, page, limit } = req.query;

      const filters = {
        applicationType: applicationType as any,
        status: status as any,
        page: page ? parseInt(page as string) : 1,
        limit: limit ? parseInt(limit as string) : 20
      };

      const result = await applicationService.getAllApplications(filters);

      res.status(200).json({
        success: true,
        message: 'Applications retrieved successfully',
        data: result
      });
    } catch (error) {
      logger.error('Get all applications failed:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to retrieve applications'
      });
    }
  }

  // Admin: Review application
  async reviewApplication(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const applicationId = (req as any).params?.applicationId;
      const { status, comments } = req.body;
      const reviewerId = req.user?.id;

      if (!applicationId) {
        res.status(400).json({
          success: false,
          message: 'Application ID is required'
        });
        return;
      }

      if (!reviewerId) {
        res.status(401).json({
          success: false,
          message: 'Reviewer authentication required'
        });
        return;
      }

      if (!['APPROVED', 'REJECTED'].includes(status)) {
        res.status(400).json({
          success: false,
          message: 'Invalid status. Must be APPROVED or REJECTED'
        });
        return;
      }

      const application = await applicationService.reviewApplication(
        applicationId,
        reviewerId,
        status,
        comments
      );

      res.status(200).json({
        success: true,
        message: `Application ${status.toLowerCase()} successfully`,
        data: { application }
      });
    } catch (error) {
      logger.error('Application review failed:', error);
      
      if (error instanceof NotFoundError) {
        res.status(404).json({
          success: false,
          message: error.message
        });
      } else {
        res.status(500).json({
          success: false,
          message: 'Application review failed'
        });
      }
    }
  }
}

export const applicationController = new ApplicationController();
export default applicationController;
