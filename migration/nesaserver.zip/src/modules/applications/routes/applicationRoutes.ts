import { Router } from 'express';
import { verifyToken, requireVerification, requireRole } from '@/shared/middleware/auth';
import { validateRequest } from '@/shared/utils/validation';
import { authLimiter } from '@/shared/middleware/rateLimiter';
import { z } from 'zod';
import { applicationController } from '../controllers/ApplicationController';

const router = Router();

// Validation schemas
const submitApplicationSchema = z.object({
  body: z.object({
    applicationType: z.enum(['JUDGE', 'NRC_VOLUNTEER', 'AMBASSADOR', 'CHAPTER_LEADER']),
    personalInfo: z.object({
      fullName: z.string().min(1),
      email: z.string().email(),
      phone: z.string().min(1),
      country: z.string().min(1),
      state: z.string().min(1),
      city: z.string().optional()
    }),
    professionalInfo: z.object({
      currentPosition: z.string().min(1),
      organization: z.string().min(1),
      yearsOfExperience: z.number().min(0),
      educationLevel: z.string().min(1),
      fieldOfExpertise: z.array(z.string()),
      linkedinProfile: z.string().optional(),
      resume: z.string().optional() // File URL after upload
    }),
    motivation: z.object({
      whyApply: z.string().min(1),
      relevantExperience: z.string().min(1),
      timeCommitment: z.string().min(1),
      additionalInfo: z.string().optional()
    }),
    references: z.array(z.object({
      name: z.string().min(1),
      position: z.string().min(1),
      organization: z.string().min(1),
      email: z.string().email(),
      phone: z.string().min(1)
    })).optional()
  })
});

const updateApplicationSchema = z.object({
  body: z.object({
    status: z.enum(['DRAFT', 'SUBMITTED', 'UNDER_REVIEW', 'APPROVED', 'REJECTED', 'WITHDRAWN']).optional(),
    reviewComments: z.string().optional(),
    // Allow partial updates of any application field
  }).passthrough()
});

const applicationIdSchema = z.object({
  params: z.object({
    applicationId: z.string().cuid()
  })
});

// ApplicationController is now imported from the actual implementation

// Public routes
router.get('/requirements/:applicationType',
  applicationController.getApplicationRequirements
);

router.get('/eligibility/:applicationType',
  applicationController.checkEligibility
);

// Protected routes (require authentication)
router.use(verifyToken);

// User application routes
router.post('/submit',
  authLimiter,
  requireVerification,
  validateRequest(submitApplicationSchema),
  applicationController.submitApplication
);

router.post('/draft',
  authLimiter,
  requireVerification,
  applicationController.saveDraft
);

router.get('/user/:userId',
  requireVerification,
  applicationController.getUserApplications
);

router.get('/:applicationId',
  requireVerification,
  validateRequest(applicationIdSchema),
  applicationController.getApplication
);

router.put('/:applicationId',
  requireVerification,
  validateRequest(applicationIdSchema),
  validateRequest(updateApplicationSchema),
  applicationController.updateApplication
);

router.put('/:applicationId/withdraw',
  requireVerification,
  validateRequest(applicationIdSchema),
  applicationController.withdrawApplication
);

router.post('/upload-document',
  requireVerification,
  applicationController.uploadDocument
);

// Admin routes (require admin role)
router.get('/',
  requireRole('ADMIN', 'SUPER_ADMIN'),
  applicationController.getAllApplications
);

router.put('/:applicationId/review',
  requireRole('ADMIN', 'SUPER_ADMIN'),
  validateRequest(applicationIdSchema),
  applicationController.reviewApplication
);

export default router;
