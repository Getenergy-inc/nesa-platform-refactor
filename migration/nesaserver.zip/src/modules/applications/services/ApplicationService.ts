import { prisma } from '@/shared/database/postgresql';
import { ValidationError, NotFoundError, ConflictError } from '@/shared/utils/errors';
import logger from '@/shared/utils/logger';

export type ApplicationType = 'JUDGE' | 'NRC_VOLUNTEER' | 'AMBASSADOR' | 'CHAPTER_LEADER' | 'VOLUNTEER';
export type ApplicationStatus = 'DRAFT' | 'SUBMITTED' | 'UNDER_REVIEW' | 'APPROVED' | 'REJECTED' | 'WITHDRAWN';

export interface ApplicationData {
  id?: string;
  userId: string;
  applicationType: ApplicationType;
  status: ApplicationStatus;
  personalInfo: {
    fullName: string;
    email: string;
    phone: string;
    country: string;
    state: string;
    city?: string;
  };
  professionalInfo: {
    currentPosition: string;
    organization: string;
    yearsOfExperience: number;
    educationLevel: string;
    fieldOfExpertise: string[];
    linkedinProfile?: string;
    resume?: string;
  };
  motivation: {
    whyApply: string;
    relevantExperience: string;
    timeCommitment: string;
    additionalInfo?: string;
  };
  references?: {
    name: string;
    position: string;
    organization: string;
    email: string;
    phone: string;
  }[];
  documents?: {
    type: string;
    name: string;
    url: string;
  }[];
  submittedAt?: Date;
  reviewedAt?: Date;
  reviewedBy?: string;
  reviewComments?: string;
  createdAt?: Date;
  updatedAt?: Date;
}

class ApplicationService {
  // Submit new application
  async submitApplication(applicationData: Omit<ApplicationData, 'id' | 'status' | 'submittedAt'>): Promise<ApplicationData> {
    try {
      // Check if user already has an application of this type
      const existingApplication = await prisma.application.findFirst({
        where: {
          userId: applicationData.userId,
          applicationType: applicationData.applicationType,
          status: {
            not: 'WITHDRAWN'
          }
        }
      });

      if (existingApplication) {
        throw new ConflictError(`User already has a ${applicationData.applicationType} application`);
      }

      // Create application
      const application = await prisma.application.create({
        data: {
          userId: applicationData.userId,
          applicationType: applicationData.applicationType,
          status: 'SUBMITTED',
          personalInfo: applicationData.personalInfo,
          professionalInfo: applicationData.professionalInfo,
          motivation: applicationData.motivation,
          references: applicationData.references || [],
          documents: applicationData.documents || [],
          submittedAt: new Date()
        }
      });

      logger.info(`Application submitted: ${application.id} for user ${applicationData.userId}`);

      // TODO: Send confirmation email
      // await this.sendApplicationConfirmationEmail(application);

      return this.mapPrismaToApplicationData(application);
    } catch (error) {
      logger.error('Application submission failed:', error);
      throw error;
    }
  }

  // Save application as draft
  async saveDraft(applicationData: Partial<ApplicationData>): Promise<ApplicationData> {
    try {
      if (!applicationData.userId || !applicationData.applicationType) {
        throw new ValidationError('User ID and application type are required');
      }

      // Check for existing draft
      const existingDraft = await prisma.application.findFirst({
        where: {
          userId: applicationData.userId,
          applicationType: applicationData.applicationType,
          status: 'DRAFT'
        }
      });

      let application;
      if (existingDraft) {
        // Update existing draft
        application = await prisma.application.update({
          where: { id: existingDraft.id },
          data: {
            personalInfo: applicationData.personalInfo || null,
            professionalInfo: applicationData.professionalInfo || null,
            motivation: applicationData.motivation || null,
            references: applicationData.references || null,
            documents: applicationData.documents || null,
            updatedAt: new Date()
          }
        });
      } else {
        // Create new draft
        application = await prisma.application.create({
          data: {
            userId: applicationData.userId,
            applicationType: applicationData.applicationType,
            status: 'DRAFT',
            personalInfo: applicationData.personalInfo || {},
            professionalInfo: applicationData.professionalInfo || {},
            motivation: applicationData.motivation || {},
            references: applicationData.references || [],
            documents: applicationData.documents || []
          }
        });
      }

      return this.mapPrismaToApplicationData(application);
    } catch (error) {
      logger.error('Draft save failed:', error);
      throw error;
    }
  }

  // Get user's applications
  async getUserApplications(userId: string): Promise<ApplicationData[]> {
    try {
      const applications = await prisma.application.findMany({
        where: { userId },
        orderBy: { createdAt: 'desc' }
      });

      return applications.map(this.mapPrismaToApplicationData);
    } catch (error) {
      logger.error('Get user applications failed:', error);
      throw error;
    }
  }

  // Get application by ID
  async getApplication(applicationId: string): Promise<ApplicationData> {
    try {
      const application = await prisma.application.findUnique({
        where: { id: applicationId }
      });

      if (!application) {
        throw new NotFoundError('Application not found');
      }

      return this.mapPrismaToApplicationData(application);
    } catch (error) {
      logger.error('Get application failed:', error);
      throw error;
    }
  }

  // Update application
  async updateApplication(applicationId: string, updates: Partial<ApplicationData>): Promise<ApplicationData> {
    try {
      const application = await prisma.application.findUnique({
        where: { id: applicationId }
      });

      if (!application) {
        throw new NotFoundError('Application not found');
      }

      // Prevent updates to submitted applications unless it's status change
      if (application.status === 'SUBMITTED' && updates.status !== 'WITHDRAWN') {
        throw new ValidationError('Cannot update submitted application');
      }

      const updatedApplication = await prisma.application.update({
        where: { id: applicationId },
        data: {
          ...updates,
          updatedAt: new Date()
        }
      });

      return this.mapPrismaToApplicationData(updatedApplication);
    } catch (error) {
      logger.error('Application update failed:', error);
      throw error;
    }
  }

  // Withdraw application
  async withdrawApplication(applicationId: string, reason?: string): Promise<ApplicationData> {
    try {
      const application = await prisma.application.update({
        where: { id: applicationId },
        data: {
          status: 'WITHDRAWN',
          reviewComments: reason || 'Application withdrawn by user',
          updatedAt: new Date()
        }
      });

      logger.info(`Application withdrawn: ${applicationId}`);
      return this.mapPrismaToApplicationData(application);
    } catch (error) {
      logger.error('Application withdrawal failed:', error);
      throw error;
    }
  }

  // Admin: Get all applications
  async getAllApplications(filters?: {
    applicationType?: ApplicationType;
    status?: ApplicationStatus;
    page?: number;
    limit?: number;
  }): Promise<{ applications: ApplicationData[]; total: number; page: number; totalPages: number }> {
    try {
      const page = filters?.page || 1;
      const limit = filters?.limit || 20;
      const skip = (page - 1) * limit;

      const where: any = {};
      if (filters?.applicationType) where.applicationType = filters.applicationType;
      if (filters?.status) where.status = filters.status;

      const [applications, total] = await Promise.all([
        prisma.application.findMany({
          where,
          skip,
          take: limit,
          orderBy: { createdAt: 'desc' }
        }),
        prisma.application.count({ where })
      ]);

      return {
        applications: applications.map(this.mapPrismaToApplicationData),
        total,
        page,
        totalPages: Math.ceil(total / limit)
      };
    } catch (error) {
      logger.error('Get all applications failed:', error);
      throw error;
    }
  }

  // Admin: Review application (approve/reject)
  async reviewApplication(
    applicationId: string, 
    reviewerId: string, 
    status: 'APPROVED' | 'REJECTED', 
    comments?: string
  ): Promise<ApplicationData> {
    try {
      const application = await prisma.application.update({
        where: { id: applicationId },
        data: {
          status,
          reviewedBy: reviewerId,
          reviewedAt: new Date(),
          reviewComments: comments || null,
          updatedAt: new Date()
        }
      });

      // If approved, upgrade user role
      if (status === 'APPROVED') {
        await this.upgradeUserRole(application.userId, application.applicationType);
      }

      logger.info(`Application ${status.toLowerCase()}: ${applicationId} by ${reviewerId}`);

      // TODO: Send notification email
      // await this.sendApplicationStatusEmail(application);

      return this.mapPrismaToApplicationData(application);
    } catch (error) {
      logger.error('Application review failed:', error);
      throw error;
    }
  }

  // Upgrade user role after application approval
  private async upgradeUserRole(userId: string, applicationType: ApplicationType): Promise<void> {
    const roleMapping: Record<ApplicationType, string> = {
      'JUDGE': 'JUDGE',
      'NRC_VOLUNTEER': 'NRC_VOLUNTEER',
      'AMBASSADOR': 'AMBASSADOR',
      'CHAPTER_LEADER': 'CHAPTER_LEADER',
      'VOLUNTEER': 'VOLUNTEER'
    };

    const newRole = roleMapping[applicationType];
    if (!newRole) return;

    await prisma.user.update({
      where: { id: userId },
      data: { role: newRole as any }
    });

    logger.info(`User role upgraded: ${userId} → ${newRole}`);
  }

  // Map Prisma model to ApplicationData interface
  private mapPrismaToApplicationData(prismaApplication: any): ApplicationData {
    return {
      id: prismaApplication.id,
      userId: prismaApplication.userId,
      applicationType: prismaApplication.applicationType,
      status: prismaApplication.status,
      personalInfo: prismaApplication.personalInfo,
      professionalInfo: prismaApplication.professionalInfo,
      motivation: prismaApplication.motivation,
      references: prismaApplication.references,
      documents: prismaApplication.documents,
      submittedAt: prismaApplication.submittedAt,
      reviewedAt: prismaApplication.reviewedAt,
      reviewedBy: prismaApplication.reviewedBy,
      reviewComments: prismaApplication.reviewComments,
      createdAt: prismaApplication.createdAt,
      updatedAt: prismaApplication.updatedAt
    };
  }
}

export const applicationService = new ApplicationService();
export default applicationService;
