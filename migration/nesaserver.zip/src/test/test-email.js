const sgMail = require('@sendgrid/mail');
require('dotenv').config();

sgMail.setApiKey(process.env.SENDGRID_API_KEY);

const msg = {
  to: 'your-test-email@gmail.com', // Your email for testing
  from: process.env.FROM_EMAIL,
  subject: 'SendGrid Test Email',
  text: 'Hello from NESA-Africa Platform!',
  html: '<strong>Hello from NESA-Africa Platform!</strong>',
};

sgMail
  .send(msg)
  .then(() => {
    console.log('✅ Test email sent successfully!');
  })
  .catch((error) => {
    console.error('❌ Email sending failed:', error);
  });