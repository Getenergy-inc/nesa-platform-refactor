import express from "express";
import cors from "cors";
import helmet from "helmet";
import { config } from "./config";
import { prisma } from "./shared/database/postgresql";

import {
  errorHandler,
  notFoundHandler,
} from "./shared/middleware/errorHandler";
import { generalLimiter } from "./shared/middleware/rateLimiter";
import logger from "./shared/utils/logger";
import cookieParser from "cookie-parser";
import { setupSwagger } from "./config/swagger";

// Import route modules
import authRoutes from "./modules/auth/routes/authRoutes";
import healthRoutes from "./shared/routes/health";
import { issueCsrfToken } from "./shared/middleware/csrf";

// Import queue system
import { serverAdapter, initializeWorkers } from "./shared/queues";

class App {
  public app: express.Application;

  constructor() {
    this.app = express();
    this.initializeMiddlewares();
    this.initializeSwagger();
    this.initializeRoutes();
    this.initializeErrorHandling();
  }

  private initializeMiddlewares(): void {
    // Security middleware
    this.app.use(
      helmet({
        crossOriginResourcePolicy: { policy: "cross-origin" },
      })
    );

    // CORS configuration
    this.app.use(
      cors({
        origin: config.corsOrigins,
        credentials: true,
        methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
        allowedHeaders: [
          "Content-Type",
          "Authorization",
          "X-Requested-With",
          "x-bypass-auth",
        ],
      })
    );

    // Serve static files (for email assets like logo)
    this.app.use("/assets", express.static("src/public/assets"));

    // Rate limiting
    this.app.use(generalLimiter);

    // Body parsing middleware
    this.app.use(express.json({ limit: "10mb" }));
    this.app.use(express.urlencoded({ extended: true, limit: "10mb" }));

    // Cookie parser (for HttpOnly refresh token)
    this.app.use(cookieParser());

    // Request logging
    this.app.use((req, _res, next) => {
      logger.info(`${req.method} ${req.originalUrl} - ${req.ip}`);
      next();
    });
  }

  private initializeSwagger(): void {
    // Setup Swagger documentation
    setupSwagger(this.app);
  }

  private initializeRoutes(): void {
    // Bull Board Dashboard (Admin only - add authentication middleware in production)
    this.app.use("/admin/queues", serverAdapter.getRouter());
    logger.info("📊 Bull Board dashboard available at /admin/queues");

    // Health check endpoints are provided by shared healthRoutes.
    // We expose them at both the root and versioned API base for convenience.
    // Root exposure is configured below via this.app.use('/', healthRoutes).
    // Versioned exposure is added by mounting healthRoutes on apiRouter.

    // API routes
    const apiRouter = express.Router();

    // Mount module routes
    apiRouter.use("/auth", authRoutes);

    // Queue management routes
    try {
      const queueRoutes = require("./shared/routes/queues").default;
      apiRouter.use("/queues", queueRoutes);
      console.log("✅ Queue routes loaded successfully");
    } catch {
      console.warn("⚠️ Queue routes not loaded");
    }

    // TODO: Implement these missing route modules for full functionality
    try {
      const applicationsRoutes = require("./modules/applications/routes/applicationRoutes")
        .default;
      apiRouter.use("/applications", applicationsRoutes);
    } catch {
      console.warn("⚠️ Applications routes not implemented yet");
    }

    try {
      // Explicitly use the full NRC routes implementation, not the simplified version
      const nrcRoutes = require("./modules/nrc/routes/nrcRoutes").default;
      apiRouter.use("/nrc", nrcRoutes);
      console.log("✅ NRC routes loaded successfully");
    } catch (error) {
      console.warn("⚠️ NRC routes not implemented yet");
      console.error(
        "NRC routes error:",
        error instanceof Error ? error.message : String(error)
      );

      // Fallback to simplified routes if full implementation fails
      try {
        console.warn("⚠️ Attempting to load simplified NRC routes as fallback");
        const nrcRoutesSimple = require("./modules/nrc/routes/nrcRoutes-simple")
          .default;
        apiRouter.use("/nrc", nrcRoutesSimple);
        console.log("✅ Simplified NRC routes loaded as fallback");
      } catch (fallbackError) {
        console.error(
          "❌ Failed to load even simplified NRC routes:",
          fallbackError instanceof Error
            ? fallbackError.message
            : String(fallbackError)
        );
      }
    }

    try {
      const nominationRoutes = require("./modules/nominations/routes/nominationRoutes")
        .default;
      apiRouter.use("/nominations", nominationRoutes);
    } catch {
      console.warn("⚠️ Nomination routes not implemented yet");
    }

    try {
      const judgeRoutes = require("./modules/judges/routes/judgeRoutes")
        .default;
      apiRouter.use("/judges", judgeRoutes);
    } catch {
      console.warn("⚠️ Judge routes not implemented yet");
    }

    try {
      const walletRoutes = require("./modules/wallet/routes/walletRoutes")
        .default;
      apiRouter.use("/wallet", walletRoutes);

      // Admin wallet routes
      const adminWalletRoutes = require("./modules/wallet/routes/adminWalletRoutes")
        .default;
      apiRouter.use("/wallet/admin", adminWalletRoutes);
    } catch {
      console.warn("⚠️ Wallet routes not implemented yet");
    }

    try {
      const votingRoutes = require("./modules/voting/routes/votingRoutes")
        .default;
      apiRouter.use("/voting", votingRoutes);
      console.log("✅ Voting routes loaded successfully");
    } catch (error) {
      console.warn("⚠️ Voting routes not implemented yet");
      console.error(
        "Voting routes error:",
        error instanceof Error ? error.message : String(error)
      );
    }

    try {
      const fileRoutes = require("./modules/files/routes/fileRoutes").default;
      apiRouter.use("/files", fileRoutes);
    } catch {
      console.warn("⚠️ File routes not implemented yet");
    }

    try {
      const nomineeRoutes = require("./modules/nominees/routes/nomineeRoutes")
        .default;
      apiRouter.use("/nominees", nomineeRoutes);
      console.log("✅ Nominee routes loaded successfully");
    } catch (error) {
      console.warn("⚠️ Nominee routes not implemented yet");
      console.error(
        "Nominee routes error:",
        error instanceof Error ? error.message : String(error)
      );
    }

    try {
      const certificateRoutes = require("./modules/certificates/routes/certificateRoutes")
        .default;
      apiRouter.use("/certificates", certificateRoutes);
      console.log("✅ Certificate routes loaded successfully");
    } catch (error) {
      console.warn("⚠️ Certificate routes not implemented yet");
      console.error(
        "Certificate routes error:",
        error instanceof Error ? error.message : String(error)
      );
    }

    // apiRouter.use('/nominations', nominationRoutes);
    // apiRouter.use('/notifications', notificationRoutes);
    // apiRouter.use('/admin', adminRoutes);

    // Health check routes (comprehensive)
    this.app.use("/", healthRoutes); // e.g., /health, /ready, /live remain available
    apiRouter.use("/", healthRoutes); // also expose under /api/v1/*

    // Mount API router
    this.app.use(`/api/${config.apiVersion}`, apiRouter);

    // Optional: legacy compatibility router at /api/auths/*
    try {
      // Dynamic import to avoid circulars at top level
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const legacyAuthRoutes = require("./modules/auth/routes/legacyAuthRoutes")
        .default;
      this.app.use("/api/auths", legacyAuthRoutes);
    } catch {
      // ignore if route file not found
    }

    // Root endpoint
    this.app.get("/", (req, res) => {
      // Ensure CSRF token cookie exists
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const { ensureCsrfCookie } = require("./shared/middleware/csrf");
      ensureCsrfCookie(req, res);
      res.json({
        message: "NESA-Africa Backend API",
        version: config.apiVersion,
        environment: config.nodeEnv,
        timestamp: new Date().toISOString(),
      });
    });

    // Public CSRF endpoint (for SPAs to fetch initial token)
    this.app.get("/csrf", issueCsrfToken);
  }

  private initializeErrorHandling(): void {
    // 404 handler
    this.app.use(notFoundHandler);

    // Global error handler
    this.app.use(errorHandler);
  }

  public async initialize(): Promise<void> {
    console.log("the problem is here");
    try {
      // Connect to PostgreSQL (primary database)
      await prisma.connect();
      logger.info("✅ PostgreSQL connected successfully");

      logger.info("✅ Database initialization completed");

      // Initialize queue workers
      initializeWorkers();
      logger.info("✅ Queue workers initialized");

      // Start monitoring services
      this.startMonitoringServices();
    } catch (error) {
      logger.error("❌ Critical database connection failed:", error);
      throw error;
    }
  }

  private startMonitoringServices(): void {
    try {
      // Start provider health checks
      const {
        providerHealthService,
      } = require("./modules/wallet/services/providerHealthService");
      providerHealthService.startPeriodicHealthChecks();
      logger.info("✅ Provider health monitoring started");

      // Start currency rate updates
      const {
        currencyService,
      } = require("./modules/wallet/services/currencyService");
      currencyService.startPeriodicUpdates();
      logger.info("✅ Currency rate updates started");
    } catch (error) {
      logger.warn("⚠️ Failed to start monitoring services:", error);
    }
  }

  public listen(): void {
    this.app.listen(config.port, () => {
      logger.info(
        `🚀 Server running on port ${config.port} in ${config.nodeEnv} mode`
      );
      logger.info(
        `📚 API Documentation: http://localhost:${config.port}/api/docs`
      );
      logger.info(
        `📄 API JSON Schema: http://localhost:${config.port}/api/docs/json`
      );
      logger.info(
        `🏥 Health Check: http://localhost:${config.port}/health and http://localhost:${config.port}/api/${config.apiVersion}/health`
      );
    });
  }
}

export default App;
