# 🐳 Docker Setup for NESA-Africa Backend

Complete Docker containerization with PostgreSQL, Redis, and the application ready for Contabo deployment.

## 📦 What's Included

- **PostgreSQL 15** - Primary database
- **Redis 7** - Caching, sessions, and job queues
- **Node.js App** - Your backend application
- **Nginx** (optional) - Reverse proxy for production

## 🚀 Quick Start

### For Development (Local)

```bash
# Start only PostgreSQL and Redis
docker-compose -f docker-compose.dev.yml up -d

# Your app runs locally with nodemon
npm run dev
```

### For Production (Contabo)

```bash
# 1. Configure environment
cp .env.production .env
nano .env  # Update all values

# 2. Deploy everything
./deploy.sh  # Linux/Mac
# OR
.\deploy.ps1  # Windows

# 3. Check status
docker-compose ps
docker-compose logs -f
```

## 📋 Environment Files

- `.env.example` - Template with all variables
- `.env.development` - Local development settings
- `.env.production` - Production template (copy to `.env`)
- `.env` - Active configuration (gitignored)

## 🔧 Docker Compose Files

- `docker-compose.yml` - Full production stack (app + db + redis + nginx)
- `docker-compose.dev.yml` - Development stack (only db + redis)

## 🎯 Common Commands

### Start/Stop

```bash
# Start all services
docker-compose up -d

# Start in foreground (see logs)
docker-compose up

# Stop all services
docker-compose down

# Stop and remove volumes (⚠️ deletes data)
docker-compose down -v
```

### Logs

```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f app
docker-compose logs -f postgres
docker-compose logs -f redis

# Last 100 lines
docker-compose logs --tail=100 app
```

### Database Operations

```bash
# Run migrations
docker-compose exec app npx prisma migrate deploy

# Seed database
docker-compose exec app npm run seed

# Open Prisma Studio
docker-compose exec app npx prisma studio

# Access PostgreSQL directly
docker-compose exec postgres psql -U nesa_user -d nesa_africa
```

### Container Management

```bash
# Restart a service
docker-compose restart app

# Rebuild and restart
docker-compose up -d --build app

# Execute command in container
docker-compose exec app sh
docker-compose exec app npm run seed

# View container stats
docker stats
```

## 💾 Backup & Restore

### Backup Database

```bash
# Using backup script
./backup.sh

# Manual backup
docker-compose exec postgres pg_dump -U nesa_user nesa_africa > backup.sql

# Compressed backup
docker-compose exec postgres pg_dump -U nesa_user nesa_africa | gzip > backup.sql.gz
```

### Restore Database

```bash
# From SQL file
docker-compose exec -T postgres psql -U nesa_user -d nesa_africa < backup.sql

# From compressed file
gunzip < backup.sql.gz | docker-compose exec -T postgres psql -U nesa_user -d nesa_africa
```

## 🔒 Security Checklist

Before deploying to production:

- [ ] Change `POSTGRES_PASSWORD` in `.env`
- [ ] Change `REDIS_PASSWORD` in `.env`
- [ ] Generate strong `JWT_SECRET` (64+ characters)
- [ ] Generate strong `JWT_REFRESH_SECRET` (different from JWT_SECRET)
- [ ] Update `SESSION_SECRET`
- [ ] Configure `SENDGRID_API_KEY`
- [ ] Configure `CLOUDINARY_*` credentials
- [ ] Configure `PAYSTACK_*` credentials
- [ ] Set correct `FRONTEND_URL` and `CORS_ORIGINS`
- [ ] Change `SUPERADMIN_PASSWORD`
- [ ] Enable firewall on server
- [ ] Setup SSL certificates
- [ ] Configure automated backups

## 🌐 Contabo Deployment Steps

### 1. Prepare Server

```bash
# SSH into your Contabo VPS
ssh root@your-server-ip

# Update system
apt update && apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Install Docker Compose
curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

# Verify
docker --version
docker-compose --version
```

### 2. Deploy Application

```bash
# Clone repository
git clone <your-repo-url> nesa-africa-backend
cd nesa-africa-backend

# Configure environment
cp .env.production .env
nano .env  # Update all values

# Deploy
chmod +x deploy.sh
./deploy.sh
```

### 3. Setup Firewall

```bash
# Allow necessary ports
ufw allow 22/tcp   # SSH
ufw allow 80/tcp   # HTTP
ufw allow 443/tcp  # HTTPS
ufw enable
```

### 4. Setup SSL (Optional but Recommended)

```bash
# Install certbot
apt install certbot -y

# Get certificate
certbot certonly --standalone -d your-domain.com

# Copy to nginx folder
cp /etc/letsencrypt/live/your-domain.com/fullchain.pem nginx/ssl/
cp /etc/letsencrypt/live/your-domain.com/privkey.pem nginx/ssl/

# Enable nginx with SSL
docker-compose --profile production up -d
```

### 5. Setup Automated Backups

```bash
# Make backup script executable
chmod +x backup.sh

# Add to crontab (daily at 2 AM)
crontab -e
# Add: 0 2 * * * /root/nesa-africa-backend/backup.sh
```

## 📊 Monitoring

### Health Checks

```bash
# Check container health
docker-compose ps

# Application health endpoint
curl http://localhost:5000/health

# Check specific container
docker inspect --format='{{.State.Health.Status}}' nesa-app
```

### Resource Usage

```bash
# Real-time stats
docker stats

# Disk usage
docker system df

# Clean up unused resources
docker system prune -a
```

## 🐛 Troubleshooting

### Container won't start

```bash
# Check logs
docker-compose logs app

# Check if port is in use
netstat -tulpn | grep :5000

# Restart services
docker-compose down && docker-compose up -d
```

### Database connection issues

```bash
# Check postgres health
docker-compose ps postgres

# Test connection from app
docker-compose exec app npx prisma db pull

# Check environment variables
docker-compose exec app env | grep DATABASE_URL
```

### Out of memory

```bash
# Check memory usage
free -h
docker stats

# Restart containers
docker-compose restart
```

### Disk space issues

```bash
# Check disk usage
df -h

# Clean Docker
docker system prune -a --volumes

# Remove old images
docker image prune -a
```

## 📁 Directory Structure

```
.
├── docker-compose.yml          # Production stack
├── docker-compose.dev.yml      # Development stack
├── Dockerfile                  # App container definition
├── .dockerignore              # Files to exclude from build
├── .env.production            # Production env template
├── deploy.sh                  # Linux deployment script
├── deploy.ps1                 # Windows deployment script
├── backup.sh                  # Database backup script
├── nginx/
│   └── nginx.conf            # Nginx configuration
├── backups/                  # Database backups (created)
├── logs/                     # Application logs
└── DEPLOYMENT.md             # Detailed deployment guide
```

## 🔗 Useful Links

- [Docker Documentation](https://docs.docker.com/)
- [Docker Compose Documentation](https://docs.docker.com/compose/)
- [PostgreSQL Docker Image](https://hub.docker.com/_/postgres)
- [Redis Docker Image](https://hub.docker.com/_/redis)
- [Nginx Docker Image](https://hub.docker.com/_/nginx)

## 💡 Tips

1. **Development**: Use `docker-compose.dev.yml` to run only databases locally
2. **Production**: Use main `docker-compose.yml` for full stack deployment
3. **Logs**: Always check logs when troubleshooting: `docker-compose logs -f`
4. **Backups**: Automate backups with cron jobs
5. **Updates**: Use `git pull && docker-compose up -d --build` to deploy updates
6. **Security**: Never commit `.env` file to git
7. **Monitoring**: Setup monitoring tools like Prometheus/Grafana for production

## 📞 Support

For detailed deployment instructions, see [DEPLOYMENT.md](./DEPLOYMENT.md)

For issues:
- Check logs: `docker-compose logs -f`
- Review health: `docker-compose ps`
- Contact: support@nesa-africa.com
